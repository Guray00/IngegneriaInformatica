<?php

require_once(realpath(dirname(__FILE__)) . '/ProspettoPDFLaureando.php');

/**
 * @access public
 * @author giann
 */
class ProspettoPDFLaureandoSimulazione extends ProspettoPDFLaureando
{
    private $_simulazioneVotoLaureaLaureando;
    private $_laureando;

    public function ProspettoPDFLaureandoSimulazione($simulazioneVoto, $laureando) //simulazione voto è un array, laureando è un oggetto di tipo CarrieraLaureando
    {
        $this-> _simulazioneVotoLaureaLaureando = $simulazioneVoto;
        $this-> _laureando = $laureando;
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Times', '', 12);
/*
     width --> 0 occupa tutta la pagina
     height --> altezza della cella
     txt -> testo della cella
       border 0 no bordo , 1 si bordo , L solo bordo sinistra , RL bordo destra sinistra (B T )
       ln --> se 1 va  acapo , se 0 non va a capo
        align -->  C centro, L sinistra , R dx
        */
        $pdf->Cell(0, 6, $laureando->getCdL(), 0, 1, 'C');
        $pdf->Cell(0, 8, 'CARRIERA E SIMULAZIONE DEL VOTO DI LAUREA', 0, 1, 'C');
        $pdf->SetFont('Times', '', 10);
        $str = "
		Matricola:                           " . $this-> _laureando->getMatricola() . "\n	
		Nome:                                 " . $this-> _laureando->getNome() . "\n
		Cognome:                           " . $this-> _laureando->getCognome() . "\n
		E-MAIL:                             " . $this-> _laureando->getEmail() . "\n
		Data:                                   " . $this-> _laureando->getDataAppello() . "
		";
        $widthEsame = 157;
        $widthEsameInfo = 11;
        $newLine = 1;
        if (get_class($this-> _laureando) == "CarrieraLaureandoInformatica") {
            $str .= " 
		BONUS:                             " . $this-> _laureando->getBonusLaurea() . " 
			";
            $widthEsame = 154;
            $widthEsameInfo = 9;
            $newLine = 0;
        }

        $pdf->MultiCell(0, 2.3, $str, 1, 'L');
//Larghezza di una pagina pdf --> 190
        $pdf->cell(0, 2, "", 0, 1, 'C');
        $pdf->SetFont('Times', '', 8.5);
        $string = file_get_contents("./file_configurazione/esami-informatici.json");
        $esamiInformatici = json_decode($string, true);
        $esami = $this-> _laureando-> getEsami();
        for ($i = 0; $i < sizeof($esami); $i++) {
            if ($i == 0) {
                $pdf->Cell($widthEsame, 6, "ESAME", 1, 0, 'C');
                $pdf->Cell($widthEsameInfo, 6, "CFU", 1, 0, 'C');
                $pdf->Cell($widthEsameInfo, 6, "VOT", 1, 0, 'C');
                $pdf->Cell($widthEsameInfo, 6, "MED", 1, $newLine, 'C');
                if (get_class($this-> _laureando) == "CarrieraLaureandoInformatica") {
                    $pdf->Cell($widthEsameInfo, 6, "INF", 1, 1, 'C');
                }
            }

            $pdf->Cell($widthEsame, 4.5, $esami[$i]["DES"], 1, 0, 'L');
            $pdf->Cell($widthEsameInfo, 4.5, $esami[$i]["PESO"], 1, 0, 'C');
            $pdf->Cell($widthEsameInfo, 4.5, $esami[$i]["VOTO"], 1, 0, 'C');
            $str = "X";
            if ($esami[$i]["MEDIA"] == false) {
            //controllo se fa media
                           $str = "";
            }

            $pdf->Cell($widthEsameInfo, 4.5, $str, 1, $newLine, 'C');
            if (get_class($this-> _laureando) == "CarrieraLaureandoInformatica") {
                $str = "X";
                if (!in_array($esami[$i]["DES"], $esamiInformatici["T. Ing. Informatica"])) {
                    $str = "";
                }

                    $pdf->Cell($widthEsameInfo, 4.5, $str, 1, 1, 'C');
//se esame informatico
            }
        }

        $pdf->cell(0, 4, "", 0, 1, 'C');
        $pdf->SetFont('Times', '', 10);
        if (get_class($this-> _laureando) == "CarrieraLaureandoInformatica") {
            $str = "
		Media Pesata (M):                                                " . $this-> _laureando->getMediaPonderata() . "\n	
		Crediti che fanno media (CFU):                          " . $this-> _laureando->getCFUMedia() . "\n
		Crediti curriculari conseguiti:                              " . $this-> _laureando->getCFULaureando() . "/" . $this-> _laureando->getCFUPerConseguimentoLaurea() . "\n
		Voto di tesi (T):                                                    0 \n
		Formula calcolo voto di laurea:                            " . $this-> _laureando->getFormulaVotoLaurea() . "\n 
	 Media pesata esami INF:                                      " . $this-> _laureando->getMediaEsamiInformatici() . "
		";
        } else {
            $str = "
		Media Pesata (M):                                                " . $this-> _laureando->getMediaPonderata() . "\n	
		Crediti che fanno media (CFU):                          " . $this-> _laureando->getCFUMedia() . "\n
		Crediti curriculari conseguiti:                              " . $this-> _laureando->getCFULaureando() . "/" . $this-> _laureando->getCFUPerConseguimentoLaurea() . "\n
		Formula calcolo voto di laurea:                           " . $this-> _laureando->getFormulaVotoLaurea() . "\n ";
        }

        $pdf->MultiCell(0, 2.7, $str, 1, 'L');
        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(0, 2, "", 0, 1, 'C');


        $pdf->Cell(190, 5.5, "SIMULAZIONE VOTO LAUREA", 1, 1, 'C');
        (sizeof($this-> _simulazioneVotoLaureaLaureando) > 7) ? $width = 47.5 : $width = 95;
        $arr = array_keys($this-> _simulazioneVotoLaureaLaureando[0]);
        if ($width == 95) {
            $pdf->Cell($width, 6, $arr[0], 1, 0, 'C');
            $pdf->Cell($width, 6, $arr[1], 1, 1, 'C');

            for ($i = 0; $i < sizeof($this-> _simulazioneVotoLaureaLaureando); $i++) {
                $pdf->Cell(95, 6, $this-> _simulazioneVotoLaureaLaureando[$i][$arr[0]], 1, 0, 'C');
                $pdf->Cell(95, 6, $this-> _simulazioneVotoLaureaLaureando[$i][$arr[1]], 1, 1, 'C');
            }
        } elseif ($arr[0] == "VOTO COMMISSIONE (C)") {
            $pdf->Cell($width, 6, $arr[0], 1, 0, 'C');
            $pdf->Cell($width, 6, $arr[1], 1, 0, 'C');
            $pdf->Cell($width, 6, $arr[0], 1, 0, 'C');
            $pdf->Cell($width, 6, $arr[1], 1, 1, 'C');

            for ($i = 0; $i < sizeof($this-> _simulazioneVotoLaureaLaureando) - 5; $i++) {
                $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i][$arr[0]], 1, 0, 'C');
                $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i][$arr[1]], 1, 0, 'C');
                if ($this-> _simulazioneVotoLaureaLaureando[$i][$arr[0]] + 6 <= sizeof($this-> _simulazioneVotoLaureaLaureando)) {
                    $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i + 6][$arr[0]], 1, 0, 'C');
                    $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i + 6][$arr[1]], 1, 1, 'C');
                }
            }
        } else {
            $pdf->Cell($width, 6, $arr[0], 1, 0, 'C');
            $pdf->Cell($width, 6, $arr[1], 1, 0, 'C');
            $pdf->Cell($width, 6, $arr[0], 1, 0, 'C');
            $pdf->Cell($width, 6, $arr[1], 1, 1, 'C');

            for ($i = 0; $i < sizeof($this-> _simulazioneVotoLaureaLaureando) - 6; $i++) {
                $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i][$arr[0]], 1, 0, 'C');
                $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i][$arr[1]], 1, 0, 'C');
                if ($this-> _simulazioneVotoLaureaLaureando[$i][$arr[0]] + 7 <= 30) {
                    $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i + 7][$arr[0]], 1, 0, 'C');
                    $pdf->Cell($width, 6, $this-> _simulazioneVotoLaureaLaureando[$i + 7][$arr[1]], 1, 1, 'C');
                }
            }
        }

        $pdf->Cell(0, 10, "", 0, 1, 'C');
        $string = file_get_contents("./file_configurazione/info-CdL.json");
        $corsiJSON = json_decode($string, true);
        $messaggioCommissione = $corsiJSON[$this-> _laureando-> getCdL()]["MessaggioCommissione"];
        $pdf->Cell(190, 4, $messaggioCommissione, 0, 1, 'C');
        $pdf->Output("prospetti/prospetti_commissione/" . $this-> _laureando-> getMatricola() . ".pdf", 'F');
    }
}
