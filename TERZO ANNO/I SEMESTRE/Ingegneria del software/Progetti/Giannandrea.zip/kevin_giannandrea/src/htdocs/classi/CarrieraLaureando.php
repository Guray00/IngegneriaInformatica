<?php

/**
 * @access public
 * @author giann
 */
class CarrieraLaureando
{
    protected $_CdL;
    protected $_nome;
    protected $_cognome;
    protected $_matricola;
    protected $_email;
    protected $_mediaPonderata;
    protected $_esami;
    protected $_formulaVotoLaurea;
    protected $_dataAppello;
    protected $_CFUPerConseguimentoLaurea;
    protected $_CFULaureando;
    protected $_CFUMedia;
    protected $_mediaPonderataAccurata; // è la media senza arrotondamento alla 3 cifra decimale, utilizzata dalla classe CarrieraLaureandoInformatica per calcolare la media con bonus in modo piu' accurato senza perdita di errore

    public function __construct($anagrafica, $carriera, $CdL, $dataAppello)
    {
        $string = file_get_contents("./file_configurazione/info-CdL.json");
        $corsiJSON = json_decode($string, true);
        $initAttributi = $this-> inizializzaAttributi($carriera["Esami"]["Esame"]);
// array che contiene attributi come esame, mediaPesata,CFULaureandoConseguiti,CFUCheFannoMedia

        $this-> _nome = $anagrafica["Entries"]["Entry"]["nome"];
        $this-> _cognome = $anagrafica["Entries"]["Entry"]["cognome"];
        $this-> _email = $anagrafica["Entries"]["Entry"]["email_ate"];
        $this-> _CdL = $CdL;
        $this-> _dataAppello = $dataAppello;
        $this-> _formulaVotoLaurea =  $corsiJSON[$this-> _CdL]["formulaLaurea"];
        $this-> _CFUPerConseguimentoLaurea = $corsiJSON[$this-> _CdL]["CFUCurriculari"];
        $this-> _matricola = $carriera["Esami"]["Esame"][0]["MATRICOLA"];
        $this-> _esami = $initAttributi["esami"];
        $this-> _CFUMedia = $initAttributi["CFUMedia"];
        $this-> _CFULaureando = $initAttributi["CFUConseguiti"];
        $this-> _mediaPonderata = $initAttributi["mediaPonderata"];
        $this-> _mediaPonderataAccurata = $initAttributi["mediaPonderataAccurata"];
    }


    /*public function restituisciCarrieraLaureando() { //debug
     return $this-> _matricola." ".
      $this-> _nome." ".
         $this->_cognome." ".
       $this->_email." ".
         $this->_CdL." ".
       $this->_formulaVotoLaurea." ".
         $this-> _CFUPerConseguimentoLaurea." ".
        var_dump($this-> _esami)." ".
         $this-> _CFUMedia." ".
        $this-> _CFULaureando." ".
         $this-> _mediaPonderata." ".
       $this-> _mediaPonderataAccurata;
    }*/

    private function inizializzaAttributi($esamiLaureando)
    {
        $esami = array();
        $CFUCheFannoMedia = 0;
        $CFUConseguiti = 0;
        $sommatoriaCFUVoto = 0; //utile per il calcolo della media ponderata degli esami

        for ($i = 0; sizeof($esamiLaureando) > $i; $i++) {
            $informazioneEsame = array();
            if ($esamiLaureando[$i]["DES"] == "LIBERA SCELTA PER RICONOSCIMENTI") {
                continue;
            }
            if ($esamiLaureando[$i]["DES"] == "PROVA FINALE") {
                continue;
            }
            if ($esamiLaureando[$i]["DES"] == "TEST DI VALUTAZIONE DI INGEGNERIA") {
                continue;
            }

            $checkMedia = true;
// flag che mi indica se esame è in media
            if ($esamiLaureando[$i]["VOTO"] == "30  e lode" && $this-> _CdL != "M. Cybersecurity") {
                $esamiLaureando[$i]["VOTO"] = "33";
            } elseif ($esamiLaureando[$i]["VOTO"] == "30 e lode" && $this-> _CdL == "M. Cybersecurity") {
                $esamiLaureando[$i]["VOTO"] = "32";
            }

            if ($esamiLaureando[$i]["DES"] == "PROVA DI LINGUA INGLESE (B1)" || $esamiLaureando[$i]["DES"] == "PROVA DI LINGUA INGLESE B2") {
                $esamiLaureando[$i]["VOTO"] = "0";
                $checkMedia = false;
            }

            if ($esamiLaureando[$i]["VOTO"] == null) {
                continue;
            }

            $informazioneEsame["DES"] = $esamiLaureando[$i]["DES"];
            $informazioneEsame["VOTO"] = $esamiLaureando[$i]["VOTO"];
            $informazioneEsame["DATA_ESAME"] = $esamiLaureando[$i]["DATA_ESAME"];
            $informazioneEsame["PESO"] = $esamiLaureando[$i]["PESO"];
            $informazioneEsame["SOVRAN_FLG"] = $esamiLaureando[$i]["SOVRAN_FLG"];
            $informazioneEsame["CORSO"] = $esamiLaureando[$i]["CORSO"];
            $informazioneEsame["MEDIA"] = $checkMedia;
            $esami[] = $informazioneEsame;
            if ($esamiLaureando[$i]["VOTO"] != null && $esamiLaureando[$i]["VOTO"] != "0") {
            //escludo dai cfu che fanno media la prova finale,inglese,test ammissione ingegneria. Considero solo esami che fanno media
                $CFUCheFannoMedia += $esamiLaureando[$i]["PESO"];
                $sommatoriaCFUVoto += intval($esamiLaureando[$i]["VOTO"]) * $esamiLaureando[$i]["PESO"];
            }

            if ($esamiLaureando[$i]["VOTO"] != null) {
                $CFUConseguiti = $CFUConseguiti + $esamiLaureando[$i]["PESO"];
            }
        }


        usort($esami, function ($element1, $element2) { // ordinamento degli esami in array esame in base alla data di conseguimento registrata nella carriera
            $datetime1 = strtotime(str_replace('/', '-', $element1['DATA_ESAME']));
            $datetime2 = strtotime(str_replace('/', '-', $element2['DATA_ESAME']));
            return $datetime1 - $datetime2;
        });
        $mediaPonderata = number_format($sommatoriaCFUVoto / $CFUCheFannoMedia, 3);
        $mediaPonderataAccurata = number_format($sommatoriaCFUVoto / $CFUCheFannoMedia, 10);
        return array("esami" => $esami, "CFUMedia" => $CFUCheFannoMedia, "CFUConseguiti" => $CFUConseguiti, "mediaPonderata" => $mediaPonderata, "mediaPonderataAccurata" => $mediaPonderataAccurata);
    }

    public function getMediaPonderataAccurata()
    {
        return $this-> _mediaPonderataAccurata;
    }

    public function getFormulaVotoLaurea()
    {
        return $this-> _formulaVotoLaurea;
    }

    public function getCdL()
    {
        return $this-> _CdL;
    }

    public function getCFUPerConseguimentoLaurea()
    {
        return $this-> _CFUPerConseguimentoLaurea;
    }

    public function getMatricola()
    {
        return $this-> _matricola;
    }

    public function getNome()
    {
        return $this-> _nome;
    }

    public function getCognome()
    {
        return $this-> _cognome;
    }

    public function getEmail()
    {
        return $this-> _email;
    }

    public function getDataAppello()
    {
        return $this-> _dataAppello;
    }

    public function getMediaPonderata()
    {
        return $this-> _mediaPonderata;
    }

    public function getCFUMedia()
    {
        return $this-> _CFUMedia;
    }

    public function getCFULaureando()
    {
 //quelli conseguiti
        return $this-> _CFULaureando;
    }

    public function getEsami()
    {
        return $this-> _esami;
    }
}
