<?php
    require_once(realpath(dirname(__FILE__)) . '/classi/GUIPaginaLaureandosi.php');

   if(isset($_GET["laureandi"]) && !empty($_GET["laureandi"]) && isset($_GET["crea_prospetti"]) && isset($_GET["CdL"])){
        $string = file_get_contents("./file_configurazione/info-CdL.json");
        $corsiJSON = json_decode($string,true);
        //echo var_dump($_GET["laureandi"]);

        if(isset($corsiJSON[$_GET["CdL"]])){ // controllo se il CdL è presente nel file info-CdL.json, se si procedo con la creazione dei prospetti
            $GUI = new GUIPaginaLaureandosi($_GET["laureandi"], $_GET["CdL"], "2023-01-04");
            $GUI-> creaProspetti();
            $path = $GUI-> ApriProspetti();
        }
   }
      
?>
<!DOCTYPE html>
<html>
	<head>
		<style type = "text/css">
        body {
            margin:auto;
            width: 60%;
        }

        table {
            background-color: #C8E1F1;
            border-width: 1px;
            border-style: solid;
            border-color: #4E55B2;
            width: 100%;
            height: 500px;
        }

        #container{
            margin-top:8%;
        }

        #title {
            font-family: "Calibri"; 
            font-size: 20pt;
            color: #0001CD;
            font-weight: 700;
            text-align: center;
        }

        div.text {
            color: #0001CD;
            font-size: 13pt;
            font-weight: 700;
            text-align:center;
            font-family: 'Times New Roman', Times, serif;
        }

        .altro {
            border-width: 2px;
            border-style: solid;
            border-color: #4E55B2;
        }

        .date{
            width: 70%;
            height: 30%;
            background-color: #B0E0E6;
            font-family: 'Times New Roman', Times, serif;
            font-size: 13pt;
        }

        .textarea{
            height: 80%;
        }

        .menu{
            width: 70%;
            font-family:'Times New Roman', Times, serif;
            font-size: 13pt;
        }

        button {
            border:#0073AA;
            background-color: #0073AA;
            color: #FFFFFF;
            font-size: 15pt;
            font-family: "Calibri";
            border-radius: 6px;
            height: 35%;
            width: 60%;
        }
		</style>
	</head>

	<body>
		<div id = "container">
			<form action = "index.php" method = "get">
				<table>
					<tr>
						<th colspan = 3 height = "10%">
							<div id = "title">Laureandosi 2 - Gestione Lauree</div>
						</th>
					</tr>
					<tr>
						<th height = "30%" width = "30%">
							<label for = "Cdl">
								<div class = "text">Cdl:</div>
							</label>
							<select name = "CdL" class = "altro menu">
								<option>Seleziona Cdl</option>
								<option name = "CdL">T. Ing. Informatica</option>
								<option name = "CdL">M. Ing. Elettronica</option>
								<option name = "CdL">M. Ing. delle Telecomunicazioni</option>
                                <option name = "CdL">M. Cybersecurity</option>
							</select>
						</th>
						<th rowspan = 3 valign = "middle" width = "40%">
							<div class = "text">Matricole:</div>
							<textarea class = "altro textarea" name = "laureandi"></textarea>
						</th>
						<th>
                            <button type = "submit" value = "Crea Prospetti" name = "crea_prospetti">Crea Prospetti</button>
						</th>
					</tr>
					<tr>
						<th height = "30%">
							<div class = "text">Data Laurea:</div>
							<input type = "date" class = "altro date" name = "data"/>
						</th>
						<th>
							<a href = <?php if(isset($path)) echo $path; ?> style = "font-size: 13pt"> apri prospetti</a>
						</th>
					</tr>
					<tr>
						<th></th>
						<th>
							<button type = "submit" value = "Invia Prospetti" name = "invia_prospetti">Invia Prospetti</button>
						</th>
					</tr>
				</table>
			</form>
		</div>
	</body>
</html>