<?php
/**
 * @access public
 * @author giann
 */
class ProspettoPDFCommissione {
	private $pathPDFLaureandoSimulazione;

	public function __construnct($pathPDFLaureandoConSimulazione) {
	}

}
?>