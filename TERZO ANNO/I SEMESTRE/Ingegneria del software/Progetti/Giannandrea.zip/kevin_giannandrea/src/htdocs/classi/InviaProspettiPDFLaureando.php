<?php
require_once(realpath(dirname(__FILE__)) . '/CarrieraLaureando.php');

/**
 * @access public
 * @author giann
 */
class InviaProspettiPDFLaureando {

	/**
	 * @access public
	 * @param CarrieraLaureando[] aLaureandi
	 * @ParamType aLaureandi CarrieraLaureando[]
	 */
	public function inviaProspetti(array $aLaureandi) {
		// Not yet implemented
	}
}
?>