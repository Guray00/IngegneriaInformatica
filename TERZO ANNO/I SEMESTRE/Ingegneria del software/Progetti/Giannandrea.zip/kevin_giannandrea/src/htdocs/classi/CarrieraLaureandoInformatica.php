<?php

require_once(realpath(dirname(__FILE__)) . '/CarrieraLaureando.php');
/**
 * @access public
 * @author giann
 */
class CarrieraLaureandoInformatica extends CarrieraLaureando
{
    private $_annoImmatricolazione;
    private $_annoChiusuraCarriera;
    private $_mediaEsamiInformatici;
    private $_bonusLaurea;
    private $_esameNonMedia;

    public function __construct($anagrafica, $carriera, $CdL, $dataAppello, $annoImmatricolazione, $annoChiusuraCarriera)
    {
        parent::__construct($anagrafica, $carriera, $CdL, $dataAppello);

        $this-> _annoImmatricolazione = $annoImmatricolazione;
        $this-> _annoChiusuraCarriera = $annoChiusuraCarriera; // vedi nota sotto
        $this-> _mediaEsamiInformatici = $this-> calcolaMediaEsamiInformatici();
        $this-> verificaBonusLaurea(); // controlla se il laureando ha diritto al bonus, se si aggiorna bonusLaurea, mediaPonderata ed esameNonMedia
    }

    /*public function restituisciCarrieraLaureando(){ //debug
        return $this-> _matricola." ".
         $this-> _nome." ".
         $this-> _cognome." ".
         $this-> _email." ".
         $this-> _CdL." ".
         $this-> _formulaVotoLaurea." ".
         $this-> _CFUPerConseguimentoLaurea." ".
         var_dump($this-> _esami)." ".
         $this-> _CFUMedia." ".
         $this-> _CFULaureando." ".
         $this-> _mediaPonderata." ".
         $this-> _annoImmatricolazione." ".
         $this-> _mediaEsamiInformatici." ".
         $this-> _bonusLaurea." ".
         $this-> _esameNonMedia." ".
         $this-> _mediaPonderataAccurata;
    }*/

    private function calcolaMediaEsamiInformatici()
    {

        $string = file_get_contents("./file_configurazione/esami-informatici.json");
        $esamiInformatici = json_decode($string, true);
        $sommatoriaCFUVoto = 0;
        $CFUCheFannoMedia = 0;

        for ($i = 0; sizeof($this-> _esami) > $i; $i++) {
            if (in_array($this-> _esami[$i]["DES"], $esamiInformatici["T. Ing. Informatica"])) {
                $CFUCheFannoMedia += $this-> _esami[$i]["PESO"];
                $sommatoriaCFUVoto += intval($this-> _esami[$i]["VOTO"]) * $this-> _esami[$i]["PESO"];
            }
        }

        $mediaPonderataInformatici = number_format($sommatoriaCFUVoto / $CFUCheFannoMedia, 3);
        return $mediaPonderataInformatici;
    }

    private function verificaBonusLaurea()
    {

        if ($this-> _annoChiusuraCarriera - $this-> _annoImmatricolazione < 3) { //andrebbe usato la data dell'appello di laurea
            $this-> _bonusLaurea = "SI";                                       //al posto di $this-> _annoChiusuraCarriera
            $this-> aggiornaMediaBonus();                                      //ma essendo fittizio (la data dell'appello di laurea),
                                                                               //alcuni studenti non riceverebbero il bonus
        } else {                                                                 //(mentre ne avrebbero diritto), ex. guarda studente 345678
            $this-> _bonusLaurea = "NO";
        }
    }

    private function aggiornaMediaBonus()
    {

        $minVoto = $this-> _esami[0]["VOTO"];
        $CFUMinVoto = $this-> _esami[0]["PESO"];
        $nomeEsame = $this-> _esami[0]["DES"];

        for ($i = 0; sizeof($this-> _esami) > $i; $i++) {
            if ($this-> _esami[$i]["VOTO"] == 0) {
                continue;
            }

            if ($minVoto > $this-> _esami[$i]["VOTO"]) {
                $nomeEsame = $this-> _esami[$i]["DES"];
                $minVoto = $this-> _esami[$i]["VOTO"];
                $CFUMinVoto = $this-> _esami[$i]["PESO"];
            } elseif ($minVoto == $this-> _esami[$i]["VOTO"] && $CFUMinVoto < $this-> _esami[$i]["PESO"]) {
                $CFUMinVoto = $this-> _esami[$i]["PESO"];
                $nomeEsame = $this-> _esami[$i]["DES"];
            }
        }


        $found_key = array_search($nomeEsame, array_column($this-> _esami, "DES"));
        $this-> _esami[$found_key]["MEDIA"] = false; //aggiorno l'esame che non è piu' in media
        $valore = $CFUMinVoto * intval($minVoto);
        $CFUMediaNuovoValore = $this-> _CFUMedia - $CFUMinVoto;
        $mediaPonderataNuova = round((($this-> _mediaPonderataAccurata * $this-> _CFUMedia) - $valore) / $CFUMediaNuovoValore, 10);
        $this-> _mediaPonderata = round($mediaPonderataNuova, 3); //aggiorno la media ponderata togliendo l'esame con voto minore e, a parità di cfu scelgo quello con piu' crediti
        $this-> _CFUMedia = $CFUMediaNuovoValore; //aggiorno i cfu in media togliendo l'esame non in media
        $this-> _mediaPonderataAccurata = $mediaPonderataNuova;
        $this-> _esameNonMedia = $nomeEsame; //riporto l'esame che è stato escluso dalla media
    }

    public function getBonusLaurea()
    {
        return $this-> _bonusLaurea;
    }

    public function getMediaEsamiInformatici()
    {
        return $this-> _mediaEsamiInformatici;
    }
}
