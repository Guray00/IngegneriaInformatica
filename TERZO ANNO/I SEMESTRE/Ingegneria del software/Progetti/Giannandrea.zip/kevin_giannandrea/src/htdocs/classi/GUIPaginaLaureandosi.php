<?php

require_once(realpath(dirname(__FILE__)) . '/CarrieraLaureando.php');
require_once(realpath(dirname(__FILE__)) . '/CarrieraLaureandoInformatica.php');
require_once(realpath(dirname(__FILE__)) . '/SimulazioneVotoLaureando.php');
require_once(realpath(dirname(__FILE__)) . '/ProspettoPDFLaureandoSimulazione.php');
require_once(realpath(dirname(__FILE__)) . '/GestioneCarrieraStudente.php');
require_once(realpath(dirname(__FILE__)) . '/InviaProspettiPDFLaureando.php');

/**
 * @access public
 * @author giann
 */
class GUIPaginaLaureandosi
{
    private $_matricole;
    private $_CdL;
    private $_dataAppello;


    public function GUIPaginaLaureandosi($aMatricole, $aCdL, $aDataAppello)
    {
        $this-> _matricole = explode(PHP_EOL, $aMatricole);
        $this-> _CdL = $aCdL;
        $this-> _dataAppello = $aDataAppello;
    }

    public function CreaProspetti()
    {

        $gestoreCarriere = new GestioneCarrieraStudente('./');
        for ($i = 0; $i < sizeof($this-> _matricole); $i++) {
            $anagrafica = $gestoreCarriere-> restituisciAnagraficaStudente($this-> _matricole[$i]);
            $carriera = $gestoreCarriere-> restituisciCarrieraStudente($this-> _matricole[$i]);
            if ($this->_CdL == "T. Ing. Informatica") {
                $Laureando = new CarrieraLaureandoInformatica($anagrafica, $carriera, $this->_CdL, $this->_dataAppello, $carriera["Esami"]["Esame"][0]["ANNO_IMM"], $carriera["Esami"]["Esame"][0]["AA_CHIUSURA"]);
            } else {
                $Laureando = new CarrieraLaureando($anagrafica, $carriera, $this->_CdL, $this->_dataAppello);
            }

            $SimulazioneLaurea = new SimulazioneVotoLaureando($Laureando);
            $prospettoLaureandoSimulazione = new ProspettoPDFLaureandoSimulazione($SimulazioneLaurea->getSimulazioneVotoLaurea(), $Laureando);
        }

        echo "Prospetti Generati";
    }

    public function ApriProspetti()
    {
        return "/prospetti/prospetti_commissione";
    }

    public function InviaProspetti()
    {
    }
}
