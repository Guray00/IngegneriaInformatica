<?php

require "./classi/CarrieraLaureando.php";
require "./classi/CarrieraLaureandoInformatica.php";
require "./classi/GestioneCarrieraStudente.php";

class DatiLaureandoTest extends \PHPUnit\Framework\TestCase
{
    protected $gestoreCarriere;
    protected $datiOracoloLaureando;
    protected $corsiDiLaurea;

    protected function setUp(): void
    {
        $this-> gestoreCarriere = new GestioneCarrieraStudente('./');
        $string = file_get_contents("./oracolo/dati_test.json");
        $json_string = json_decode($string, true);
        $this-> datiOracoloLaureando = $json_string;
        $string = file_get_contents("./file_configurazione/info-CdL.json");
        $corsiJSON = json_decode($string, true);
        $this-> corsiDiLaurea = $corsiJSON;
    }

    /** @test */
    public function controlloDatiCarrieraLaureando()
    {

        for ($i = 0; $i < sizeof($this-> datiOracoloLaureando); $i++) {
            $matricola = $this-> datiOracoloLaureando["laureando" . $i]["matricola"];
            $CdL = $this-> datiOracoloLaureando["laureando" . $i]["cdl"];
            if (!isset($this-> corsiDiLaurea[$CdL])) { // se il CdL non è presente nel file "info-CdL.json", l'automation test deve fallire. Guardasi caso in cui CdL è uguale a "M. Cybersecurity"
                $this-> assertNotNull(null, "Corso di laurea " . $CdL . " non presente nel file corsi!");
            }

            $anagrafica = $this-> gestoreCarriere-> restituisciAnagraficaStudente($matricola);
            $carriera =  $this-> gestoreCarriere-> restituisciCarrieraStudente($matricola);

            if ($CdL == "T. Ing. Informatica") {
                $annoImmatricolazione = $this-> datiOracoloLaureando["laureando" . $i]["anno_immatricolazione"];
                $annoChiusura = $this-> datiOracoloLaureando["laureando" . $i]["anno_chiusura"];
                $Laureando = new CarrieraLaureandoInformatica($anagrafica, $carriera, $CdL, "2023-01-04", $annoImmatricolazione, $annoChiusura);
            } else {
                $Laureando = new CarrieraLaureando($anagrafica, $carriera, $CdL, "2023-01-04");
            }

            $nome =  $this-> datiOracoloLaureando["laureando" . $i]["nome"];
            $cognome = $this-> datiOracoloLaureando["laureando" . $i]["cognome"];
            $mediaPesata = $this-> datiOracoloLaureando["laureando" . $i]["media_pesata"];
            $creditiInMedia = $this-> datiOracoloLaureando["laureando" . $i]["crediti_media"];
            $creditiCurriculariConseguiti = $this-> datiOracoloLaureando["laureando" . $i]["crediti_curriculari_conseguiti"];

            $this-> assertSame($nome, $Laureando->getNome());
            $this-> assertSame($cognome, $Laureando->getCognome());
            $this-> assertEquals($mediaPesata, $Laureando->getMediaPonderata());
            $this-> assertSame($creditiInMedia, $Laureando->getCFUMedia());
            $this-> assertSame($creditiCurriculariConseguiti, $Laureando->getCFULaureando());

            if ($CdL == "T. Ing. Informatica") { // se il laureando è ing. informatica, controllo altri attributi
                $bonus = $this-> datiOracoloLaureando["laureando" . $i]["bonus"];
                $mediaPesataInf = $this-> datiOracoloLaureando["laureando" . $i]["media_pesata_inf"];
                $this-> assertSame($bonus, $Laureando->getBonusLaurea());
                $this-> assertEquals($mediaPesataInf, $Laureando->getMediaEsamiInformatici());
            }
        }
    }
}
