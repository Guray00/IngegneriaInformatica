<?php
require_once(realpath(dirname(__FILE__)) . '/CarrieraLaureando.php');
require "../../lib/fpdf184/fpdf.php";

/**
 * @access public
 * @author giann
 */
class ProspettoPDFLaureando {
	
	private $_laureando;

	public function ProspettoPDFLaureando($laureando) {
		/*$this-> _laureando = $laureando;

		$pdf = new FPDF();
		$pdf->AddPage();
		$pdf->SetFont('Times', '' , 12);
		/*
		width --> 0 occupa tutta la pagina
		height --> altezza della cella
		txt -> testo della cella
		border 0 no bordo , 1 si bordo , L solo bordo sinistra , RL bordo destra sinistra (B T )
		ln --> se 1 va  acapo , se 0 non va a capo
        align -->  C centro, L sinistra , R dx
		*/
		/*$pdf->Cell(0, 6 ,$laureando->getCdL(), 0 ,1, 'C');
		$pdf->Cell(0, 8 , 'CARRIERA E SIMULAZIONE DEL VOTO DI LAUREA', 0 , 1,'C');
		$pdf->SetFont('Times', '' , 10);

		$str = "
		Matricola:                           ".$this-> _laureando->getMatricola()."\n	
		Nome:                                 ".$this-> _laureando->getNome()."\n
		Cognome:                           ".$this-> _laureando->getCognome()."\n
		E-MAIL:                             ".$this-> _laureando->getEmail()."\n
		Data:                                   ".$this-> _laureando->getDataAppello()."
		";

		$widthEsame = 157;
		$widthEsameInfo = 11;
		$newLine = 1;
		if(get_class($this-> _laureando) == "CarrieraLaureandoInformatica"){
			$str .= " 
			BONUS:                             ".$this-> _laureando->getBonusLaurea()." 
			";	
		   $widthEsame = 154;
		   $widthEsameInfo = 9;
		   $newLine = 0;
		}

		$pdf->MultiCell(0 , 2.3,$str, 1, 'L');
        //Larghezza di una pagina pdf --> 190
        $pdf->cell(0 , 2,"",0,1,'C');
		$pdf->SetFont('Times', '' , 8.5);
		$string = file_get_contents("./file_configurazione/esami-informatici.json");
		$esamiInformatici= json_decode($string,true);
		$esami = $this-> _laureando-> getEsami();
		for($i = 0; $i < sizeof($esami); $i++){
			if($i == 0){
				$pdf->Cell($widthEsame, 6 , "ESAME", 1 , 0, 'C');
				$pdf->Cell($widthEsameInfo, 6 , "CFU", 1 , 0, 'C');
				$pdf->Cell($widthEsameInfo, 6, "VOT", 1 , 0, 'C');
				$pdf->Cell($widthEsameInfo, 6 , "MED", 1 , $newLine, 'C');
				if(get_class($this-> _laureando) == "CarrieraLaureandoInformatica")
					$pdf->Cell($widthEsameInfo, 6 , "INF", 1 , 1, 'C');
			}
			$pdf->Cell($widthEsame, 4.5 , $esami[$i]["DES"], 1 , 0, 'L');
			$pdf->Cell($widthEsameInfo, 4.5 , $esami[$i]["PESO"], 1 , 0, 'C');
			$pdf->Cell($widthEsameInfo, 4.5 , $esami[$i]["VOTO"], 1 , 0, 'C');
			$str = "X";
			if($esami[$i]["MEDIA"] == false) //controllo se fa media
			   $str = "";

		    $pdf->Cell($widthEsameInfo, 4.5 , $str , 1 , $newLine , 'C'); 	
			if(get_class($this-> _laureando) == "CarrieraLaureandoInformatica"){
				$str = "X";

				if(!in_array($esami[$i]["DES"], $esamiInformatici["T. Ing. Informatica"]))
					$str = "";

				    $pdf->Cell($widthEsameInfo, 4.5 , $str , 1 , 1, 'C'); //se esame informatico
			}			
		}

		$pdf->cell(0 , 4 ,"",0,1,'C');
		$pdf->SetFont('Times', '' , 10);
		if(get_class($this-> _laureando) == "CarrieraLaureandoInformatica"){
		    $str = "
		Media Pesata (M):                                                ".$this-> _laureando->getMediaPonderata()."\n	
		Crediti che fanno media (CFU):                          ".$this-> _laureando->getCFUMedia()."\n
		Crediti curriculari conseguiti:                              ".$this-> _laureando->getCFULaureando()."/".$this-> _laureando->getCFUPerConseguimentoLaurea()."\n
		Voto di tesi (T):                                                    0 \n
		Formula calcolo voto di laurea:                            ".$this-> _laureando->getFormulaVotoLaurea()."\n 
	Media pesata esami INF:                                      ".$this-> _laureando->getMediaEsamiInformatici()."
		";
		}else{
			$str = "
		Media Pesata (M):                                                ".$this-> _laureando->getMediaPonderata()."\n	
		Crediti che fanno media (CFU):                          ".$this-> _laureando->getCFUMedia()."\n
		Crediti curriculari conseguiti:                              ".$this-> _laureando->getCFULaureando()."/".$this-> _laureando->getCFUPerConseguimentoLaurea()."\n
		Formula calcolo voto di laurea:                            ".$this-> _laureando->getFormulaVotoLaurea()."\n ";
		}

		$pdf->MultiCell(0 , 2.7 ,$str, 1, 'L');
		$pdf->SetFont('Times', '' , 10);
		$pdf->Cell(0 , 2,"",0,1,'C');

		$pdf->Output("prospetti/prospetti_laureando/".$this-> _laureando-> getMatricola().".pdf", 'F');*/
	}
}
?>