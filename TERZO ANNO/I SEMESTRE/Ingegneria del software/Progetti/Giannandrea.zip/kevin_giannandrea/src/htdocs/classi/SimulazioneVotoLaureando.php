<?php

require_once(realpath(dirname(__FILE__)) . '/CarrieraLaureando.php');

/**
 * @access public
 * @author giann
 */
class SimulazioneVotoLaureando
{
    private $_formulaVotoLaurea;
    private $_votoDiPartenza;
    private $_simulazioneVotoLaurea; //array per creare la tabella laureando


    public function SimulazioneVotoLaureando($laureando, $votoDiPartenza = 0, $simulazioneVotoLaurea = 0)
    {
        $string = file_get_contents("./file_configurazione/info-CdL.json");
        $corsiJSON = json_decode($string, true);

        $this-> _formulaVotoLaurea = $corsiJSON[$laureando-> getCdL()]["formulaLaureaCalcolo"];
        $this-> _votoDiPartenza = $this-> calcoloVotoPartenza($laureando-> getMediaPonderataAccurata(), $laureando-> getCFUPerConseguimentoLaurea());
        $this-> _simulazioneVotoLaurea = $this-> calcolaSimulazioneVotoLaurea($laureando-> getCdL(), $corsiJSON, $laureando-> getMediaPonderataAccurata(), $laureando-> getCFUPerConseguimentoLaurea());
    }

    /*public function restituisciSimulazioneVotoLaurea() { //debug
        return print_r($this-> _simulazioneVotoLaurea)." ". $this-> _votoDiPartenza;
    }*/

    private function calcolaSimulazioneVotoLaurea($CdL, $corsiJSON, $M, $CFU)
    {

        $simulazioneLaurea = array();
        if ($corsiJSON[$CdL]["Cmin"] != 0) {
            $Cmax = $corsiJSON[$CdL]["Cmax"];
            $Cmin = $corsiJSON[$CdL]["Cmin"];
            $Cstep = $corsiJSON[$CdL]["Cstep"];

            for ($i = $Cmin; $i <= $Cmax; $i += $Cstep) {
                $simulazioneVoto = array();
                $simulazioneVoto["VOTO COMMISSIONE (C)"] = $i;
                $simulazioneVoto["VOTO LAUREA"] = $this-> _votoDiPartenza + $i;
                $simulazioneLaurea[] = $simulazioneVoto;
            }
        } else {
            $Tmax = $corsiJSON[$CdL]["Tmax"];
            $Tmin = $corsiJSON[$CdL]["Tmin"];
            $Tstep = $corsiJSON[$CdL]["Tstep"];

            for ($i = $Tmin; $i <= $Tmax; $i += $Tstep) {
                $simulazioneVoto = array();
                $simulazioneVoto["VOTO TESI (T)"] = $i;
                $simulazioneVoto["VOTO LAUREA"] = $this-> calcoloVotoPartenza($M, $CFU, $i);
                $simulazioneLaurea[] = $simulazioneVoto;
            }
        }

        return $simulazioneLaurea;
    }

    private function calcoloVotoPartenza($M, $CFU, $T = 0)
    {
        $C = 0;
        $arr = explode(" ", $this-> _formulaVotoLaurea);
        $voa = "\$votoPartenza = " . $this-> _formulaVotoLaurea . ";";
        eval($voa);
        return round($votoPartenza, 3);
    }


    public function getSimulazioneVotoLaurea()
    {
        return $this-> _simulazioneVotoLaurea;
    }
}
