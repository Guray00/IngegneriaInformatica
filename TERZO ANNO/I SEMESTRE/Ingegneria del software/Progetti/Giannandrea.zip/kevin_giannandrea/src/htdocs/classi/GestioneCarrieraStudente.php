<?php

class GestioneCarrieraStudente
{
    // Properties
    private $data_path;

    public function __construct($data_path)
    {
        $this->data_path = $data_path;
    }

    // Methods
    public function restituisciAnagraficaStudente($matricola)
    {
        $string = file_get_contents($this->data_path . "data/" . $matricola . "_anagrafica.json");
        $json_string = json_decode($string, true);
        return $json_string;
        #echo var_dump($json_string['Entries']['Entry']);
    }

    public function restituisciCarrieraStudente($matricola)
    {
        $string = file_get_contents($this->data_path . "data/" . $matricola . "_esami.json");
        $json_string = json_decode($string, true);
        return $json_string;
    }
}


//$gestoreCarriere = new GestioneCarrieraStudente('./');
//$gestoreCarriere->restituisciAnagraficaStudente(123456);
