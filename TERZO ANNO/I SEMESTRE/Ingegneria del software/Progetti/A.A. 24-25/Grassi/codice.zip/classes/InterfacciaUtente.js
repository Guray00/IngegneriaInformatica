class InterfacciaUtente
{
    constructor()
    {
        this.baseUrl = "ajaxReceiver.php"
        this.feedbackElement = document.getElementById("message");
    }
    feedbackGlow(className)
    {
        this.feedbackElement.classList.add(className);
        setTimeout(() => { this.feedbackElement.classList.remove(className); }, 1500);
    }
    sendPostRequest(formData, callback)
    {
        let xhttp = new XMLHttpRequest();
        xhttp.open("POST", this.baseUrl, true);
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState === 4)
                callback(xhttp);
        };
        xhttp.send(formData);
    }
    callGeneraProspetti()
    {
        let matricole = document.getElementById("matricole").value.replaceAll(",", " ").split(/\s+/).filter(Boolean);
        if(matricole.length === 0 || document.getElementById("cdl").value === "")
            return;

        let formData = new FormData();
        formData.append("functionToCall", "generaProspettiLaurea");
        formData.append("CdL", document.getElementById("cdl").value);
        formData.append("dataLaurea", document.getElementById("data-laurea").value);
        formData.append("matricole", matricole);

        this.sendPostRequest(formData, (xhttp) => {
            if (xhttp.status === 200 && xhttp.responseText === "ok")
            {
                this.feedbackElement.innerHTML = "Prospetti generati";
                this.feedbackGlow("justUpdated");
            }
            else
            {
                this.feedbackElement.innerHTML = "Errore non identificato";
                console.error(xhttp.readyState, xhttp.status, xhttp.responseText);
                this.feedbackGlow("justUpdatedErr");
            }
        });
    }
    visualizzaProspetti()
    {
        let cdl = document.getElementById("cdl").value;
        if(cdl)
            window.open("/data/" + cdl + "/commissione_prospetto.pdf");
    }
    callInviaProspetto(matricole, i, tot)
    {
        if(i > tot)
            return;
        let matricola = matricole[i - 1];
        let formData = new FormData();
        formData.append("functionToCall", "inviaProspettoLaurea");
        formData.append("CdL", document.getElementById("cdl").value);
        formData.append("matricola", matricola);
        this.sendPostRequest(formData, (xhttp) => {
            if (xhttp.status === 200 && xhttp.responseText === "ok")
            {
                this.feedbackElement.innerHTML = `Prospetto ${i}/${tot} inviato`;
                this.feedbackGlow("justUpdated");
                setTimeout(() => this.callInviaProspetto(matricole, i + 1, tot), 3000);
            }
            else if (xhttp.status === 200 && xhttp.responseText === "err")
            {
                this.feedbackElement.innerHTML = "Errore durante l'invio dell'email";
                this.feedbackGlow("justUpdatedErr");
            }
            else
            {
                this.feedbackElement.innerHTML = "Errore non identificato";
                console.error(xhttp.readyState, xhttp.status, xhttp.responseText);
                this.feedbackGlow("justUpdatedErr");
            }
        });
    }
    inviaProspetti()
    {
        let matricole = document.getElementById("matricole").value.replaceAll(",", " ").split(/\s+/).filter(Boolean);
        let tot = matricole.length;
        if(tot > 0)
            this.callInviaProspetto(matricole, 1, tot);
    }
}