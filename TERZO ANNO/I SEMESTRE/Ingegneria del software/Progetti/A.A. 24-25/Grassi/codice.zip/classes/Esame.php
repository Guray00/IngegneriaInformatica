<?php
class Esame
{
    public $nome;
    public $cfu;
    public $voto;
    public $faMedia;
    public $dataEsame;
    public function __construct($rawData, $CdL, $matricola)
    {
        global $configurazione;
        $this->nome = $rawData["DES"];
        $this->cfu = $rawData["PESO"];
        $voto = $rawData["VOTO"];
        $this->dataEsame = strtotime(str_replace("/", "-", $rawData["DATA_ESAME"]));
        if($voto == null)
            $voto = 0;
        else if($voto == "30  e lode")
            $voto = $configurazione->getValoreLode($CdL);
        $this->voto = (int)$voto;
        $this->faMedia = true;
        if ($this->voto == 0 || in_array($this->nome, $configurazione->getEsamiNonMedia($CdL, $matricola)))
            $this->faMedia = false;
    }
    public function isInformatico()
    {
        global $configurazione;
        return in_array($this->nome, $configurazione->getEsamiInformatici());
    }
}