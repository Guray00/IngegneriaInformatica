<?php
class LaureandoInformatica extends Laureando
{
    private $bonus;
    public function __construct($matricola, $CdL, $dataLaurea)
    {
        parent::__construct($matricola, $CdL);
        $dataLaurea = strtotime($dataLaurea);
        if($dataLaurea - 3.6 * 365 * 86400 < $this->dataIscrizione)
            $this->bonus = true;
        else
            $this->bonus = false;
        if($this->bonus)
        {
            $esameMin = $this->esameMinimo();
            $this->togliVotoPiuBasso($esameMin);
        }
    }
    public function bonus()
    {
        return $this->bonus;
    }
    private function esameMinimo()
    {
        $minVoto = null;
        $maxCfu = null;
        $nome = null;
        foreach ($this->esami as $esame)
        {
            if(!$esame->faMedia)
                continue;
            if($minVoto == null || $esame->voto < $minVoto || ($esame->voto == $minVoto && $esame->cfu > $maxCfu))
            {
                $minVoto = $esame->voto;
                $maxCfu = $esame->cfu;
                $nome = $esame->nome;
            }
        }
        return $nome;
    }
    private function togliVotoPiuBasso($esameMin)
    {
        foreach ($this->esami as $esame)
        {
            if($esame->nome == $esameMin)
            {
                $esame->faMedia = false;
                break;
            }
        }
    }
    public function calcolaMediaEsamiInformatici()
    {
        $tot = 0;
        $cfu = 0;
        foreach ($this->esami as $esame)
        {
            if(!$esame->faMedia || !$esame->isInformatico())
                continue;
            $tot += $esame->voto * $esame->cfu;
            $cfu += $esame->cfu;
        }
        if($cfu == 0)
            return 0;
        return $tot/$cfu;
    }
}