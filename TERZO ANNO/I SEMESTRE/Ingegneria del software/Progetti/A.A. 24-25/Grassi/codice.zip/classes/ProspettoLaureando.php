<?php
class ProspettoLaureando
{
    public Laureando $laureando;
    private $corsoDiLaurea;
    private $dataLaurea;
    public function __construct($laureando, $corsoDiLaurea, $dataLaurea)
    {
        $this->laureando = $laureando;
        $this->corsoDiLaurea = $corsoDiLaurea;
        $this->dataLaurea = $dataLaurea;
    }
    public function costruisciPdf($pdf)
    {
        global $configurazione;
        $info = false;
        if($this->corsoDiLaurea == "T. Ing. Informatica")
            $info = true;
        $pdf->SetMargins(11, 8);
        $pdf->AddPage();
        $font = "Arial";
        
        $pdf->SetFont($font, "", 13);
        $pdf->Cell(0, 6, $this->corsoDiLaurea, 0, 1, "C");
        $pdf->Cell(0, 6, "CARRIERA E SIMULAZIONE DEL VOTO DI LAUREA", 0, 1, "C");
        $pdf->Ln(3);
        
        $pdf->SetFontSize(9);
        $pdf->Rect($pdf->GetX(), $pdf->GetY(), $pdf->GetPageWidth() - 22, $info ? 33 : 27.5);
        $pdf->Cell(45, 5.5, "Matricola:", 0, 0);
        $pdf->Cell(0, 5.5, $this->laureando->matricola, 0, 1);
        $pdf->Cell(45, 5.5, "Nome:", 0, 0);
        $pdf->Cell(0, 5.5, $this->laureando->nome, 0, 1);
        $pdf->Cell(45, 5.5, "Cognome:", 0, 0);
        $pdf->Cell(0, 5.5, $this->laureando->cognome, 0, 1);
        $pdf->Cell(45, 5.5, "Email:", 0, 0);
        $pdf->Cell(0, 5.5, $this->laureando->email, 0, 1);
        $pdf->Cell(45, 5.5, "Data:", 0, 0);
        $pdf->Cell(0, 5.5, $this->dataLaurea, 0, 1);
        if ($info)
        {
            $pdf->Cell(45, 5.5, "Bonus:", 0, 0);
            $pdf->Cell(0, 5.5, $this->laureando->bonus() ? "SI" : "NO", 0, 1);
        }
        $pdf->Ln(3);
        
        $pdf->Cell($pdf->GetPageWidth() - 22 - ($info ? 44 : 33), 5.5, "ESAME", 1, 0, "C");
        $pdf->Cell(11, 5.5, "CFU", 1, 0, "C");
        $pdf->Cell(11, 5.5, "VOT", 1, 0, "C");
        $pdf->Cell(11, 5.5, "MED", 1, 0, "C");
        if ($info)
            $pdf->Cell(11, 5.5, "INF", 1, 0, "C");
        $pdf->Ln();
        
        $pdf->SetFontSize(8);
        
        foreach ($this->laureando->esami as $esame)
        {
            $pdf->Cell($pdf->GetPageWidth() - 22 - ($info ? 44 : 33), 4.5, $esame->nome, 1, 0);
            $pdf->Cell(11, 4.5, $esame->cfu, 1, 0, "C");
            $pdf->Cell(11, 4.5, $esame->voto, 1, 0, "C");
            $pdf->Cell(11, 4.5, $esame->faMedia ? "X" : "", 1, 0, "C");
            if ($info)
                $pdf->Cell(11, 4.5, $esame->isInformatico() ? "X" : "", 1, 0, "C");
            $pdf->Ln();
        }
        $pdf->Ln(3);
        
        $pdf->SetFontSize(9);
        $pdf->Rect($pdf->GetX(), $pdf->GetY(), $pdf->GetPageWidth() - 22, $info ? 33 : 22);
        $pdf->Cell(80, 5.5, "Media Pesata (M):", 0, 0);
        $pdf->Cell(0, 5.5, round($this->laureando->calcolaMedia(), 3), 0, 1);
        $pdf->Cell(80, 5.5, "Crediti che fanno media (CFU):", 0, 0);
        $pdf->Cell(0, 5.5, $this->laureando->calcolaCfuMedia(), 0, 1);
        $pdf->Cell(80, 5.5, "Crediti curriculari conseguiti:", 0, 0);
        $pdf->Cell(0, 5.5, $this->laureando->calcolaCfuCurricolari()."/".$configurazione->getCfuCurricolari($this->corsoDiLaurea), 0, 1);
        if ($info)
        {
            $pdf->Cell(80, 5.5, "Voto di tesi (T):", 0, 0);
            $pdf->Cell(0, 5.5, 0, 0, 1);
        }
        $pdf->Cell(80, 5.5, "Formula calcolo voto di laurea:", 0, 0);
        $pdf->Cell(0, 5.5, $configurazione->getFormulaVoto($this->corsoDiLaurea), 0, 1);
        if ($info)
        {
            $pdf->Cell(80, 5.5, "Media pesata esami INF:", 0, 0);
            $pdf->Cell(0, 5.5, round($this->laureando->calcolaMediaEsamiInformatici(), 3), 0, 1);
        }
    }
    public function aggiungiTabella($pdf)
    {
        global $configurazione;
        $pdf->Ln(3);
        $pdf->SetFontSize(9);
        $pdf->Cell(($pdf->GetPageWidth() - 22), 5.5, "SIMULAZIONE DI VOTO DI LAUREA", 1, 1, "C");
        $formulaVoto = $configurazione->getFormulaVoto($this->corsoDiLaurea);
        $formulaVoto = str_replace('CFU', "A", $formulaVoto);
        $formulaVoto = str_replace(["M", 'T', 'A', 'C'], ['$M', '$T', '$A', '$C'], $formulaVoto);
        
        $param = $configurazione->getInfoParametro($this->corsoDiLaurea);
        $nCell = (int)(($param["max"] - $param["min"]) / $param["step"] + 1);
        
        $M = $this->laureando->calcolaMedia();
        $A = $configurazione->getCfuCurricolari($this->corsoDiLaurea);
        $C = 0;
        $T = 0;
        
        if($nCell <= 10)
        {
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 2, 5.5, $param["param"] == "T" ? "VOTO TESI" : "VOTO COMMISSIONE", 1, 0, "C");
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 2, 5.5, "VOTO DI LAUREA", 1, 1, "C");
            for ($i = $param["min"]; $i <= $param["max"]; $i += $param["step"]) {
                if($param["param"] == "T")
                    $T = $i;
                else
                    $C = $i;
                eval("\$voto = $formulaVoto;");
                
                $pdf->Cell(($pdf->GetPageWidth() - 22) / 2, 5.5, $i, 1, 0, "C");
                $pdf->Cell(($pdf->GetPageWidth() - 22) / 2, 5.5, round($voto, 3), 1, 1, "C");
            }
        }
        else
        {
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 5.5, $param["param"] == "T" ? "VOTO TESI" : "VOTO COMMISSIONE", 1, 0, "C");
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 5.5, "VOTO DI LAUREA", 1, 0, "C");
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 5.5, $param["param"] == "T" ? "VOTO TESI" : "VOTO COMMISSIONE", 1, 0, "C");
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 5.5, "VOTO DI LAUREA", 1, 1, "C");
            $even = 0;
            for ($i = 0; $i < $nCell; $i++) {
                if($even == 0)
                    $val = $param["min"] + $param["step"] * ($i / 2);
                else
                    $val = $param["min"] + $param["step"] * (ceil($nCell / 2) + ($i - 1) / 2);
                if($param["param"] == "T")
                    $T = $val;
                else
                    $C = $val;
                eval("\$voto = $formulaVoto;");
                
                $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 5.5, $val, 1, 0, "C");
                $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 5.5, round($voto, 3), 1, $even || ($i == $nCell - 1), "C");
                $even = $even == 0 ? 1 : 0;
            }
        }
        $pdf->Ln(3);
        $pdf->MultiCell(0, 4, "VOTO DI LAUREA FINALE: " . $configurazione->getMessaggioProspetto($this->corsoDiLaurea));
    }
    public function genera()
    {
        $pdf = new FPDF();
        $this->costruisciPdf($pdf);
        if(!file_exists("data/$this->corsoDiLaurea"))
            mkdir("data/$this->corsoDiLaurea");
        $pdf->Output("data/$this->corsoDiLaurea/" . $this->laureando->matricola . "_prospetto.pdf", "F");
    }
}