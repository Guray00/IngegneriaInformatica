<?php
require_once "lib/fpdf184/fpdf.php";
require_once "lib/PHPMailer/src/PHPMailer.php";
require_once "lib/PHPMailer/src/Exception.php";
require_once "lib/PHPMailer/src/SMTP.php";
require_once "classes/DatiDiConfigurazione.php";
require_once "classes/GestioneCarrieraStudente.php";
require_once "classes/Esame.php";
require_once "classes/Laureando.php";
require_once "classes/LaureandoInformatica.php";
require_once "classes/ProspettoLaureando.php";
require_once "classes/ProspettoCommissione.php";
require_once "classes/EmailLaureandi.php";
require_once "classes/AjaxHandler.php";

session_start();
$gestioneCarrieraStudente = $_SESSION["gestioneCarrieraStudente"];
$configurazione = $_SESSION["configurazione"];
$ajax = $_SESSION["ajax"];

if (isset($_POST['functionToCall']))
{
    if($_POST["functionToCall"] == "generaProspettiLaurea")
    {
        echo $ajax->generaProspettiLaurea($_POST["CdL"], $_POST["matricole"], $_POST["dataLaurea"]);
    }
    else if($_POST["functionToCall"] == "inviaProspettoLaurea")
    {
        echo $ajax->inviaProspettoLaurea($_POST["CdL"], $_POST["matricola"]);
    }
}
?>