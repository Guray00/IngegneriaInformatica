<!DOCTYPE html>
<?php
require_once "classes/GestioneCarrieraStudente.php";
require_once "classes/DatiDiConfigurazione.php";
require_once "classes/AjaxHandler.php";
session_start();
$_SESSION["gestioneCarrieraStudente"] = new GestioneCarrieraStudente();
$_SESSION["configurazione"] = new DatiDiConfigurazione();
$_SESSION["ajax"] = new AjaxHandler();
?>
<html lang="it-IT">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Generatore Prospetti di Laurea</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #e8f0fc;
                margin: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
    
            .horizontal {
                display: flex;
            }
    
            .container {
                background-color: #f9fcff;
                border: 1px solid #a0c4ff;
                border-radius: 10px;
                padding: 20px;
                width: 600px;
                box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            }
    
            .title {
                text-align: center;
                font-size: 1.5em;
                color: #3366cc;
                margin-bottom: 20px;
            }
    
            .form-group,
            .buttons {
                flex-grow: 1;
                margin-inline: 20px;
                max-width: 165px;
            }
    
            .form-group label {
                font-weight: bold;
                color: #3366cc;
                display: block;
            }
    
            .form-group select,
            .form-group input,
            .form-group textarea {
                width: 100%;
                padding: 8px;
                border: 1px solid #a0c4ff;
                border-radius: 5px;
                margin-top: 5px;
                margin-bottom: 8px;
                background-color: white;
                box-sizing: border-box;
            }
    
            .form-group input[type="date"] {
                display: block;
            }
    
            .matricole {
                width: 100%;
                height: 100px;
                border: 1px solid #a0c4ff;
                border-radius: 5px;
                resize: none;
            }
    
            .buttons {
                margin-top: 15px;
                width: 150px;
            }
    
            .buttons button {
                display: block;
                background: linear-gradient(to bottom, #cce4ff, #3366cc);
                color: white;
                border: none;
                padding: 9px 20px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 0.9em;
                margin-block: 7px;
                width: 100%;
                box-sizing: border-box;
            }
    
            .buttons button:hover {
                background: linear-gradient(to bottom, #3366cc, #002d6c);
            }
    
            .buttons a {
                color: #3366cc;
                display: block;
                text-decoration: none;
                font-size: 0.9em;
                margin-block: 7px;
                text-align: center;
            }
    
            .buttons a:hover {
                text-decoration: underline;
            }
            
            #message {
                color: #3366cc;
                height: 18px;
                text-align: center;
                transition-duration: 100ms;
            }
            
            @keyframes glow {
                from {
                    text-shadow: 0 0 10px #3366ccff;
                }
                to {
                    text-shadow: 0 0 2px #3366cc00;
                }
            }
    
            @keyframes err {
                from {
                    text-shadow: 0 0 10px #ff0000ff;
                }
                to {
                    text-shadow: 0 0 2px #ff000000;
                }
            }
            
            .justUpdated {
                animation: glow;
                animation-duration: 1200ms;
            }
            
            .justUpdatedErr {
                animation: err;
                animation-duration: 1200ms;
            }
        </style>
        <script src="classes/InterfacciaUtente.js"></script>
    </head>
    <body>
        <div class="container">
            <h1 class="title">Gestione Prospetti di Laurea</h1>
            <div class="horizontal">
                <div class="form-group">
                    <label for="cdl">CdL:</label>
                    <select id="cdl">
                        <option value="" selected disabled>Seleziona Cdl</option>
                        <option value="T. Ing. Biomedica">T. Ing. Biomedica</option>
                        <option value="T. Ing. Elettronica">T. Ing. Elettronica</option>
                        <option value="T. Ing. delle Telecomunicazioni">T. Ing. delle Telecomunicazioni</option>
                        <option value="T. Ing. Informatica">T. Ing. Informatica</option>
                        <option value="M. Cybersecurity">M. Cybersecurity</option>
                        <option value="M. Ing. Elettronica">M. Ing. Elettronica</option>
                        <option value="M. Ing. Biomedica, Bionics Engineering">M. Ing. Biomedica, Bionics Engineering</option>
                        <option value="M. Ing. delle Telecomunicazioni">M. Ing. delle Telecomunicazioni</option>
                        <option value="M. Computer Engineering, Artificial Intelligence and Data Engineering">M. Computer Engineering, Artificial Intelligence and Data Engineering</option>
                        <option value="M. Ing. Robotica e della Automazione">M. Ing. Robotica e della Automazione</option>
                    </select>
                    <label for="data-laurea">Data Laurea:</label>
                    <input type="date" id="data-laurea">
                </div>
                <div class="form-group">
                    <label for="matricole">Matricole:</label>
                    <textarea id="matricole" class="matricole"></textarea>
                </div>
                <div class="buttons">
                    <button id = "genera">Crea Prospetti</button>
                    <a href="#" id = "visualizza">Apri prospetti</a>
                    <button id = "invia">Invia Prospetti</button>
                    <p id="message" class="message"></p>
                </div>
            </div>
        </div>
        <script>
            let interfaccia = new InterfacciaUtente();
            document.getElementById("genera").addEventListener("click", () => interfaccia.callGeneraProspetti());
            document.getElementById("visualizza").addEventListener("click", () => interfaccia.visualizzaProspetti());
            document.getElementById("invia").addEventListener("click", () => interfaccia.inviaProspetti());
        </script>
    </body>
</html>
