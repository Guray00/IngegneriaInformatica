<?php
class ProspettoCommissione
{
    private $prospettiLaureando;
    private $corsoDiLaurea;
    public function __construct($CdL)
    {
        $this->prospettiLaureando = [];
        $this->corsoDiLaurea = $CdL;
    }
    public function aggiungiProspetto($prospetto)
    {
        $this->prospettiLaureando[] = $prospetto;
    }
    public function genera()
    {
        $pdf = new FPDF();
        $pdf->SetMargins(11, 8);
        $pdf->AddPage();
        $font = "Arial";
        $pdf->SetFont($font, "", 13);
        $pdf->Cell(0, 6, $this->corsoDiLaurea, 0, 1, "C");
        $pdf->Cell(0, 6, "LISTA LAUREANDI", 0, 1, "C");
        $pdf->Ln(3);
        
        $pdf->SetFontSize(11);
        $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 7, "COGNOME", 1, 0, "C");
        $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 7, "NOME", 1, 0, "C");
        $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 7, "CDL", 1, 0, "C");
        $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 7, "VOTO LAUREA", 1, 1, "C");
        
        $pdf->SetFontSize(10);
        foreach ($this->prospettiLaureando as $prospetto)
        {
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 6, $prospetto->laureando->cognome, 1, 0, "C");
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 6, $prospetto->laureando->nome, 1, 0, "C");
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 6, "", 1, 0, "C");
            $pdf->Cell(($pdf->GetPageWidth() - 22) / 4, 6, "/110", 1, 1, "C");
        }
        
        foreach ($this->prospettiLaureando as $prospetto)
        {
            $prospetto->costruisciPdf($pdf);
            $prospetto->aggiungiTabella($pdf);
        }
        if(!file_exists("data/$this->corsoDiLaurea"))
            mkdir("data/$this->corsoDiLaurea");
        $pdf->Output("data/$this->corsoDiLaurea/commissione_prospetto.pdf", "F");
    }
}