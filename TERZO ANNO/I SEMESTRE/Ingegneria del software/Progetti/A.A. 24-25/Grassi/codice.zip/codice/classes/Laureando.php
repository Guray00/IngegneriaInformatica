<?php
class Laureando
{
    public $nome;
    public $cognome;
    public $matricola;
    public $email;
    public $esami;
    public $dataIscrizione;
    
    public function __construct($matricola, $CdL)
    {
        global $gestioneCarrieraStudente;
        global $configurazione;
        $this->matricola = $matricola;
        $anagrafica = $gestioneCarrieraStudente->restituisciAnagraficaStudente($matricola);
        $esami = $gestioneCarrieraStudente->restituisciCarrieraStudente($matricola);
        $this->nome = $anagrafica["nome"];
        $this->cognome = $anagrafica["cognome"];
        $this->email = $anagrafica["email_ate"];
        $i = 0;
        foreach($esami as $esame)
        {
            if($this->dataIscrizione == null)
                $this->dataIscrizione = strtotime(str_replace("/", "-", $esame["INIZIO_CARRIERA"]));
            if($esame["SOVRAN_FLG"] == 1 || !is_string($esame["DES"]) || !is_int($esame["PESO"]) || in_array($esame["DES"], $configurazione->getEsamiNonCarriera($CdL, $matricola)))
                continue;
            $this->esami[$i] = new Esame($esame, $CdL, $matricola);
            $i++;
        }
        usort($this->esami, function($e1, $e2)
        {
            return $e1->dataEsame > $e2->dataEsame;
        });
    }
    public function calcolaMedia()
    {
        $tot = 0;
        $cfu = 0;
        foreach ($this->esami as $esame)
        {
            if(!$esame->faMedia)
                continue;
            $tot += $esame->voto * $esame->cfu;
            $cfu += $esame->cfu;
        }
        return $tot/$cfu;
    }
    public function calcolaCfuMedia()
    {
        $cfu = 0;
        foreach ($this->esami as $esame)
        {
            if(!$esame->faMedia)
                continue;
            $cfu += $esame->cfu;
        }
        return $cfu;
    }
    public function calcolaCfuCurricolari()
    {
        $cfu = 0;
        foreach ($this->esami as $esame)
            $cfu += $esame->cfu;
        return $cfu;
    }
}