<?php
class AjaxHandler {
    public function generaProspettiLaurea($CdL, $matricole, $dataLaurea)
    {
        $prospettoCommissione = new ProspettoCommissione($CdL);
        $matricole = explode(",", $matricole, PHP_INT_MAX);
        if (is_dir("data/$CdL"))
        {
            $files = glob("data/$CdL".'/*');
            foreach ($files as $file)
            {
                if (is_file($file))
                    unlink($file);
            }
        }
        foreach($matricole as $m)
        {
            if($CdL == "T. Ing. Informatica")
                $laureando = new LaureandoInformatica($m, $CdL, $dataLaurea);
            else
                $laureando = new Laureando($m, $CdL);
            $prospettoLaureando = new ProspettoLaureando($laureando, $CdL, $dataLaurea);
            $prospettoLaureando->genera();
            $prospettoCommissione->aggiungiProspetto($prospettoLaureando);
        }
        $prospettoCommissione->genera();
        return "ok";
    }
    public function inviaProspettoLaurea($CdL, $matricola)
    {
        $email = new EmailLaureandi($matricola, $CdL);
        $email->genera();
        if($email->invia())
            return "ok";
        return "err";
    }
}