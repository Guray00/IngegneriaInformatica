<?php
use PHPMailer\PHPMailer\PHPMailer;
class EmailLaureandi
{
    private $oggetto;
    private $destinatarioIndirizzo;
    private $destinatarioNome;
    private $allegato;
    private $body;
    private $email;
    public function __construct($matricola, $CdL)
    {
        global $gestioneCarrieraStudente;
        global $configurazione;
        $anagrafica = $gestioneCarrieraStudente->restituisciAnagraficaStudente($matricola);
        $this->destinatarioIndirizzo = $anagrafica["email_ate"];
        $this->destinatarioNome = $anagrafica["nome"]." ".$anagrafica["cognome"];
        $this->oggetto = "Appello di laurea in ". $CdL . "- indicatori per voto di laurea";
        $this->body = $configurazione->getEmailBody($CdL);
        $this->allegato = "data/$CdL/" .$matricola . "_prospetto.pdf";
    }
    public function genera()
    {
        $email = new PHPMailer();
        $email->IsSMTP();
        $email->Host = "mixer.unipi.it";
        $email->SMTPSecure = "tls";
        $email->Port = 25;
        $email->SMTPAuth = false;
        $email->addCustomHeader('Content-Type', 'text/plain; windows-1252');
        $email->setFrom("no-reply-laureandosi@ing.unipi.it", "Laureandosi 2.0");
        $email->AddAddress($this->destinatarioIndirizzo, $this->destinatarioIndirizzo);
        $email->AddAttachment($this->allegato);
        $email->Subject = $this->oggetto;
        $email->Body = mb_convert_encoding($this->body, 'Windows-1252', 'UTF-8');;
        $this->email = $email;
    }
    public function invia()
    {
        if (!$this->email->send())
        {
            return false;
        }
        $this->email->SmtpClose();
        return true;
    }
}