<?php
class GestioneCarrieraStudente
{
    public function restituisciAnagraficaStudente($matricola)
    {
        $json = file_get_contents("data/" . $matricola . "_anagrafica.json");
        $anagrafica = json_decode($json, true);
        return $anagrafica["Entries"]["Entry"];
    }
    
    public function restituisciCarrieraStudente($matricola)
    {
        $json = file_get_contents("data/" . $matricola . "_esami.json");
        $carriera = json_decode($json, true);
        return $carriera["Esami"]["Esame"];
    }
}