<?php
class DatiDiConfigurazione
{
    private $configData;
    public function __construct()
    {
        $this->caricaDati();
    }
    public function caricaDati()
    {
        $json = file_get_contents("data/config.json");
        $this->configData = json_decode($json, true);
    }
    public function getEsamiNonCarriera($CdL, $matricola = null)
    {
        $f = $this->configData["infoCdL"][$CdL]["esamiNonInCarriera"]["*"];
        if(array_key_exists($matricola, $this->configData["infoCdL"][$CdL]["esamiNonInCarriera"]))
            $f = array_merge($f, $this->configData["infoCdL"][$CdL]["esamiNonInCarriera"][$matricola]);
        return $f;
    }
    public function getEsamiNonMedia($CdL, $matricola = null)
    {
        $f = $this->configData["infoCdL"][$CdL]["esamiNonInMedia"]["*"];
        if(array_key_exists($matricola, $this->configData["infoCdL"][$CdL]["esamiNonInMedia"]))
            $f = array_merge($f, $this->configData["infoCdL"][$CdL]["esamiNonInMedia"][$matricola]);
        return $f;
    }
    public function getEsamiInformatici()
    {
        return $this->configData["esamiInformatici"];
    }
    public function getCfuCurricolari($CdL)
    {
        return $this->configData["infoCdL"][$CdL]["totCfu"];
    }
    public function getValoreLode($CdL)
    {
        return $this->configData["infoCdL"][$CdL]["valoreLode"];
    }
    public function getFormulaVoto($CdL)
    {
        return $this->configData["infoCdL"][$CdL]["formulaVoto"];
    }
    public function getInfoParametro($CdL)
    {
        return $this->configData["infoCdL"][$CdL]["infoParametro"];
    }
    public function getMessaggioProspetto($CdL)
    {
        return $this->configData["infoCdL"][$CdL]["messaggioProspetto"];
    }
    public function getEmailBody($CdL)
    {
        return $this->configData["infoCdL"][$CdL]["messaggioEmail"];
    }
}