<?php
class Test
{
    function testDatiDiConfigurazione()
    {
        echo "Test DatiDiConfigurazione: ";
        try
        {
            global $configurazione;
            $ok = true;
            $CdL = "Test";
            $matricola = "100000";
            $matricola2 = "111111";
            
            $esamiNonCarriera1 = $configurazione->getEsamiNonCarriera($CdL, $matricola);
            $esamiNonCarriera2 = $configurazione->getEsamiNonCarriera($CdL, $matricola2);
            if (!(in_array("TEST0", $esamiNonCarriera1) && in_array("TEST1", $esamiNonCarriera1) && in_array("TEST2", $esamiNonCarriera1)))
            {
                echo "Errore getEsamiNonCarriera. ";
                $ok = false;
            }
            if (!(in_array("TEST0", $esamiNonCarriera2) && in_array("TEST1", $esamiNonCarriera2) && !in_array("TEST2", $esamiNonCarriera2)))
            {
                echo "Errore getEsamiNonCarriera. ";
                $ok = false;
            }
            
            $esamiNonMedia = $configurazione->getEsamiNonMedia($CdL, $matricola2);
            if (!(in_array("TEST4", $esamiNonMedia) && in_array("TEST5", $esamiNonMedia)))
            {
                echo "Errore getEsamiNonMedia. ";
                $ok = false;
            }
            
            $cfuCurricolari = $configurazione->getCfuCurricolari($CdL);
            if ($cfuCurricolari != 3)
            {
                echo "Errore getCfuCurricolari. ";
                $ok = false;
            }
            
            $messaggioProspetto = $configurazione->getMessaggioProspetto($CdL);
            if ($messaggioProspetto != "ok")
            {
                echo "Errore getMessaggioProspetto. ";
                $ok = false;
            }
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
    function testGestioneCarrieraStudente()
    {
        echo "Test GestioneCarrieraStudente: ";
        try
        {
            $ok = true;
            $matricola = "123456";
            global $gestioneCarrieraStudente;
            $anagrafica = $gestioneCarrieraStudente->restituisciAnagraficaStudente($matricola);
            if (!isset($anagrafica["nome"]) || !isset($anagrafica["cognome"]) || !isset($anagrafica["email_ate"]))
            {
                echo "Errore restituisciAnagraficaStudente. ";
                $ok = false;
            }
            $esami = $gestioneCarrieraStudente->restituisciCarrieraStudente($matricola);
            if (!is_array($esami))
            {
                echo "Errore restituisciCarrieraStudente. ";
                $ok = false;
            }
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
    function testEsame()
    {
        echo "Test Esame: ";
        try
        {
            $ok = true;
            $matricolaInfo = "999999";
            $matricola = "111111";
            
            global $gestioneCarrieraStudente;
            $esame = new Esame($gestioneCarrieraStudente->restituisciCarrieraStudente($matricola)[0], "Test", $matricola);
            $esame2 = new Esame($gestioneCarrieraStudente->restituisciCarrieraStudente($matricola)[1], "Test", $matricola);
            if ($esame->voto != 40 || $esame2->faMedia || !$esame->faMedia)
            {
                echo "Errore costruttore. ";
                $ok = false;
            }
            $esameInfo = new Esame($gestioneCarrieraStudente->restituisciCarrieraStudente($matricolaInfo)[0], "T. Ing. Informatica", $matricolaInfo);
            if (!$esameInfo->isInformatico() || $esame->isInformatico())
            {
                echo "Errore isInformatico. ";
                $ok = false;
            }
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
    function testLaureando()
    {
        echo "Test Laureando: ";
        try
        {
            $ok = true;
            $matricola = "100000";
            $matricola2 = "111111";
            $CdL = "Test";
            $l1 = new Laureando($matricola, $CdL);
            $l2 = new Laureando($matricola2, $CdL);
            if ($l1->calcolaMedia() != 30 || $l2->calcolaMedia() != 30)
            {
                echo "Errore calcolaMeida. ";
                $ok = false;
            }
            if ($l1->calcolaCfuCurricolari() != 3 || $l2->calcolaCfuCurricolari() != 3)
            {
                echo "Errore calcolaCfuCurricolari. ";
                $ok = false;
            }
            if ($l1->calcolaCfuMedia() != 1 || $l2->calcolaCfuMedia() != 2)
            {
                echo "Errore calcolaCfuMedia. ";
                $ok = false;
            }
            
            $l3 = new Laureando("234567","M. Ing. Elettronica");
            $l4 = new Laureando("456789","M. Ing. delle Telecomunicazioni");
            $l5 = new Laureando("567890","M. Cybersecurity");
            
            if($l3->calcolaMedia() > 24.56 || $l3->calcolaMedia() < 24.55 || $l4->calcolaMedia() > 32.63 || $l4->calcolaMedia() < 32.62 || $l5->calcolaMedia() > 24.89 || $l5->calcolaMedia() < 24.88)
            {
                echo "Errore calcolaMeida. ";
                $ok = false;
            }
            if($l3->calcolaCfuCurricolari() != 102 || $l4->calcolaCfuCurricolari() != 96 || $l5->calcolaCfuCurricolari() != 120)
            {
                echo "Errore calcolaCfuCurricolari. ";
                $ok = false;
            }
            if($l3->calcolaCfuMedia() != 102 || $l4->calcolaCfuMedia() != 96 || $l5->calcolaCfuMedia() != 102)
            {
                echo "Errore calcolaCfuMedia. ";
                $ok = false;
            }
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
    function testLaureandoInformatica()
    {
        echo "Test LaureandoInformatica: ";
        try
        {
            $ok = true;
            $matricola = "999999";
            $CdL = "T. Ing. Informatica";
            $l1 = new LaureandoInformatica($matricola, $CdL, "01/01/2023");
            $l2 = new LaureandoInformatica($matricola, $CdL, "01/01/2024");
            if (!$l1->bonus() || $l2->bonus())
            {
                echo "Errore bonus. ";
                $ok = false;
            }
            if ($l1->calcolaMediaEsamiInformatici() != 30)
            {
                echo "Errore calcolaMediaEsamiInformatici. ";
                $ok = false;
            }
            if ($l1->calcolaMedia() != 25 || $l2->calcolaMedia() >= 25)
            {
                echo "Errore togliEsameMinimo. ";
                $ok = false;
            }
            
            $l3 = new LaureandoInformatica("123456",$CdL, "2023-01-04");
            $l4 = new LaureandoInformatica("345678",$CdL, "2023-01-04");
            
            if($l3->calcolaMediaEsamiInformatici() > 23.67 || $l3->calcolaMediaEsamiInformatici() < 23.66 || $l4->calcolaMediaEsamiInformatici() > 25.751 || $l4->calcolaMediaEsamiInformatici() < 25.749)
            {
                echo "Errore calcolaMeidaEsamiInformatici. ";
                $ok = false;
            }
            if($l3->bonus() || !$l4->bonus())
            {
                echo "Errore bonus. ";
                $ok = false;
            }
            if($l3->calcolaMedia() > 23.66 || $l3->calcolaMedia() < 23.65 || $l4->calcolaMedia() > 25.57 || $l4->calcolaMedia() < 25.56)
            {
                echo "Errore togliEsameMinimo. ";
                $ok = false;
            }
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
    function testProspettoLaureando()
    {
        echo "Test ProspettoLaureando: ";
        try
        {
            $ok = true;
            $prospetto = new ProspettoLaureando(new Laureando("100000", "Test"), "Test", "2023-01-04");
            $pdf = new FPDF();
            $prospetto->costruisciPdf($pdf);
            $prospetto->aggiungiTabella($pdf);
            $prospetto = new ProspettoLaureando(new LaureandoInformatica("123456", "T. Ing. Informatica", "2023-01-04"), "T. Ing. Informatica", "2023-01-04");
            $pdf = new FPDF();
            $prospetto->costruisciPdf($pdf);
            $prospetto->aggiungiTabella($pdf);
            $prospetto = new ProspettoLaureando(new Laureando("234567", "M. Ing. Elettronica"), "M. Ing. Elettronica", "2023-01-04");
            $pdf = new FPDF();
            $prospetto->costruisciPdf($pdf);
            $prospetto->aggiungiTabella($pdf);
            $prospetto = new ProspettoLaureando(new LaureandoInformatica("345678", "T. Ing. Informatica", "2023-01-04"), "T. Ing. Informatica", "2023-01-04");
            $pdf = new FPDF();
            $prospetto->costruisciPdf($pdf);
            $prospetto->aggiungiTabella($pdf);
            $prospetto = new ProspettoLaureando(new Laureando("456789", "M. Ing. delle Telecomunicazioni"), "M. Ing. delle Telecomunicazioni", "2023-01-04");
            $pdf = new FPDF();
            $prospetto->costruisciPdf($pdf);
            $prospetto->aggiungiTabella($pdf);
            $prospetto = new ProspettoLaureando(new Laureando("567890", "M. Cybersecurity"), "M. Cybersecurity", "2023-01-04");
            $pdf = new FPDF();
            $prospetto->costruisciPdf($pdf);
            $prospetto->aggiungiTabella($pdf);
            $prospetto->genera();
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
    function testProspettoCommissione()
    {
        echo "Test ProspettoCommissione: ";
        try
        {
            $ok = true;
            $prospettoC = new ProspettoCommissione("T. Ing. Informatica");
            $prospettoL1 = new ProspettoLaureando(new LaureandoInformatica("123456", "T. Ing. Informatica", "2023-01-04"), "T. Ing. Informatica", "2023-01-04");
            $prospettoL2 = new ProspettoLaureando(new LaureandoInformatica("345678", "T. Ing. Informatica", "2023-01-04"), "T. Ing. Informatica", "2023-01-04");
            $prospettoC->aggiungiProspetto($prospettoL1);
            $prospettoC->aggiungiProspetto($prospettoL2);
            $prospettoC->genera();
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
    function testEmailLaureandi()
    {
        echo "Test EmailLaureandi: ";
        try
        {
            $ok = true;
            $email = new EmailLaureandi("111111", "Test");
            $email->genera();
            if (!$email->invia())
            {
                echo "Errore invia. ";
                $ok = false;
            }
        }
        catch (Throwable $e)
        {
            echo "Errore: " . $e;
            $ok = false;
        }
        if ($ok)
        {
            echo "Ok";
        }
        echo "\n";
    }
}