<!DOCTYPE html>
<html lang="it-IT">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gestione Prospetti di Laurea: Test</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #e8f0fc;
                margin: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                line-height: 1.6;
                height: 100vh;
            }
            
            .container {
                background-color: #f9fcff;
                border: 1px solid #a0c4ff;
                border-radius: 10px;
                padding: 20px;
                width: 800px;
                box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
                max-height: 90%;
                display: flex;
                flex-direction: column;
            }
            
            h1 {
                text-align: center;
                font-size: 1.5em;
                color: #3366cc;
                margin-bottom: 20px;
            }
            
            pre {
                background: #f1f1f1;
                border: 1px solid #a0c4ff;
                border-left: 4px solid #3366cc;
                padding: 10px;
                overflow-x: auto;
                overflow-y: auto;
                border-radius: 4px;
                flex-grow: 1;
                width: 100%;
                box-sizing: border-box;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Gestione Prospetti di Laurea - Test</h1>
            <pre><?php
                    require_once "lib/fpdf184/fpdf.php";
                    require_once "lib/PHPMailer/src/PHPMailer.php";
                    require_once "lib/PHPMailer/src/Exception.php";
                    require_once "lib/PHPMailer/src/SMTP.php";
                    require_once "classes/DatiDiConfigurazione.php";
                    require_once "classes/GestioneCarrieraStudente.php";
                    require_once "classes/Esame.php";
                    require_once "classes/Laureando.php";
                    require_once "classes/LaureandoInformatica.php";
                    require_once "classes/ProspettoLaureando.php";
                    require_once "classes/ProspettoCommissione.php";
                    require_once "classes/EmailLaureandi.php";
                    require_once "classes/Test.php";
                    
                    $configurazione = new DatiDiConfigurazione();
                    $gestioneCarrieraStudente = new GestioneCarrieraStudente();
                    $t = new Test();
                    $t->testDatiDiConfigurazione();
                    $t->testGestioneCarrieraStudente();
                    $t->testEsame();
                    $t->testLaureando();
                    $t->testLaureandoInformatica();
                    $t->testProspettoLaureando();
                    $t->testProspettoCommissione();
                    $t->testEmailLaureandi();
                    ?></pre>
        </div>
    </body>
</html>
