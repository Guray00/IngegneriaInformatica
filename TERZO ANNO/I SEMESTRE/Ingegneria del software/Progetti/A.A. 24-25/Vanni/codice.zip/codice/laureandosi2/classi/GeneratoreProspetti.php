<?php

namespace classi;

use InvalidArgumentException;

require_once __DIR__ . '/CarrieraLaureando.php';

require_once __DIR__ . '/ProspettoPDFLaureando.php';

require_once __DIR__ . '/ProspettoPDFCommissione.php';

class GeneratoreProspetti
{
    private static string $outputPath = "prospetti_generati";
    private string $corsoDiLaurea;
    private string $dataLaurea; //array di string
    private array $matricole;

    public function __construct(array $matricole, string $cdl, string $dataLaurea)
    {
        if (!file_exists(self::$outputPath)) {
            mkdir(self::$outputPath, 0777, true);
        }

        $matricole = array_filter($matricole ?? [], function ($element) {
            return !empty($element);
        });

        if (is_null($matricole) || empty($matricole)) {
            throw new InvalidArgumentException("Matricole non inserite");
        }

        $this->matricole = $matricole;
        $this->corsoDiLaurea = $cdl;
        $this->dataLaurea = $dataLaurea;
    }

    public function generaProspetti($test = null): void
    {
        $carriere = array();
        $path = self::$outputPath . DIRECTORY_SEPARATOR . $this->corsoDiLaurea . DIRECTORY_SEPARATOR . $this->dataLaurea . DIRECTORY_SEPARATOR;
        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        if ($test !== null) {
            $path = "test/generati" . DIRECTORY_SEPARATOR . $test . DIRECTORY_SEPARATOR;
        } // SOLO PER I TEST

        foreach ($this->matricole as $matricola) {
            if ($this->corsoDiLaurea == "t-inf") {
                $carriera = new CarrieraLaureandoInf($matricola, $this->corsoDiLaurea, $this->dataLaurea);
            } else {
                $carriera = new CarrieraLaureando($matricola, $this->corsoDiLaurea, $this->dataLaurea);
            }

            $carriere[] = $carriera;

            $prospettoLaureando = new ProspettoPDFLaureando($carriera);
            $prospettoLaureando->prospettoLaureando->Output('F', $path . $matricola . ".pdf");
        }

        $prospettoCommissioneGenerato = new ProspettoPDFCommissione($carriere, $this->corsoDiLaurea);
        $pathProspettoCommissione = $path . "commissione-" . $this->corsoDiLaurea . "-" . $this->dataLaurea . ".pdf";
        $prospettoCommissioneGenerato->prospettoCommissione->Output('F', $pathProspettoCommissione);
    }
}