<?php

namespace classi;

require_once __DIR__ . '/../lib/fpdf184/fpdf.php';

use Exception;
use FPDF;

require_once __DIR__ . '/CarrieraLaureando.php';

require_once __DIR__ . '/CarrieraLaureandoInf.php';

require_once __DIR__ . '/GestioneCarrieraStudente.php';

require_once __DIR__ . '/FormulaVoto.php';

class ProspettoPDFLaureando
{

    protected static string $pathCdl = 'config/cdl.json';
    public FPDF $prospettoLaureando;
    public CarrieraLaureando $carriera;

    public function __construct($carriera)
    {
        $this->carriera = $carriera;
        $this->prospettoLaureando = new FPDF();
        $this->generaPDFLaureando();
        $this->prospettoLaureando->Close();
    }

    protected function generaPDFLaureando(): void
    {
        // Dati necessari al pdf
        $file = file_get_contents(self::$pathCdl);
        $config = json_decode($file, true);
        $cdlCorto = $this->carriera->corsoDiLaurea;
        $nomeCdl = $config[$cdlCorto]['nome'];
        $creditiNecessari = $config[$cdlCorto]['crediti_totali'];

        $parametro = null;
        if ($config[$cdlCorto]['range_T']['max'] !== 0 && $config[$cdlCorto]['range_T']['min'] !== 0 && $config[$cdlCorto]['range_T']['step'] !== 0) {
            $parametro = 'T';
        } elseif ($config[$cdlCorto]['range_C']['max'] !== 0 && $config[$cdlCorto]['range_C']['min'] !== 0 && $config[$cdlCorto]['range_C']['step'] !== 0) {
            $parametro = 'C';
        }

        $formulaVoto = $config[$cdlCorto]['formula'];
        $inf = $this->carriera instanceof CarrieraLaureandoInf;

        // Creazione del pdf
        $this->prospettoLaureando->AddPage();
        $padding = 20;
        $larghezza_pagina = $this->prospettoLaureando->GetPageWidth() - $padding;

        //Titolo
        $this->prospettoLaureando->SetFont('Arial', '', 14);
        $this->prospettoLaureando->Cell(0, 5, $nomeCdl, 0, 1, 'C');
        $this->prospettoLaureando->Cell(0, 5, "CARRIERA E SIMULAZIONE DEL VOTO DI LAUREA", 0, 1, 'C');
        $this->prospettoLaureando->Ln(5);

        //Anagrafica
        $anagrafica = array(
            "Matricola" => $this->carriera->matricola,
            "Nome" => $this->carriera->nome,
            "Cognome" => $this->carriera->cognome,
            "Email" => $this->carriera->emailAteneo,
            "Data" => $this->carriera->dataLaurea
        );
        if ($inf) {
            $anagrafica["Bonus"] = $this->carriera->idoneitaBonus ? "SI" : "NO";
        }

        $this->aggiungiDati(5, 60, $larghezza_pagina, 10, $anagrafica);
        $this->prospettoLaureando->Ln(5);

        //Esami
        $this->aggiungiEsami(4, 10, $larghezza_pagina, 10, $this->carriera->esami, $inf);
        $this->prospettoLaureando->Ln(5);

        //Dati per il voto
        if ($this->carriera->creditiTotali() < $creditiNecessari) {
            throw new Exception($this->carriera->matricola . "non ha abbastanza crediti per la laurea.");
        }
        $dati = array(
            "Media Pesata (M)" => rtrim(number_format($this->carriera->mediaPesata(), 3), '0'),
            "Crediti che fanno media (CFU)" => $this->carriera->creditiMedia(),
            "Crediti curricolari conseguiti" => (string)$this->carriera->creditiTotali() . '/' . $creditiNecessari,
            "Voto di tesi (T)" => 0,
            "Formula calcolo voto di laurea" => $formulaVoto
        );
        if ($inf) {
            $dati["Media pesata esami INF"] = rtrim(number_format($this->carriera->mediaInf(), 3), '0');
        }
        if ($cdlCorto != "t-inf" && $cdlCorto != "m-coe" && $cdlCorto != "m-aid") {
            unset($dati["Voto di tesi (T)"]);
        }
        $this->aggiungiDati(5, 60, $larghezza_pagina, 10, $dati);
        $this->prospettoLaureando->Ln(h: 5);
    }

    private function aggiungiDati(
        float $altezza,
        int $spazioChiaveValore,
        int $larghezzaTotale,
        float $dimFont,
        array $dati
    ): void {
        $this->prospettoLaureando->SetFont('Arial', '', $dimFont);

        $this->prospettoLaureando->Rect(
            $this->prospettoLaureando->GetX(),
            $this->prospettoLaureando->GetY(),
            $larghezzaTotale,
            $altezza * count($dati)
        );

        foreach ($dati as $chiave => $valore) {
            $this->prospettoLaureando->Cell($spazioChiaveValore, $altezza, $chiave . ":", 0, 0);
            $this->prospettoLaureando->Cell($larghezzaTotale - $spazioChiaveValore, $altezza, $valore, 0, 1);
        }
    }

    private function aggiungiEsami(
        float $altezza,
        int $larghezzaDati,
        int $larghezzaTotale,
        float $dimFont,
        array $esami,
        bool $inf
    ): void {
        $larghezzaNome = $larghezzaTotale - (3 + $inf) * $larghezzaDati;
        $altezzaTitolo = $altezza * 1.5;
        $this->prospettoLaureando->SetFont('Arial', '', $dimFont);

        $this->prospettoLaureando->Cell($larghezzaNome, $altezzaTitolo, "ESAME", 1, 0, 'C');
        $this->prospettoLaureando->Cell($larghezzaDati, $altezzaTitolo, "CFU", 1, 0, 'C');
        $this->prospettoLaureando->Cell($larghezzaDati, $altezzaTitolo, "VOT", 1, 0, 'C');
        $this->prospettoLaureando->Cell($larghezzaDati, $altezzaTitolo, "MED", 1, 0, 'C');
        if ($inf) {
            $this->prospettoLaureando->Cell($larghezzaDati, $altezzaTitolo, "INF", 1, 0, 'C');
        }
        $this->prospettoLaureando->ln();

        $this->prospettoLaureando->SetFont('Arial', '', $dimFont * 0.75);
        foreach ($esami as $esame) {
            $this->prospettoLaureando->Cell($larghezzaNome, $altezza, $esame->nome, 1, 0);
            $this->prospettoLaureando->Cell($larghezzaDati, $altezza, $esame->cfu, 1, 0, 'C');
            $this->prospettoLaureando->Cell($larghezzaDati, $altezza, $esame->voto, 1, 0, 'C');
            $this->prospettoLaureando->Cell($larghezzaDati, $altezza, $esame->media ? 'X' : '', 1, 0, 'C');
            if ($inf) {
                $this->prospettoLaureando->Cell($larghezzaDati, $altezza, $esame->inf ? 'X' : '', 1, 0, 'C');
            }
            $this->prospettoLaureando->ln();
        }
    }

}
