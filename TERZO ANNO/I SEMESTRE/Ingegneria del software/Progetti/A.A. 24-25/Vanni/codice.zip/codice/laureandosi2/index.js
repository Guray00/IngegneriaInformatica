//////// ELEMENTI DOM /////////

const input_matricole = document.getElementById('matricole');
const input_cdl = document.getElementById('cdl');
const input_data = document.getElementById('data');

const btn_genera = document.getElementById('genera');
const btn_apri = document.getElementById('apri');
const btn_invia = document.getElementById('invia');

const txt_output = document.getElementById('output');

////////// FUNZIONI //////////

function disabilita_pulsanti() {
    btn_genera.disabled = true;
    btn_apri.disabled = true;
    btn_invia.disabled = true;
}
function abilita_pulsanti() {
    btn_genera.disabled = false;
    btn_apri.disabled = false;
    btn_invia.disabled = false;
}
function aggiungiCdl() {
    txt_output.innerText = "Caricamento corsi di laurea...";
    fetch('config/cdl.json')
        .then(response => response.json())
        .then(data => {
            Object.keys(data).forEach(key => {
                const cdl = data[key];
                const option = document.createElement('option');
                option.value = cdl["nome_corto"];
                option.text = cdl["nome"];
                input_cdl.appendChild(option);
            });
            txt_output.innerText = "";
            abilita_pulsanti();
        })
        .catch(error => console.error('Errore nella ricerca dei corsi di laurea', error));
}

async function genera() {
    txt_output.innerText = "Generazione prospetti in corso...";
    disabilita_pulsanti();

    const matricole = input_matricole.value;
    const cdl = input_cdl.value;
    const data = input_data.value;
    const array_matricole = matricole.split(/\s+/);

    const richiesta = JSON.stringify({array_matricole, cdl, data});

    try {
        const res = await fetch("API.php?GUI=GeneraProspetti", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: richiesta
        });

        const json = await res.json();

        if (res.ok) {
            txt_output.innerText = json.message;
        } else {
            txt_output.innerText = json.error;
        }
    } catch (error) {
        txt_output.innerText = "Errore nella generazione dei prospetti";
    }

    abilita_pulsanti();
}

async function apri() {
    const cdl = input_cdl.value;
    const data = input_data.value;

    const url = `API.php?GUI=ApriProspetti&cdl=${cdl}&data=${data}`;

    try {
        const res = await fetch(url);
        if (!res.ok) {
            throw res;
        }
        const prospetto = await res.blob();
        txt_output.innerText = "Prospetti aperti";
        window.open(window.URL.createObjectURL(prospetto), '_blank').focus();
    } catch (err) {
        txt_output.innerText = "Errore nell'apertura dei prospetti";
    }
}

async function invia() {
    txt_output.innerText = "Invio in corso...";
    disabilita_pulsanti();

    const matricole = input_matricole.value;
    const cdl = input_cdl.value;
    const data = input_data.value;
    const array_matricole = (matricole.split(/\s+/)).filter(matricola => matricola !== "");
    if (array_matricole.length === 0) {
        txt_output.innerText = "Nessuna matricola inserita";
        return;
    }

    let prospetti_totali = array_matricole.length;
    let prospetti_inviati = 0;

    for (const matricola of array_matricole) {
        const richiesta = JSON.stringify({matricola, cdl, data});

        try {
            const res = await fetch("API.php?GUI=InviaProspetti", {
                method: "POST", headers: {
                    "Content-Type": "application/json"
                }, body: richiesta
            });
            const json = await res.json();

            if (res.ok) {
                await new Promise(resolve => setTimeout(resolve, 5000));
                prospetti_inviati++;
                txt_output.innerText = "Prospetti inviati: " + prospetti_inviati + " di " + prospetti_totali;
            } else {
                txt_output.innerText = json.error;
            }
        } catch (error) {
            txt_output.innerText = "Errore nell'invio dei prospetti";
        }
    }

    abilita_pulsanti();
}

////////// EVENTI //////////

window.addEventListener('load', aggiungiCdl);

btn_genera.addEventListener('click', genera);
btn_apri.addEventListener('click', apri);
btn_invia.addEventListener('click', invia);
