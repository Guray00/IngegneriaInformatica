<?php

namespace classi;

require_once __DIR__ . '/../lib/fpdf184/fpdf.php';

use FPDF;

require_once __DIR__ . '/CarrieraLaureando.php';

require_once __DIR__ . '/ProspettoPDFLaureando.php';

require_once __DIR__ . '/ProspettoConSimulazione.php';

require_once __DIR__ . '/SimulazioneVotoLaurea.php';


class ProspettoPDFCommissione
{

    private static string $pathCdl = 'config/cdl.json';
    public FPDF $prospettoCommissione; //array di CarrieraLaureando
    public array $carriere;
    public string $corsoDiLaurea;

    public function __construct(array $carriere, string $cdl)
    {
        $this->prospettoCommissione = new FPDF();
        $this->prospettoCommissione->AddPage();
        $this->prospettoCommissione->SetFont('Arial', '', 12);

        $file = file_get_contents(self::$pathCdl);
        $config = json_decode($file, true);
        $nomeCdl = $config[$cdl]['nome'];
        $larghezzaPagina = $this->prospettoCommissione->GetPageWidth() - 20;

        //Elenco laureandi
        $this->prospettoCommissione->SetFont('Arial', '', 10);
        $this->prospettoCommissione->Cell(0, 5, $nomeCdl, 0, 1, 'C');
        $this->prospettoCommissione->Ln(5);
        $this->prospettoCommissione->Cell(
            0,
            5,
            "LAUREANDOSI 2 - Progettazione: mario.cimino@unipi.it, Amministrazione: rose.rossiello@unipi.it",
            0,
            1,
            'C'
        );
        $this->prospettoCommissione->Ln(5);
        $this->prospettoCommissione->Cell(0, 5, "LISTA LAUREANDI", 0, 1, 'C');

        $this->aggiungiListaLaureandi(5, $larghezzaPagina, 10, $carriere);


        //Prospetti individuali
        foreach ($carriere as $carriera) {
            $pdfConSimulazione = new ProspettoConSimulazione($this->prospettoCommissione, $carriera);
            $pdfConSimulazione->aggiungiPDFConSimulazione();
        }

        $this->prospettoCommissione->Close();
    }

    private function aggiungiListaLaureandi(float $altezza, int $larghezzaTotale, float $dimFont, array $carriere): void
    {
        $larghezzaDati = $larghezzaTotale / 4;
        $altezzaTitolo = $altezza * 1.5;
        $this->prospettoCommissione->SetFont('Arial', '', $dimFont);

        $this->prospettoCommissione->Cell($larghezzaDati, $altezzaTitolo, "COGNOME", 1, 0, 'C');
        $this->prospettoCommissione->Cell($larghezzaDati, $altezzaTitolo, "NOME", 1, 0, 'C');
        $this->prospettoCommissione->Cell($larghezzaDati, $altezzaTitolo, "CDL", 1, 0, 'C');
        $this->prospettoCommissione->Cell($larghezzaDati, $altezzaTitolo, "VOTO LAUREA", 1, 1, 'C');

        $this->prospettoCommissione->SetFont('Arial', '', $dimFont * 0.75);
        foreach ($carriere as $carriera) {
            $this->prospettoCommissione->Cell($larghezzaDati, $altezza, $carriera->cognome, 1, 0, 'C');
            $this->prospettoCommissione->Cell($larghezzaDati, $altezza, $carriera->nome, 1, 0, 'C');
            $this->prospettoCommissione->Cell($larghezzaDati, $altezza, $carriera->corsoDiLaurea, 1, 0, 'C');
            $this->prospettoCommissione->Cell($larghezzaDati, $altezza, "/110", 1, 1, 'C');
        }
    }
}