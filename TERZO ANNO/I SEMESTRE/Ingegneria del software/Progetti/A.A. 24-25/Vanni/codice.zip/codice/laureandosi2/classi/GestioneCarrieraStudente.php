<?php

namespace classi;

use Exception;

class GestioneCarrieraStudente
{

    private static string $pathAnagrafica = "data/anagrafica.json";
    private static string $pathCarriere = "data/carriere.json";

    public function __construct()
    {
    }

    public static function prelevaAnagrafica(string $matricola): ?string
    {
        $file = file_get_contents(self::$pathAnagrafica);
        $dati = json_decode($file, true);

        if (isset($dati[$matricola])) {
            return json_encode($dati[$matricola]["Entries"]["Entry"]);
        } else {
            throw new Exception("Anagrafica di $matricola non trovata.");
        }
    }

    public static function prelevaCarriera(string $matricola): ?string
    {
        $file = file_get_contents(self::$pathCarriere);
        $dati = json_decode($file, true);

        if (isset($dati[$matricola])) {
            return json_encode($dati[$matricola]["Esami"]["Esame"]);
        } else {
            throw new Exception("Carriera di $matricola non trovata.");
        }
    }
}
