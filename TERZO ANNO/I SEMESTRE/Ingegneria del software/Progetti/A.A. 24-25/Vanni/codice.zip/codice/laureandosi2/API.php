<?php

require_once __DIR__ . '/classi/GUI.php';

use classi\GUI;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['GUI']) && $_GET['GUI'] === 'GeneraProspetti') {
    $json = file_get_contents('php://input');
    echo GUI::GeneraProspetti($json);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['GUI']) && $_GET['GUI'] === 'ApriProspetti') {
    $corso_laurea = $_GET["cdl"];
    $data_laurea = $_GET["data"];

    GUI::ApriProspetti($corso_laurea, $data_laurea);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['GUI']) && $_GET['GUI'] === 'InviaProspetti') {
    $json = file_get_contents('php://input');
    echo GUI::InviaProspetto($json);
}
