<?php

namespace classi;

require_once __DIR__ . '/FormulaVoto.php';

require_once __DIR__ . '/CarrieraLaureando.php';

require_once __DIR__ . '/Simulazione.php';

class SimulazioneVotoLaurea
{

    public array $simulazioni;
    public string $parametro; //char


    public function __construct(CarrieraLaureando $carriera)
    {
        $this->simulazioni = array();
        $formula = new FormulaVoto($carriera->corsoDiLaurea);
        $this->parametro = $formula->parametro;

        $media = $carriera->mediaPesata();
        $crediti = $carriera->creditiMedia();

        $min = $formula->minVoto;
        $max = $formula->maxVoto;
        $step = $formula->stepVoto;

        for ($p = $min; $p <= $max; $p += $step) {
            $votoLaurea = $formula->valutaFormula($media, $crediti, $p);
            $this->simulazioni[] = new Simulazione($p, $votoLaurea);
        }
    }
}