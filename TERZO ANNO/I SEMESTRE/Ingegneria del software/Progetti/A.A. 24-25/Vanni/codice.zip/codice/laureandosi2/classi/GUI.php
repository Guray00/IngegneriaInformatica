<?php

namespace classi;

use Exception;

require_once __DIR__ . '/GeneratoreProspetti.php';

require_once __DIR__ . '/InvioProspetti.php';

class GUI
{

    public function __construct()
    {
    }

    public static function GeneraProspetti(string $json, $test = null): string
    {
        $dati = json_decode($json, true);

        try {
            $generatore = new GeneratoreProspetti($dati["array_matricole"], $dati["cdl"], $dati["data"]);
            $generatore->generaProspetti($test);
        } catch (Exception $e) {
            http_response_code(500);
            return json_encode(["error" => $e->getMessage(), "success" => false]);
        }

        http_response_code(200);
        return json_encode(["message" => "Prospetti generati", "success" => true]);
    }

    public static function ApriProspetti(string $cdl, string $dataLaurea): string
    {
        $directory = "prospetti_generati" . DIRECTORY_SEPARATOR . $cdl . DIRECTORY_SEPARATOR . $dataLaurea . DIRECTORY_SEPARATOR;
        $nomeFile = "commissione-" . $cdl . "-" . $dataLaurea . ".pdf";
        $percorsoFile = $directory . $nomeFile;

        if (file_exists($percorsoFile)) {
            header('Content-type: application/pdf');
            header('Content-Disposition: inline; filename="prospetti.pdf"');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: ' . filesize($percorsoFile));
            header('Accept-Ranges: bytes');
            readfile($percorsoFile);

            http_response_code(200);
            return json_encode(["success" => true]);
        } else {
            http_response_code(404);
            return json_encode(["error" => "Prospetti non trovati", "success" => false]);
        }
    }

    public static function InviaProspetto(string $json, string $indirizzo_test = null): string
    {
        $dati = json_decode($json, true);

        try {
            $invioMail = new InvioProspetti($dati["matricola"], $dati["cdl"], $dati["data"]);
            $invioMail->inviaProspetto($indirizzo_test);
        } catch (Exception $e) {
            http_response_code(500);
            return json_encode(["error" => $e->getMessage(), "success" => false]);
        }

        http_response_code(200);
        return json_encode(["success" => true]);
    }
}