<?php

namespace classi;

class Simulazione
{
    public float $valoreParametro;
    public float $votoLaurea;

    public function __construct(float $valoreParametro, float $votoLaurea)
    {
        $this->valoreParametro = $valoreParametro;
        $this->votoLaurea = $votoLaurea;
    }
}