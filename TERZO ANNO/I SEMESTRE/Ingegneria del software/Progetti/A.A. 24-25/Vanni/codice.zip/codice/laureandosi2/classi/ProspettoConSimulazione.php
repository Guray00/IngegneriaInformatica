<?php

namespace classi;

require_once __DIR__ . '/../lib/fpdf184/fpdf.php';

use FPDF;

require_once __DIR__ . '/CarrieraLaureando.php';

require_once __DIR__ . '/ProspettoPDFLaureando.php';

require_once __DIR__ . '/SimulazioneVotoLaurea.php';


class ProspettoConSimulazione extends ProspettoPDFLaureando
{

    public function __construct(FPDF $pdf, CarrieraLaureando $carriera)
    {
        $this->prospettoLaureando = $pdf;
        $this->carriera = $carriera;
    }

    public function aggiungiPDFConSimulazione(): void
    {
        $this->generaPDFLaureando();

        $simulazione = new SimulazioneVotoLaurea($this->carriera);

        $padding = 20;
        $larghezzaPagina = $this->prospettoLaureando->GetPageWidth() - $padding;

        $this->aggiungiSimulazione(
            5,
            $larghezzaPagina,
            10,
            $simulazione->parametro,
            $simulazione->simulazioni
        );
    }

    private function aggiungiSimulazione(
        float $altezza,
        int $larghezzaTotale,
        float $dimFont,
        string $parametro,
        array $simulazioni
    ): void {
        $this->prospettoLaureando->SetFont('Arial', '', $dimFont);

        $colonne = min(ceil(count($simulazioni) / 7), 3);
        $righe = ceil(count($simulazioni) / $colonne);
        $larghezzaColonna = $larghezzaTotale / $colonne;
        $larghezzaDati = $larghezzaColonna / 2;

        $simStampate = 0;

        $this->prospettoLaureando->Cell($larghezzaTotale, $altezza, "SIMULAZIONE VOTO DI LAUREA", 1, 1, 'C');

        $xInizio = $this->prospettoLaureando->GetX();
        $yInizio = $this->prospettoLaureando->GetY();

        for ($i = 0; $i < $colonne; $i++) {
            $xCorrente = $xInizio + $larghezzaColonna * $i;
            $yCorrente = $yInizio;

            $this->prospettoLaureando->SetXY($xCorrente, $yCorrente);

            $this->prospettoLaureando->Cell(
                $larghezzaDati,
                $altezza,
                $parametro == "T" ? "VOTO TESI (T)" : "VOTO COMMISSIONE (C)",
                1,
                0,
                'C'
            );
            $this->prospettoLaureando->Cell($larghezzaDati, $altezza, "VOTO LAUREA", 1, 0, 'C');

            $yCorrente += $altezza;
            $this->prospettoLaureando->SetXY($xCorrente, $yCorrente);

            for ($j = 0; $j < $righe; $j++) {
                if ($simStampate >= count($simulazioni)) {
                    break;
                }
                $simulazione = $simulazioni[$simStampate++];
                $this->prospettoLaureando->Cell($larghezzaDati, $altezza, $simulazione->valoreParametro, 1, 0, 'C');
                $this->prospettoLaureando->Cell(
                    $larghezzaDati,
                    $altezza,
                    rtrim(number_format($simulazione->votoLaurea, 3), '0'),
                    1,
                    0,
                    'C'
                );

                $yCorrente += $altezza;
                $this->prospettoLaureando->SetXY($xCorrente, $yCorrente);
            }
        }

        $this->prospettoLaureando->SetXY($xInizio, $yInizio + $altezza * $righe + $altezza);

        $file = file_get_contents(self::$pathCdl);
        $config = json_decode($file, true);
        $msgCommissione = $config[$this->carriera->corsoDiLaurea]['msg_commissione'];

        $this->prospettoLaureando->Ln(5);
        $this->prospettoLaureando->MultiCell($larghezzaTotale, $altezza, $msgCommissione, 0, 1);
    }
}