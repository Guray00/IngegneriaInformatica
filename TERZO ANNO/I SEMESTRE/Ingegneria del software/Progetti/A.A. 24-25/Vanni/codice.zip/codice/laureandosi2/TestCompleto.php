<?php

require_once __DIR__ . DIRECTORY_SEPARATOR . 'classi' . DIRECTORY_SEPARATOR . 'GUI.php';
const INDIRIZZO_TEST = "nome.cognome@studenti.unipi.it"; //INSERIRE QUI UN INDIRIZZO A CUI MANDARE I PROSPETTI
function TestCompleto()
{
    //cancellazione file di test già generati
    if (file_exists("test/generati") && is_dir("test/generati")) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator("test/generati", RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($files as $fileinfo) {
            $todo = ($fileinfo->isDir() ? 'rmdir' : 'unlink');
            $todo($fileinfo->getRealPath());
        }
    }

    //input da testare
    $dati = array(
        (object)array('matricola' => '123456', 'cdl' => 't-inf', 'data' => '2023-01-04'),
        (object)array('matricola' => '234567', 'cdl' => 'm-ele', 'data' => '2023-01-04'),
        (object)array('matricola' => '345678', 'cdl' => 't-inf', 'data' => '2023-01-04'),
        (object)array('matricola' => '456789', 'cdl' => 'm-tel', 'data' => '2023-01-04'),
        (object)array('matricola' => '567890', 'cdl' => 'm-cyb', 'data' => '2023-01-04'),
    );

    //generazione pdf
    foreach ($dati as $d) {
        $input = json_encode(array("array_matricole" => array($d->matricola), "cdl" => $d->cdl, "data" => $d->data));

        if (!file_exists("test/generati/" . $d->matricola)) {
            mkdir("test/generati/" . $d->matricola, 0777, true);
        }

        $res = classi\GUI::GeneraProspetti($input, $d->matricola);
        if (json_decode($res)->success) {
            echo "Generato prospetto per " . $d->matricola . "<br>";
        } else {
            echo "ERRORE durante la generazione per $d->matricola: " . json_decode($res)->error . "<br>";
        }
    }

    echo "<br>";

    //aggiunta dei pulsanti per vedere i pdf
    foreach ($dati as $d) {
        echo '<a href="test/generati/' . $d->matricola . '/commissione-' . $d->cdl . '-' . $d->data . '.pdf">Visualizza prospetto generato per ' . $d->matricola . '</a>';
        echo '    |    ';
        echo '<a href="test/output_giusti/' . $d->matricola . '_output.pdf">Visualizza prospetto giusto per ' . $d->matricola . '</a>';
        echo '<br>';
    }

    echo "<br>";

    //invio dei pdf
    foreach ($dati as $d) {
        $input = json_encode(array("matricola" => $d->matricola, "cdl" => $d->cdl, "data" => $d->data));

        $res = classi\GUI::InviaProspetto($input, INDIRIZZO_TEST);
        if (json_decode($res)->success) {
            echo "Inviato prospetto per " . $d->matricola . "<br>";
            sleep(5);
        } else {
            echo "ERRORE durante l'invio di $d->matricola: " . json_decode($res)->error . "<br>";
        }
    }
}

function apripdf($matricola, $cdl)
{
    echo "aaa";
}

?>

<html>
<head>
    <title>Test completo</title>
</head>
<body>
<h1>Test generazione e invio prospetti</h1><br>
<?php
TestCompleto();
?>

</body>
</html>
