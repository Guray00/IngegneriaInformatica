<?php

namespace classi;

class ElencoEsamiInformatica
{
    private static string $pathElenco = "config/esami_inf.json"; //array di string
    private static ElencoEsamiInformatica $istanza;
    public array $esamiInf;

    private function __construct()
    {
        $this->esamiInf = json_decode(file_get_contents(self::$pathElenco), true);
    }

    public static function instance(): ElencoEsamiInformatica
    {
        if (!isset(self::$istanza)) {
            self::$istanza = new ElencoEsamiInformatica();
        }
        return self::$istanza;
    }
}