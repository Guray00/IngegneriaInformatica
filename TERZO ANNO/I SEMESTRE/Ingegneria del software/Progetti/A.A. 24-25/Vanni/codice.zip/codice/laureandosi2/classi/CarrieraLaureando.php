<?php

namespace classi;

require_once __DIR__ . '/GestioneCarrieraStudente.php';

require_once __DIR__ . '/FiltroEsami.php';

require_once __DIR__ . '/Esame.php';

class CarrieraLaureando
{
    public string $nome;
    public string $cognome;
    public string $emailAteneo;
    public string $matricola;
    public array $esami = []; //array di oggetti Esame
    public string $corsoDiLaurea;
    public string $dataLaurea;


    public function __construct(string $matricola, string $cdl, string $dataLaurea)
    {
        $this->corsoDiLaurea = $cdl;

        //Anagrafica
        $json_anagrafica = GestioneCarrieraStudente::prelevaAnagrafica($matricola);
        $anagrafica = json_decode($json_anagrafica, true);

        $this->nome = $anagrafica["nome"];
        $this->cognome = $anagrafica["cognome"];
        $this->emailAteneo = $anagrafica["email_ate"];
        $this->matricola = $matricola;
        $this->dataLaurea = $dataLaurea;

        //Filtro
        $filtro = new FiltroEsami($matricola, $cdl);

        //Carriera
        $jsonCarriera = GestioneCarrieraStudente::prelevaCarriera($matricola);
        $carriera = json_decode($jsonCarriera, true);
        foreach ($carriera as $esame) {
            if ($esame["MOT_STASTU_COD"] == "IMM") {
                continue;
            }
            if (array_search($esame["DES"], $filtro->esamiDaTogliere) !== false) {
                continue;
            }

            $media = array_search($esame["DES"], $filtro->esamiNonMedia) === false;
            $nuovo_esame = new Esame(
                $esame["DES"], $esame["COD"], $esame["VOTO"], $esame["PESO"], $esame["DATA_ESAME"], $media
            );

            $this->esami[] = $nuovo_esame;
        }

        //Esami in ordine di data
        usort($this->esami, function ($a, $b) {
            return strtotime($a->data) - strtotime($b->data);
        });
    }

    public function mediaPesata(): float
    {
        $somma = 0;
        $crediti = 0;
        foreach ($this->esami as $esame) {
            if ($esame->media) {
                $somma += $esame->voto * $esame->cfu;
                $crediti += $esame->cfu;
            }
        }
        if ($crediti == 0) {
            return 0;
        }
        return $somma / $crediti;
    }

    public function creditiTotali(): int
    {
        $crediti = 0;
        foreach ($this->esami as $esame) {
            $crediti += $esame->cfu;
        }
        return $crediti;
    }

    public function creditiMedia(): int
    {
        $crediti = 0;
        foreach ($this->esami as $esame) {
            if ($esame->media) {
                $crediti += $esame->cfu;
            }
        }
        return $crediti;
    }
}