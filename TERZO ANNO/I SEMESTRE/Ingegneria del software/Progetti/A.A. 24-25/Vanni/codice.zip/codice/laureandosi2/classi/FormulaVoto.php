<?php

namespace classi;

use Exception;

class FormulaVoto
{

    private static string $pathFormule = 'config/cdl.json'; //char
    private static string $caratteriConsentiti = '0123456789+-*/(). MTCFU';
    public string $parametro;
    public float $minVoto;
    public float $maxVoto;
    public float $stepVoto;
    private string $corsoDiLaurea;
    private string $formulaVotoLaurea;

    public function __construct(string $cdl)
    {
        $file = file_get_contents(self::$pathFormule);
        $config = json_decode($file, true);

        if (isset($config[$cdl])) {
            $this->corsoDiLaurea = $cdl;
            if (!self::validaFormula($config[$cdl]['formula'])) {
                throw new Exception('Caratteri non validi nella formula.');
            }
            $this->formulaVotoLaurea = $config[$cdl]['formula'];

            $this->parametro = $this->trovaParametro($config);
            if ($this->parametro === null) {
                throw new Exception("Parametro per il corso di laurea non trovato.");
            }

            $this->minVoto = $config[$cdl]['range_' . $this->parametro]['min'];
            $this->maxVoto = $config[$cdl]['range_' . $this->parametro]['max'];
            $this->stepVoto = $config[$cdl]['range_' . $this->parametro]['step'];
        } else {
            throw new Exception("Configurazione per il corso di laurea non trovata.");
        }
    }

    private static function validaFormula(string $formula): bool
    {
        if (strspn($formula, self::$caratteriConsentiti) != strlen($formula)) {
            return false;
        } else {
            return true;
        }
    }

    private function trovaParametro(mixed $configCdl): string|null
    {
        if ($configCdl[$this->corsoDiLaurea]['range_T']['max'] === 0 && $configCdl[$this->corsoDiLaurea]['range_T']['min'] === 0 && $configCdl[$this->corsoDiLaurea]['range_T']['step'] === 0) {
            return 'C';
        } elseif ($configCdl[$this->corsoDiLaurea]['range_C']['max'] === 0 && $configCdl[$this->corsoDiLaurea]['range_C']['min'] === 0 && $configCdl[$this->corsoDiLaurea]['range_C']['step'] === 0) {
            return 'T';
        } else {
            return null;
        }
    }

    public function valutaFormula(float $media, int $crediti, float $parametro): float|null
    {
        // Individua il parametro che varia
        $commissione = 0;
        $tesi = 0;
        if ($this->parametro == 'C') {
            $commissione = $parametro;
        } else {
            $tesi = $parametro;
        }

        // Sostituisci le variabili con i valori
        $variabili = array(
            'M' => $media,
            'CFU' => $crediti,
            'T' => $tesi,
            'C' => $commissione,
        );

        $formula = $this->formulaVotoLaurea;
        foreach ($variabili as $chiave => $valore) {
            if (!is_numeric($valore)) {
                throw new Exception('Valore della variabile non valido.');
            }
            $formula = str_replace($chiave, $valore, $formula);
        }

        // Valuta la formula
        $risultato = null;
        try {
            eval('$risultato = ' . $formula . ';');
        } catch (Exception $e) {
            throw new Exception('Formula non valida: ' . $e->getMessage());
        }
        return $risultato;
    }
}

