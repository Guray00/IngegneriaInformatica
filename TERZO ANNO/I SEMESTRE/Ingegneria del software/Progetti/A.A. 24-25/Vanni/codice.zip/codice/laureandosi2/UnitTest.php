<?php

require_once __DIR__ . DIRECTORY_SEPARATOR . 'classi' . DIRECTORY_SEPARATOR . 'CarrieraLaureandoInf.php';
use classi\CarrieraLaureandoInf;

require_once __DIR__ . DIRECTORY_SEPARATOR . 'classi' . DIRECTORY_SEPARATOR . 'FormulaVoto.php';
use classi\FormulaVoto;

class UnitTest
{
    public $input;
    public $expectedOutput;
    public $functionToExecute;
    public $actualOutput;

    public function __construct($input, $expectedOutput, $functionToExecute)
    {
        $this->input = $input;
        $this->expectedOutput = $expectedOutput;
        $this->functionToExecute = $functionToExecute;

        echo "Input: " . json_encode($this->input) . " |  Expected output: " . json_encode(
                $this->expectedOutput
            ) . "<br>";
    }

    public function execute($printSuccess = true)
    {
        $this->actualOutput = call_user_func($this->functionToExecute, $this->input);

        if (!$printSuccess) return;

        $success = ($this->actualOutput === $this->expectedOutput);
        echo "Output: " . json_encode(
                $this->actualOutput
            );
        echo '<p style="color: ' . ($success ? 'green' : 'red') . ';">';
        echo $success ? "Success" : "Fail";
        echo '</p>';
        echo "<br>";
    }
}


?>

<html>
<head>
    <title>Unit Tests</title>
</head>
<body>
<h1>Unit Tests</h1><br>
<a id="test" href="TestCompleto.php">Test Completo</a><br>


<h3>Calcolo del bonus</h3>
<?php

function testBonus($dati)
{
    $carriera = new CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    return $carriera->idoneitaBonus;
}

$test = new UnitTest(
    array("matricola" => "123456", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), false, 'testBonus'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-04-30"), true, 'testBonus'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2020-01-01"), true, 'testBonus'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-05-01"), false, 'testBonus'
);
$test->execute();


?>
<br>


<h3>Calcolo della media</h3>
<?php

function testMedia($dati)
{
    if ($dati["cdl"] != "t-inf") {
        $carriera = new classi\CarrieraLaureando($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    } else {
        $carriera = new classi\CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    }
    return round($carriera->mediaPesata(), 3);
}

$test = new UnitTest(
    array("matricola" => "123456", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 23.655, 'testMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "234567", "cdl" => "m-ele", "dataLaurea" => "2023-01-01"), 24.559, 'testMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 25.564, 'testMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "456789", "cdl" => "m-tel", "dataLaurea" => "2023-01-01"), 32.625, 'testMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "567890", "cdl" => "m-cyb", "dataLaurea" => "2023-01-01"), 24.882, 'testMedia'
);
$test->execute();

?>

<h3>Calcolo della media di informatica</h3>
<?php

function testMediaInf($dati)
{
    $carriera = new classi\CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    return round($carriera->mediaPesata(), 3);
}

$test = new UnitTest(
    array("matricola" => "123456", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 23.655, 'testMediaInf'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "123456", "cdl" => "t-inf", "dataLaurea" => "2020-01-01"), 23.909, 'testMediaInf'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 25.564, 'testMediaInf'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-05-01"), 25.172, 'testMediaInf'
);
$test->execute();

?>

<h3>Calcolo dei crediti totali</h3>
<?php

function testCrediti($dati)
{
    if ($dati["cdl"] != "t-inf") {
        $carriera = new classi\CarrieraLaureando($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    } else {
        $carriera = new classi\CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    }
    return $carriera->creditiTotali();
}

$test = new UnitTest(
    array("matricola" => "123456", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 177, 'testCrediti'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "234567", "cdl" => "m-ele", "dataLaurea" => "2023-01-01"), 102, 'testCrediti'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 177, 'testCrediti'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "456789", "cdl" => "m-tel", "dataLaurea" => "2023-01-01"), 96, 'testCrediti'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "567890", "cdl" => "m-cyb", "dataLaurea" => "2023-01-01"), 120, 'testCrediti'
);
$test->execute();

?>

<h3>Calcolo dei crediti che fanno media</h3>
<?php

function testCreditiMedia($dati)
{
    if ($dati["cdl"] != "t-inf") {
        $carriera = new classi\CarrieraLaureando($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    } else {
        $carriera = new classi\CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    }
    return $carriera->creditiMedia();
}

$test = new UnitTest(
    array("matricola" => "123456", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 174, 'testCreditiMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "123456", "cdl" => "t-inf", "dataLaurea" => "2020-01-01"), 165, 'testCreditiMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "234567", "cdl" => "m-ele", "dataLaurea" => "2023-01-01"), 102, 'testCreditiMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-01-01"), 165, 'testCreditiMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "345678", "cdl" => "t-inf", "dataLaurea" => "2023-05-01"), 174, 'testCreditiMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "456789", "cdl" => "m-tel", "dataLaurea" => "2023-01-01"), 96, 'testCreditiMedia'
);
$test->execute();

$test = new UnitTest(
    array("matricola" => "567890", "cdl" => "m-cyb", "dataLaurea" => "2023-01-01"), 102, 'testCreditiMedia'
);
$test->execute();

?>

<h3>Formula voto di laurea</h3>
<?php
function testFormula($dati)
{
    $formula = new FormulaVoto($dati["cdl"]);
    $res = $formula->valutaFormula($dati["media"], $dati["crediti"], $dati["parametro"]);
    return round($res,3);
}

$test = new UnitTest(
    array("cdl" => "t-inf", "media" => "24", "crediti" => "0", "parametro" => "1"), 91.0, 'testFormula'
);
$test->execute();

$test = new UnitTest(
    array("cdl" => "t-inf", "media" => "24", "crediti" => "0", "parametro" => "5"), 95.0, 'testFormula'
);
$test->execute();

$test = new UnitTest(
    array("cdl" => "t-inf", "media" => "30", "crediti" => "0", "parametro" => "7"), 115.0, 'testFormula'
);
$test->execute();

$test = new UnitTest(
    array("cdl" => "t-bio", "media" => "24", "crediti" => "177", "parametro" => "18"), 96.761, 'testFormula'
);
$test->execute();

$test = new UnitTest(
    array("cdl" => "t-bio", "media" => "27.17", "crediti" => "177", "parametro" => "27.17"), 110.0, 'testFormula'
);
$test->execute();

$test = new UnitTest(
    array("cdl" => "t-ele", "media" => "24", "crediti" => "177", "parametro" => "18"), 97.6, 'testFormula'
);
$test->execute();

$test = new UnitTest(
    array("cdl" => "t-ele", "media" => "27", "crediti" => "177", "parametro" => "27"), 110.0, 'testFormula'
);
$test->execute();

$test = new UnitTest(
    array("cdl" => "m-ele", "media" => "27.5", "crediti" => "102", "parametro" => "27.5"), 110.0, 'testFormula'
);
$test->execute();

?>

</body>
</html>
