#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

void handler(int sig) {
	printf("Segnale %d ricevuto\n", sig);
	sleep(2);
}

int main() {
	signal(SIGINT, handler);
	
	while(1) {
		printf("hi!\n");
	}
}

/***********************************************
-- Per trovare il PID da terminale: "ps u"
-- Per terminare il processo usare: "kill PID"
************************************************/
