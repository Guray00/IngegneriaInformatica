#include<fcntl.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#define BUF_SIZE 128

int main() {
	int fd[2];
	if (pipe(fd) != 0) {
		perror("Errore nella pipe\n");
		exit(-1);
	}

	char buffer[BUF_SIZE];
	pid_t pid;
	pid = fork();
	if (pid == 0) {
		// Figlio.
		close(fd[1]); // non devo scrivere nella pipe
		ssize_t nread;
		while((nread = read(fd[0], buffer, sizeof(buffer)-1)) > 0) {
			buffer[nread] = '\0';
			printf("%s", buffer);
		}
		close(fd[0]);
		if (nread < 0) {
			perror("Errore nella read\n");
			exit(-1);
		}
		printf("Figlio: ho terminato\n");
		exit(0);
	}
	// Padre.
	close(fd[0]); // non devo leggere dalla pipe.
	sleep(3);
	char msg[] = "Hello world!\n";
	ssize_t written = write(fd[1], msg, strlen(msg));
	close(fd[1]);
	if (written != strlen(msg)) {
		perror("Errore nella write!\n");
		exit(-1);
	}
	exit(0);
}

