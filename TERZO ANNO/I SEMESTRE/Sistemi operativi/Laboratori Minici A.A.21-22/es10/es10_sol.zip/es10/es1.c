#include<fcntl.h>
#include<stdlib.h>
#include<stdio.h>

#define BUF_SIZE 128

int main() {
	int fd = open("leggi.txt", O_RDONLY);
	char buffer[BUF_SIZE];
	pid_t pid;
	pid = fork();
	if (pid == 0) {
		// Figlio.
//		close(fd);
//		fd = open("leggi.txt", O_RDONLY);
		ssize_t nread = read(fd, buffer, 2);
		close(fd);
		if (nread != 2) {
			perror("Errore nella read\n");
			exit(1);
		}
		buffer[2] = '\0'; // terminate string.
		printf("%s", buffer);
		exit(0);
	}
	// Padre.
	sleep(3);
	ssize_t nread;
	while((nread=read(fd, buffer,sizeof(buffer)-1)) > 0){
		buffer[nread] = '\0';
		printf("%s", buffer);
	}		
	close(fd);
	if (nread < 0) {
		perror("Errore nella read\n");
		exit(1);
	}
	exit(0);
}

