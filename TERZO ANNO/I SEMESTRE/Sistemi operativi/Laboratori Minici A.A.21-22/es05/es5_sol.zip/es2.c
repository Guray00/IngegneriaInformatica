#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#define NCHILDREN 3

int main()
{
	pid_t pid;
	int children = 0;

	// creation loop
	while (1) {
		children++;
		pid = fork();
		if (pid == 0) {
			// child process
			printf("Sono il figlio %d\n", getpid());
			// int a = 1/0; // uncomment this line to cause child's abnormal termination.
			exit(1);
		}
		else if (pid > 0) {
			// parent process
			// generate up to NCHILDREN processes
			if (children < NCHILDREN)
				continue;
		
		    // wait for all the children
		    while (1) {
				int status;
				pid_t term_child = wait(&status); // returns pid of terminated child
				if (term_child < 0)
					break;	// no more children left
			    if (WIFEXITED(status)) {
				    printf("Terminazione di %d volontaria\n", term_child);
				    printf("Stato di terminazione: %d\n", WEXITSTATUS(status));
				}
				else
					printf("Terminazione di %d involontaria\n", term_child);
			}
			exit(0);
		} 
		else { 
			printf("Creazione fallita!\n");
			exit(1);
		}
	}
}
