#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>

int main()
{
	pid_t pid;
	pid = fork();
	if (pid == 0) {
		// child process
		printf("Sono %d, figlio del processo %d\n", getpid(), getppid());
	}
	else if (pid > 0) {
		// parent process
		printf("Sono il padre, il PID di mio figlio e' %d\n", pid);
	}
	else 
		printf("Creazione fallita!\n");
	exit(0);
}