#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char** argv)
{
	pid_t pid;
	pid = fork();

	if (pid == 0) {
		// child
		printf("Sono il figlio %d.\n", getpid());
		char* argument = (argc > 1) ? argv[1] : NULL;
		execl("/bin/ls", "ls", "-l", argument, NULL);
		printf("Errore nella exec\n");
		exit(1);
	}
	else if (pid > 0) {		
		// parent 
		int status;
		pid_t term_child = wait(&status);
		printf("Terminato figlio %d\n", term_child);
		if (WIFEXITED(status)) {
			printf("Terminazione di %d volontaria\n", term_child);
			printf("Stato di terminazione: %d\n", WEXITSTATUS(status));
		}
		else
			printf("Terminazione di %d involontaria\n", term_child);
			
		exit(0);
	}
	else printf("Creazione fallita!\n");
}

