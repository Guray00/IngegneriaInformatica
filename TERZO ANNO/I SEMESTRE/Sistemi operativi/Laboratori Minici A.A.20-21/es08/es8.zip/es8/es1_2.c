#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define NTHREADS 4

// variabile globale per "condividere" l'ID del padre con i thread figli
pthread_t father; 

/* Corpo del thread */
void* tr_code(void * arg) 
{
	int id = *(int*)arg;
	for (int i=0; i<4; i++) {
  		printf("Hello World! My arg is %d\n", id);
		sleep(id);
  	}
  	// Il secondo figlio deve chiamare la funzione join utilizzando l'ID
  	// del padre.
  	if (id == 2) {
  		int retjoin = pthread_join(father, NULL);
  		if (retjoin != 0)
  			printf("Sono %d, Errore nella join, codice %d\n", id, retjoin);
		else
			printf("Sono %d, Join OK\n", id);
  	}
  	free(arg);
	pthread_exit(NULL);
}

int main ()
{
	pthread_t tr[NTHREADS];
	int* args[NTHREADS];
	father = pthread_self();
	int ret;
	for (int i=0; i<NTHREADS; i++) {
		args[i] = (int*)malloc(sizeof(int));
		*args[i] = i+1; // l'esercizio chiede di usare un ID da 1 a NTHREADS
	   ret = pthread_create(&tr[i], NULL, tr_code, args[i]);
	   if (ret){
	   	   printf("Error: return code from pthread_create is %d\n", ret);
		   exit(-1);
  	   }
	}
	// Il padre chiama la funzione join "in attesa" del secondo figlio.
	int retjoin = pthread_join(tr[1], NULL);
	if (retjoin != 0)
		printf("Errore nella join, codice %d\n", retjoin);
	else
		printf("Join OK\n");

	pthread_exit(NULL);
}
