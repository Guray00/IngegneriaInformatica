#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define NTHREADS 12

int cont = 0;
pthread_mutex_t M;

/* Corpo del thread */
void* tr_code(void * arg) 
{
	int id = *(int*)arg;
	for (int i=0; i<100000; i++) {
		pthread_mutex_lock(&M);
  		cont++;
  		printf("Hello World! My arg is %d and cont is %d\n", id, cont);
  		pthread_mutex_unlock(&M);

  		// Nota: la printf e' all'interno della "sezione critica" perche' 
  		// utilizza cont e vogliamo essere sicuri che il valore stampato sia
  		// effettivamente cont++ (se mettiamo la prinft fuori dai lock, un
  		// altro processo potrebbe "inserirsi" tra la cont++ e printf).
  	}
  	free(arg);
	pthread_exit(NULL);
}

int main ()
{
	pthread_mutex_init(&M, NULL);
	pthread_t tr[NTHREADS];
	int* args[NTHREADS];	
	int ret;
	for (int i=0; i<NTHREADS; i++) {
		args[i] = (int*)malloc(sizeof(int));
		*args[i] = i+1; // l'esercizio chiede di usare un ID da 1 a NTHREADS
		ret = pthread_create(&tr[i], NULL, tr_code, args[i]);
		if (ret){
			printf("Error: return code from pthread_create is %d\n", ret);
			exit(-1);
		}
	}

	pthread_exit(NULL);
}
