#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define NTHREADS 4


/* Corpo del thread */
void* tr_code(void * arg) 
{
	int id = *(int*)arg;
	for (int i=0; i<4; i++) {
  		printf("Hello World! My arg is %d\n", id);
		sleep(id);
  	}
  	free(arg);
	pthread_exit(NULL);
}

int main ()
{
	pthread_t tr[NTHREADS];
	int* args[NTHREADS];
	int ret;
	for (int i=0; i<NTHREADS; i++) {
		args[i] = (int*)malloc(sizeof(int));
		*args[i] = i+1; // l'esercizio chiede di usare un ID da 1 a NTHREADS
		ret = pthread_create(&tr[i], NULL, tr_code, args[i]);
		if (ret){
		   printf("Error: return code from pthread_create is %d\n", ret);
		   exit(-1);
		}
	}

	pthread_exit(NULL);
}
