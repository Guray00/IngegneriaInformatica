#include "costanti.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> //struttura sockaddr_in e htons()
#include <arpa/inet.h> //funzioni di conversione, inet_pton()
#include <unistd.h> //primitiva close()
#include <errno.h>
#include <stdbool.h>

//struttura di appoggio nel client per la gestione dei temi
struct temi
{
    char nome[NAME_LEN];
    bool svolto; //falso se da svolgere
};

//permette all'utente di inserire un input all'interno di stdin
void inserimento (char *buf, int dim);

void stampa_menu();

void stampa_temi(struct temi *elenco_temi);

//funzione che gestisce gli errori dovuti alla recv, in particolare la disconnessione del server
void gestione_recv (int ret, int sock);

//funzione che gestisce gli errori dovuti alla send, in particolare la disconnessione del server
void gestione_send (int sock);

//funzione che implementa il lato client di show score
void mostra_classifica(int sock);