#define NAME_LEN 20 //lunghezza nomi giocatori e temi
#define DOM_LEN  100 //lunghezza domande
#define RIS_LEN 30 //lunghezza risposte
#define N_TEMI 2 //numero temi
#define DIM_CLASSIFICA 1000 //dimensione del buffer utilizzato per show score