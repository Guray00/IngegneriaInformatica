#include "libclient.h"

//permette all'utente di inserire un input all'interno di stdin
void inserimento (char *buf, int dim)
{
    if (fgets(buf, dim, stdin) != NULL) 
    {
        size_t len = strlen(buf);
        //rimuove il newline se presente
        if (len > 0 && buf[len - 1] == '\n') 
            buf[len - 1] = '\0';
        //nel caso il newline non sia presente vuol dire che fgets ha letto più caratteri di dim
        //ripulisce residui in stdin nel caso siano stati inseriti troppi caratteri
        else
        {
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF);
        }
    }
}

void stampa_menu()
{
    system("clear");
    printf("Trivia quiz\n");
    printf("+++++++++++++++++++++++++++++++++++\n");
    printf("Menù:\n");
    printf("1 - Comincia una sessione di Trivia\n");
    printf("2 - Esci\n");
    printf("+++++++++++++++++++++++++++++++++++\n");
    printf("La tua scelta: \n");
}

void stampa_temi(struct temi *elenco_temi)
{
    printf("\nQuiz disponibili\n");
    printf("+++++++++++++++++++++++++++++++++++\n");
    for(int i = 0; i < N_TEMI; i++)
    {
        if(!elenco_temi[i].svolto)
            printf("%d- %s\n", i+1, elenco_temi[i].nome);
    }
    printf("+++++++++++++++++++++++++++++++++++\n");
}

//funzione che gestisce gli errori dovuti alla recv, in particolare la disconnessione del server
void gestione_recv (int ret, int sock)
{
    if(ret == 0 || (ret == -1 && errno == ECONNRESET))
    {
        printf("\nIl server si è disconnesso, chiusura dell'applicazione\n");
        close(sock);
        exit(0);
    }
    else
    {
        perror("Errore nella recv");
        close(sock);
        exit(EXIT_FAILURE);
    }    
}

//funzione che gestisce gli errori dovuti alla send, in particolare la disconnessione del server
void gestione_send (int sock)
{
    if(errno == EPIPE || errno == ECONNRESET)
    {
        printf("\nIl server si è disconnesso, chiusura dell'applicazione\n");
        close(sock);
        exit(0);
    }
    else
    {
        perror("Errore nella send");
        close(sock);
        exit(EXIT_FAILURE);
    }
}

//funzione che implementa il lato client di show score
void mostra_classifica(int sock)
{
    char buf[DIM_CLASSIFICA];
    u_int16_t dim;
    int ret;

    //il comando viene inviato al server in modo che richiami la sua funzione di gestione per show score
    if(send(sock, (void*)"show score", 11, MSG_NOSIGNAL) == -1)
        gestione_send(sock);

    //si riceve la dimensione della classifica
    if((ret = recv(sock, &dim, sizeof(u_int16_t), 0)) <= 0)
        gestione_recv(ret, sock);
    dim = ntohs(dim);

    //si riceve e stampa la classifica
    if((ret = recv(sock, (void*)buf, dim, 0)) <= 0)
        gestione_recv(ret, sock);
    printf("\n%s", buf);
}