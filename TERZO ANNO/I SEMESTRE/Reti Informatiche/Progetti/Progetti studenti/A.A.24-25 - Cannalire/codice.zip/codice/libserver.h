#include "costanti.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> //struttura sockaddr_in e htons()
#include <arpa/inet.h> //funzioni di conversione, inet_pton()
#include <unistd.h> //primitiva close()
#include <errno.h>
#include <pthread.h>
#include <stdbool.h>

struct giocatore
{
    char nome[NAME_LEN];
    bool attivo; //flag che indica se il giocatore sia attualmente connesso al server
    bool temi_svolti[N_TEMI]; //vettore di flag che indica i temi svolti dal giocatore
    bool temi_completati[N_TEMI]; //vettore di flag che indica i temi completati dal giocatore
    struct giocatore *next; //successivo nella lista
};

//struttura per creare le liste di giocatori che hanno completato un tema
struct quiz_completato
{
    char nome[NAME_LEN];
    struct quiz_completato *next;
};

//struttura con la quale si implementano le classifiche
struct punteggi
{
    char nome[NAME_LEN];
    int punti;
};

struct temi
{
    const char *nome;
    int n_giocatori; //numero di giocatori presenti nella classifica
    struct punteggi *classifica;
    struct quiz_completato *giocatori_completato;
    const char *domande; //path delle domande
    const char *risposte; //path delle risposte
    pthread_mutex_t mutex; //mutex per l'accesso alla classifica e alla lista
};

//restituisce false nel caso un giocatore si fosse già registrato con quel nome
bool cerca_giocatore(struct giocatore *lista_giocatori, char *nome, pthread_mutex_t *mutex_giocatori);

//i nuovi giocatori vengono inseriti in testa alla lista
struct giocatore* nuovo_giocatore(struct giocatore **lista_giocatori, char *nome, int *giocatori_tot, pthread_mutex_t *mutex_giocatori);

//inizializza la struttura temi assegnando nomi, path e impostando gli altri campi
void inizializza_temi(struct temi *elenco_temi);

//permette di selezionare il tema a cui il giocatore deve rispondere
void scegli_tema(struct giocatore *giocatore, int numero_tema, struct temi *elenco_temi);

//viene usata nella qsort per effettuare un ordinamento decrescente dei punteggi
int compare(const void* a, const void* b);

//incrementa il punteggio associato al nome del giocatore per il tema selezionato
void incrementa_punteggio(char *nome, int numero_tema, struct temi *elenco_temi);

//effettua le operazioni che seguono al completamento di un tema da parte del giocatore
void tema_completato(struct giocatore *giocatore, int numero_tema, struct temi *elenco_temi);

//rimuove il giocatore da tutte le classifiche e dagli elenchi dei temi completati e rende il giocatore inattivo
void rimuovi_giocatore(struct giocatore *giocatore, struct temi *elenco_temi, int *giocatori_tot);

void stampa_interfaccia(struct temi *elenco_temi, struct giocatore *lista_giocatori, int giocatori_tot, pthread_mutex_t *mutex_giocatori);

//funzione che gestisce gli errori dovuti alla recv, in particolare la disconnessione del client
void gestione_recv (int ret, int client_sock, struct giocatore *g, struct giocatore *lista_giocatori, struct temi *elenco_temi, int *giocatori_tot, pthread_mutex_t *mutex_giocatori);

//funzione che gestisce gli errori dovuti alla send, in particolare la disconnessione del client
void gestione_send (int client_sock, struct giocatore *g, struct giocatore *lista_giocatori, struct temi *elenco_temi, int *giocatori_tot, pthread_mutex_t *mutex_giocatori);

//lato server della funzione che implementa il comando show score
void manda_classifica(int client_sock, struct giocatore *g, struct giocatore *lista_giocatori, struct temi *elenco_temi, int *giocatori_tot, pthread_mutex_t *mutex_giocatori);