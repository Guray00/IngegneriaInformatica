#include "libserver.h"

//lista giocatori globale
struct giocatore *lista_giocatori;
int giocatori_tot = 0;
pthread_mutex_t mutex_giocatori;

//lista globale dei temi
struct temi elenco_temi[N_TEMI];

void* th_fun(void *arg)
{
    //comunicazione col client
    int client_sock = *(int*)arg;
    char buf[DOM_LEN];
    int ret;

    //gioco
    struct giocatore *g = NULL;
    int tema_scelto;
    int n_temi = N_TEMI;

    //domande e risposte
    FILE *domfp;
    FILE *risfp;
    char ris[RIS_LEN];
    int counter;

    free(arg);

    //scelta del nickname
    do
    {
        if((ret = recv(client_sock, (void*)buf, NAME_LEN, 0)) <= 0)
        //if((ret = recv(client_sock, (void*)buf, 11, 0)) <= 0)
            gestione_recv(ret, client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);

        //comando show score
        if(strcmp(buf, "show score") == 0)
        {
            manda_classifica(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
            continue;
        }
        //si verifica che il nome non sia già stato usato all'interno del server
        if(cerca_giocatore(lista_giocatori, buf, &mutex_giocatori))
        {
            //nome valido, si aggiunge il giocatore nel server
            g = nuovo_giocatore(&lista_giocatori, buf, &giocatori_tot, &mutex_giocatori);
            stampa_interfaccia(elenco_temi, lista_giocatori, giocatori_tot, &mutex_giocatori);

            //si invia una risposta che il client interpreterà come esito positivo
            if(send(client_sock, &(bool){true}, sizeof(bool), MSG_NOSIGNAL) == -1)
                gestione_send(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);

            break;
        }
        else
        {
            //si invia una risposta che il client interpreterà come esito negativo
            if(send(client_sock, &(bool){false}, sizeof(bool), MSG_NOSIGNAL) == -1)
                gestione_send(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
        }
    } while (true);

    //invio dei nomi dei temi
    for(int i = 0; i < N_TEMI; i++)
    {
        if(send(client_sock, (void*)elenco_temi[i].nome, NAME_LEN, MSG_NOSIGNAL) == -1)
            gestione_send(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
    }

    //si esce da questo ciclo quando non ci sono più temi da svolgere
    do
    {    
        //si esce da questo ciclo quando viene scelto un tema
        do
        {
            //scelta del tema
            if((ret = recv(client_sock, (void*)buf, RIS_LEN, 0)) <= 0)
                gestione_recv(ret, client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);

            //comando show score
            if(strcmp(buf, "show score") == 0)
                manda_classifica(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
            else
                break;            
        } while (true);

        //il giocatore viene aggiunto alla classifica del tema
        tema_scelto = atoi(buf);
        scegli_tema(g, tema_scelto, elenco_temi);
        stampa_interfaccia(elenco_temi, lista_giocatori, giocatori_tot, &mutex_giocatori);

        //apertura dei relativi file di domande e risposte
        domfp = fopen(elenco_temi[tema_scelto].domande, "r");
        risfp = fopen(elenco_temi[tema_scelto].risposte, "r");

        //domande e risposte
        counter = 0;
        while(counter < 5)
        {
            //lettura e invio della domanda
            fgets(buf, DOM_LEN, domfp);
            buf[strcspn(buf, "\r\n")] = '\0';
            if(send(client_sock, (void*)buf, DOM_LEN, MSG_NOSIGNAL) == -1)
                gestione_send(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);

            //si esce dal ciclo quando si riceve una risposta alla domanda
            do
            {
                //ricezione della risposta
                if((ret = recv(client_sock, (void*)buf, RIS_LEN, 0)) <= 0)
                    gestione_recv(ret, client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);

                //comando show score
                if(strcmp(buf, "show score") == 0)
                    manda_classifica(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
                else
                {
                    counter++;
                    break;
                }
            } while (true);
            
            //lettura da file della risposta
            fgets(ris, RIS_LEN, risfp);
            ris[strcspn(ris, "\r\n")] = '\0';

            //esito
            if(strcmp(buf, ris) == 0)
            {
                //risposta corretta
                if(send(client_sock, &(bool){true}, sizeof(bool), MSG_NOSIGNAL) == -1)
                    gestione_send(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
                //si aggiornano le classifiche
                incrementa_punteggio(g->nome, tema_scelto, elenco_temi);
                stampa_interfaccia(elenco_temi, lista_giocatori, giocatori_tot, &mutex_giocatori);
            }
            else
            {
                //risposta errata
                if(send(client_sock, &(bool){false}, sizeof(bool), MSG_NOSIGNAL) == -1)
                    gestione_send(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
                //invio risposta corretta
                if(send(client_sock, (void*)ris, RIS_LEN, MSG_NOSIGNAL) == -1)
                    gestione_send(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
            }
        }

        //chiusura dei relativi file di domande e risposte
        fclose(domfp);
        fclose(risfp);

        //aggiunta all'elenco dei giocatori che hanno completato il tema
        tema_completato(g, tema_scelto, elenco_temi);
        stampa_interfaccia(elenco_temi, lista_giocatori, giocatori_tot, &mutex_giocatori);

        n_temi--;
    } while (n_temi > 0);

    //il giocatore può ancora vedere le classifiche anche se ha terminato i quiz da svolgere
    do
    {
        //ricezione della risposta
        if((ret = recv(client_sock, (void*)buf, RIS_LEN, 0)) <= 0)
            gestione_recv(ret, client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
        //comando show score
        if(strcmp(buf, "show score") == 0)
            manda_classifica(client_sock, g, lista_giocatori, elenco_temi, &giocatori_tot, &mutex_giocatori);
    } while (true);
}

int main()
{
    //socket e indirizzi
    int serv_sock, new_sock;
    struct sockaddr_in my_addr, client_addr;

    //thread
    int *arg;
    pthread_t th;

    //inizializzazione semaforo
    pthread_mutex_init(&mutex_giocatori, NULL);

    //inizializzazione temi
    inizializza_temi(elenco_temi);

    //inizializzazione lista dei giocatori
    lista_giocatori = NULL;

    //creazione del socket
    if((serv_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("Errore, socket non creato");
        exit(EXIT_FAILURE);
    }

    //configurazione di indirizzo e porta del socket
    memset(&my_addr, 0, sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(3456);
    inet_pton(AF_INET, "127.0.0.1", &my_addr.sin_addr);
    if(bind(serv_sock, (struct sockaddr*)&my_addr, sizeof(my_addr)) == -1)
    {
        perror("Errore, impossibile legare socket all'indirizzo");
        close(serv_sock);
        exit(EXIT_FAILURE);
    }

    //messa in ascolto del socket
    if(listen(serv_sock, 10) == -1)
    {
        perror("Errore in ascolto");
        close(serv_sock);
        exit(EXIT_FAILURE);
    }
    printf("Server in ascolto\n");

    stampa_interfaccia(elenco_temi, lista_giocatori, giocatori_tot, &mutex_giocatori);

    while(true)
    {
        socklen_t addr_len = sizeof(client_addr);

        //accettazione della connessione con un nuovo client
        if((new_sock = accept(serv_sock, (struct sockaddr*)&client_addr, &addr_len)) == -1)
        {
            perror("Errore, connessione non accettata");
            continue;
        }
        printf("Connessione con socket %d accettata\n", new_sock);

        //creazione di un thread che si occupi del dialogo col nuovo client
        arg = malloc(sizeof(int));
        *arg = new_sock;
        if(pthread_create(&th, NULL, th_fun, (void*)arg) != 0)
        {
            perror("Errore nella creazione del thread\n");
            close(new_sock);
        }
    }

    return 0;
}