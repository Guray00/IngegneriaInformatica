#include "libserver.h"

//restituisce false nel caso un giocatore si fosse già registrato con quel nome
bool cerca_giocatore(struct giocatore *lista_giocatori, char *nome, pthread_mutex_t *mutex_giocatori)
{
    bool ret = true;

    //mutua esclusione
    pthread_mutex_lock(mutex_giocatori);

    struct giocatore *g = lista_giocatori;

    //si scorre l'elenco dei giocatori per verificare se il nickname sia stato già usato
    while(g)
    {
        if(strcmp(g->nome, nome) == 0)
            ret = false;
        g = g->next;
    }

    //mutua esclusione
    pthread_mutex_unlock(mutex_giocatori);

    return ret;
}

//i nuovi giocatori vengono inseriti in testa alla lista
struct giocatore* nuovo_giocatore(struct giocatore **lista_giocatori, char *nome, int *giocatori_tot, pthread_mutex_t *mutex_giocatori)
{
    struct giocatore *nuovo_giocatore = malloc(sizeof(struct giocatore));
    
    strcpy(nuovo_giocatore->nome, nome);
    nuovo_giocatore->attivo = true;
    for(int i = 0; i < N_TEMI; i++)
        nuovo_giocatore->temi_svolti[i] = false;
    for(int i = 0; i < N_TEMI; i++)
        nuovo_giocatore->temi_completati[i] = false;

    //mutua esclusione
    pthread_mutex_lock(mutex_giocatori);

    nuovo_giocatore->next = *lista_giocatori;
    *lista_giocatori = nuovo_giocatore;

    //mutua esclusione
    pthread_mutex_unlock(mutex_giocatori);

    //incremento del numero di giocatori attivi nel server
    (*giocatori_tot)++;

    return nuovo_giocatore;
}

//inizializza la struttura temi assegnando nomi, path e impostando gli altri campi
void inizializza_temi(struct temi *elenco_temi)
{
    char *nomi[N_TEMI]= {"Scuderia Ferrari", "Formula 1"};
    char *path_domande[N_TEMI] = {"domande&risposte/dom0.txt", "domande&risposte/dom1.txt"};
    char *path_risposte[N_TEMI] = {"domande&risposte/ris0.txt", "domande&risposte/ris1.txt"};
    struct temi *tema;

    for(int i = 0; i < N_TEMI; i++)
    {
        tema = &elenco_temi[i];
        tema->nome = nomi[i];
        tema->n_giocatori = 0;
        tema->classifica = NULL;
        tema->giocatori_completato = NULL;
        tema->domande = path_domande[i];
        tema->risposte = path_risposte[i];
        pthread_mutex_init(&tema->mutex, NULL);
    }
}

//permette di selezionare il tema a cui il giocatore deve rispondere
void scegli_tema(struct giocatore *giocatore, int numero_tema, struct temi *elenco_temi)
{
    struct temi *tema = &elenco_temi[numero_tema];

    //mutua esclusione
    pthread_mutex_lock(&tema->mutex);

    //incremento del numero di giocatori presenti nella classifica del tema
    tema->n_giocatori++;

    //array che conterrà la nuova classifica dei giocatori
    struct punteggi *nuova_classifica = malloc(sizeof(struct punteggi)*tema->n_giocatori);

    if(tema->classifica) //nel caso esistesse già una classifica allora devono essere copiati i precedenti punteggi
    {
        for(int i = 0; i < tema->n_giocatori - 1; i++)
        {
            strcpy(nuova_classifica[i].nome, tema->classifica[i].nome);
            nuova_classifica[i].punti = tema->classifica[i].punti;
        }
    }

    //aggiunta del nuovo giocatore alla classifica
    strcpy(nuova_classifica[tema->n_giocatori - 1].nome, giocatore->nome);
    nuova_classifica[tema->n_giocatori - 1].punti = 0;

    //si associa la nuova classifica al descrittore del tema
    free(tema->classifica);
    tema->classifica = nuova_classifica;

    //mutua esclusione
    pthread_mutex_unlock(&tema->mutex);

    //si setta il flag all'interno del descrittore del giocatore per indicare che il tema è stato svolto
    giocatore->temi_svolti[numero_tema] = true;
}

//viene usata nella qsort per effettuare un ordinamento decrescente dei punteggi
int compare(const void* a, const void* b) 
{
    struct punteggi p_a, p_b;
    p_a = *(struct punteggi*)a;
    p_b = *(struct punteggi*)b;

    return (p_b.punti - p_a.punti);
}

//incrementa il punteggio associato al nome del giocatore per il tema selezionato
void incrementa_punteggio(char *nome, int numero_tema, struct temi *elenco_temi)
{
    struct temi *tema = &elenco_temi[numero_tema];

    //mutua esclusione
    pthread_mutex_lock(&tema->mutex);

    //ciclo che effettua la ricerca col nome
    for(int i = 0; i < tema->n_giocatori; i++)
    {
        if(strcmp(nome, tema->classifica[i].nome) == 0)
        {
            tema->classifica[i].punti++;
            //in seguito all'incremento la classifica potrebbe essere cambiata e quindi deve essere riordinata
            qsort(tema->classifica, tema->n_giocatori, sizeof(struct punteggi), compare);
            break;
        }
    }

    //mutua esclusione
    pthread_mutex_unlock(&tema->mutex);
}

//effettua le operazioni che seguono al completamento di un tema da parte del giocatore
void tema_completato(struct giocatore *giocatore, int numero_tema, struct temi *elenco_temi)
{
    struct temi *tema = &elenco_temi[numero_tema];

    //mutua esclusione
    pthread_mutex_lock(&tema->mutex);

    //si aggiunge il giocatore all'elenco dei partecipanti che hanno concluso il tema
    struct quiz_completato *nuovo_giocatore = malloc(sizeof(struct quiz_completato));
    strcpy(nuovo_giocatore->nome, giocatore->nome);
    nuovo_giocatore->next = tema->giocatori_completato;
    tema->giocatori_completato = nuovo_giocatore;

    //mutua esclusione
    pthread_mutex_unlock(&tema->mutex);

    //si setta il flag all'interno del descrittore del giocatore per indicare che il tema è stato completato
    giocatore->temi_completati[numero_tema] = true;
}

//rimuove il giocatore da tutte le classifiche e dagli elenchi dei temi completati e rende il giocatore inattivo
void rimuovi_giocatore(struct giocatore *giocatore, struct temi *elenco_temi, int *giocatori_tot)
{
    for(int i = 0; i < N_TEMI; i++)
    {
        if(!giocatore->temi_svolti[i])
            continue;
        
        struct temi *tema = &elenco_temi[i];

        //mutua esclusione
        pthread_mutex_lock(&tema->mutex);

        //decremento del numero di giocatori presenti nella classifica del tema
        tema->n_giocatori--;
    
        //array che conterrà la nuova classifica dei giocatori
        struct punteggi *nuova_classifica = malloc(sizeof(struct punteggi)*tema->n_giocatori);
    
        //si ricopiano nel nuovo array i punteggi dei giocatori diversi da quello da rimuovere
        for(int l = 0, j = 0; l <= tema->n_giocatori; l++)
        {
            if(strcmp(giocatore->nome, tema->classifica[l].nome) == 0)
                continue;

            strcpy(nuova_classifica[j].nome, tema->classifica[l].nome);
            nuova_classifica[j].punti = tema->classifica[l].punti;
            j++;
        }
    
        //si associa la nuova classifica al descrittore del tema
        free(tema->classifica);
        tema->classifica = nuova_classifica;

        if(giocatore->temi_completati[i])
        {
            //si rimuove il giocatore dall'elenco dei giocatori che hanno completato il tema
            struct quiz_completato *avanti, *dietro;
            avanti = tema->giocatori_completato;
            dietro = NULL;
            while(avanti)
            {
                if(strcmp(giocatore->nome, avanti->nome) == 0)
                    break;
                dietro = avanti;
                avanti = avanti->next;
            }
            if(avanti)
            {
                if(avanti == tema->giocatori_completato)
                    tema->giocatori_completato = avanti->next;
                else
                    dietro->next = avanti->next;
                free(avanti);
            }
        }

        //mutua esclusione
        pthread_mutex_unlock(&tema->mutex);
    }    

    //si resetta il flag all'interno del descrittore del giocatore per indicare che non è più attivo
    //e si aggiorna il contatore si giocatori attivi
    giocatore->attivo = false;
    (*giocatori_tot)--;
}

void stampa_interfaccia(struct temi *elenco_temi, struct giocatore *lista_giocatori, int giocatori_tot, pthread_mutex_t *mutex_giocatori)
{
    struct giocatore *g = lista_giocatori;

    system("clear");

    //stampa l'elenco dei temi
    printf("Trivia quiz\n");
    printf("+++++++++++++++++++++++++++++++++++\n");
    printf("Temi:\n");
    for(int i = 0; i < N_TEMI; i++)
        printf("%d - %s\n", i+1, elenco_temi[i].nome);
    printf("+++++++++++++++++++++++++++++++++++\n\n");

    //mutua esclusione
    pthread_mutex_lock(mutex_giocatori);

    //stampa la lista dei giocatori attivi
    printf("Partecipanti (%d)\n", giocatori_tot);
    if(giocatori_tot)
    {
        while(g)
        {
            if(g->attivo)
                printf("- %s\n", g->nome);
            g = g->next;
        }
    }
    else
        printf("------\n");
    printf("\n");

    //mutua esclusione
    pthread_mutex_unlock(mutex_giocatori);

    //stampa le classifiche
    for(int i = 0; i < N_TEMI; i++)
    {
        printf("Punteggio tema %d\n", i+1);

        //mutua esclusione
        pthread_mutex_lock(&elenco_temi[i].mutex);

        if(elenco_temi[i].n_giocatori == 0)
            printf("------\n");
        else
        {
            for(int j = 0; j < elenco_temi[i].n_giocatori; j++)
                printf("- %s %d\n", elenco_temi[i].classifica[j].nome, elenco_temi[i].classifica[j].punti);
        }
        printf("\n");

        //mutua esclusione
        pthread_mutex_unlock(&elenco_temi[i].mutex);
    }

    //stampa gli elenchi dei giocatori che hanno completato i temi
    for(int i = 0; i < N_TEMI; i++)
    {
        printf("Quiz tema %d completato\n", i+1);

        //mutua esclusione
        pthread_mutex_lock(&elenco_temi[i].mutex);

        if(elenco_temi[i].n_giocatori == 0)
            printf("------\n");
        else
        {
            struct quiz_completato *q = elenco_temi[i].giocatori_completato;

            if(!q)
                printf("------\n");
            else
            {
                while(q)
                {
                    printf("- %s\n", q->nome);
                    q = q->next;
                }
            }
        }
        printf("\n");

        //mutua esclusione
        pthread_mutex_unlock(&elenco_temi[i].mutex);
    }
}

//funzione che gestisce gli errori dovuti alla recv, in particolare la disconnessione del client
void gestione_recv (int ret, int client_sock, struct giocatore *g, struct giocatore *lista_giocatori, struct temi *elenco_temi, int *giocatori_tot, pthread_mutex_t *mutex_giocatori)
{
    //in caso di errore si rimuove se presente il corrispondente giocatore
    if(g)
    {
        rimuovi_giocatore(g, elenco_temi, giocatori_tot);
        stampa_interfaccia(elenco_temi, lista_giocatori, *giocatori_tot, mutex_giocatori);
    }

    if(ret == 0 || (ret == -1 && errno == ECONNRESET))
    {
        printf("Il giocatore con n° di socket %d si è disconnesso\n", client_sock);
        close(client_sock);
        pthread_exit(NULL);
    }
    else
    {
        perror("Errore nella recv");
        close(client_sock);
        pthread_exit((void*)EXIT_FAILURE);
    }    
}

//funzione che gestisce gli errori dovuti alla send, in particolare la disconnessione del client
void gestione_send (int client_sock, struct giocatore *g, struct giocatore *lista_giocatori, struct temi *elenco_temi, int *giocatori_tot, pthread_mutex_t *mutex_giocatori)
{
    //in caso di errore si rimuove se presente il corrispondente giocatore
    if(g)
    {
        rimuovi_giocatore(g, elenco_temi, giocatori_tot);
        stampa_interfaccia(elenco_temi, lista_giocatori, *giocatori_tot, mutex_giocatori);
    }

    if(errno == EPIPE || errno == ECONNRESET)
    {
        printf("Il giocatore con n° di socket %d si è disconnesso\n", client_sock);
        close(client_sock);
        pthread_exit(NULL);
    }
    else
    {
        perror("Errore nella send");
        close(client_sock);
        pthread_exit((void*)EXIT_FAILURE);
    }
}

//lato server della funzione che implementa il comando show score
void manda_classifica(int client_sock, struct giocatore *g, struct giocatore *lista_giocatori, struct temi *elenco_temi, int *giocatori_tot, pthread_mutex_t *mutex_giocatori)
{
    char buf[DIM_CLASSIFICA];
    u_int16_t dim = 0;

    //inserisce le classifiche formattate all'interno del buffer
    for(int i = 0; i < N_TEMI; i++)
    {
        dim += sprintf(buf + dim, "Punteggio tema %d\n", i+1);

        //mutua esclusione
        pthread_mutex_lock(&elenco_temi[i].mutex);

        if(elenco_temi[i].n_giocatori == 0)
            dim += sprintf(buf + dim, "------\n");
        else
        {
            for(int j = 0; j < elenco_temi[i].n_giocatori; j++)
                dim += sprintf(buf + dim, "- %s %d\n", elenco_temi[i].classifica[j].nome, elenco_temi[i].classifica[j].punti);
        }
        dim += sprintf(buf + dim, "\n");

        //mutua esclusione
        pthread_mutex_unlock(&elenco_temi[i].mutex);
    }

    buf[dim] = '\0';
    dim++;

    //si invia la dimensione della classifica
    dim = htons(dim);
    if(send(client_sock, &dim, sizeof(u_int16_t), MSG_NOSIGNAL) == -1)
        gestione_send(client_sock, g, lista_giocatori, elenco_temi, giocatori_tot, mutex_giocatori);

    //si invia la classifica
    dim = ntohs(dim);
    if(send(client_sock, (void*)buf, dim, MSG_NOSIGNAL) == -1)
        gestione_send(client_sock, g, lista_giocatori, elenco_temi, giocatori_tot, mutex_giocatori);
}