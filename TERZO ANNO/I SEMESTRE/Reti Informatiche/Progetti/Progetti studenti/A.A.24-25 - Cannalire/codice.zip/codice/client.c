#include "libclient.h"

int main(int argc, char **argv)
{
    //verifica della presenza del numero di porta nella chiamata dell'applicazione
    if(argc != 2)
    {
        perror("Numero di argomenti errato\n");
        exit(EXIT_FAILURE);
    }

    do
    {
        //comunicazione col server
        int sock;
        struct sockaddr_in server_addr;
        char from_serv[DOM_LEN]; //buffer usato per la ricezione di messaggi dal server
        char to_serv[RIS_LEN]; //buffer usato per l'input dell'utente e per l'inoltro di messaggi al server
        bool esito;
        int ret;

        //menù
        int modalita = 0;

        //contatore di domande e risposte
        int counter;

        //temi
        struct temi elenco_temi[N_TEMI];
        int n_temi = N_TEMI;
        int tema_scelto;

        //selezione della modalità
        do
        {
            stampa_menu();
            inserimento(to_serv, 3);
            modalita = atoi(to_serv);
        } while (modalita != 1 && modalita != 2);

        if(modalita == 2)
        {
            printf("\nUscita dall'applicazione\n");
            exit(0);
        }
        //else, si è comunque usciti dal ciclo
        printf("\nTrivia quiz\n");
        printf("+++++++++++++++++++++++++++++++++++\n");

        //creazione del socket
        if((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        {
            perror("Errore nella creazione del socket");
            exit(EXIT_FAILURE);
        }

        //configurazione di indirizzo e porta del server
        memset(&server_addr, 0, sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(atoi(argv[1]));
        inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

        //connessione al server
        if(connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1)
        {
            perror("Errore in connessione\n");
            close(sock);
            exit(EXIT_FAILURE);
        }

        //scelta del nickname
        do
        {
            printf("Scegli un nickname (deve essere univoco)\n");
            inserimento(to_serv, NAME_LEN);

            if(strcmp(to_serv, "") == 0)
            {
                printf("Nickname non valido, inserire almeno un carattere\n");
                continue;
            }

            //comando show score
            if(strcmp(to_serv, "show score") == 0)
                mostra_classifica(sock);
            //comando endquiz
            else if(strcmp(to_serv, "endquiz") == 0)
                goto endquiz;
            else
            {
                //invio del nickname
                if(send(sock, (void*)to_serv, NAME_LEN, MSG_NOSIGNAL) == -1)
                    gestione_send(sock);
                //ricezione dell'esito
                if((ret = recv(sock, &esito, sizeof(bool), 0)) <= 0)
                    gestione_recv(ret, sock);

                if(esito)
                    break;
                else
                    printf("\nNickname già in uso\n");
            }
        } while (true);

        //ricezione dei nomi dei temi
        for(int i = 0; i < N_TEMI; i++)
        {
            if((ret = recv(sock, (void*)from_serv, NAME_LEN, 0)) <= 0)
                gestione_recv(ret, sock);
            
            strcpy(elenco_temi[i].nome, from_serv);
            elenco_temi[i].svolto = false;
        }

        //si esce da questo ciclo quando non ci sono più temi da svolgere
        do
        {
            stampa_temi(elenco_temi);

            //selezione del tema, i controlli vengono effettuati lato client
            do
            {
                printf("La tua scelta:\n");
                inserimento(to_serv, RIS_LEN);

                //comando show score
                if(strcmp(to_serv, "show score") == 0)
                {
                    mostra_classifica(sock);
                    continue;
                }
                //comando endquiz
                else if(strcmp(to_serv, "endquiz") == 0)
                    goto endquiz;
            
                tema_scelto = atoi(to_serv);
                tema_scelto--;

                if(tema_scelto >= 0 && tema_scelto < N_TEMI && !elenco_temi[tema_scelto].svolto)
                    break;
                else
                    printf("\nNumero tema non valido \n");
            } while (true);

            //invio del tema scelto
            sprintf(to_serv, "%d", tema_scelto);
            if(send(sock, (void*)to_serv, RIS_LEN, MSG_NOSIGNAL) == -1)
                gestione_send(sock);

            //stampa del tema scelto
            printf("\nQuiz - %s\n", elenco_temi[tema_scelto].nome);

            //domande e risposte
            counter = 0;
            while(counter < 5)
            {
                //ricezione della domanda
                if((ret = recv(sock, (void*)from_serv, DOM_LEN, 0)) <= 0)
                    gestione_recv(ret, sock);

                //si esce da questo ciclo quando viene inserita una risposta alla domanda
                do
                {
                    //stampa della domanda
                    printf("+++++++++++++++++++++++++++++++++++\n");
                    printf("%s\n\n", from_serv);

                    //inserimento della risposta
                    printf("Risposta:\n");
                    inserimento(to_serv, RIS_LEN);

                    //comando show score
                    if(strcmp(to_serv, "show score") == 0)
                        mostra_classifica(sock);
                    //comando endquiz
                    else if(strcmp(to_serv, "endquiz") == 0)
                        goto endquiz;
                    else
                    {
                        counter++; //si incrementa il numero di domande svolte
                        break;
                    }
                } while (true);
                
                //invio della risposta alla domanda
                if(send(sock, (void*)to_serv, RIS_LEN, MSG_NOSIGNAL) == -1)
                    gestione_send(sock);

                //ricezione dell'esito
                if((ret = recv(sock, &esito, sizeof(bool), 0)) <= 0)
                    gestione_recv(ret, sock);
                if(esito)
                    printf("\nRisposta corretta!\n");
                else
                {
                    if((ret = recv(sock, (void*)from_serv, RIS_LEN, 0)) <= 0)
                        gestione_recv(ret, sock);
                    printf("\nRisposta errata: %s\n", from_serv);
                }
            }

            printf("+++++++++++++++++++++++++++++++++++\n");
            printf("Quiz %s completato\n", elenco_temi[tema_scelto].nome);

            elenco_temi[tema_scelto].svolto = true;
            n_temi--;
        } while (n_temi > 0);

        //il giocatore può ancora vedere le classifiche o concludere la sessione anche se ha terminato i quiz da svolgere
        do
        {
            printf("\nTemi completati. È ancora possibile vedere le classifiche digitando show score.\n");
            printf("In alternativa è possibile concludere la sessione digitando endquiz.\n");

            inserimento(to_serv, RIS_LEN);

            //comando show score
            if(strcmp(to_serv, "show score") == 0)
                mostra_classifica(sock);

            //comando endquiz
            if(strcmp(to_serv, "endquiz") == 0)
                break;
        } while (true);

        endquiz:;
        close(sock);
    } while (true);

    return 0;
}