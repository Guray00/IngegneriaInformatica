package it.unipi.SmartFreezerServer;

import com.google.gson.Gson;
import java.util.Calendar;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping(path="/freezer")
public class MainController 
{
    
    private final int spazioTotale = 35;
    private static final Logger logger = LogManager.getLogger(MainController.class);
    
    @Autowired
    private AlimentiRepository alimentiRepository;
    
    //metodo di utilità interno al server che restituisce lo spazio rimanente
    public int getSpazio()
    {
        logger.info("Richiesta getSpazio()");
        
        return spazioTotale - alimentiRepository.sumPorzioni();
    }
    
    //metodo che restituisce l'intero elenco degli Alimenti all'interno del congelatore a partire da quello con la minore data di scadenza
    @GetMapping(path="/all")
    public @ResponseBody Iterable<Alimenti> getAllAlimenti()
    {
        logger.info("Richiesta getAllAlimenti()");
        
        return alimentiRepository.findAllByOrderByScadenza();
    }
    
    //metodo che restituisce l'elenco degli Alimenti scaduti all'interno del congelatore a partire da quello con la minore data di scadenza
    @GetMapping(path="/scaduti")
    public @ResponseBody Iterable<Alimenti> getScaduti()
    {
        logger.info("Richiesta getScaduti()");
        
        return alimentiRepository.findByScadenzaBeforeOrderByScadenza(new Date());
    }
    
    //metodo che restituisce l'elenco degli Alimenti che scadranno nella prossima settimana a partire da quello con la minore data di scadenza
    @GetMapping(path="/scadenza")
    public @ResponseBody Iterable<Alimenti> getScadenza()
    {
        logger.info("Richiesta getScadenza()");
        
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 7);
        Date settimana = c.getTime();
        
        return alimentiRepository.findByScadenzaBetweenOrderByScadenza(new Date(), settimana);
    }
    
    //metodo che restituisce lo spazio rimanente, il numero di Alimenti che scadranno nella prossima settimana e il numero di Alimenti scaduti
    @GetMapping(path="/numeri")
    public @ResponseBody String getNumeri()
    {
        logger.info("Richiesta getNumeri()");
        
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 7);
        Date settimana = c.getTime();
        
        int[] numeri = new int[3];
        numeri[0] = getSpazio();
        numeri[1] = alimentiRepository.sumPorzioniByScadenzaBefore(new Date());
        numeri[2] = alimentiRepository.sumPorzioniByScadenzaBetween(new Date(), settimana);
        
        Gson gson = new Gson();
        return gson.toJson(numeri);
    }
    
    /*metodo che ricerca gli alimenti secondo 3 possibilità:
        - cerca tutti gli Alimenti che hanno un certo nome in input
        - cerca tutti gli Alimenti che appartengono a una certa categoria in input
        - cerca tutti gli Alimenti che hanno un certo nome e che appartengono a una certa categoria dati in input*/
    @PostMapping(path="/cerca")
    public @ResponseBody Iterable<Alimenti> getAlimenti(@RequestBody String s)
    {
        logger.info("Richiesta getAlimenti(...)");
        
        Gson gson = new Gson();
        SerializzazioneCerca sc = gson.fromJson(s, SerializzazioneCerca.class);
        
        if(sc.categoria.equals("null"))//non è stato considerato il caso di categoria e nome nulli contemporanemente poiché impedito lato client
        {
            logger.info("getAlimenti(...): categoria nulla");
            return alimentiRepository.findByNomeIgnoreCaseOrderByScadenza(sc.nome);
        }
        else if(sc.nome.equals(""))
        {
            logger.info("getAlimenti(...): nome nullo");
            return alimentiRepository.findByCategoriaOrderByScadenza(sc.categoria);
        }
        else
        {
            logger.info("getAlimenti(...): nome e categoria non nulli");
            return alimentiRepository.findByNomeIgnoreCaseAndCategoriaOrderByScadenza(sc.nome, sc.categoria);
        }
    }
    
    /*metodo che inserisce un nuovo Alimento all'interno del freezer. In caso ne sia già presente uno con la stessa chiave,
    indipendentemente dalla presenza di lettere maiuscole nel nome verrà aggiornato il numero di porzioni di quello esistente.
    In caso lo spazio non sia sufficiente il server non inserisce nulla*/
    @PostMapping(path="/add")
    public @ResponseBody String addNewAlimento(@RequestBody String s)
    {
        logger.info("Richiesta addNewAlimento(...)");
        
        Gson gson = new Gson();
        Alimenti a = gson.fromJson(s, Alimenti.class);
        
        if(getSpazio() < a.getPorzioni())
        {
            logger.info("addNewAlimento(...): spazio insufficiente per l'inserimento richiesto");
            return gson.toJson("Codice 0");
        }
        
        Alimenti presente = alimentiRepository.findByNomeIgnoreCaseAndScadenzaAndCategoria(a.getNome(), a.getScadenza(), a.getCategoria());
        if(presente == null)
        {
            logger.info("addNewAlimento(...): nuovo alimento salvato");
            alimentiRepository.save(a);
            return gson.toJson("Codice 1");
        }
        else
        {
            logger.info("addNewAlimento(...): porzione aggiunta a alimento esistente");
            alimentiRepository.updatePorzioniByNomeAndScadenzaAndCategoria(presente.getPorzioni()+a.getPorzioni(), presente.getNome(), presente.getScadenza(), presente.getCategoria());
            return gson.toJson("Codice 2");
        }
    }
    
    /*metodo che ricevuto un Alimento in input ne verifica l'esistenza all'interno del freezer e in tal caso ne elimina una porzione.
    Se l'alimento dovesse essere presente in una sola porzione allora questo verrebbe eliminato completamente*/
    @DeleteMapping(path="/remove/singolo")
    public @ResponseBody String removePorzione(@RequestBody String s)
    {
        logger.info("Richiesta removePorzione(...)");
        
        Gson gson = new Gson();
        AlimentiID alimento = gson.fromJson(s, AlimentiID.class);
        
        Alimenti presente = alimentiRepository.findByNomeIgnoreCaseAndScadenzaAndCategoria(alimento.getNome(), alimento.getScadenza(), alimento.getCategoria());
        if(presente == null)
        {
            logger.info("removePorzione(...): alimento assente");
            return gson.toJson("Codice 0", String.class);
        }
        else if(presente.getPorzioni() == 1)
        {
            logger.info("removePorzione(...): alimento completamente rimosso");
            alimentiRepository.delete(presente);
            return gson.toJson("Codice 1", String.class);
        }
        else
        {
            logger.info("removePorzione(...): eliminata una porzionee");
            alimentiRepository.updatePorzioniByNomeAndScadenzaAndCategoria(presente.getPorzioni()-1, alimento.getNome(), alimento.getScadenza(), alimento.getCategoria());
            return gson.toJson("Codice 2", String.class);
        }
    }
    
    //metodo che ricevuto un Alimento in input ne verifica l'esistenza all'interno del freezer e in tal caso lo elimina completamente.
    @DeleteMapping(path="/remove/tutto")
    public @ResponseBody String removeAlimento(@RequestBody String s)
    {
        logger.info("Richiesta removeAlimento(...)");
        
        Gson gson = new Gson();
        AlimentiID alimento = gson.fromJson(s, AlimentiID.class);
        
        Alimenti presente = alimentiRepository.findByNomeIgnoreCaseAndScadenzaAndCategoria(alimento.getNome(), alimento.getScadenza(), alimento.getCategoria());
        if(presente == null)
        {
            logger.info("removeAlimento(...): alimento assente");
            return gson.toJson("Codice 0", String.class);
        }
        else
        {
            logger.info("removeAlimento(...): alimento completamente rimosso");
            alimentiRepository.delete(presente);
            return gson.toJson("Codice 1", String.class);
        }
    }
}
