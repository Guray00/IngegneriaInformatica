package it.unipi.SmartFreezerServer;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@IdClass(AlimentiID.class) //la chiave è composta da ppiù attributi
@Table(name="alimenti", schema="635881")
public class Alimenti implements Serializable
{
    
    @Id
    @Column(name="nome")
    private String nome;
    @Id
    @Column(name="scadenza")
    @Temporal(TemporalType.DATE)
    private Date scadenza;
    @Id
    @Column(name="categoria")
    private String categoria;
    
    @Column(name="porzioni")
    private int porzioni;

    public Alimenti(String nome, Date scadenza, String categoria, int porzioni) 
    {
        this.nome = nome;
        this.scadenza = scadenza;
        this.categoria = categoria;
        this.porzioni = porzioni;
    }

    public Alimenti() 
    {
        
    }

    public String getNome() 
    {
        return nome;
    }

    public void setNome(String nome) 
    {
        this.nome = nome;
    }

    public Date getScadenza() 
    {
        return scadenza;
    }

    public void setScadenza(Date scadenza) 
    {
        this.scadenza = scadenza;
    }

    public String getCategoria() 
    {
        return categoria;
    }

    public void setCategoria(String categoria) 
    {
        this.categoria = categoria;
    }

    public int getPorzioni() 
    {
        return porzioni;
    }

    public void setPorzioni(int porzioni) 
    {
        this.porzioni = porzioni;
    }
}
