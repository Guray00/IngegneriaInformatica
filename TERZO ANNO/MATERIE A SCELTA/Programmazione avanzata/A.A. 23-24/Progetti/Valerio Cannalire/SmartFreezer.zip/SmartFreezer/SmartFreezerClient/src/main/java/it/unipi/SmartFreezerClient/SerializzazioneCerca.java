package it.unipi.SmartFreezerClient;

import java.io.Serializable;

//classe di utilità che serve per la serializzazione nella ricerca
public class SerializzazioneCerca implements Serializable {
    public String nome;
    public String categoria;

    public SerializzazioneCerca(String nome, String categoria) {
        this.nome = nome;
        this.categoria = categoria;
    }
}