package it.unipi.SmartFreezerClient;

import java.io.Serializable;

//nel client questa classe viene usata per la serializzazione durante le richieste di eliminazione
public class AlimentiID implements Serializable 
{
    public String nome;
    public String scadenza;
    public String categoria;

    public AlimentiID(String nome, String scadenza, String categoria) 
    {
        this.nome = nome;
        this.scadenza = scadenza;
        this.categoria = categoria;
    }
}
