package it.unipi.SmartFreezerServer;

import java.io.Serializable;


//classe di utilità che serve per la deserializzazione nella getAlimenti(...)
public class SerializzazioneCerca implements Serializable 
{
    public String nome;
    public String categoria;

    public SerializzazioneCerca(String nome, String categoria) 
    {
        this.nome = nome;
        this.categoria = categoria;
    }
}
