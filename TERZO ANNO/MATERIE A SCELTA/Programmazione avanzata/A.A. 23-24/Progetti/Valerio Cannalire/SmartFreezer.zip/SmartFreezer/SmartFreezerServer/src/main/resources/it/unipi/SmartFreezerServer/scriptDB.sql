CREATE SCHEMA `635881`;

SET @@global.time_zone = '+00:00';

CREATE TABLE `635881`.`alimenti` (
  `nome` VARCHAR(45) NOT NULL,
  `scadenza` DATE NOT NULL,
  `categoria` VARCHAR(45) NOT NULL DEFAULT 'altro',
  `porzioni` INT NOT NULL,
  PRIMARY KEY (`nome`, `scadenza`, `categoria`));

INSERT INTO `635881`.`alimenti` (`nome`, `scadenza`, `categoria`, `porzioni`) VALUES
    ('polpettone', '2024-02-15', 'carne', 3),
    ('pollo', '2024-03-01', 'carne', 2),
    ('sofficini', '2025-03-01', 'fritto', 1),
    ('polpette', '2024-03-01', 'carne', 3),
    ('polpette', '2023-12-01', 'verdure', 1),
    ('bastoncini', '2024-05-01', 'pesce', 1),
    ('carciofi', '2024-02-05', 'verdure', 2),
    ('patatine', '2024-02-13', 'fritto', 3),
    ('sugo', '2024-01-05', 'avanzi', 2),
    ('orata', '2024-02-17', 'pesce', 1),
    ('polpettone', '2024-04-15', 'carne', 2),
    ('melanzane', '2024-07-25', 'verdure', 2),
    ('pizza', '2024-02-16', 'altro', 2),
    ('gelato', '2024-10-16', 'dolci', 1),
    ('parmigiana', '2024-02-13', 'avanzi', 1),
    ('brodo', '2024-02-07', 'avanzi', 3);