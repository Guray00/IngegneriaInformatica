package it.unipi.SmartFreezerClient;

//eccezione che viene invocata quando il nome o la scadenza dell'alimento non vengono inseriti
public class InserimentoException extends Exception{
    public InserimentoException()
    {
        super("Errore nell'inserimento, necessario inserire entrambi i campi");
    }
}
