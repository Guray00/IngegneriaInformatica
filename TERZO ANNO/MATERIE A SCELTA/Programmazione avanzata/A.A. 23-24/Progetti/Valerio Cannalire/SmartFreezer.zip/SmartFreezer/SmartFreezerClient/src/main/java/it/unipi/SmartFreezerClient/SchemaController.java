package it.unipi.SmartFreezerClient;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class SchemaController 
{
    private static final Logger logger = LogManager.getLogger();
    
    @FXML Button buttonHome;
    
    @FXML TableView<Alimenti> tabellaRisultati = new TableView<>();
    public ObservableList<Alimenti> ol;
    
    @FXML
    private TableColumn nomeCol;
    @FXML
    private TableColumn scadenzaCol;
    @FXML
    private TableColumn categoriaCol;
    @FXML
    private TableColumn porzioniCol;
    
    @FXML
    public void initialize()
    {
        logger.info("Inizializzazione tabella");
        
        nomeCol = new TableColumn("Nome");
        nomeCol.setCellValueFactory(new PropertyValueFactory<>("nome"));

        scadenzaCol = new TableColumn("Scadenza");
        scadenzaCol.setCellValueFactory(new PropertyValueFactory<>("scadenza"));

        categoriaCol = new TableColumn("Categoria");
        categoriaCol.setCellValueFactory(new PropertyValueFactory<>("categoria"));

        porzioniCol = new TableColumn("Porzioni");
        porzioniCol.setCellValueFactory(new PropertyValueFactory<>("porzioni"));

        tabellaRisultati.getColumns().addAll(nomeCol, scadenzaCol, categoriaCol, porzioniCol);
        
        ol = FXCollections.observableArrayList();
        tabellaRisultati.setItems(ol);
    }
    
    public void popolaGet(String indirizzo) //metodo che popola la tabella con una richiesta di tipo GET al server
    {
        logger.info("Popolamento tabella tramite GET");
        
        buttonHome.setDisable(true);
        
        Task task = new Task<Void>() //task necessario per attendere la risposta da parte del server
        {
            @Override public Void call()
            {
                try
                {
                    ol.clear();
                    
                    URL url = new URL(indirizzo);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String inputLine;
                    StringBuffer content = new StringBuffer();
                    while ((inputLine = in.readLine()) != null)
                    {
                        content.append(inputLine);
                    }
                    in.close();

                    Gson gson = new Gson();

                    JsonElement json = gson.fromJson(content.toString(), JsonElement.class);
                    JsonArray alimenti = json.getAsJsonArray();

                    for(int i=0; i<alimenti.size(); i++)
                    {
                        JsonObject j = alimenti.get(i).getAsJsonObject();
                        Alimenti a = new Alimenti(j.get("nome").getAsString(), j.get("scadenza").getAsString(), j.get("categoria").getAsString(), j.get("porzioni").getAsInt());
                        ol.add(a);
                    }
                    
                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            buttonHome.setDisable(false);
                            tabellaRisultati.setItems(ol);
                        }
                    });
                }
                catch(Exception e)
                {
                    logger.error("Errore nel popolamento della tabella tramite GET: "+e.getMessage());
                }
                
                return null;
            }
        };
        new Thread(task).start();
    }
    
    public void popolaPost(String indirizzo, String serializzato) //metodo che popola la tabella con una richiesta di tipo POST al server
    {
        logger.info("Popolamento tabella tramite POST");
        
        buttonHome.setDisable(true);
        
        Task task = new Task<Void>() //task necessario per attendere la risposta da parte del server
        {
            @Override public Void call()
            {
                try
                {
                    URL url = new URL(indirizzo);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setRequestProperty("Content-Type", "application/json");
                    con.setDoOutput(true);
                    
                    PrintWriter out = new PrintWriter(con.getOutputStream());
                    out.print(serializzato);
                    out.close();
                    
                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String inputLine;
                    StringBuffer content = new StringBuffer();
                    while ((inputLine = in.readLine()) != null)
                    {
                        content.append(inputLine);
                    }
                    in.close();

                    Gson gson = new Gson();

                    JsonElement json = gson.fromJson(content.toString(), JsonElement.class);
                    JsonArray alimenti = json.getAsJsonArray();

                    for(int i=0; i<alimenti.size(); i++)
                    {
                        JsonObject j = alimenti.get(i).getAsJsonObject();
                        Alimenti a = new Alimenti(j.get("nome").getAsString(), j.get("scadenza").getAsString(), j.get("categoria").getAsString(), j.get("porzioni").getAsInt());
                        ol.add(a);
                    }

                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            buttonHome.setDisable(false);
                            tabellaRisultati.setItems(ol);
                        }
                    });
                }
                catch(Exception e)
                {
                    buttonHome.setDisable(false);
                    logger.error("Errore nel popolamento della tabella tramite POST: "+e.getMessage());
                }
                
                return null;
            }
        };
        new Thread(task).start();
    }
    
    @FXML
    public void removeSingolo() //metodo che rimuove una singola porzione dell'Alimento selezionato. Se la porzione è l'ultima allora verrà eliminato l'intero alimento
    {
        logger.info("Inoltrata richiesta di rimozione di una porzione"); 
        buttonHome.setDisable(true);
        
        Task task = new Task<Void>() //task necessario per attendere la conferma di eliminazione di una porzione da parte del server
        {
            @Override public Void call()
            {
                try
                {
                    Alimenti target = tabellaRisultati.getSelectionModel().getSelectedItem();
                    AlimentiID alimentiID = new AlimentiID(target.getNome(), target.getScadenza(), target.getCategoria());
                    Gson gson = new Gson();
                    String serializzato = gson.toJson(alimentiID, AlimentiID.class);

                    URL url = new URL("http://localhost:8080/freezer/remove/singolo");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("DELETE");
                    con.setRequestProperty("Content-Type", "application/json");
                    con.setDoOutput(true);
                    PrintWriter out = new PrintWriter(con.getOutputStream());
                    out.print(serializzato);
                    out.close();

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String risposta = gson.fromJson(in, String.class);
                    in.close();
                    switch(risposta)
                    {
                        case "Codice 0":
                        {
                            logger.error("Errore: alimento assente");
                            break;
                        }
                        case "Codice 1":
                        {
                            logger.info("Alimento interamente eliminato");
                            ol.remove(target);
                            break;
                        }
                        case "Codice 2":
                        {
                            logger.info("Eliminata una porzione dell'alimento");
                            Alimenti nuovo = new Alimenti(target.getNome(), target.getScadenza(), target.getCategoria(), target.getPorzioni()-1);
                            ol.set(ol.indexOf(target), nuovo);
                            break;
                        }
                        default:
                            logger.error("Errore, codice inaspettato dal server");
                    }
                }
                catch(Exception e)
                {
                    logger.error("Errore generico nella rimozione di una porzione: "+e.getMessage());
                }
                
                Platform.runLater(new Runnable()
                {
                    @Override public void run()
                    {
                        buttonHome.setDisable(false);
                    }
                });
                
                return null;
            }
        };
        new Thread(task).start();
    }
    
    @FXML
    public void removeTutto() //metodo che rimuove interamente l'Alimento selezionato
    {
        logger.info("Inoltrata richiesta di rimozione di un alimento");
        buttonHome.setDisable(true);
        
        Task task = new Task<Void>() //task necessario per attendere la conferma di eliminazione di un alimento da parte del server
        {
            @Override public Void call()
            {
                try
                {
                    Alimenti target = tabellaRisultati.getSelectionModel().getSelectedItem();
                    AlimentiID alimentiID = new AlimentiID(target.getNome(), target.getScadenza(), target.getCategoria());
                    Gson gson = new Gson();
                    String serializzato = gson.toJson(alimentiID, AlimentiID.class);

                    URL url = new URL("http://localhost:8080/freezer/remove/tutto");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("DELETE");
                    con.setRequestProperty("Content-Type", "application/json");
                    con.setDoOutput(true);
                    PrintWriter out = new PrintWriter(con.getOutputStream());
                    out.print(serializzato);
                    out.close();

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String risposta = gson.fromJson(in, String.class);
                    in.close();
                    switch(risposta)
                    {
                        case "Codice 0":
                        {
                            logger.error("Errore: alimento assente");
                            break;
                        }
                        case "Codice 1":
                        {
                            logger.info("Alimento interamente eliminato");
                            ol.remove(target);
                            break;
                        }
                        default:
                            logger.error("Errore, codice inaspettato dal server");
                    }
                }
                catch(Exception e)
                {
                    logger.error("Errore generico nella rimozione di un alimento : "+e.getMessage());
                }
                
                Platform.runLater(new Runnable()
                {
                    @Override public void run()
                    {
                        buttonHome.setDisable(false);
                    }
                });
                
                return null;
            }
        };
        new Thread(task).start();
    }
    
    //metodo che serve per tornare alla Home
    @FXML
    private void switchToHome() throws IOException 
    {
        logger.info("Passaggio a schermata Home");
        App.setRoot("home");
    }
}
