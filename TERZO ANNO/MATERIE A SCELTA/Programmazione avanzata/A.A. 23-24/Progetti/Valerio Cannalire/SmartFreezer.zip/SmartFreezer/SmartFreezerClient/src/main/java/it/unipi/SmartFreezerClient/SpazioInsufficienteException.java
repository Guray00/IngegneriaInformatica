package it.unipi.SmartFreezerClient;

//eccezione che viene lanciata quando si prova a inserire un alimento con un numero di porzioni maggiore rispetto allo spazio rimanente
public class SpazioInsufficienteException extends Exception 
{
    public SpazioInsufficienteException()
    {
        super("Spazio insufficiente, provare a inserire meno porzioni");
    }
}
