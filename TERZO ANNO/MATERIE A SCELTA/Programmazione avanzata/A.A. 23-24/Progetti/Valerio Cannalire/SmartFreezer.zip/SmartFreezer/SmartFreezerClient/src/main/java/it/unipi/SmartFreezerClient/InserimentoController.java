package it.unipi.SmartFreezerClient;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class InserimentoController 
{
    private static final Logger logger = LogManager.getLogger();
    
    @FXML TextField inserimentoNome;
    @FXML ChoiceBox<String> inserimentoCategoria;
    String[] listaCategorie = {"carne", "pesce", "fritto", "dolci", "avanzi", "verdure", "altro"};
    @FXML DatePicker inserimentoScadenza;
    @FXML Slider inserimentoPorzioni;
    
    @FXML Button buttonPost;
    @FXML Button buttonNuovo;
    @FXML Button buttonHome;
    
    @FXML Label etichettaAvviso;
    @FXML Label spazioRimanente;
    
    @FXML
    public void initialize()
    {
        logger.info("Caricamento della schermata Inserimento");
        
        inserimentoCategoria.getItems().addAll(listaCategorie);
        
        Task task = new Task<Void>()    //task necessario per l'inizializzazione dal server dell'etichetta che mostra lo spazio rimanente
        {
            @Override public Void call()
            {
                try
                {
                    Gson gson = new Gson();

                    URL url = new URL("http://localhost:8080/freezer/numeri");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    Integer[] numero = gson.fromJson(in.readLine(), Integer[].class);
                    
                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            spazioRimanente.setText(numero[0].toString());
                        }
                    });
                }
                catch(Exception e)
                {
                    logger.error("Errore durante l'inizializzazione della schermata Inserimento: "+e.getMessage());
                }
                
                return null;
            }
        };
        new Thread(task).start();
                
    }
    
    @FXML
    public void inserimentoAlimento()
    {
        logger.info("Chiamata della funzione di inserimento");
        
        inserimentoNome.setDisable(true);
        inserimentoScadenza.setDisable(true);
        inserimentoCategoria.setDisable(true);
        inserimentoPorzioni.setDisable(true);
        buttonHome.setDisable(true);
        
        Task task = new Task<Void>() //task necessario per aspettare una risposta dal server in seguito all'inserimento di un Alimento
        {
            @Override public Void call()
            {
                try
                {
                    if(inserimentoNome.getText().equals("") || inserimentoScadenza.getValue() == null)
                        throw new InserimentoException();
                    
                    if(Integer.parseInt(spazioRimanente.getText()) < inserimentoPorzioni.getValue())
                        throw new SpazioInsufficienteException();
                    
                    String categoria;
                    if(inserimentoCategoria.getValue() == null)
                        categoria = "altro";    //se l'utente non inserisce alcuna categoria allora l'app di default imposterà "altro"
                    else
                        categoria = inserimentoCategoria.getValue();

                    Alimenti a = new Alimenti(inserimentoNome.getText(), inserimentoScadenza.getValue().toString(), categoria, (int)inserimentoPorzioni.getValue());
                    Gson gson = new Gson();
                    String serializzato = gson.toJson(a, Alimenti.class);

                    URL url = new URL("http://localhost:8080/freezer/add");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setRequestProperty("Content-Type", "application/json");
                    con.setDoOutput(true);
                    PrintWriter out = new PrintWriter(con.getOutputStream());
                    out.print(serializzato);
                    out.close();

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String risposta = gson.fromJson(in, String.class);
                    in.close();
                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            switch(risposta)
                            {
                                case "Codice 1":
                                {
                                    logger.info("Inserimento avvenuto con successo");
                                    etichettaAvviso.setText("Inserimento avvenuto con successo");
                                    etichettaAvviso.setTextFill(Color.FORESTGREEN);
                                    break;
                                }
                                case "Codice 2":
                                {
                                    logger.info("Porzione aggiunta a esistente");
                                    etichettaAvviso.setText("Porzione aggiunta a esistente");
                                    etichettaAvviso.setTextFill(Color.FORESTGREEN);
                                    break;
                                }
                                default:
                                {
                                    logger.error("Errore inaspettato");
                                    etichettaAvviso.setText("Errore inaspettato");
                                    etichettaAvviso.setTextFill(Color.RED);
                                }
                            }

                            buttonPost.setVisible(false);
                            buttonNuovo.setVisible(true);
                            buttonHome.setDisable(false);
                        }
                    });
                }
                
                catch(InserimentoException re)
                {
                    logger.error("Nome o scadenza null: "+re.getMessage());
                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            etichettaAvviso.setText("Errore: necessario inserire almeno nome e scadenza");
                            etichettaAvviso.setTextFill(Color.RED);
                            inserimentoNome.setDisable(false);
                            inserimentoScadenza.setDisable(false);
                            inserimentoCategoria.setDisable(false);
                            inserimentoPorzioni.setDisable(false);
                            buttonHome.setDisable(false);
                        }
                    });
                }
                catch(SpazioInsufficienteException se)
                {
                    logger.error("Errore: "+se.getMessage());
                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            etichettaAvviso.setText("Errore: spazio insufficiente, provare a inserire meno porzioni");
                            etichettaAvviso.setTextFill(Color.RED);
                            inserimentoNome.setDisable(false);
                            inserimentoScadenza.setDisable(false);
                            inserimentoCategoria.setDisable(false);
                            inserimentoPorzioni.setDisable(false);
                            buttonHome.setDisable(false);
                        }
                    });
                }
                catch(Exception e)
                {
                    logger.error("Errore generico nella fase di inserimento");
                }

                //aggiornamento spazio rimanente in seguito all'inserimento, per gli stessi motivi menzionati sopra si trova all'interno del task
                try
                {
                    Gson gson = new Gson();

                    URL url = new URL("http://localhost:8080/freezer/numeri");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    Integer[] numero = gson.fromJson(in.readLine(), Integer[].class);
                    
                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            spazioRimanente.setText(numero[0].toString());
                        }
                    });
                }
                catch(Exception e)
                {
                    logger.error("Errore generico durante l'aggiornamento dello spazio rimanente");
                }
                
                return null;
            }
        };
        new Thread(task).start();
    }

    //metodo che serve per tornare alla Home
    @FXML
    private void switchToHome() throws IOException 
    {
        logger.info("Passaggio a schermata Home");
        App.setRoot("home");
    }
    
    //metodo che serve per resettare la pagina a seguito di un inserimento
    @FXML
    private void nuovoInserimento() throws IOException 
    {
        logger.info("Reset della pagina");
        App.setRoot("inserimento");
    }
}
