package it.unipi.SmartFreezerClient;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HomeController 
{
    private static final Logger logger = LogManager.getLogger();
    
    @FXML Label numeroScadenza;
    @FXML Label numeroScaduti;
    @FXML Label spazioRimanente;
    
    @FXML Button buttonScadenza;
    @FXML Button buttonTutti;
    @FXML Button buttonRicerca;
    @FXML Button buttonInserimento;
    
    public void initialize()
    {
        logger.info("Caricamento della schermata Home");
        
        buttonScadenza.setDisable(true);
        buttonTutti.setDisable(true);
        buttonRicerca.setDisable(true);
        buttonInserimento.setDisable(true);
        
        Task task = new Task<Void>() //task necessario a causa di alcuni numeri nell'intefaccia che devono essere inizializzati dal server
        {
            @Override public Void call()
            {
                try
                {
                    Gson gson = new Gson();

                    URL url = new URL("http://localhost:8080/freezer/numeri");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    Integer[] numero = gson.fromJson(in.readLine(), Integer[].class);

                    Platform.runLater(new Runnable()
                    {
                        @Override public void run()
                        {
                            spazioRimanente.setText(numero[0].toString());
                            numeroScaduti.setText(numero[1].toString());
                            numeroScadenza.setText(numero[2].toString());
                            buttonScadenza.setDisable(false);
                            buttonTutti.setDisable(false);
                            buttonRicerca.setDisable(false);
                            buttonInserimento.setDisable(false);
                        }
                    });
                }
                catch(Exception e)
                {
                    logger.error("Errore durante l'inizializzazione della schermata Home: "+e.getMessage());
                }
                return null;
            }
        };
        new Thread(task).start();
        
        
    }
    
    //metodi che servono per passare alle altre schermate
    @FXML
    private void switchToScadenza() throws IOException 
    {
        logger.info("Passaggio a schermata Scadenza");
        App.setRoot("scadenza");
    }
    
    @FXML
    private void switchToTutti() throws IOException 
    {
        logger.info("Passaggio a schermata Tutti");
        App.setRoot("tutti");
    }
    
    @FXML
    private void switchToRicerca() throws IOException 
    {
        logger.info("Passaggio a schermata Ricerca");
        App.setRoot("ricerca");
    }
    
    @FXML
    private void switchToInserimento() throws IOException 
    {
        logger.info("Passaggio a schermata Inserimento");
        App.setRoot("inserimento");
    }
}
