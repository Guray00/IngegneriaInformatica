package it.unipi.SmartFreezerClient;

//eccezione che viene lanciata quando si prova a inoltrare una richiesta di ricerca con entrambi i campi nulli
public class RicercaException extends Exception 
{
    public RicercaException()
    {
        super("Errore nella ricerca, inserire almeno uno dei 2 campi");
    }
}
