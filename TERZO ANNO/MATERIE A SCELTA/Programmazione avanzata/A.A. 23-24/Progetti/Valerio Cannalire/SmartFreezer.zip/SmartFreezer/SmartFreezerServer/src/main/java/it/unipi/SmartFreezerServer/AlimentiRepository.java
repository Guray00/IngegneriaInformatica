package it.unipi.SmartFreezerServer;

import java.util.Date;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
public interface AlimentiRepository extends CrudRepository<Alimenti, AlimentiID> 
{
    @Query("SELECT SUM(a.porzioni) FROM Alimenti a") //serve per la getSpazio()
    int sumPorzioni();
        
    Iterable<Alimenti> findAllByOrderByScadenza(); //serve per la getAll()
    
    Iterable<Alimenti> findByScadenzaBeforeOrderByScadenza(Date scadenza); //serve per la getScaduti()
    Iterable<Alimenti> findByScadenzaBetweenOrderByScadenza(Date prima, Date dopo); //serve per la getScadenza()
   
    @Query("SELECT SUM(a.porzioni) FROM Alimenti a WHERE a.scadenza < ?1") //questi metodi servono per la getNumeri()
    int sumPorzioniByScadenzaBefore(Date scadenza);
    @Query("SELECT SUM(porzioni) FROM Alimenti WHERE scadenza BETWEEN ?1 and ?2")
    int sumPorzioniByScadenzaBetween(Date prima, Date dopo);
    
    Iterable<Alimenti> findByNomeIgnoreCaseAndCategoriaOrderByScadenza(String nome, String categoria); //questi metodi servono per la getAlimenti(...)
    Iterable<Alimenti> findByNomeIgnoreCaseOrderByScadenza(String nome); 
    Iterable<Alimenti> findByCategoriaOrderByScadenza(String categoria); 
    
    Alimenti findByNomeIgnoreCaseAndScadenzaAndCategoria(String nome, Date scadenza, String categoria); //questi metodi servono per addNewAlimento(...), removePorzione(...), removeAlimento(...)
    @Modifying
    @Transactional
    @Query("UPDATE Alimenti a SET a.porzioni = ?1 WHERE a.nome = ?2 AND a.scadenza = ?3 AND a.categoria = ?4")
    void updatePorzioniByNomeAndScadenzaAndCategoria(int porzioni, String nome, Date scadenza, String categoria);
}
