package it.unipi.SmartFreezerServer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.TimeZone;

import org.apache.ibatis.jdbc.RuntimeSqlException;
import org.apache.ibatis.jdbc.ScriptRunner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class Inizializzazione 
{
    private static final Logger logger = LogManager.getLogger(Inizializzazione.class);
    
    public static void inizializza() //questo metodo si connette a mysql e verifica la presenza del server attraverso i metadata, se non presente lo crea
    {
        boolean trovato = false;
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));   //per la scadenza di un alimento è sufficiente solo la data, quindi per praticità si è impostata l'UTC
        try (Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306", "root", "root"))
        {
            ResultSet rs = con.getMetaData().getCatalogs();
            while(rs.next())
            {
                String appoggio = rs.getString(1);
                if(appoggio.equals("635881"))
                {
                    logger.info("Database già esistente");
                    trovato = true;
                    break;
                }
            }
            
            if(!trovato)
            {
                logger.info("Database non esistente, creazione");
                Reader r = new BufferedReader(new FileReader("src/main/resources/it/unipi/SmartFreezerServer/scriptDB.sql"));
                try                             
                {
                    ScriptRunner s = new ScriptRunner(con); //esecuzione dello script di creazione
                    s.setStopOnError(true);
                    s.runScript(r);
                }
                catch (RuntimeSqlException re)
                {
                    logger.error("Errore nell'esecuzione dello script: "+re.getMessage());
                }
            }
        }
        catch (Exception e)
        {
            logger.error("Errore generico durante la fase di inizializzazione: "+e.getMessage());
        }
    }
}
