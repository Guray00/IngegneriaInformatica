package it.unipi.SmartFreezerClient;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppTest {
    
    public AppTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
    
    @Test
    public void testConnessione() 
    {
        try
        {
            Gson gson = new Gson();

            URL url = new URL("http://localhost:8080/freezer/numeri");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            Integer[] numero = gson.fromJson(in.readLine(), Integer[].class);
            
            if(numero[0]!=null)//se il server è in funzione ritornerà sicuramente un numero
                System.out.println("Prova di connessione al server superata");
            else
                fail("Prova di connessione al server non riuscita");
        }
        catch(Exception e)
        {
            fail("Prova di connessione al server non riuscita");
        }
    }
}
