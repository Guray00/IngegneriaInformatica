package it.unipi.SmartFreezerClient;

import com.google.gson.Gson;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class RicercaController extends SchemaController 
{
    private static final Logger logger = LogManager.getLogger();
    
    @FXML TextField inserimentoNome;
    @FXML ChoiceBox<String> inserimentoCategoria;
    String[] listaCategorie = {"carne", "pesce", "fritto", "dolci", "avanzi", "verdure", "altro"};
    
    @FXML Button buttonPost;
    @FXML Button buttonNuova;
    
    @FXML Label etichettaAvviso;
    
    @Override
    public void initialize()
    {
        super.initialize();
        inserimentoCategoria.getItems().addAll(listaCategorie);
        tabellaRisultati.setVisible(false);
        buttonNuova.setVisible(false);
    }
    
    @FXML
    public void mostraRisultati() //metodo che mostra i risultati di una ricerca attraverso la popolaPost(...)
    {
        logger.info("Richiesta di ricerca");
        
        try
        {
            if(inserimentoNome.getText().equals("") && inserimentoCategoria.getValue() == null) //necessario che almeno uno dei 2 non sia nullo
                throw new RicercaException();
            
            buttonPost.setVisible(false);
            inserimentoNome.setDisable(true);
            inserimentoCategoria.setDisable(true);
            
            String categoria;
            if(inserimentoCategoria.getValue() == null)
                categoria = "null";
            else
                categoria = inserimentoCategoria.getValue();
            
            SerializzazioneCerca sc = new SerializzazioneCerca(inserimentoNome.getText(), categoria);
            Gson gson = new Gson();
            String s = gson.toJson(sc, SerializzazioneCerca.class);
            
            super.popolaPost("http://localhost:8080/freezer/cerca", s);
            
            tabellaRisultati.setVisible(true);
            buttonNuova.setVisible(true);
            etichettaAvviso.setVisible(false);
            
            logger.info("Ricerca avvenuta");
        }
        catch(RicercaException re)
        {
            logger.info(re.getMessage());
            etichettaAvviso.setText("Errore: necessario inserire almeno uno dei 2 campi");
            etichettaAvviso.setTextFill(Color.RED);
        }
    }
    
    //metodo che serve per resettare la pagina a seguito di un inserimento
    @FXML
    private void nuovaRicerca() throws IOException 
    {
        logger.info("Reset della pagina");
        App.setRoot("ricerca");
    }
}
