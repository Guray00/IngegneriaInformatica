package it.unipi.SmartFreezerClient;


public class TuttiController extends SchemaController 
{
    @Override
    public void initialize()
    {
        super.initialize();
        super.popolaGet("http://localhost:8080/freezer/all");
    }
}
