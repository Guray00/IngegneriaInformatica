package it.unipi.SmartFreezerServer;

import java.io.Serializable;
import java.util.Date;


//classe che rappresenta una chiave composta da più attributi
//viene anche usata per la deserializzazione durante le richieste di eliminazione
public class AlimentiID implements Serializable 
{
    private String nome;
    private Date scadenza;
    private String categoria;

    public AlimentiID(String nome, Date scadenza, String categoria) 
    {
        this.nome = nome;
        this.scadenza = scadenza;
        this.categoria = categoria;
    }

    public AlimentiID() 
    {
        
    }

    public String getNome() 
    {
        return nome;
    }

    public Date getScadenza() 
    {
        return scadenza;
    }

    public String getCategoria() 
    {
        return categoria;
    }

    //una @IDClass necessita la ridefinizione di equals e hashcode
    public boolean equals(Object o)
    {
        if(o == null || o.getClass() != getClass())
            return false;
        AlimentiID a = (AlimentiID) o;
        return nome.equals(a.nome) && scadenza == a.scadenza && categoria.equals(a.categoria);
    }
    
    public int hashCode()
    {
        return nome.hashCode() + scadenza.hashCode() + categoria.hashCode();
    }
    
}
