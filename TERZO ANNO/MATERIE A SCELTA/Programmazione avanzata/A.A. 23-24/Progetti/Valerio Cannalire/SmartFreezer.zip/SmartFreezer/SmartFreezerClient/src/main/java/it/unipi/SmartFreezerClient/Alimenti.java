package it.unipi.SmartFreezerClient;

import java.io.Serializable;

public class Alimenti implements Serializable
{
    public String nome;
    public String scadenza;
    public String categoria; //per semplicità, siccome sono statiche, le date sono riportate come stringhe
    public int porzioni;

    public Alimenti(String nome, String scadenza, String categoria, int porzioni) 
    {
        this.nome = nome;
        this.scadenza = scadenza;
        this.categoria = categoria;
        this.porzioni = porzioni;
    }

    public String getNome() 
    {
        return nome;
    }

    public void setNome(String nome) 
    {
        this.nome = nome;
    }

    public String getScadenza() 
    {
        return scadenza;
    }

    public void setScadenza(String scadenza) 
    {
        this.scadenza = scadenza;
    }

    public String getCategoria() 
    {
        return categoria;
    }

    public void setCategoria(String categoria) 
    {
        this.categoria = categoria;
    }

    public int getPorzioni() 
    {
        return porzioni;
    }

    public void setPorzioni(int porzioni) 
    {
        this.porzioni = porzioni;
    }
}
