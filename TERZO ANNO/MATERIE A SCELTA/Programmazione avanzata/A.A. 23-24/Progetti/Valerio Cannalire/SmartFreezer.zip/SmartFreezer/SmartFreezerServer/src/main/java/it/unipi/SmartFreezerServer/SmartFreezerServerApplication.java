package it.unipi.SmartFreezerServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartFreezerServerApplication {

	public static void main(String[] args) {
                Inizializzazione.inizializza();
		SpringApplication.run(SmartFreezerServerApplication.class, args);
	}
}
