module it.unipi.SmartFreezerClient {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.base;
    requires org.apache.logging.log4j;

    opens it.unipi.SmartFreezerClient to javafx.fxml;
    exports it.unipi.SmartFreezerClient;
}
