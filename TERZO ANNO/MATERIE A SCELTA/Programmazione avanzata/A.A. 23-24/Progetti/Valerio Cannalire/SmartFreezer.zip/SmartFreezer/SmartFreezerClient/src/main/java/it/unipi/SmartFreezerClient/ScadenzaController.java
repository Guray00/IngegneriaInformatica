package it.unipi.SmartFreezerClient;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class ScadenzaController extends SchemaController 
{
    private static final Logger logger = LogManager.getLogger();
    
    @FXML Button buttonScadenza;
    @FXML Button buttonScaduti;
    @FXML Label etichettaModalita;
    
    @Override
    public void initialize()
    {
        super.initialize();
        etichettaModalita.setVisible(false);
        tabellaRisultati.setVisible(false);
    }
    
    public void mostraScadenza()
    {
        logger.info("Richiesta la visualizzazione degli alimenti in scadenza");
        
        buttonScadenza.setDisable(true);
        super.popolaGet("http://localhost:8080/freezer/scadenza");
        buttonHome.setDisable(false);
        etichettaModalita.setText("Alimenti in scadenza");
        etichettaModalita.setTextFill(Color.ORANGE);
        etichettaModalita.setVisible(true);
        tabellaRisultati.setVisible(true);
        buttonScaduti.setDisable(false);
    }
    
    public void mostraScaduti()
    {
        logger.info("Richiesta la visualizzazione degli alimenti scaduti");
        
        buttonScaduti.setDisable(true);
        super.popolaGet("http://localhost:8080/freezer/scaduti");
        buttonHome.setDisable(false);
        etichettaModalita.setText("Alimenti scaduti");
        etichettaModalita.setTextFill(Color.RED);
        etichettaModalita.setVisible(true);
        tabellaRisultati.setVisible(true);
        buttonScadenza.setDisable(false);
    }
}
