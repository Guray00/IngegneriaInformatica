package it.unipi.memorizer.app;

public class DisconnectedException extends Exception
{
    public DisconnectedException(String s)
    {
        super(s);
    }
}
