package it.unipi.moriconi.clientsciurus;

/**
 * Classe astraente la tabella "Article"
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ArticleTable {
    //----- Riferimenti di struttura della tabella
    @FXML private final TableView<Article> articleTable;
    @FXML private final TableColumn id;
    @FXML private final TableColumn title;
    @FXML private final TableColumn dataCreation;
    @FXML private final TableColumn topic;
    @FXML private final TableColumn body;
    private final ObservableList<Article> ol;
    
    //----- Creazione tabella
    public ArticleTable(TableView at){
        articleTable=at;
        //Associazione valore/colonna e definizione della grandezza
        id = new TableColumn("ID");
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        
        title = new TableColumn("Title");
        title.setCellValueFactory(new PropertyValueFactory<>("title"));

        dataCreation = new TableColumn("Created");
        dataCreation.setCellValueFactory(new PropertyValueFactory<>("dataCreation"));

        topic = new TableColumn("Topic");
        topic.setCellValueFactory(new PropertyValueFactory<>("topic"));
        
        body = new TableColumn("Body");
        body.setCellValueFactory(new PropertyValueFactory<>("body"));
       
        id.setMinWidth(10);
        title.setMinWidth(200);
        dataCreation.setMinWidth(50);
        topic.setMinWidth(100);
        
        articleTable.getColumns().addAll(id, title, dataCreation, topic, body);
        ol = FXCollections.observableArrayList();
        articleTable.setItems(ol);
    }
    
    /**
     * Aggiunge un Articolo alla tabella
     * @param item new Article 
     */
    public void add(Article item) {
        ol.add(item);
    }
    
    /**
     * Elimina un Articolo dalla tabella
     * @param item remove Article
     */
    public void remove(Article item){
        ol.remove(item);
    }
    
    /**
     * Svuota la tabella
     */
    public void clear() {
        ol.clear();
    }
    
    public int getTotalArticles() {
        return ol.size();
    }
    
    /**
     * Seleziona un articolo dalla tabella ritornandolo
     * @return Article Selected Article
     * @throws ArticleNotSelected 
     */
    public Article selected() throws ArticleNotSelected {
        Article a = articleTable.getSelectionModel().getSelectedItem();
        if(a == null) throw new ArticleNotSelected();
        return a;
    } 
}
