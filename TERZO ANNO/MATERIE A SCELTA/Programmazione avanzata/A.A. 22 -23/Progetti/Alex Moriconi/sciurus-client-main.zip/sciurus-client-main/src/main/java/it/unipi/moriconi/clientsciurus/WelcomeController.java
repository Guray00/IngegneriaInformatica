package it.unipi.moriconi.clientsciurus;

/**
 * Classe controller del interfaccia "Welcome"
 * 
 * Gestione della raggiungibilità del server prima di accedere
 * alla manipolazione dei dati 
 * 
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javafx.fxml.FXML;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

public class WelcomeController{
    //----- Variabili di interfaccia FX
    @FXML private Text VersionLabel; //Esprime la versione dell'interfaccia Sciurus
    @FXML private Text IPLabel; //Esprime l'indirizzo IP del server Sciurus
    @FXML private Text ServerStatusLabel; //Esprime lo status del server (ONLINE | OFFLINE | INIT)
    @FXML private Circle ServerStatusIcon; //Icona grafica per ServerStatusLabel
    @FXML private Text errorLabel; //Esprime errori anomali nella cominucazione con il server
    
    //----- Attributi di gestione
    private Boolean serverStatus=false; //Indica la possibilità o meno di iniziare la modifica dei dati
        
    /**
     * Metodo che testa la raggiungibilità del server e assegna lo stato a "ServerStatus"
     */
    private void checkServer(){
        errorLabel.setText(""); //Resetto il campo di errori
        try{
            URL url=new URL("http://"+Costants.getIPDB()+":8080/sciurus/status");
            HttpURLConnection sc=(HttpURLConnection) url.openConnection();
            sc.setRequestMethod("GET");
            int responseCode = sc.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(sc.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();
                
                JsonParser parser = new JsonParser();
                JsonObject jsonResponse =  parser.parse(content.toString()).getAsJsonObject();
                
                if (jsonResponse.has("label") && "server".equals(jsonResponse.get("label").getAsString())) {
                    if (jsonResponse.has("status") && jsonResponse.get("status").getAsBoolean()) {
                        serverStatus=true;
                        //System.out.println("[ OK ] Server Online");
                        ServerStatusLabel.setText("[ONLINE]");
                        ServerStatusIcon.setFill(Color.GREEN);
                    }else{
                        serverStatus=false;
                        //System.out.println("[FAIL] Server Init");
                        ServerStatusLabel.setText("[INIT]");
                        ServerStatusIcon.setFill(Color.ORANGE);
                    }
                }else{
                    errorLabel.setText("Error: Malformed response");
                    //System.out.println("Error: Risposta malformata" + content.toString());
                }
            } else {
                errorLabel.setText("Error: Incorrect Answer");
                //System.out.println("Errore nella richiesta, codice di risposta: " + responseCode);
            }
            sc.disconnect();
        } catch (IOException e) {
                serverStatus=false;
                //System.out.println("[FAIL] Server Online");
                ServerStatusLabel.setText("[OFFLINE]");
                ServerStatusIcon.setFill(Color.RED);
        }
    }
    
    /**
     * Metodo eseguito all'avvio dell'interfaccia JavaFX
     * Sincronizza le Label e testa preventivamente la raggiungibilità del server
     */
    @FXML
    protected void initialize(){
        //Visualizzazione delle info
        VersionLabel.setText(Costants.getVERSION());
        IPLabel.setText(Costants.getIPDB());
        checkServer();
    }
        
    /**
     * Metodo che permette il passaggio all'interfaccia JavaFX di modifica
     * Questo avviene solo nel caso il server sia raggiungibile
     */
    @FXML
    private void adminData(){
        checkServer();
        if(serverStatus){
            try {
                App.setRoot("articleList");
            } catch (IOException ex) {
                errorLabel.setText("Error: Admin Interface not work");
            }
        }        
    }
}
