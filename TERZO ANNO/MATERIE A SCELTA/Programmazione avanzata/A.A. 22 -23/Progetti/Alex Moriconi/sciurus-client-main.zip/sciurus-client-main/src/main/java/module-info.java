module it.unipi.moriconi.clientsciurus {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    opens it.unipi.moriconi.clientsciurus to javafx.fxml;
    exports it.unipi.moriconi.clientsciurus;
}
