package it.unipi.moriconi.clientsciurus;

/**
 * Classe raccoglitrice di costanti relative al setup e versione dell'applicazione
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

public class Costants {
    //----- Dati Generali dell'APP
    private final static String VERSION = "Sciurus GUI V1.0";
    private final static String IPDB = "127.0.0.1";
    
    //----- Getter (autogenerati)
    /**
     * @return String Version of Sciurus GUI
     */
    public static String getVERSION() {
        return VERSION;
    }

    /**
     * @return String IP Address of Sciurus Server
     */
    public static String getIPDB() {
        return IPDB;
    }
    
}
