package it.unipi.moriconi.clientsciurus;

/**
 * Classe rappresentante un "Article"
 * {id,title,dataCreation,body,topic}
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import java.io.Serializable;
import java.util.Date;

public class Article implements Serializable{
    public Integer id;
    public String title;
    public Date dataCreation;
    public String body;
    public String topic;
    
    //----- Costruttori
    public Article(){
        
    }
    
    public Article(Integer id, String title, Date dataCreation, String body, String topic){
        this.id=id;
        this.title=title;
        this.dataCreation=dataCreation;
        this.body=body;
        this.topic=topic;
    }
    
    public Article(String title, String body, String topic){
        this.title=title;
        this.body=body;
        this.topic=topic;
    }
    
    @Override
    public String toString() {
        return "Article{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", dataCreation=" + dataCreation +
                ", body='" + body + '\'' +
                ", topic='" + topic + '\'' +
                '}';
    }

    //----- Getter (autogenerati)
    public Integer getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Date getDataCreation() {
        return dataCreation;
    }

    public String getBody() {
        return body;
    }

    public String getTopic() {
        return topic;
    }    
}
