package it.unipi.moriconi.clientsciurus;

/**
 * Eccezione per articolo non selezionato
 * 
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

public class ArticleNotSelected extends Exception {

    public ArticleNotSelected() {
    }

    public ArticleNotSelected(String msg) {
        super(msg);
    }
}
