package it.unipi.moriconi.clientsciurus;

/**
 * Classe controller del interfaccia "Articlelist"
 * 
 * Gestisce operazioni di visualizzazione, eliminazione e aggiunta di articoli
 * 
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class ArticlelistController {
    //----- Varibili di interfaccia FX
    @FXML private TableView<Article> articleTable = new TableView<>(); //Tabella di visualizzazine di tutti gli articoli
    private ArticleTable at;
    @FXML private Text VersionLabel; //Esprime la versione dell'interfaccia Sciurus 
    @FXML private Text IPLabel; //Esprime l'indirizzo IP del server Sciurus
    @FXML private Text errorLabel; //Esprime errori anomali nella cominucazione con il server
    
    //----- Varibili di inserimento nuovo articolo
    @FXML private TextField titleInput; 
    @FXML private TextField topicInput;
    @FXML private TextArea bodyInput;
    @FXML private Text titleLabel;
    @FXML private Text topicLabel;
    @FXML private Text bodyLabel;
    @FXML private Text responseLabel;

    /**
     * Metodo eseguito all'avvio dell'interfaccia JavaFX
     * Sincronizza le Label e testa preventivamente la raggiungibilità del server
     * Inserisce gli articoli nella tabella per essere visualizzati
     */
    @FXML
    protected void initialize(){
        VersionLabel.setText(Costants.getVERSION());
        IPLabel.setText(Costants.getIPDB());
        
        at=new ArticleTable(articleTable);
        loadArticleList(); //Caricamento degli articoli nella tabella
    }
    
    /**
     * Metodo che elimina effettua uno svuotamento dell'istanza della Tabella Articoli locale
     * per ricaricane il contenuto direttamente dal server
     */
    private void reloadArticleList() {
        at.clear(); //Svuota
        loadArticleList(); //Carica
    }
    
    /**
     * Metodo di popolamento della tabella per la visualizzazione
     * Effettua un chiamata GET al server
     */
    private void loadArticleList(){
        errorLabel.setText("");
        try{
            URL url = new URL("http://"+Costants.getIPDB()+":8080/sciurus/article/all");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            
            StringBuilder content = new StringBuilder();
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
            } catch (IOException ex) {
                errorLabel.setText("Error: Buffer Read");
                ex.printStackTrace();
            }
            
            Gson gson = new Gson();
            JsonElement json = gson.fromJson(content.toString(), JsonElement.class);
            JsonArray article = json.getAsJsonArray();
            
            for(int counter=0; counter<article.size(); counter++){
                JsonObject a = article.get(counter).getAsJsonObject();
                Integer id = a.get("id").getAsInt();
                String title = a.get("title").getAsString();
                String body = a.get("body").getAsString();
                String topic = a.get("topic").getAsString();
                String dataCreation = a.get("dataCreation").getAsString();
                
                //Converione della data
                String pattern = "yyyy-MM-dd";
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
                    Date dateConv = dateFormat.parse(dataCreation);
                    Article item = new Article(id, title, dateConv, body, topic);
                    at.add(item);
                    //System.out.println(item);
                    //System.out.println(at.getTotalArticles());
                    
                } catch (ParseException e) {
                    errorLabel.setText("Error: parsing date");
                    e.printStackTrace();
                }
            }
        } catch (MalformedURLException ex) {
            errorLabel.setText("Error: malformed URL");
            ex.printStackTrace();
        } catch (ProtocolException ex) {
            errorLabel.setText("Error: protocol not compatible");
            ex.printStackTrace();
        } catch (IOException ex) {
            errorLabel.setText("Error: answer read");
            ex.printStackTrace();
        }
    }
    
    /**
     * Metodo di ritorno all'interfaccia JavaFX iniziale
     * Svuotamento della tabella di visualizzazione
     */
    @FXML
    private void exit(){
        at.clear();
        try {
            App.setRoot("welcome");
        } catch (IOException ex) {
            errorLabel.setText("Error: Welcome Interface not work");
            ex.printStackTrace();
        }
    }  
    
    /**
     * Metodo attuo all'inserimento di un nuovo articolo
     * Verifica che tutti i campi siano validi e ne effettua l'invio al server tramite POST
     */
    @FXML
    private void newArticle() {
        errorLabel.setText("");
        //----- Variabile di controllo che input sia corretto
        boolean inputCheck = true;
        
        if (titleInput.getText().isEmpty()) {
            titleLabel.setFill(Color.RED);
            inputCheck = false;
        } else {
            titleLabel.setFill(Color.GREEN);
        }

        if (topicInput.getText().isEmpty()) {
            topicLabel.setFill(Color.RED);
            inputCheck = false;
        } else {
            topicLabel.setFill(Color.GREEN);
        }

        if (bodyInput.getText().isEmpty()) {
            bodyLabel.setFill(Color.RED);
            inputCheck = false;
        } else {
            bodyLabel.setFill(Color.GREEN);
        }

        if (inputCheck) {
            try {
                // Crea un nuovo oggetto Article (Incompleto)
                Article newArticle = new Article(
                        titleInput.getText(),
                        bodyInput.getText(),
                        topicInput.getText()
                );

                // Conversione oggetto in JSON
                Gson gson = new Gson();
                String requestBody = gson.toJson(newArticle);

                // Invio tramite POST
                URL url = new URL("http://" + Costants.getIPDB() + ":8080/sciurus/article/new");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);

                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = requestBody.getBytes("utf-8");
                    os.write(input, 0, input.length);
                } catch (IOException ex) {
                    errorLabel.setText("Error: Buffer Set");
                }

                // Analisi risposta del server
                StringBuilder content = new StringBuilder();
                try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                    }
                } catch (IOException ex) {
                    errorLabel.setText("Error: Buffer Read");
                    ex.printStackTrace();
                }

                // Analizza la risposta JSON
                JsonParser parser = new JsonParser();
                JsonObject jsonResponse = parser.parse(content.toString()).getAsJsonObject();

                // Verifica se la risposta contiene la chiave "label" con il valore "new" e "status" true
                if (jsonResponse.has("label") && "new".equals(jsonResponse.get("label").getAsString())
                        && jsonResponse.has("status")) {
                    boolean status = jsonResponse.get("status").getAsBoolean();
                    if (status) {
                        //System.out.println("[ OK ] New Article");
                        responseLabel.setText("OK");
                        reloadArticleList();
                    } else {
                        //System.out.println("[FAIL] New Article");
                        responseLabel.setText("FAIL");
                    }
                } else {
                    errorLabel.setText("Error: Malformed response");
                    //System.out.println("Risposta malformata o status falso: " + content.toString());
                }
            } catch (MalformedURLException ex) {
                errorLabel.setText("Error: malformed URL");
                ex.printStackTrace();
            } catch (ProtocolException ex) {
                errorLabel.setText("Error: protocol not compatible");
                ex.printStackTrace();
            } catch (IOException ex) {
                errorLabel.setText("Error: answer read");
                ex.printStackTrace();
            }
        }
    }

    /**
     * Metodo che rimuove un articolo dato il suo ID
     * Utilizza un approccio task per questa operazione
     */
    @FXML
    private void removeArticle(){
        Task removeTask = new Task<Void>(){
            @Override
            public Void call(){
                errorLabel.setText("");
                try {
                    Article targetArticle = at.selected();
                    URL url = new URL("http://" + Costants.getIPDB() + ":8080/sciurus/article/remove?idArticle=" + targetArticle.getId());
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("DELETE");

                    StringBuilder content = new StringBuilder();
                    try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                        String inputLine;
                        while ((inputLine = in.readLine()) != null) {
                            content.append(inputLine);
                        }
                    } catch (IOException ex) {
                        errorLabel.setText("Error: Buffer Read");
                        ex.printStackTrace();
                    }

                    // Analizza la risposta JSON
                    JsonParser parser = new JsonParser();
                    JsonObject jsonResponse = parser.parse(content.toString()).getAsJsonObject();

                    // Verifica se la risposta contiene la chiave "label" con il valore "remove" e "status" true
                    if (jsonResponse.has("label") && "remove".equals(jsonResponse.get("label").getAsString())
                            && jsonResponse.has("status") && jsonResponse.get("status").getAsBoolean()) {
                        // Rimuovi l'articolo dalla tabella FX
                        at.remove(targetArticle);
                    } else {
                        // Gestisci il caso in cui la risposta non corrisponde alle aspettative
                        errorLabel.setText("Error: Malformed response");
                        System.out.println("Risposta malformata o status falso: " + content.toString());
                    }
                } catch (MalformedURLException ex) {
                    errorLabel.setText("Error: malformed URL");
                    ex.printStackTrace();
                } catch (IOException ex) {
                    errorLabel.setText("Error: answer read");
                    ex.printStackTrace();
                } catch (ArticleNotSelected ex) {
                    errorLabel.setText("Error: not selected article");
                    ex.printStackTrace();
                }   
                return null;
            }
        };
        new Thread(removeTask).start();
    }
}
