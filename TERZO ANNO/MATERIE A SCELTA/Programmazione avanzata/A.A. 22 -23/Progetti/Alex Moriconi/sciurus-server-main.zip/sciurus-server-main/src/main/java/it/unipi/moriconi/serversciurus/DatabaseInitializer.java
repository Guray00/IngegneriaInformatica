package it.unipi.moriconi.serversciurus;

/**
 * Verifica del DB se esiste o no, popolazione ed inizializzazione
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

@Configuration
public class DatabaseInitializer {
    
    @Autowired
    private DataSource dataSource;

    /**
     * L'annotazione "@BEAN" identifica un metodo di fabbrica
     * per la creazione dell'ambiente Spring
     * In questo caso si occupa dell'inizializzazione del DB in caso questo
     * non esista
     * @return 
     */
    
    @Bean
    public CommandLineRunner initData() {
        return args -> {
            if (!databaseExists()) {
                System.out.println("[FAIL] DB Inesistente");
                initializeDatabase();
            } else {
                System.out.println("[ OK ] DB Esistente");
            }
        };
    }
    
    /**
     * Verifica l'esistenza del DB attraverso un query sull information_schema
     * @return true if exists
     */
    boolean databaseExists() {
        try {
            JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
            String query = "SELECT 1 FROM information_schema.tables WHERE table_schema = '615958' AND table_name = 'Article'";
            Integer result = jdbcTemplate.queryForObject(query, Integer.class);
            return (result != null && result == 1);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Inizializza il DB attraverso il file data.sql
     */
    private void initializeDatabase() {
        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        populator.addScript(new ClassPathResource("data.sql"));

        DataSourceInitializer initializer = new DataSourceInitializer();
        initializer.setDataSource(dataSource);
        initializer.setDatabasePopulator(populator);

        try {
            initializer.afterPropertiesSet();
            System.out.println("[ OK ] DB Popolato da data.sql");
        } catch (Exception e) {
            System.out.println("[FAIL] Errore durante l'inizializzazione del database: " + e.getMessage());
        }
    }
}