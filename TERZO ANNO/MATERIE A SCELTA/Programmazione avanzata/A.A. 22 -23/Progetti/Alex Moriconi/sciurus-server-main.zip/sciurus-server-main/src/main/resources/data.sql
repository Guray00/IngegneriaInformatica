/**
 * Definizione della struttura del DB e popolamento con i dati di test
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

CREATE TABLE IF NOT EXISTS article (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255),
    body TEXT,
    data_creation DATE,
    topic VARCHAR(255)
);

INSERT INTO article (title, body, data_creation, topic) VALUES
('Java Basics', 'Introduction to Java programming language.', '2022-01-01', 'Programming'),
('Spring Boot Overview', 'Understanding the basics of the Spring Boot framework.', '2022-01-02', 'Java Framework'),
('Introduction to Python', 'Getting started with the Python programming language.', '2022-01-03', 'Programming'),
('Web Development with JavaScript', 'Exploring frontend development with JavaScript.', '2022-01-04', 'Web Development'),
('Data Structures in C++', 'Learn about common data structures in C++.', '2022-01-05', 'Programming'),
('Cybersecurity Fundamentals', 'Understanding the basics of cybersecurity.', '2022-01-06', 'Cybersecurity'),
('Android App Development', 'Building mobile apps with Android.', '2022-01-07', 'Mobile Development'),
('Database Design Principles', 'Essential principles for designing databases.', '2022-01-08', 'Database'),
('Cloud Computing Technologies', 'Overview of cloud computing technologies.', '2022-01-09', 'Cloud Computing'),
('Artificial Intelligence Basics', 'Introduction to AI and machine learning.', '2022-01-10', 'Artificial Intelligence'),
('RESTful API Design', 'Best practices for designing RESTful APIs.', '2022-02-11', 'Web Development'),
('Microservices Architecture', 'Exploring microservices architecture in software development.', '2022-02-12', 'Software Architecture'),
('React.js Fundamentals', 'Getting started with React.js for building user interfaces.', '2022-02-13', 'Web Development'),
('Node.js Server-Side Development', 'Building server-side applications with Node.js.', '2022-02-14', 'Web Development'),
('Software Testing Techniques', 'Understanding various software testing techniques.', '2022-02-15', 'Software Testing'),
('Big Data Analytics', 'Overview of big data analytics and its applications.', '2022-02-16', 'Big Data'),
('Machine Learning Algorithms', 'Exploring common machine learning algorithms.', '2022-02-17', 'Machine Learning'),
('DevOps Principles', 'Introduction to DevOps principles and practices.', '2022-02-18', 'DevOps'),
('Containerization with Docker', 'Getting started with containerization using Docker.', '2022-02-19', 'DevOps'),
('RESTful Web Services', 'Building RESTful web services for modern applications.', '2022-02-20', 'Web Development'),
('Python Flask Framework', 'Building web applications with the Python Flask framework.', '2022-02-21', 'Web Development'),
('JavaScript ES6 Features', 'Exploring the features of JavaScript ES6.', '2022-02-22', 'Web Development'),
('JavaFX GUI Programming', 'Creating graphical user interfaces with JavaFX.', '2022-02-23', 'Java Framework'),
('Agile Software Development', 'Understanding Agile methodologies in software development.', '2022-02-24', 'Software Development'),
('Introduction to Blockchain', 'Overview of blockchain technology and its applications.', '2022-02-25', 'Blockchain'),
('Mobile App Security', 'Best practices for securing mobile applications.', '2022-02-26', 'Mobile Development'),
('Responsive Web Design', 'Designing web applications for different screen sizes.', '2022-02-27', 'Web Development'),
('GraphQL API Development', 'Building APIs with GraphQL for efficient data retrieval.', '2022-02-10', 'Web Development'),
('Linux System Administration', 'Essential skills for Linux system administration.', '2022-02-11', 'Linux'),
('Java Multithreading Concepts', 'Understanding multithreading concepts in Java programming.', '2022-03-01', 'Programming'),
('Data Encryption Techniques', 'Exploring techniques for data encryption and security.', '2022-03-02', 'Security'),
('Vue.js Frontend Framework', 'Building interactive user interfaces with Vue.js.', '2022-03-03', 'Web Development'),
('Artificial Neural Networks', 'Introduction to artificial neural networks in machine learning.', '2022-03-04', 'Machine Learning'),
('User Experience (UX) Design', 'Designing user-friendly and intuitive user experiences.', '2022-03-05', 'Design'),
('Java Persistence with Hibernate', 'Using Hibernate for database persistence in Java applications.', '2022-03-06', 'Java Framework'),
('Git Version Control', 'Understanding version control with Git for software development.', '2022-03-07', 'Version Control'),
('Internet of Things (IoT)', 'Overview of IoT and its impact on the modern world.', '2022-03-08', 'IoT'),
('Angular Framework Basics', 'Getting started with the Angular framework for web development.', '2022-03-09', 'Web Development'),
('Distributed Systems Concepts', 'Understanding concepts of distributed systems architecture.', '2022-03-10', 'Distributed Systems'),
('Python Django Web Framework', 'Building web applications with the Python Django framework.', '2022-03-11', 'Web Development'),
('Cloud Security Best Practices', 'Best practices for ensuring security in cloud computing.', '2022-03-12', 'Cloud Computing'),
('Java Design Patterns', 'Exploring common design patterns in Java programming.', '2022-03-13', 'Design Patterns'),
('Mobile App Accessibility', 'Ensuring accessibility in mobile app design and development.', '2022-03-14', 'Mobile Development'),
('Ruby on Rails Web Framework', 'Building web applications with the Ruby on Rails framework.', '2022-03-15', 'Web Development'),
('Software Refactoring Techniques', 'Techniques for improving code quality through refactoring.', '2022-03-16', 'Software Development'),
('Kotlin Programming Language', 'Introduction to the Kotlin programming language for Android development.', '2022-03-17', 'Programming'),
('Computer Vision Concepts', 'Understanding concepts of computer vision in artificial intelligence.', '2022-03-18', 'Computer Vision'),
('Network Security Fundamentals', 'Exploring fundamental concepts of network security.', '2022-03-19', 'Security'),
('Java EE (Enterprise Edition)', 'Overview of Java EE for building enterprise-level applications.', '2022-03-20', 'Java Framework');
