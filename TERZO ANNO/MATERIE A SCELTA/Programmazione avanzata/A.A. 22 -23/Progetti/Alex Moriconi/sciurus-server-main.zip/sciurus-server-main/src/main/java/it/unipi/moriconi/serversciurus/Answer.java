package it.unipi.moriconi.serversciurus;

/**
 * Implementa le risposte per le vari interazioni Json con il server
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */
public class Answer {
    private String label;
    private Boolean status;
    
    public Answer(String label, Boolean status){
        this.label=label;
        this.status=status;
    }
    
}
