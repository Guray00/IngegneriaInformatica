package it.unipi.moriconi.serversciurus;

/**
 * Costituisce la Unit Test per il "Server Controller"
 * 
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.extension.ExtendWith;

/* Indico a JUnit (Entità Java per la gestione dei test) di utilizzare il framework
*  Mockito durante l'esecuzione dei test.
*/
@ExtendWith(MockitoExtension.class)
public class ServerControllerTest {

    /* Creo un oggetto mock di tipo DatabaseInitializer 
    *  Questa fase è denominata "Micking"
    *  Gli oggetti "Mock" consentono di emulare oggetti reali tuttavia
    *  consentono a fini di test di stabilire in modo predefinito la risposta alle chiamate
    */
    @Mock
    private DatabaseInitializer databaseInitializerMock;

    /* Inietto gli oggetti mock nelle proprietà della classe serverController
    */
    @InjectMocks
    private ServerController serverController;

    /* Specifico a JUnit che questo metodo è un Test ed dovrà essere eseguito
    */
    @Test
    public void testGetStatus() {
        
        /* Con il metodo when configuro il comportamento dell'oggetto mock al fine di rituronare
        *  true nel alla chiamata del metodo databaseExists();
        *  L'operazione descritta si chiama "Stubbing"
        */
        when(databaseInitializerMock.databaseExists()).thenReturn(true);
        /* Effettuo la chiamata vera a prioria al metodo da testare getStatus
        *  a sua volta richiamerà il metodo dell'oggetto mock di cui abbiamo già obblicato
        *  il comportamento
        */
        String jsonResponse = serverController.getStatus();
        /* Infine verifico che la risposta soddisfi i requisiti.
        *  In questo caso la comparo con la risposta JSON prevista per tale caso
        */
        assertEquals("{\"label\":\"server\",\"status\":true}", jsonResponse);
        when(databaseInitializerMock.databaseExists()).thenReturn(false);
        jsonResponse = serverController.getStatus();
        assertEquals("{\"label\":\"server\",\"status\":false}", jsonResponse);
    }
}

