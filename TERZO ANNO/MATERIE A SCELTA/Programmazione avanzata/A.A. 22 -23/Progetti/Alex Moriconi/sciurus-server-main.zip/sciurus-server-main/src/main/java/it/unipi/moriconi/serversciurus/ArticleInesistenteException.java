package it.unipi.moriconi.serversciurus;

/**
 * UtenteInesistenteException
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */
public class ArticleInesistenteException extends Exception {

    public ArticleInesistenteException() {
    }

    public ArticleInesistenteException(String msg) {
        super(msg);
    }
}
