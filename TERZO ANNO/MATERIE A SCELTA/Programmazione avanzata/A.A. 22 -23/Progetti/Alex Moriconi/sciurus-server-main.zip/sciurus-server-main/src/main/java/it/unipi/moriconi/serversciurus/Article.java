package it.unipi.moriconi.serversciurus;

/**
 * Classe rappresentante la tabella "Article" del database
 * {id,title,dataCreation,body,topic}
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;

@Entity
@Table(name="Article", schema="Article")
public class Article{
    @Id
    //La numerazione degli indici degli "Article" è autogestita
    //@GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;
    
    @Column(name="title")
    private String title;
    
    @Column(name="dataCreation")
    @Temporal(javax.persistence.TemporalType.DATE)
    //La data di inserimento è inserita in automatico
    private Date dataCreation;
    
    @PrePersist
    protected void onCreate() {
        this.dataCreation = new Date();
    }
        
    @Column(name="body")
    private String body;

    @Column(name="topic")
    private String topic;
            
    //----- Costruttori
    public Article(){
        
    }
  
    public Article(Integer id, String title, String body, String topic){
        this.id=id;
        this.title=title;
        this.body=body;
        this.topic=topic;
    }
    
    //----- Getter & Setter (autogenerati)
    public Integer getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Date getDataCreation() {
        return dataCreation;
    }

    public String getBody() {
        return body;
    }
            
    public String getTopic() {
        return topic;
    }
    
}