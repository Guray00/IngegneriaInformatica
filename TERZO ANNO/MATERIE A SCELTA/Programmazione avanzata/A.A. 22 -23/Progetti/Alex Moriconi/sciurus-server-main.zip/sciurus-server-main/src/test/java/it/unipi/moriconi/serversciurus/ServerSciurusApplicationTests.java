package it.unipi.moriconi.serversciurus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerSciurusApplicationTests {

	@Test
	void contextLoads() {
	}
}
