package it.unipi.moriconi.serversciurus;

/**
 * Classe di astrazione e gestione dati rispetto al DataBase per la tabella "Article"
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface ArticleRepository extends CrudRepository<Article, Integer> {
    /**
     * Trova un articolo dato il titolo 
     * @param title
     * @return boolean
     */
    public Article findByTitle(String title);


    /**
     * Trova un articolo dato il suo Id
     * @param id
     * @return boolean
     */
    public Article findById(int id);
    
    /**
     * Elimina un articolo dato il suo Id
     * @param id
     * @return boolean
     */
    public Article deleteById(int id);
    
    /**
     * Ritorna il prossimo ID utilizzabile
     * @return int next ID
     */
    @Query(value= "SELECT COALESCE(MAX(id), 0) + 1 FROM Article", nativeQuery = true)
    public int nextId();
}
