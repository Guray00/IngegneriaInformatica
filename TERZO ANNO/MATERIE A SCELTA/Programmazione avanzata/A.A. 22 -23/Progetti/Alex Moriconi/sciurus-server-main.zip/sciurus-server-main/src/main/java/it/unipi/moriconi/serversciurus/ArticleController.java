package it.unipi.moriconi.serversciurus;

/**
 * Costituisce la classe controller che permette l'interfazione con la tabella "Article"
 * 
 * Mapping espositi:
 * - /scriurus/article/all
 * - /scriurus/article/new
 * - /scriurus/article/remove
 * 
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(path="/sciurus/article") //Path base per questa implementazione
public class ArticleController{

    @Autowired
    private ArticleRepository articleRepository;
    
    /**
     * Ritorna l'elenco completo degli "Article" presenti nel DB
     * @return Iterable di "Article"
     */
    @GetMapping("/all")
    @ResponseBody
    public Iterable<Article> getAllArticles() {
        return articleRepository.findAll();
    }
    
    /**
     * Effettua l'inserimento di un nuovo articolo nel DB
     * verificando l'univocità del titoli
     * @param request
     * @return String Json format
     */
    @PostMapping("new")
    @ResponseBody
    public String addNewArticle(@RequestBody Article request) {
        Gson gson = new Gson();
        boolean newStatus;

        try {
            Article existingArticle = articleRepository.findByTitle(request.getTitle());
            if (existingArticle != null) {
                // Articolo già presente nel repository
                newStatus = false;
                System.out.println("[FAIL] Add new Article - Titolo esistente");
            } else {
                // Articolo non presente nel repository, lo salviamo
                Article newArticle = new Article(articleRepository.nextId(), request.getTitle(), request.getBody(), request.getTopic());
                articleRepository.save(newArticle);
                newStatus = true;
                System.out.println("[ OK ] Add new Article");
            }
        } catch (Exception ex) {
            // Gestione delle eccezioni
            newStatus = false;
            System.out.println("[FAIL] Add new Article - Eccezione: " + ex.getMessage());
            ex.printStackTrace(); // Questo stampa l'intera traccia dell'eccezione
        }

        return gson.toJson(new Answer("new", newStatus));
    }
    
    /**
     * Effettua l'eliminazione di un articolo dal DB
     * @param idArticle
     * @return String Json format
     */
    @DeleteMapping("remove")
    @ResponseBody
    public String removeArticle(@RequestParam int idArticle){
        Gson gson = new Gson();
        boolean removeStatus;
        Article a=articleRepository.findById(idArticle);
        if(a==null){ 
            removeStatus=false;
        }else{
            articleRepository.deleteById(idArticle);
            removeStatus=true;
        }
        return gson.toJson(new Answer("remove",removeStatus)); 
    }
}
