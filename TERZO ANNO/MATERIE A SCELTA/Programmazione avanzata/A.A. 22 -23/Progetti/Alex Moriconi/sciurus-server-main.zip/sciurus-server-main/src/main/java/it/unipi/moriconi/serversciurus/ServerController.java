package it.unipi.moriconi.serversciurus;

/**
 * Costituisce la classe controller che permette al client di avere informazioni
 * in merito allo stato del DB
 * 
 * Mapping espositi:
 * - /scriurus/status
 * 
 * @author Alex Moriconi (615958)
 * @versione 1.0
 * @date 03/2024
 */

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(path = "/sciurus/")
public class ServerController {

    @Autowired
    private DatabaseInitializer databaseInitializer;

    /**
     * Verifica la possibilità del client di accedere
     * @return String Json format
     */
    @GetMapping(path = "/status")
    public @ResponseBody String getStatus() {
        Gson gson = new Gson();
        boolean serverStatus = databaseInitializer.databaseExists();
        return gson.toJson(new Answer("server",serverStatus));
    }
}
