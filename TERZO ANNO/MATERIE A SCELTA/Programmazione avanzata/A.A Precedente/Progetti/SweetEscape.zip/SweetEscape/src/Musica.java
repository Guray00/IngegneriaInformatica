
import java.io.*;
import javafx.scene.media.*;
import javafx.util.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class Musica {
	
	static MediaPlayer musicPlayer;
	static MediaPlayer scoreUp;
	static MediaPlayer gameOver;
	static MediaPlayer clockTick;
	
	public static void creaMusica()
	{
		String musicPath = "./assets/music/coffee_rain.mp3";
		String scoreUpPath = "./assets/music/score_up.wav";
		String gameOverPath = "./assets/music/game_over.mp3";
		String tickPath = "./assets/music/time_click.mp3";
		
		Media game = new Media(new File(gameOverPath).toURI().toString());
		gameOver =new MediaPlayer(game);
		
		Media tick = new Media(new File(tickPath).toURI().toString());
		clockTick =new MediaPlayer(tick);
		
		Media score = new Media(new File(scoreUpPath).toURI().toString());
		scoreUp =new MediaPlayer(score);
		
		Media music = new Media(new File(musicPath).toURI().toString());
		musicPlayer =new MediaPlayer(music);
		musicPlayer.setOnEndOfMedia
		(() -> {
			musicPlayer.seek(Duration.ZERO);
		});
		
		musicPlayer.setVolume(((double)SweetEscape.config.volumeAudio/101)%1);
	}
	
	public static void avviaMusica()
	{
		if(SweetEscape.config.statoAudio)
		musicPlayer.play();
	}
	
	public static void fermaMusica()
	{
		if(SweetEscape.config.statoAudio)
		musicPlayer.pause();
	}
	
	public static void resettaMusica()
	{
		if(SweetEscape.config.statoAudio)
		musicPlayer.stop();
	}
	
	public static void scoreUp()
	{
		if(SweetEscape.config.statoAudio)
		{
			scoreUp.stop();
			scoreUp.play();
		}
	}
	
	public static void gameOver()
	{
		if(SweetEscape.config.statoAudio)
		{
			gameOver.stop();
			gameOver.play();
		}
	}
	
	public static void clockTick()
	{
		if(SweetEscape.config.statoAudio)
		{
			clockTick.stop();
			clockTick.play();
		}
	}
}
