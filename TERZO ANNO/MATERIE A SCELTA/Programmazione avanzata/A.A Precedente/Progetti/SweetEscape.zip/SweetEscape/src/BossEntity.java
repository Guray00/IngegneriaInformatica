
import java.util.*;
import javafx.animation.*;
import javafx.scene.layout.*;
import javafx.util.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class BossEntity extends Entity implements GAME_PARAMETERS{
	
	int currentEntities = 0;
	private Timeline lanciaLibriTimeline=null;
	List<BookProjectileEntity> proiettili = new ArrayList<>();
	Pane bossPane;
	
	BossEntity(Pane gamePane, double x,double y,double w,double h)
	{
		super(gamePane,x,y,w,h,DEFAULT_BOSS);
		bossPane = gamePane;
	}
	
	private void creaAnimazioniLibri()
	{
		lanciaLibriTimeline = new Timeline
		(
			new KeyFrame
			(
				Duration.seconds
				(
					5
				)
			)
		);
		lanciaLibriTimeline.setCycleCount(Animation.INDEFINITE);
		lanciaLibriTimeline.play();
	}
	void ricreaAnimazioniLibri()
	{
		if(lanciaLibriTimeline==null)creaAnimazioniLibri();
		double secondiAttesa;
		switch(SweetEscape.GAME_DIFFICULTY)
		{
			case EASY:  secondiAttesa = 4; break;
			case NORMAL:  secondiAttesa = 2.5; break;
			case HARD:  secondiAttesa = 1; break;
			case INSANITY:  secondiAttesa = 0.4; break;
			default: secondiAttesa = 2.5; break;
		}
		KeyFrame keyFrame = new KeyFrame(
				Duration.seconds(secondiAttesa), e -> 
				{
					if(SweetEscape.GAME_STARTED && currentEntities<MAX_PROJECTILES_ON_SCREEN)
					{
						proiettili.add(
						new BookProjectileEntity(
							this,
							entityPane,
							currX+DEFAULT_BOOK_WIDTH/2,
							currY+DEFAULT_BOOK_HEIGHT/2,
							DEFAULT_BOOK_WIDTH
							,DEFAULT_BOOK_HEIGHT
						));
						currentEntities++;
					}
				}
		);
		lanciaLibriTimeline.stop();
		lanciaLibriTimeline.getKeyFrames().setAll(keyFrame);
		lanciaLibriTimeline.play();
	}
}
