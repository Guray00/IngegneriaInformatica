
import java.io.*;
import java.util.*;
import java.util.stream.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

class DatiLibri implements Serializable{
	
	List<Double> currX;
	List<Double> currY;
	List<Double> velX;
	List<Double> velY;
	List<Boolean> active;
	List<Double> width;
	List<Double> height;
	
	DatiLibri(List<BookProjectileEntity> proiettili) {
		currX = proiettili.stream().map(BookProjectileEntity -> BookProjectileEntity.getCurrX()).collect(Collectors.toList());
		currY = proiettili.stream().map(BookProjectileEntity -> BookProjectileEntity.getCurrY()).collect(Collectors.toList());
		velX = proiettili.stream().map(BookProjectileEntity -> BookProjectileEntity.getVelX()).collect(Collectors.toList());
		velY = proiettili.stream().map(BookProjectileEntity -> BookProjectileEntity.getVelY()).collect(Collectors.toList());
		active = proiettili.stream().map(BookProjectileEntity -> BookProjectileEntity.getActive()).collect(Collectors.toList());
		width = proiettili.stream().map(BookProjectileEntity -> BookProjectileEntity.getWidth()).collect(Collectors.toList());
		height = proiettili.stream().map(BookProjectileEntity -> BookProjectileEntity.getHeight()).collect(Collectors.toList());
	}
	
	void ricostruisciListaLibriLanciati(BossEntity boss)
	{
		for (int i = 0; i < active.size(); ++i) //tanto avranno tutti la stessa lunghezza
		{
			if(active.get(i))
			{
				boss.proiettili.add
				(
					new BookProjectileEntity
					(
						boss,
						boss.bossPane,
						currX.get(i),
						currY.get(i),
						width.get(i),
						height.get(i)
					)
				);
				boss.proiettili.get(i).velX=this.velX.get(i);
				boss.proiettili.get(i).velY=this.velY.get(i);
			}
		}
	}
}
