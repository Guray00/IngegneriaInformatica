
import javafx.animation.*;
import javafx.util.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class GestoreCollisioni implements GAME_PARAMETERS{
		
	static void controllaCollisioniLibri(KidEntity kid,BossEntity boss,BookProjectileEntity book)
	{
		Timeline gameTime = 
		new Timeline
		(
			new KeyFrame
			(
				Duration.millis(50),(evt) -> 
				{
					try
					{
						if
						(
							kid.aspectReference.getBoundsInParent().intersects
							(
								book.aspectReference.getBoundsInParent()
							)
						)
						{
							System.out.println("Stai prendendo danni!");
							book.active=false;
							EntityDrawEngine.removeEntityDrawing(book);
							GestoreStatiDiGioco.gameOver();
							Musica.gameOver();
						}
						if(SweetEscape.GAME_RESET && !SweetEscape.GAME_LOADED)
						{
							book.active=false;
							EntityDrawEngine.removeEntityDrawing(book);
						}
						if 
						(
							book.currX < 0 || 
							book.currX >= GAME_WINDOW_RIGHT_BOUND-
								DEFAULT_BOOK_WIDTH ||
							book.currY < 0 || 
							book.currY >= GAME_WINDOW_LOWER_BOUND-
								DEFAULT_BOOK_HEIGHT ||
							(SweetEscape.GAME_RESET && !SweetEscape.GAME_LOADED)
						) {
							EntityDrawEngine.removeEntityDrawing(book);
							book.active = false;
							boss.proiettili.remove(book);
							boss.currentEntities--;
						}
					}
					catch(java.lang.NullPointerException e)
					{
						System.err.println("Lanciata NullPointerException");
					}
					catch(Exception e)
					{
						System.err.println("Lanciata altra Eccezione libri");
					}
				}
			)
		);
		
		gameTime.setCycleCount(Animation.INDEFINITE);
		gameTime.play();
	}
	
	static void controllaCollisioniCaramella(KidEntity kid, CandyEntitySpawner spawnerCaramelle, CandyEntity caramella)
	{
		Timeline gameTime = 
		new Timeline
		(
			new KeyFrame
			(
				Duration.millis(100),(evt) -> 
				{
					try
					{
						if
						(	
							caramella.eaten==false &&
							kid.aspectReference.getBoundsInParent().intersects
							(
								caramella.aspectReference.getBoundsInParent()
							)
						)
						{
							System.out.println("Hai preso una caramella!");
							caramella.eaten=true;
							EntityDrawEngine.removeEntityDrawing(caramella);
							spawnerCaramelle.candyList.remove(caramella);
							spawnerCaramelle.currentCandys--;
							kid.addPoints();
							Musica.scoreUp();
						}
						if(SweetEscape.GAME_RESET && !SweetEscape.GAME_LOADED)
						{
							caramella.eaten=true;
							EntityDrawEngine.removeEntityDrawing(caramella);
							spawnerCaramelle.currentCandys=0;
						}
					}
					catch(java.lang.NullPointerException e)
					{
						System.err.println("Lanciata NullPointerException");
					}
					catch(Exception e)
					{
						System.err.println("Lanciata altra Eccezione caramella");
					}
				}
			)
		);
		
		gameTime.setCycleCount(Animation.INDEFINITE);
		gameTime.play();
	}
}
