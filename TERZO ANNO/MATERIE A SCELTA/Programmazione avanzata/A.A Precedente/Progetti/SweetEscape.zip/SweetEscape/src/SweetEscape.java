
import javafx.application.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class SweetEscape extends Application implements GAME_PARAMETERS{

	public static boolean GAME_STARTED = false;
	public static boolean GAME_RESET = true;
	public static boolean GAME_LOADED = false;
	public static Difficulty GAME_DIFFICULTY = Difficulty.NORMAL;
	

	private BorderPane root;

	public static KidEntity kid;
	public static BossEntity boss;
	public static CandyEntitySpawner fabbricaCaramelle;
	public static ConfigObj config;
	private VistaGiocoSweetEscape vistaGioco;
	private VistaLeaderboard vistaLeaderboard;
	private ZonaUsername registrazione;
	static Label vistaPunti;
	static Label vistaTempo;
	private Label vistaInfo;
	private Button bottoneDifficultyUp;
	private Button bottoneDifficultyDown;
	private Button bottoneReset;
	private Button bottoneStart;
	private Button bottonePause;
	private Stage finestraPrincipale;
	private Scene scenaPrincipale;
	private VBox vboxRight;
	private HBox hboxBottom;

	private Parent createContent()
	{
		root.setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		registrazione = new ZonaUsername();
		registrazione.setId("registrazione");
		vistaGioco = new VistaGiocoSweetEscape();
		vistaLeaderboard = new VistaLeaderboard();

		vistaPunti = new Label("Punti: 0");
		vistaPunti.setId("puntiAttuali");

		vistaTempo = new Label("Tempo: 00 : 00");
		vistaTempo.setId("tempoAttuale");

		vistaInfo = new Label(
				"Muoviti con A/S/D/W \n"
				+ "mentre schivi i micidiali \n"
				+ "libri del boss!\n"
				+ "Quante caramelle\n"
				+ "otterrai prima di farti\n"
				+ "prendere?"
				);
		vistaInfo.setId("vistaInfo");

		bottoneDifficultyUp = new Button("Difficulty Up");
		bottoneDifficultyUp.setId("bottoneDifficultyUp");
		bottoneDifficultyUp.setOnAction(actionEvent ->  {
			switch(GAME_DIFFICULTY)
			{
				case EASY: GAME_DIFFICULTY = Difficulty.NORMAL;break;
				case NORMAL: GAME_DIFFICULTY = Difficulty.HARD;break;
				case HARD: GAME_DIFFICULTY = Difficulty.INSANITY;break;
				case INSANITY: break;
			}
			LogSender.inviaOperazione(new Log("Premuto pulsante Aumenta Difficolta' Gioco"));
		});

		bottoneDifficultyDown = new Button("Difficulty Down");
		bottoneDifficultyDown.setId("bottoneDifficultyDown");
		bottoneDifficultyDown.setOnAction(actionEvent ->  {
			switch(GAME_DIFFICULTY)
			{
				case EASY: break;
				case NORMAL: GAME_DIFFICULTY = Difficulty.EASY;break;
				case HARD: GAME_DIFFICULTY = Difficulty.NORMAL;break;
				case INSANITY: GAME_DIFFICULTY = Difficulty.HARD;break;
			}
			LogSender.inviaOperazione(new Log("Premuto pulsante Abbassa Difficolta' Gioco"));
		});

		bottoneReset = new Button("",resetButton);
		bottoneReset.setId("bottoneReset");
		bottoneReset.setOnAction(actionEvent ->  {
			bottoneDifficultyUp.setDisable(false);
			bottoneDifficultyDown.setDisable(false);
			bottoneStart.setDisable(false);
			bottonePause.setDisable(true);
			registrazione.setDisable(false);
			GestoreStatiDiGioco.resettaGioco();
			LogSender.inviaOperazione(new Log("Premuto pulsante Resetta Gioco"));
		});

		bottoneStart = new Button("",playButton);
		bottoneStart.setId("bottoneStart");
		bottoneStart.setOnAction(actionEvent ->  {
			try
			{
				if(!registrazione.getText().isEmpty())
				{
					bottoneDifficultyUp.setDisable(true);
					bottoneDifficultyDown.setDisable(true);
					bottoneStart.setDisable(true);
					bottonePause.setDisable(false);
					registrazione.setDisable(true);
					GestoreStatiDiGioco.avviaGioco(registrazione);
					LogSender.inviaOperazione(new Log("Premuto pulsante Avvia Gioco"));
				}
				else
				System.err.println("Avvio impossibile, zona nome vuota!");
			}
			catch(Exception e)
			{
				System.err.println("Avvio impossibile, zona nome vuota!");
			}

		});

		bottonePause = new Button("",pauseButton);
		bottonePause.setId("bottonePause");
		bottonePause.setDisable(true);
		bottonePause.setOnAction(actionEvent ->  {
			bottoneStart.setDisable(false);
			bottonePause.setDisable(true);
			GestoreStatiDiGioco.pausaGioco();
			LogSender.inviaOperazione(new Log("Premuto pulsante Pausa Gioco"));
		});

		vistaGioco.loadStyle();

		vboxRight = new VBox();
		vboxRight.setPrefSize(WINDOW_WIDTH-GAME_WINDOW_RIGHT_BOUND, WINDOW_HEIGHT);
		vboxRight.getChildren().addAll(vistaPunti,vistaTempo);
		
		VistaLeaderboard.creaLeaderboard();
		vboxRight.getChildren().add(VistaLeaderboard.tabellaGiocatori);
		VistaLeaderboard.tabellaGiocatori.setId("leaderboard");
		
		vboxRight.getChildren().addAll(vistaInfo,registrazione);

		hboxBottom = new HBox();
		hboxBottom.setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT-GAME_WINDOW_LOWER_BOUND);
		hboxBottom.getChildren().addAll(bottoneDifficultyUp,bottoneDifficultyDown,bottoneReset,bottoneStart,bottonePause);

		hboxBottom.getStylesheets().add("file:./css/hbox.css");
		vboxRight.getStylesheets().add("file:./css/vbox.css");

		root.setRight(vboxRight);
		root.setBottom(hboxBottom);
		root.setCenter(vistaGioco);

		return root;
	}
		
	@Override
	public void start(Stage fp) 
	{
		Thread serverRemoto = new Thread() 
		{
			@Override
			public void run() 
			{
				LogServerRemoto.main(); //facciamo finta che in remoto il server di log sia attivo
			}
		};
		serverRemoto.start();
		
		finestraPrincipale=fp;
		finestraPrincipale.setTitle("Sweet Escape");
		root = new BorderPane();
		
		config = GestoreConfigurazioneXML.caricaConfigurazioneXML();
		
		finestraPrincipale.setScene(new Scene(createContent())); 
		scenaPrincipale = finestraPrincipale.getScene();
		finestraPrincipale.setResizable(false);
		
		GestoreStatiDiGioco.preparzioneGioco(vistaGioco,scenaPrincipale);
		
		CacheStatoGiocoSweetEscape.caricaStatoGioco(kid,boss,fabbricaCaramelle, registrazione);//carica cache se esiste e triggera redraw
		if(GAME_LOADED)
		{
			bottoneDifficultyUp.setDisable(true);
			bottoneDifficultyDown.setDisable(true);
		}
		
		finestraPrincipale.setOnCloseRequest(
			(WindowEvent chiusura) -> 
			{
				LogSender.inviaOperazione(new Log("Gioco Terminato!"));
				CacheStatoGiocoSweetEscape.salvaStatoGioco(kid,boss,fabbricaCaramelle);
				serverRemoto.interrupt();
				LogSender.inviaOperazione(new Log("stop")); // serve a sbloccare l' accept
			}
		);
		
		root.requestFocus();
		finestraPrincipale.show();
		LogSender.inviaOperazione(new Log("Avviata Applicazione"));
	}
}
