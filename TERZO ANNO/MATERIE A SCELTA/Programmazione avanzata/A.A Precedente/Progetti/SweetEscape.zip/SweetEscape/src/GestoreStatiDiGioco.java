
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.*;
import javafx.util.Duration;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class GestoreStatiDiGioco implements GAME_PARAMETERS{
	
	
	static KeyFrame frame= new KeyFrame(
					Duration.seconds(1), e -> 
					{if(SweetEscape.GAME_STARTED){
						SweetEscape.kid.tempoPartita++;
						SweetEscape.vistaTempo.setText
						(
							"Tempo: "+
							(int)Math.floor(SweetEscape.kid.tempoPartita/600)+""+
							(SweetEscape.kid.tempoPartita/60)%10+
							" : "+
							(int)Math.floor(SweetEscape.kid.tempoPartita%60/10)+""+
							(SweetEscape.kid.tempoPartita%60)%10
						);
						SweetEscape.kid.controllaDetrazioniPunti();
					}}
			);
	static Timeline timerGioco = new Timeline(frame);
	
	
	static void avviaGioco(ZonaUsername registrazione)
	{
		if(SweetEscape.GAME_RESET)
		{
			SweetEscape.GAME_RESET = false;
			SweetEscape.boss.ricreaAnimazioniLibri();
			resettaTimer();
		}
		SweetEscape.GAME_LOADED = false;
		SweetEscape.GAME_STARTED = true;
		SweetEscape.kid.username = new String(registrazione.getText());
		avviaTimer();
		Musica.avviaMusica();
	}
	static void resettaGioco()
	{
		GAME_OVER.setVisible(false);
		SweetEscape.GAME_RESET = true;
		SweetEscape.GAME_STARTED = false;
		resettaTimer();
		Musica.resettaMusica();
	}
	static void pausaGioco()
	{
		SweetEscape.GAME_STARTED = false;
		fermaTimer();
		Musica.fermaMusica();
	}
	static void gameOver()
	{
		Giocatore tempGiocatore = GestoreDatabase.estraiGiocatore(SweetEscape.kid.username);
		if(tempGiocatore == null || tempGiocatore.getPunteggio() <SweetEscape.kid.points)
		SweetEscape.kid.salvaDatiDB();
		resettaGioco();
		GAME_OVER.setVisible(true);
		VistaLeaderboard.aggiornaDati();
		LogSender.inviaOperazione(new Log("Morte Personaggio!"));
	}
	static void preparzioneGioco(VistaGiocoSweetEscape vistaGioco,Scene scenaPrincipale)
	{
		Musica.creaMusica();
		timerGioco.setCycleCount(Animation.INDEFINITE);
		timerGioco.pause();
		GAME_OVER.setVisible(false);
		EntityDrawEngine.add(vistaGioco,GAME_OVER);
		EntityDrawEngine.setDimensions(
				GAME_OVER, 
				GAME_WINDOW_RIGHT_BOUND-GAME_WINDOW_LEFT_BOUND, 
				GAME_WINDOW_LOWER_BOUND-GAME_WINDOW_UPPER_BOUND
		);
		EntityDrawEngine.repositionDrawing(
				GAME_OVER, 
				GAME_WINDOW_LEFT_BOUND, 
				GAME_WINDOW_UPPER_BOUND
		);
		
		SweetEscape.fabbricaCaramelle = new CandyEntitySpawner(vistaGioco);
		SweetEscape.boss = new BossEntity(
			vistaGioco,
			DEFAULT_BOSS_POSX, 
			DEFAULT_BOSS_POSY, 
			DEFAULT_BOSS_WIDTH, 
			DEFAULT_BOSS_HEIGHT
		);
		SweetEscape.kid = new KidEntity(
			scenaPrincipale,
			vistaGioco,
			DEFAULT_KID_POSX, 
			DEFAULT_KID_POSY, 
			DEFAULT_KID_WIDTH, 
			DEFAULT_KID_HEIGHT
		);
		
	}
	static void resettaTimer()
	{
		
		if(!SweetEscape.GAME_LOADED)SweetEscape.kid.tempoPartita=0;
		timerGioco.pause();
	}
	static void avviaTimer()
	{
		timerGioco.play();
	}
	static void fermaTimer()
	{
		timerGioco.pause();
	}
	
		
}
