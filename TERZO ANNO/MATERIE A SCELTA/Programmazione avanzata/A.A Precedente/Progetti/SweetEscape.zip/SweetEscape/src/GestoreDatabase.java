
import java.sql.*;
import java.util.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class GestoreDatabase {
	
	static ArrayList<Giocatore> leaderboard;
	static final String portaDB = SweetEscape.config.portaServerSQL;
	static final String IpDB = SweetEscape.config.ipServerSQL;
	static final String userDB = SweetEscape.config.userSQL;
	static final String passwordDB = SweetEscape.config.passwordSQL;
	
	public static void inserisciOdAggiornaGiocatore(String username,int punteggio,String tempo) 
	{
		try
		(
			Connection connessioneDB = DriverManager.getConnection("jdbc:mysql://"+IpDB+":"+portaDB+"/game", userDB, passwordDB);
			PreparedStatement inserisci = connessioneDB.prepareStatement
			(
				"INSERT INTO gamedata (username, punteggio, tempo) VALUES (?,?,?) ON DUPLICATE KEY UPDATE punteggio=?, tempo=?"
			);              
		) {
			inserisci.setString(1, username);
			inserisci.setInt(2, punteggio);
			inserisci.setString(3, tempo);
			inserisci.setInt(4, punteggio);
			inserisci.setString(5, tempo);
			inserisci.executeUpdate();
		} 
		catch (SQLException e) 
		{ 
			System.err.println(e.getMessage());
		}
	}
	
	public static Giocatore estraiGiocatore(String username)
	{
		try
		(
			Connection connessioneDB = DriverManager.getConnection("jdbc:mysql://"+IpDB+":"+portaDB+"/game", userDB, passwordDB);
			PreparedStatement estrai = connessioneDB.prepareStatement
			(
				"SELECT * FROM gamedata WHERE username = ?"
			);              
		) {
			estrai.setString(1, username);
			ResultSet giocatoreEstratto = estrai.executeQuery();
			while(giocatoreEstratto.next())
			{
				return new Giocatore
				(
					0,
					giocatoreEstratto.getString("username"),
					giocatoreEstratto.getInt("punteggio"),
					giocatoreEstratto.getString("tempo")
				);
			}
		} 
		catch (SQLException e) 
		{ 
			System.err.println(e.getMessage());
		}
		return null;
	}
	
	public static ArrayList estraiLeaderboard()
	{
		leaderboard = new ArrayList<>();
		int pos=1;
		try
		(
			Connection connessioneDB = DriverManager.getConnection("jdbc:mysql://"+IpDB+":"+portaDB+"/game", userDB, passwordDB);
			PreparedStatement estrai = connessioneDB.prepareStatement
			(
				"SELECT * FROM gamedata ORDER BY punteggio DESC,tempo ASC LIMIT 3 "
			);              
		) {
			ResultSet giocatoreEstratto = estrai.executeQuery();
			while(giocatoreEstratto.next())
			{
				leaderboard.add
				(
					new Giocatore
					(
						pos++,
						giocatoreEstratto.getString("username"),
						giocatoreEstratto.getInt("punteggio"),
						giocatoreEstratto.getString("tempo")
					)
				);
			}
			return leaderboard;
		} 
		catch (SQLException e) 
		{ 
			System.err.println(e.getMessage());
		}
		return null;
	}
}
