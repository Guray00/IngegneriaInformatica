import javafx.animation.AnimationTimer;
import javafx.scene.image.*;
import javafx.scene.layout.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class EntityDrawEngine implements GAME_PARAMETERS{
		
	public static void repositionDrawing(ImageView target,double x,double y)
	{
		target.setX(x);
		target.setY(y);
	}
	
	public static void createDrawing(ImageView target,Image source)
	{
		target.setImage(source);
	}
	
	public static void setDimensions(ImageView target, double height, double width) 
	{
		target.setFitHeight(height);
		target.setFitWidth(width);
		target.setPreserveRatio(true);
	}
	public static void add(Pane where,ImageView what)
	{
		where.getChildren().add(what);
	}
	
	public static void launchBookEntity(BookProjectileEntity book)
	{
		AnimationTimer timerLibro;
		timerLibro = new AnimationTimer()
		{
			@Override
			public void handle(long arg0)
			{
				if(book.active && SweetEscape.GAME_STARTED)
				{
					book.currX+=book.velX;
					book.currY+=book.velY;
					repositionDrawing(book.aspectReference,book.currX,book.currY);
				}
			}
		};
		timerLibro.start();
	}
	
	public static void removeEntityDrawing(BookProjectileEntity book)
	{
		book.aspectReference.setVisible(false);
		repositionDrawing(
			book.aspectReference,
			DEFAULT_BOSS_POSX,
			DEFAULT_BOSS_POSY
		);
	}
	public static void removeEntityDrawing(CandyEntity candy)
	{
		candy.aspectReference.setVisible(false);
		repositionDrawing(
			candy.aspectReference,
			DEFAULT_BOSS_POSX,
			DEFAULT_BOSS_POSY
		);
	}
	
	public static void startKidAnimation(KidEntity kid)
	{
		AnimationTimer timerGioco = 
			new AnimationTimer()
			{
				double delta = 3;
				@Override
				public void handle(long arg0)
				{
					if(kid.goUp && kid.currY-delta>=GAME_WINDOW_UPPER_BOUND){ kid.currY -=delta;}
					if(kid.goDown && kid.currY+delta<=GAME_WINDOW_LOWER_BOUND-(DEFAULT_KID_HEIGHT*1.4)){ kid.currY +=delta;}
					if(kid.goLeft && kid.currX-delta>=GAME_WINDOW_LEFT_BOUND){ kid.currX -=delta;}
					if(kid.goRight && kid.currX+delta<=GAME_WINDOW_RIGHT_BOUND-(DEFAULT_KID_WIDTH*0.6)){ kid.currX +=delta;}
					EntityDrawEngine.repositionDrawing(kid.aspectReference,kid.currX,kid.currY);
					if(SweetEscape.GAME_RESET && !SweetEscape.GAME_LOADED)
					{
						EntityDrawEngine.repositionDrawing(
								kid.aspectReference,
								DEFAULT_KID_POSX,
								DEFAULT_KID_POSY
						);
						kid.currX = DEFAULT_KID_POSX;
						kid.currY = DEFAULT_KID_POSY;
					}
				}
			};
		timerGioco.start();
	}
	
	public static void redrawKid(KidEntity kid)
	{
		if(kid.goRight)
		{
			kid.aspectReference.setImage(DEFAULT_RIGHT_KID);
		}
		if(kid.goLeft)
		{
			kid.aspectReference.setImage(DEFAULT_LEFT_KID);
		}
		if(kid.goDown && !kid.goRight && !kid.goLeft)
		{
			kid.aspectReference.setImage(DEFAULT_DOWN_KID);
		}
		if(kid.goUp && !kid.goRight && !kid.goLeft)
		{
			kid.aspectReference.setImage(DEFAULT_UP_KID);
		}
		if(!kid.goUp && !kid.goRight && !kid.goLeft && !kid.goDown)
		{
			kid.aspectReference.setImage(DEFAULT_STILL_KID);
		}
	}
	
}
