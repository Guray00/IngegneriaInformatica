import javafx.scene.*;
import javafx.scene.layout.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class KidEntity  extends Entity implements GAME_PARAMETERS{
	
	KidEntity kid = this;
	int points = 0;
	String username;
	long tempoPartita = 0;
	
	KidEntity(Scene finestraLavoro,Pane gameField, double x,double y,double w,double h)
	{
		super(gameField,x,y,w,h,DEFAULT_STILL_KID);
		EntityDrawEngine.startKidAnimation(kid);
		gestoreEventiTastiera(finestraLavoro);
	}
	
	public void gestoreEventiTastiera(Scene zonaControllata)
	{
		
		zonaControllata.setOnKeyPressed(
			(evt) -> 
			{
				if(SweetEscape.GAME_STARTED)
				{
					switch(evt.getCode())
					{
						case W: goUp=true; break;
						case S: goDown=true; break;
						case A: goLeft=true; break;
						case D: goRight=true; break;
						default:break;
					}
					EntityDrawEngine.redrawKid(kid);
				}
				else
				{
					goUp=false;
					goDown=false;
					goLeft=false;
					goRight=false;
					EntityDrawEngine.redrawKid(kid);
				}
			}
		);
		
		zonaControllata.setOnKeyReleased(
			(evt) -> 
			{
				if(SweetEscape.GAME_STARTED)
				{
					switch(evt.getCode())
					{
						case W: goUp=false; break;
						case S: goDown=false; break;
						case A: goLeft=false; break;
						case D: goRight=false; break;
						default:break;
					}
					EntityDrawEngine.redrawKid(kid);
				}
				else
				{
					goUp=false;
					goDown=false;
					goLeft=false;
					goRight=false;
					EntityDrawEngine.redrawKid(kid);
				}
			}
		);
	}
	
	public void addPoints()
	{
		switch(SweetEscape.GAME_DIFFICULTY)
		{
			case EASY:  points += 1; break;
			case NORMAL:  points += 2; break;
			case HARD:  points += 3; break;
			case INSANITY:  points += 5; break;
		}
		SweetEscape.vistaPunti.setText("Punti: "+points);
	}
	public void controllaDetrazioniPunti()
	{
		if(tempoPartita!=0 && tempoPartita%20==0)
		{
			points--;
			SweetEscape.vistaPunti.setText("Punti: "+points);
			Musica.clockTick();
		}
	}
	
	public void salvaDatiDB()
	{
		GestoreDatabase.inserisciOdAggiornaGiocatore
		(
			SweetEscape.kid.username,
			SweetEscape.kid.points,
			(int)Math.floor(SweetEscape.kid.tempoPartita/600)+""+
			(SweetEscape.kid.tempoPartita/60)%10+
			" : "+
			(int)Math.floor(SweetEscape.kid.tempoPartita%60/10)+""+
			(SweetEscape.kid.tempoPartita%60)%10
		);
		SweetEscape.kid.points=0;
		SweetEscape.vistaPunti.setText("Punti: "+SweetEscape.kid.points);
	}
}

