import java.util.*;
import javafx.collections.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

class VistaLeaderboard {
	static ArrayList<Giocatore> giocatoriTop;
	
	static TableView<Giocatore> tabellaGiocatori = new TableView<>();
	static ObservableList<Giocatore>  observableTabellaGiocatori;
	
	static TableColumn posizione = new TableColumn("Rank");
	static TableColumn username = new TableColumn("User");
	static TableColumn punteggio = new TableColumn("Punti");
	static TableColumn tempo = new TableColumn("Tempo");
	
	static void creaLeaderboard()
	{
		posizione.setCellValueFactory(new PropertyValueFactory<>("posizione"));
		username.setCellValueFactory(new PropertyValueFactory<>("username"));
		punteggio.setCellValueFactory(new PropertyValueFactory<>("punteggio"));
		tempo.setCellValueFactory(new PropertyValueFactory<>("tempo"));
		
		giocatoriTop = GestoreDatabase.estraiLeaderboard(); 
		if(giocatoriTop!=null)
		observableTabellaGiocatori = FXCollections.observableArrayList(giocatoriTop);
		else
		observableTabellaGiocatori = FXCollections.observableArrayList(new Giocatore("No players Found!"));
		
		tabellaGiocatori.setItems(observableTabellaGiocatori);
		tabellaGiocatori.getColumns().addAll(posizione, username, punteggio, tempo);
		
	}
	
	static void aggiornaDati()
	{
		giocatoriTop = GestoreDatabase.estraiLeaderboard();
		observableTabellaGiocatori = FXCollections.observableArrayList(giocatoriTop);
		
		tabellaGiocatori.setItems(observableTabellaGiocatori);
	}
}
