
import java.io.*;
import java.util.*;
import java.util.stream.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

class DatiCaramelle implements Serializable{

	List<Double> currX;
	List<Double> currY;
	List<Boolean> eaten;
	List<Double> width;
	List<Double> height;
	
	DatiCaramelle(List<CandyEntity> candyList) {
		currX = candyList.stream().map(CandyEntity -> CandyEntity.getCurrX()).collect(Collectors.toList());
		currY = candyList.stream().map(CandyEntity -> CandyEntity.getCurrY()).collect(Collectors.toList());
		eaten = candyList.stream().map(CandyEntity -> CandyEntity.getEaten()).collect(Collectors.toList());
		width = candyList.stream().map(CandyEntity -> CandyEntity.getWidth()).collect(Collectors.toList());
		height = candyList.stream().map(CandyEntity -> CandyEntity.getHeight()).collect(Collectors.toList());
	}
	
	void ricostruisciCandyList(CandyEntitySpawner fabbricaCaramelle)
	{
		for (int i = 0; i < eaten.size(); ++i) //tanto avranno tutti la stessa lunghezza
		{
			if(!eaten.get(i))
			{
				fabbricaCaramelle.candyList.add
				(
					new CandyEntity
					(
						fabbricaCaramelle.candyPane,
						SweetEscape.kid,
						fabbricaCaramelle,
						currX.get(i),
						currY.get(i),
						width.get(i),
						height.get(i)
					)
				);
			}
		}
	}
}
