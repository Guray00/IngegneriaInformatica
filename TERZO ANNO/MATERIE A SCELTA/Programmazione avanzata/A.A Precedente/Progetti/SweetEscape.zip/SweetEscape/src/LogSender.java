
import com.thoughtworks.xstream.*;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class LogSender {
	
	public static final int portaServerLog = Integer.parseInt(SweetEscape.config.portaServerLog);
	public static final String ipServerLog = SweetEscape.config.ipServerLog;
	
	public static void inviaOperazione(Log logGenerato) 
	{
		InetAddress inetAddress;
		try 
		{
			inetAddress = InetAddress.getLocalHost();
		
			try 
			(
				Socket socketLocale = new Socket(ipServerLog, portaServerLog);
				DataOutputStream datiOut =
					new DataOutputStream(socketLocale.getOutputStream());
			) {
				datiOut.writeUTF((new XStream()).toXML(logGenerato));
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			System.out.println("invio Log da "+inetAddress.getHostAddress()+" :  " + logGenerato.rigaDiLog +" a: "+ipServerLog + ":" + portaServerLog);
		} 
		catch (UnknownHostException ex) 
		{
			ex.printStackTrace();
		}
	} 
}
