
import javafx.scene.image.*;
import javafx.scene.layout.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public abstract class Entity
{
	private static final Image DEFAULT_SKIN = new Image( "file:./assets/images/angry.png");

	public ImageView aspectReference= new ImageView();
	protected Pane entityPane;
	double currX=0;
	double currY=0;
	double width = 0;
	double height = 0;

	boolean goUp = false;
	boolean goDown = false;
	boolean goLeft = false;
	boolean goRight = false;

	Entity(Pane target, double posX, double posY, double width, double height, Image skin)
	{
		EntityDrawEngine.createDrawing(aspectReference,skin);
		EntityDrawEngine.repositionDrawing(aspectReference,posX,posY);
		EntityDrawEngine.setDimensions(aspectReference,height,width);
		EntityDrawEngine.add(target,aspectReference);
		entityPane=target;
		currX=posX;
		currY=posY;
		this.width = width;
		this.height = height;
	}

	Entity(Pane target, double posX, double posY, double width, double height)
	{
		this(target, posX,posY,width,height,DEFAULT_SKIN);
	}
	
	public double getCurrX()
	{
		return this.currX;
	}
	public void setCurrX(double currX)
	{
		this.currX=currX;
	}
	public double getCurrY()
	{
		return this.currY;
	}
	public void setCurrY(double currY)
	{
		this.currY=currY;
	}
	public double getWidth()
	{
		return this.width;
	}
	public void setWidth(double width)
	{
		this.width=width;
	}
	public double getHeight()
	{
		return this.height;
	}
	public void setHeight(double height)
	{
		this.height=height;
	}
}
