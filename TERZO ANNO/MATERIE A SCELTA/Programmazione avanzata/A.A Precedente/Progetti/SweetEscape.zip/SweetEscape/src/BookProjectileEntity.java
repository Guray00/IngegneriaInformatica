
import javafx.scene.layout.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class BookProjectileEntity extends Entity implements GAME_PARAMETERS{
	boolean active = true;
	double velX = ((Math.random()*1000)%8)-4;
	double velY = ((Math.random()*1000)%4)+4;

	public BookProjectileEntity(BossEntity mother, Pane root, double posX, double posY, double width, double height) {
		super(root, posX, posY, width, height,DEFAULT_BOOK);
		EntityDrawEngine.launchBookEntity(this);
		GestoreCollisioni.controllaCollisioniLibri(SweetEscape.kid,mother,this);
	}
	public double getVelX()
	{
		return this.velX;
	}
	public void setVelX(double velX)
	{
		this.velX=velX;
	}
	public double getVelY()
	{
		return this.velY;
	}
	public void setVelY(double velY)
	{
		this.velY=velY;
	}
	public boolean getActive()
	{
		return this.active;
	}
	public void setActive(boolean active)
	{
		this.active=active;
	}
	
}
