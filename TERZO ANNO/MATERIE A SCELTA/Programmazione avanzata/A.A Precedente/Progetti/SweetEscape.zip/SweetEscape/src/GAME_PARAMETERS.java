
import javafx.scene.image.*;
import javafx.scene.layout.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public interface GAME_PARAMETERS {
	
	public static final ImageView playButton = new ImageView(new Image("file:./assets/images/play.jpg",60,60,true,false));
	public static final ImageView pauseButton = new ImageView(new Image("file:./assets/images/pause.png",60,60,true,false));
	public static final ImageView resetButton = new ImageView(new Image("file:./assets/images/reset.png",60,60,true,false));
	public static enum Difficulty {EASY,NORMAL,HARD,INSANITY};
	static final double WINDOW_WIDTH = 900;
	static final double WINDOW_HEIGHT = 750;
	static final double GAME_WINDOW_RIGHT_BOUND = WINDOW_WIDTH-300;
	static final double GAME_WINDOW_LEFT_BOUND = 0;
	static final double GAME_WINDOW_LOWER_BOUND = WINDOW_HEIGHT-50;
	static final double GAME_WINDOW_UPPER_BOUND = 110;
	public static final ImageView GAME_OVER = new ImageView(new Image("file:./assets/images/gameOver.png"));
	public static final Image DEAD_KID = new Image("file:./assets/images/death.png");
	public static final Image DEFAULT_STILL_KID = new Image("file:./assets/images/kidStill.png");
	public static final Image DEFAULT_UP_KID = new Image("file:./assets/images/kidUp.gif");
	public static final Image DEFAULT_DOWN_KID = new Image("file:./assets/images/kidDown.gif");
	public static final Image DEFAULT_LEFT_KID = new Image("file:./assets/images/kidLeft.gif");
	public static final Image DEFAULT_RIGHT_KID = new Image("file:./assets/images/kidRight.gif");
	public static final Image DEFAULT_CANDY = new Image("file:./assets/images/candy.png");
	public static final Image DEFAULT_BOOK = new Image("file:./assets/images/book.png");
	public static final Image DEFAULT_BOSS = new Image("file:./assets/images/boss.gif");
	public static final double DEFAULT_BOSS_WIDTH = 100;
	public static final double DEFAULT_BOSS_HEIGHT = 100;
	public static final double DEFAULT_BOSS_POSX = 
		(GAME_WINDOW_RIGHT_BOUND-GAME_WINDOW_LEFT_BOUND-DEFAULT_BOSS_WIDTH)/2;
	public static final double DEFAULT_BOSS_POSY = 0;
	public static final double DEFAULT_KID_WIDTH = 40;
	public static final double DEFAULT_KID_HEIGHT = 60;
	public static final double DEFAULT_KID_POSX = 
		(GAME_WINDOW_RIGHT_BOUND-GAME_WINDOW_LEFT_BOUND-DEFAULT_KID_WIDTH)/2;
	public static final double DEFAULT_KID_POSY = 500;
	public static final double DEFAULT_BOOK_WIDTH = 50;
	public static final double DEFAULT_BOOK_HEIGHT = 50;
	public static final int MAX_PROJECTILES_ON_SCREEN = 10;
	public static final int MAX_CANDY_ON_SCREEN = 5;
	public static final double ATTESA_TRA_CANDY_SECONDI = 6;
	public static final double DEFAULT_CANDY_WIDTH = 40;
	public static final double DEFAULT_CANDY_HEIGHT = 40;
	public static final BackgroundImage BACKGROUND_IMAGE = 
		new BackgroundImage(
			new Image
			(
				"file:./assets/images/library.png",
				GAME_WINDOW_RIGHT_BOUND,
				GAME_WINDOW_LOWER_BOUND,
				false,
				true
			),
			BackgroundRepeat.REPEAT, 
			BackgroundRepeat.NO_REPEAT, 
			BackgroundPosition.DEFAULT,
			BackgroundSize.DEFAULT
		);
}
