
import javafx.scene.image.*;
import javafx.scene.layout.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

class VistaGiocoSweetEscape extends Pane implements GAME_PARAMETERS{
	BackgroundImage customBackground;
	void loadStyle()
	{
		this.getStylesheets().add("file:./css/gameWindow.css");
		this.setId("vistaGioco");
		if(!SweetEscape.config.percorsoImmagineSfondo.isEmpty())
		{
			customBackground = 
			new BackgroundImage(
			new Image
			(
				SweetEscape.config.percorsoImmagineSfondo,
				GAME_WINDOW_RIGHT_BOUND,
				GAME_WINDOW_LOWER_BOUND,
				false,
				true
			),
				BackgroundRepeat.REPEAT, 
				BackgroundRepeat.NO_REPEAT, 
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT
			);
			setBackground(new Background(customBackground));
		}
		else
			setBackground(new Background(BACKGROUND_IMAGE));
		setPrefSize(GAME_WINDOW_RIGHT_BOUND, GAME_WINDOW_LOWER_BOUND);
	}
}
