
import java.util.*;
import javafx.animation.*;
import javafx.scene.layout.Pane;
import javafx.util.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class CandyEntitySpawner  implements GAME_PARAMETERS{
	
	int currentCandys = 0;
	List<CandyEntity> candyList = new ArrayList<>();
	Pane candyPane;

	public CandyEntitySpawner(Pane target) {
		startSpawningCandy(target);
		candyPane = target;
	}
	
	private void startSpawningCandy(Pane whereToSpawn)
	{
		
		Timeline lanciaLibriTimeline = new Timeline
		(
			new KeyFrame
			(
				Duration.seconds
				(
					ATTESA_TRA_CANDY_SECONDI
				), e -> 
				{
					if(currentCandys<MAX_CANDY_ON_SCREEN && SweetEscape.GAME_STARTED)
					{
						candyList.add(new CandyEntity(
							whereToSpawn,
							SweetEscape.kid,
							this,
							GAME_WINDOW_LEFT_BOUND+
								0.6*((Math.random()*1000)%
								(GAME_WINDOW_RIGHT_BOUND-
								GAME_WINDOW_LEFT_BOUND)),
							GAME_WINDOW_UPPER_BOUND+
								0.6*((Math.random()*1000)%
								(GAME_WINDOW_LOWER_BOUND-
								GAME_WINDOW_UPPER_BOUND)),
							DEFAULT_CANDY_WIDTH,
							DEFAULT_CANDY_HEIGHT
						));
						currentCandys++;
					}
					
				}
			)
		);
		lanciaLibriTimeline.setCycleCount(Animation.INDEFINITE);
		lanciaLibriTimeline.playFromStart();
	}
	
	
}
