
import java.io.*;
import java.util.*;

/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

class CacheStatoGiocoSweetEscape implements Serializable,GAME_PARAMETERS
{
	private static CacheStatoGiocoSweetEscape cacheGioco;
	
	double kidX;
	double kidY;
	int kidPoints;
	long tempoPartita;
	List<BookProjectileEntity> proiettiliBoss;
	int numEntityLibri;
	List<CandyEntity> candyList;
	int numEntityCandy;
	Difficulty difficoltaPartita;
	boolean giocoResettato;
	DatiLibri bookData;
	DatiCaramelle candyData;
	String kidUsername;
	
	private CacheStatoGiocoSweetEscape(KidEntity kid, BossEntity boss, CandyEntitySpawner fabbricaCaramelle)
	{
		giocoResettato = SweetEscape.GAME_RESET;
		difficoltaPartita = SweetEscape.GAME_DIFFICULTY;
		kidX=kid.currX;
		kidY=kid.currY;
		kidUsername = kid.username;
		kidPoints = kid.points;
		tempoPartita = kid.tempoPartita;
		bookData = new DatiLibri(boss.proiettili);
		numEntityLibri = boss.currentEntities;
		candyData = new DatiCaramelle(fabbricaCaramelle.candyList);
		numEntityCandy = fabbricaCaramelle.currentCandys;
	}
	
	static void caricaStatoGioco(KidEntity kid, BossEntity boss, CandyEntitySpawner fabbricaCaramelle,ZonaUsername registrazione) 
	{
		try(FileInputStream fIn = new FileInputStream("./assets/cacheGioco.bin");  //try con risorse: chiude automaticamente le risorse richieste invece di doversi occupare granularmente della gestione
				ObjectInputStream oIn = new ObjectInputStream(fIn);
				)
		{
			cacheGioco = (CacheStatoGiocoSweetEscape) oIn.readObject();//qua ho gia'deserializzato
			if(cacheGioco.giocoResettato){registrazione.setText(cacheGioco.kidUsername);return;}//non spreco tempo a caricare un gioco resettato
			
			SweetEscape.GAME_LOADED=true;// un segnalino per sapere che ho caricato i dati
			
			kid.currX = cacheGioco.kidX;
			kid.currY = cacheGioco.kidY;
			kid.points = cacheGioco.kidPoints;
			kid.username = cacheGioco.kidUsername;
			kid.tempoPartita=cacheGioco.tempoPartita;
			cacheGioco.bookData.ricostruisciListaLibriLanciati(boss);
			boss.currentEntities=cacheGioco.numEntityLibri;
			cacheGioco.candyData.ricostruisciCandyList(fabbricaCaramelle);
			fabbricaCaramelle.currentCandys=cacheGioco.numEntityCandy;
			
			EntityDrawEngine.repositionDrawing(
				kid.aspectReference,
				kid.currX,
				kid.currY
			);
			registrazione.setText(cacheGioco.kidUsername);
			GestoreStatiDiGioco.resettaTimer();
		}
		catch(IOException | ClassNotFoundException ex)
		{
			System.err.println("Impossibile Caricare cache");
		}
	}
	static void salvaStatoGioco(KidEntity kid, BossEntity boss, CandyEntitySpawner fabbricaCaramelle)
	{
		cacheGioco = new CacheStatoGiocoSweetEscape(kid, boss, fabbricaCaramelle);
		try(FileOutputStream fOut = new FileOutputStream("./assets/cacheGioco.bin");//try con risorse: chiude automaticamente le risorse richieste invece di doversi occupare granularmente della gestione
				ObjectOutputStream oOut = new ObjectOutputStream(fOut);
				)
		{
			oOut.writeObject(cacheGioco);
		}
		catch(IOException ex)
		{
			System.err.println("Impossibile Salvare cache");
		}
	}
	
	
	
}
