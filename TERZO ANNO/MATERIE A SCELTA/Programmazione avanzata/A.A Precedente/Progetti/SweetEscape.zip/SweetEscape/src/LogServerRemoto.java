
import com.thoughtworks.xstream.*;
import java.io.*;
import static java.lang.Thread.*;
import java.net.*;
import java.nio.file.*;
import static java.nio.file.StandardOpenOption.*;


/*
	Progetto realizzato da Francesco Boldrini

	Spero che ti possa aiutare a risolvere qualunque dubbio ti possa venire
	durante lo sviluppo del tuo!

	NB: 
	il diagramma UML non e' un buon esempio e quindi e' stato rimosso, 
	per realizzare il tuo, ti consiglio di farlo come prima cosa e fare riferimento
	agli ultimi set di slide dei laboratori, che sono ottimi per capire cosa vada
	fatto davvero. 

	Altro errore che si fa spesso e quindi cito qui, e' quello di sovraccaricare le 
	funzionalita' di alcune classi: ad esempio usare una classe di costruzione dell' 
	interfaccia per passare i dati alla cache, e' considerato errore, mentre non lo e'
	se si effettua solo la chiamata alla cache nel load o chiusura, lasciando
	che sia la classe cache stessa a procurarsi i dati.
*/

public class LogServerRemoto {

	public static final int PORTA_DEFAULT_RICEZIONE = 8080;
	
	public static void ricevi(int portaRicezione) 
	{
		Log logRicezione = null;
		try 
		(
			ServerSocket servsock = new ServerSocket(portaRicezione);
				
			Socket socketRicezione = servsock.accept();
				
			DataInputStream dataLog = 
				new DataInputStream(socketRicezione.getInputStream());
		) {
			logRicezione = (Log)(new XStream()).fromXML(dataLog.readUTF());
			System.out.println("Ricevuto: " + logRicezione.rigaDiLog);
			scriviSuLog(logRicezione.rigaDiLog);
		} 
		catch (IOException ex) 
		{
			ex.printStackTrace();
		}
	}

	private static void scriviSuLog(String logLine) 
	{
		try
		{
			Files.write
			(
				Paths.get("./log/logFile.txt"),
				(logLine + System.lineSeparator()).getBytes(),
				CREATE,
				APPEND
			);
		}
		catch(IOException ex)
		{
			System.err.println("Socket chiuso o file chiuso inaspettatamente in scrittura");
		}
	}
	
	public static void main()
	{
		while(!interrupted())
		{
			ricevi(PORTA_DEFAULT_RICEZIONE);
		}
	}
	
	public static void main(String args[])
	{
		main();
	}
}
