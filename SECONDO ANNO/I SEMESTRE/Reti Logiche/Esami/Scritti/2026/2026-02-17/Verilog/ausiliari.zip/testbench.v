module testbench();

    wire clock;

    clock_generator clk(
        .clock(clock)
    );

    reg reset_;
    reg soc;
    wire eoc;
    reg [7:0] n_0;
    wire [15:0] result;

    ABC dut(
        .n_0(n_0), .result(result),
        .soc(soc), .eoc(eoc),
        .clock(clock), .reset_(reset_)
    );

    initial
    begin
        $dumpfile("waveform.vcd");
        $dumpvars;

        fork : f
        begin
            #10000000;
            $display("Timeout - waiting for signal failed");
            disable f;
        end
        begin
            soc = 0;
            reset_ = 0; #(clk.HALF_PERIOD);
            reset_ = 1;

            if(eoc !== 1)
                $display("eoc is not 1 after reset");

            fork
            begin : consumer
                reg [9:0] i;
                reg [7:0] n_0_c;
                reg [15:0] result_c;

                // for (i = 0; i <= 200; i++) begin
                for (i = 0; i <= 20; i++) begin
                    {n_0_c, result_c} = get_testcase(i[7:0]);

                    n_0 = n_0_c;
                    #(2*clk.HALF_PERIOD);
                    soc = 1;
                    @(negedge eoc);
                    #(20*clk.HALF_PERIOD);
                    soc = 0;
                    @(posedge eoc);

                    if(result !== result_c) begin
                        $display("Test #%g failed, expected %g, got %g", i, result_c, result);
                        error = 1;
                    end
                    #(2*clk.HALF_PERIOD);
                end
            end
            join

            disable f;
        end
        join

        $finish;
    end

    reg error;
    initial error = 0;
    always @(posedge error) #1 error = 0;

    function automatic [23:0] get_testcase;
        input [7:0] n_0;
        reg [15:0] result;
        begin
            case(n_0)
                8'd0: result = 16'd940;
                8'd1: result = 16'd315;
                8'd2: result = 16'd940;
                8'd3: result = 16'd315;
                8'd4: result = 16'd940;
                8'd5: result = 16'd315;
                8'd6: result = 16'd440;
                8'd7: result = 16'd565;
                8'd8: result = 16'd690;
                8'd9: result = 16'd815;
                8'd10: result = 16'd940;
                8'd11: result = 16'd215;
                8'd12: result = 16'd240;
                8'd13: result = 16'd265;
                8'd14: result = 16'd290;
                8'd15: result = 16'd315;
                8'd16: result = 16'd340;
                8'd17: result = 16'd365;
                8'd18: result = 16'd390;
                8'd19: result = 16'd415;
                8'd20: result = 16'd440;
                8'd21: result = 16'd465;
                8'd22: result = 16'd490;
                8'd23: result = 16'd515;
                8'd24: result = 16'd540;
                8'd25: result = 16'd565;
                8'd26: result = 16'd590;
                8'd27: result = 16'd615;
                8'd28: result = 16'd640;
                8'd29: result = 16'd665;
                8'd30: result = 16'd690;
                8'd31: result = 16'd715;
                8'd32: result = 16'd740;
                8'd33: result = 16'd765;
                8'd34: result = 16'd790;
                8'd35: result = 16'd815;
                8'd36: result = 16'd840;
                8'd37: result = 16'd865;
                8'd38: result = 16'd890;
                8'd39: result = 16'd915;
                8'd40: result = 16'd940;
                8'd41: result = 16'd965;
                8'd42: result = 16'd990;
                8'd43: result = 16'd205;
                8'd44: result = 16'd210;
                8'd45: result = 16'd215;
                8'd46: result = 16'd220;
                8'd47: result = 16'd225;
                8'd48: result = 16'd230;
                8'd49: result = 16'd235;
                8'd50: result = 16'd240;
                8'd51: result = 16'd245;
                8'd52: result = 16'd250;
                8'd53: result = 16'd255;
                8'd54: result = 16'd260;
                8'd55: result = 16'd265;
                8'd56: result = 16'd270;
                8'd57: result = 16'd275;
                8'd58: result = 16'd280;
                8'd59: result = 16'd285;
                8'd60: result = 16'd290;
                8'd61: result = 16'd295;
                8'd62: result = 16'd300;
                8'd63: result = 16'd305;
                8'd64: result = 16'd310;
                8'd65: result = 16'd315;
                8'd66: result = 16'd320;
                8'd67: result = 16'd325;
                8'd68: result = 16'd330;
                8'd69: result = 16'd335;
                8'd70: result = 16'd340;
                8'd71: result = 16'd345;
                8'd72: result = 16'd350;
                8'd73: result = 16'd355;
                8'd74: result = 16'd360;
                8'd75: result = 16'd365;
                8'd76: result = 16'd370;
                8'd77: result = 16'd375;
                8'd78: result = 16'd380;
                8'd79: result = 16'd385;
                8'd80: result = 16'd390;
                8'd81: result = 16'd395;
                8'd82: result = 16'd400;
                8'd83: result = 16'd405;
                8'd84: result = 16'd410;
                8'd85: result = 16'd415;
                8'd86: result = 16'd420;
                8'd87: result = 16'd425;
                8'd88: result = 16'd430;
                8'd89: result = 16'd435;
                8'd90: result = 16'd440;
                8'd91: result = 16'd445;
                8'd92: result = 16'd450;
                8'd93: result = 16'd455;
                8'd94: result = 16'd460;
                8'd95: result = 16'd465;
                8'd96: result = 16'd470;
                8'd97: result = 16'd475;
                8'd98: result = 16'd480;
                8'd99: result = 16'd485;
                8'd100: result = 16'd490;
                8'd101: result = 16'd495;
                8'd102: result = 16'd500;
                8'd103: result = 16'd505;
                8'd104: result = 16'd510;
                8'd105: result = 16'd515;
                8'd106: result = 16'd520;
                8'd107: result = 16'd525;
                8'd108: result = 16'd530;
                8'd109: result = 16'd535;
                8'd110: result = 16'd540;
                8'd111: result = 16'd545;
                8'd112: result = 16'd550;
                8'd113: result = 16'd555;
                8'd114: result = 16'd560;
                8'd115: result = 16'd565;
                8'd116: result = 16'd570;
                8'd117: result = 16'd575;
                8'd118: result = 16'd580;
                8'd119: result = 16'd585;
                8'd120: result = 16'd590;
                8'd121: result = 16'd595;
                8'd122: result = 16'd600;
                8'd123: result = 16'd605;
                8'd124: result = 16'd610;
                8'd125: result = 16'd615;
                8'd126: result = 16'd620;
                8'd127: result = 16'd625;
                8'd128: result = 16'd630;
                8'd129: result = 16'd635;
                8'd130: result = 16'd640;
                8'd131: result = 16'd645;
                8'd132: result = 16'd650;
                8'd133: result = 16'd655;
                8'd134: result = 16'd660;
                8'd135: result = 16'd665;
                8'd136: result = 16'd670;
                8'd137: result = 16'd675;
                8'd138: result = 16'd680;
                8'd139: result = 16'd685;
                8'd140: result = 16'd690;
                8'd141: result = 16'd695;
                8'd142: result = 16'd700;
                8'd143: result = 16'd705;
                8'd144: result = 16'd710;
                8'd145: result = 16'd715;
                8'd146: result = 16'd720;
                8'd147: result = 16'd725;
                8'd148: result = 16'd730;
                8'd149: result = 16'd735;
                8'd150: result = 16'd740;
                8'd151: result = 16'd745;
                8'd152: result = 16'd750;
                8'd153: result = 16'd755;
                8'd154: result = 16'd760;
                8'd155: result = 16'd765;
                8'd156: result = 16'd770;
                8'd157: result = 16'd775;
                8'd158: result = 16'd780;
                8'd159: result = 16'd785;
                8'd160: result = 16'd790;
                8'd161: result = 16'd795;
                8'd162: result = 16'd800;
                8'd163: result = 16'd805;
                8'd164: result = 16'd810;
                8'd165: result = 16'd815;
                8'd166: result = 16'd820;
                8'd167: result = 16'd825;
                8'd168: result = 16'd830;
                8'd169: result = 16'd835;
                8'd170: result = 16'd840;
                8'd171: result = 16'd845;
                8'd172: result = 16'd850;
                8'd173: result = 16'd855;
                8'd174: result = 16'd860;
                8'd175: result = 16'd865;
                8'd176: result = 16'd870;
                8'd177: result = 16'd875;
                8'd178: result = 16'd880;
                8'd179: result = 16'd885;
                8'd180: result = 16'd890;
                8'd181: result = 16'd895;
                8'd182: result = 16'd900;
                8'd183: result = 16'd905;
                8'd184: result = 16'd910;
                8'd185: result = 16'd915;
                8'd186: result = 16'd920;
                8'd187: result = 16'd925;
                8'd188: result = 16'd930;
                8'd189: result = 16'd935;
                8'd190: result = 16'd940;
                8'd191: result = 16'd945;
                8'd192: result = 16'd950;
                8'd193: result = 16'd955;
                8'd194: result = 16'd960;
                8'd195: result = 16'd965;
                8'd196: result = 16'd970;
                8'd197: result = 16'd975;
                8'd198: result = 16'd980;
                8'd199: result = 16'd985;
                8'd200: result = 16'd990;
                default: result = 0;
            endcase
            get_testcase = {n_0, result};
        end
    endfunction

endmodule

module clock_generator(
    clock
);
    output clock;
    parameter HALF_PERIOD = 5;
    reg CLOCK;
    assign clock = CLOCK;
    initial CLOCK <= 0;
    always #HALF_PERIOD CLOCK <= ~CLOCK;
endmodule
