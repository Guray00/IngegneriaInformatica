// myscript14.js
let text = "Example of Sliding Text ..............";
function slide() {  //(1)    
    const firstchar = text.charAt(0);    
    text = text.slice(1,text.length) + firstchar;    
    document.forms[0].mytext.value = text;            //(2)
}