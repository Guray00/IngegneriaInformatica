function visit(node, obj, depth) {
  obj.txt += ".".repeat(depth) + node.nodeName + ", type: " + node.nodeType + ", value: " + node.nodeValue+ "<br>";
  if (node.hasChildNodes()) {
 	for (let i=0; i<node.childNodes.length; i++) {
			visit(node.childNodes[i], obj, depth +1);
	}
  }
}

let node = document.documentElement;
let obj = new Object();
obj.txt = "";
visit(node, obj, 0);
document.body.style.fontFamily = "Courier";
document.write(obj.txt);