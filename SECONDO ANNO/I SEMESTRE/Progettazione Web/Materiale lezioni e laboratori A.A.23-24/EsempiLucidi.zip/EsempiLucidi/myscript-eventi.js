function dettaglia(elemento, evento) {
      console.log(elemento + ": " + evento);
      console.log("\t name=" + elemento.name + ", type=" + elemento.type);
      if(elemento.type=="text" && evento=="Change") {
            console.log("\t the new value of the text field is " + elemento.value);
      }
}

function aggiungi_gestori(f) {
   const gestore_click = new Function("dettaglia(this, 'Click')");
   const gestore_change = new Function("dettaglia(this, 'Change')");
   const gestore_focus = new Function("dettaglia(this, 'Focus')");
   const gestore_blur  = new Function("dettaglia(this, 'Blur')");
   const gestore_select  = new Function("dettaglia(this, 'Select')");
   const gestore_dblclick  = new Function("dettaglia(this, 'DblClick')");
	
  for(let i = 0; i < f.elements.length; i++) {
    const e = f.elements[i];
    e.onclick    = gestore_click; 
    e.onchange   = gestore_change;
    e.onfocus    = gestore_focus;
    e.onblur     = gestore_blur;
    e.onselect   = gestore_select;
    e.ondblclick = gestore_dblclick;
  }
}
const f = document.getElementById("f1");
aggiungi_gestori(f);