var elem = document.getElementById('mydiv');
function set() {
	document.onkeydown = onKeyHandler;
}

function onKeyHandler(e) {
	switch(e.code) {
		case "KeyS":
		case "ArrowDown":
		  move(0,  3);
		  break;
		case "KeyW":
		case "ArrowUp":
			move(0, -3);
		  break;
		case "KeyA":
		case "ArrowLeft":
			move(-3, 0);
		  break;
		case "KeyD":
		case "ArrowRight":
		  move(3,  0);
		  break;
		default: window.alert('stop'); 
	}      
}

function move(dx,dy) {  
	elem.style.left = parseInt(elem.style.left) + dx + "px";  
	elem.style.top  = parseInt(elem.style.top) + dy + "px"; 
}