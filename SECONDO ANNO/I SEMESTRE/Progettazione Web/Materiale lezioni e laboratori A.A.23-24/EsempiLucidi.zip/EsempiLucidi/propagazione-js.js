
// References to the elements
let dive;
let ule;
let lie;
let ce;

// Capturing
let capture = false;

// Retrieve the references to the elements
// Set the listener for the checkbox and the li elements
// Set the listener for the div and ul, in capture or not
function letsgo(){
    dive = document.querySelector("div");
    ule = document.querySelector("ul");
    lie = document.querySelectorAll("li");
    ce = document.querySelector('input[type="checkbox"]');

    ce.addEventListener("click", captureSwitch);
    for(let i of lie)
        i.addEventListener("click", liHandler);
    setListeners(capture);    
}

// Set the listeners for the div and the ul
function setListeners(iWantToCapture) {
    dive.addEventListener("click", divHandler, iWantToCapture);
    ule.addEventListener("click", ulHandler, iWantToCapture);
}
// Remove the listeners for the div and the ul so that thay can be 
// added again in a different mode
function removeListeners(iWantToCapture) {
    dive.removeEventListener("click", divHandler, iWantToCapture);
    ule.removeEventListener("click", ulHandler, iWantToCapture);
}
// Handler for the div
// It stops propagation
// In capture mode it is invoked as the firs one and the event is 
// not propagated to the contained element
function divHandler(event) {
    console.log("divHandler: " + event.target.id);
    event.stopPropagation();
}
// Handler for the ul
function ulHandler(event) {
    console.log("ulHandler: " + event.target.id);
}
// Handler for the li
function liHandler(event) {
    console.log("liHandler: " + event.target.id);
}
// Handler for the checkbox
function captureSwitch() {
    console.log(ce.checked);
    // To remove the listeners the old value of checked is used
    removeListeners(!ce.checked);
    // Set the listener again, but in a different mode
    setListeners(ce.checked);
}