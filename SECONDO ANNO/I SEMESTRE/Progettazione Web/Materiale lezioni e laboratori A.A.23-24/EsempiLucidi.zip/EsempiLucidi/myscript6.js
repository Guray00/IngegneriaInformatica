document.writeln("<h1>Screen Information</h1><p>");
printScreenInfo('width'); 
printScreenInfo('height');
printScreenInfo('colorDepth'); 
printScreenInfo('availWidth');
printScreenInfo('availHeight'); 

function printScreenInfo(name) { 
document.writeln("<strong>"+ name + ":</strong>"+ screen[name]+ "<br>");
}