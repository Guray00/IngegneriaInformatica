//myscript18.js
const Queries = ["What is the keyword in Javascript for defining a function?",
	"What is not a valid comment in Javascript?",
	"What is the handler for the 'loss of active state' event?",
	"Which operator can be used to instance an object?",
	"To periodically call a function you use the method:"];
const Options = [["var", "function", "script"],
	["\\*...*\\", "*/.../*", " //...", "//...//"],
	["onFocus", "onBlur", "onClick"],
	["create", "new", "add"],
	["window.setInterval", "window.setTimeout", "date.setTime"]];
const Answers = [0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0];

function check() {
	let score = 0;
	let answers = document.getElementsByTagName("INPUT");
	for (var i = 0; i < answers.length - 1; i++)
		if (answers[i].checked)
			if (Answers[i] == 1) score++;
			else score--;
	window.alert("Your score is: " + score);
	document.mymodule.reset();
}