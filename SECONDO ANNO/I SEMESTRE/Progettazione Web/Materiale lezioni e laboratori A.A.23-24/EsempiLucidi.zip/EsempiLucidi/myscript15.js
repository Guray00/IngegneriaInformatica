// myscript15.js
var ERROR = false;
function read(i) {
	value = 0;
	with (document.mymodule) {
		switch (i) {
			case 1: return idiv.value; break;
			case 2: value = top.value; break;
			case 3: value = left.value; break;
			case 4: value = width.value; break;
			case 5: value = height.value; break;
			case 6: value = level.value;
		}
	}
	value = parseInt(value);
	if ((value < 0) || isNaN(value)) {
		window.alert("Error in the field n." + i);
		ERROR = true;
	}
	return value;
}
function set() {
	var i = read(1);
	var x = read(2);
	var y = read(3);
	var w = read(4);
	var h = read(5);
	var z = read(6);
	if (!ERROR) {
		var mydiv = document.getElementById(i);
		mydiv.style.top = x + "px";
		mydiv.style.left = y + "px";
		mydiv.style.width = w + "px";
		mydiv.style.height = h + "px";
		mydiv.style.zIndex = z + "";
		//(1)  
	}
	ERROR = false;
}