// myscript13.js
const img1 = new Array(2); //  
img1[0] = new Image();  
img1[1] = new Image();
const img2 = new Array(2);  
img2[0]= new Image();  
img2[1]= new Image(); //
img1[0].src="a.jpg"; 
img1[1].src="b.gif"; //default images
img2[0].src="b.gif"; 
img2[1].src="a.jpg"; //rollover images

function modify(i,type) {  
	if (type == "over")    
		document.images[i].src = img2[i].src; //mouseover  
	else
		document.images[i].src = img1[i].src; //mouseout
}