<!DOCTYPE html>
<?php  
	session_start();  unset($_SESSION['Login']);
?>
  <html lang="en">
  <head>
	<meta charset="utf-8"> 
    <title>Logout</title>
    <style type="text/css"> p { font-size: 30pt;} </style>
  </head>
  <body>
	<p>Good Bye :(</p>
	</body>
	</html>	