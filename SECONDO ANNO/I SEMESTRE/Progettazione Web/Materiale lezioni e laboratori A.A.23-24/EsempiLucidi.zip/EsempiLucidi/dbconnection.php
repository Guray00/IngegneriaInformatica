<?php
  $nomeHost = "localhost";
  $nomeUtente = "root";
  $password = "";
  $nomeDb = "pweb";
	$mysqli= new mysqli($nomeHost, $nomeUtente, $password, $nomeDb);
	if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') '
            . $mysqli->connect_error);
	}
	echo 'Success... ' . $mysqli->host_info . "<br>";
	// Formulate Query
	// This is the best way to perform an SQL query
	$query = "SELECT * FROM studenti";

	// Perform Query
	$result = $mysqli->query($query);

	/* Check result
	    This shows the actual query sent to MySQL, and the error. 
	    Useful for debugging.*/
	checkResult($result,$query);

	//show results
	showResult($result);
	// Free the resources associated with the result set
  // This is done automatically at the end of the script
  $result->close();
  $mysqli->close();

function checkResult($result, $query)
{	if (!$result) {
    $message  = 'Invalid query: ' . $mysqli->error . "\n";
    $message .= 'Whole query: ' . $query;
    die($message);
	  }
}
function showResult($result)
	{ 	while ($row = $result->fetch_assoc()) {
    	echo $row['MATRICOLA']. " ";
    	echo $row['NOME'] . "<br>";
		}
		echo "<br>";
	}
?>


