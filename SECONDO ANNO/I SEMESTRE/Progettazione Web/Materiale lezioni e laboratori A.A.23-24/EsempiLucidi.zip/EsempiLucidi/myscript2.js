let elems = document.getElementsByTagName("p");
let text =  elems[0].firstChild.nodeValue;
window.alert("The paragraph has text: " + text);
