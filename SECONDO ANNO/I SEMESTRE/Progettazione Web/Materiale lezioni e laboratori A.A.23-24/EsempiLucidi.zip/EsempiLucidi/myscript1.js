let text = document.getElementById("mypar1").firstChild.nodeValue;
let type = document.getElementById("mypar1").firstChild.nodeType;
window.alert("The paragraph has text: " + text);
window.alert("The node has type: " + type);