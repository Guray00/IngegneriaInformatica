function colour() { 
var indexCol = document.forms[0].sel.selectedIndex;           
document.body.style.backgroundColor = document.forms[0].sel.options[indexCol].value;
}

function send() {  
var indexCol = document.forms[0].sel.selectedIndex;  
var nameCol = document.forms[0].sel.options[indexCol].value;  
var name = document.forms[0].name.value;                        
HTMLcode = '<p style="color:' + nameCol + '"; font-weight:700;> Name: ' + name + '</p>';  
document.writeln(HTMLcode);                                 
}

