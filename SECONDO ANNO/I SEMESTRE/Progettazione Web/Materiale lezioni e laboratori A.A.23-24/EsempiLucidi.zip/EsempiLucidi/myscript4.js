function visit(node, obj, depth) { 
  if (node == null) return;
  obj.txt += ".".repeat(depth) + node.nodeName + ", type: " + node.nodeType + ", value: " + node.nodeValue+ "<br>"; 
  if (node.firstChild) {
			visit(node.firstChild, obj, depth+1);
	}
	if (node.nextSibling) {
			visit(node.nextSibling,obj, depth);
	}
}

let node = document.documentElement;
let obj = new Object();
obj.txt = "";
visit(node,obj, 0);
document.body.style.fontFamily = "courier";
document.write(obj.txt);