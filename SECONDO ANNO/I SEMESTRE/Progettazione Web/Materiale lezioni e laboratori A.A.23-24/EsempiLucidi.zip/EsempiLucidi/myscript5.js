let infobrowser = "<h1>Information on your browser</h1><p>";
for (let proprietyName in navigator)  
	infobrowser += "<strong>" + proprietyName + ":</strong>" + 
	navigator[proprietyName] + "<br>";
infobrowser += "</p>";
document.writeln(infobrowser);