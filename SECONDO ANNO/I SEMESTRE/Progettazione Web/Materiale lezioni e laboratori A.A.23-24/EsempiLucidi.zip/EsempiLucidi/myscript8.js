// myscript8.js
document.writeln("<p>You are on '"+ document.URL + "'<p>");

function openW(color) {  
	win = window.open("",color,"width=400,height=250");  
	HTMLcode = '<html><head><meta charset="utf-8"><title>Page '+ color+ '</title></head>' +  
    '<body><p>This is a ' + color + ' page </p></body></html>';  
	win.document.writeln(HTMLcode);   
	win.document.body.style.background = color;  
	win.document.body.style.color = "white";
}
			
function openDoc(color) {  
	doc = document.open("text/html","replace"); 
	HTMLcode = '<html><head><meta charset="utf-8"><title>Page '+ color+ '</title></head>' +  
    '<body><p>This is a ' + color + ' page </p></body></html>'; 
	doc.writeln(HTMLcode);  
	doc.body.style.backgroundColor = color; 
	doc.body.style.color = "green";
	doc.close();
}
