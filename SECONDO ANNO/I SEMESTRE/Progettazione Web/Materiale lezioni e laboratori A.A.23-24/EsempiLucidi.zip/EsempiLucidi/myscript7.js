display('URL',location.href);
display('Protocol',location.protocol);
display('Host name', location.hostname);
display('Local Address', location.hash);
display('Port', location.port);
display('Path', location.pathname);

function send() {  
  location.search="&Name=" + document.forms[0].Name.value;
}

function display(propriety, value) {  
  document.writeln("<p><strong>"+propriety+":</strong>"+value+"</p>");
}