let fields = document.getElementsByTagName("input");
const shouldBeALPHANUMERICAL = [0, 1, 4];   //(1)
const shouldBeNUMERICAL = [2, 4];
const shouldBeALPHABETICAL = [0, 1, 3];
const shouldBe5NUMBERS = [4];
const MESSAGES = ["The following field does not have valid symbols: ",
	"The following field is not exclusively numerical: ",
	"The following field must have five digits: ",
	"The following field must have only letters: ",
	"...",
	"OK"];
const existALPHANUMERICAL = /\w/; //(2)
const existNONALPHANUMERICAL = /\W/; //(3)
const existNONNUMERICAL = /\D/; //(4)
const existNUMERICAL = /\d/; //(5)	
const exist5NUMERICAL = /\d{5}/; //(6)

function error(idmess, field) {
	window.alert(MESSAGES[idmess] + field.name);
	field.focus(); 
	field.select();
}
function isTrue(cond, elem, mustBe, mess) { //(7)   
	for (var i = 0; i < elem.length; i++) {
		let j = elem[i];
		let field = fields[j];
		if (cond.test(field.value) == mustBe) {   //(8)        
			error(mess, field);
			return true;
		}
	}
	return false;
}
function validate() {
	if (isTrue(existALPHANUMERICAL, shouldBeALPHANUMERICAL, false, 0)) return;//(9)  
	if (isTrue(existNONALPHANUMERICAL, shouldBeALPHANUMERICAL, true, 0)) return;//(10)  
	if (isTrue(existNONNUMERICAL, shouldBeNUMERICAL, true, 1)) return;//(11)  
	if (isTrue(exist5NUMERICAL, shouldBe5NUMBERS, false, 2)) return;//(12)  
	if (isTrue(existNUMERICAL, shouldBeALPHABETICAL, true, 3)) return;//(13)  
	if (isTrue(existNONALPHANUMERICAL, shouldBeALPHABETICAL, true, 3)) return;//(14)  
	window.alert(MESSAGES[MESSAGES.length - 1]);
}