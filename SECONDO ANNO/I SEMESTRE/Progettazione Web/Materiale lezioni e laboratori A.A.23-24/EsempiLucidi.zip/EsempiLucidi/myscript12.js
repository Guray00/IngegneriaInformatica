// myscript12.js
var elem = document.getElementById('mydiv');
function set() {
	document.onkeydown = onKeyHandler;
}

function onKeyHandler(e) {  
	e = (!e) ? window.event : e; 			//Explorer -> !e
	var key =(e.which != null) ? e.which : e.keyCode;      //Firefox -> e.which    
	switch (key){    
		case 37: move(-3, 0); break;         // left    
		case 38: move(0, -3); break;         // up    
		case 39: move(3,  0); break;         // right    
		case 40: move(0,  3); break;         // down    
		default: window.alert('stop');  }       
}

function move(dx,dy) {  
	elem.style.left = parseInt(elem.style.left) + dx + "px";  
	elem.style.top  = parseInt(elem.style.top) + dy + "px"; 
}