-- Progettazione Web 
DROP DATABASE if exists ressa_615601; 
CREATE DATABASE ressa_615601; 
USE ressa_615601; 
-- MySQL dump 10.13  Distrib 5.7.28, for Win64 (x86_64)
--
-- Host: localhost    Database: ressa_615601
-- ------------------------------------------------------
-- Server version	5.7.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bar`
--

DROP TABLE IF EXISTS `bar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar` (
  `idproduct` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`idproduct`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar`
--

LOCK TABLES `bar` WRITE;
/*!40000 ALTER TABLE `bar` DISABLE KEYS */;
INSERT INTO `bar` VALUES (1,'Coca-cola',2.5,9),(2,'Fanta',1.5,187),(3,'Martello da Fabbro',2,64),(4,'Colla a Presa Rapida',1.3,10),(6,'Cavo Elettrico',2,50),(7,'Sprite',2,50),(8,'Grissini',0.9,12),(9,'Torta',4,22),(10,'Spina Elettrica',5,100),(11,'Sega a Manico',2,100),(12,'Trapano Elettrico',2,2),(13,'Saldatore a Stagno',21,100),(14,'Chiodi da 5cm',22,99),(15,'Scala Alluminio',2,2),(16,'Lima per Metallo',222,100),(17,'Vodka',8,11);
/*!40000 ALTER TABLE `bar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_sales`
--

DROP TABLE IF EXISTS `bar_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_sales` (
  `idprod` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `many` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`idprod`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_sales`
--

LOCK TABLES `bar_sales` WRITE;
/*!40000 ALTER TABLE `bar_sales` DISABLE KEYS */;
INSERT INTO `bar_sales` VALUES (1,'Coca-cola',2,'2025-03-28'),(2,'Coca-cola',2,'2025-03-29'),(3,'Trapano Elettrico',1,'2025-03-29'),(4,'Cacciavite a Croce',1,'2025-03-29'),(5,'Viti in Acciaio',1,'2025-03-29'),(6,'Carta Vetrata Fina',1,'2025-03-29'),(7,'Chiodi da 5cm',1,'2025-03-29'),(8,'Livella a Bolla',1,'2025-03-29'),(9,'Mascherina Protettiva',1,'2025-03-29'),(10,'Guanti da Lavoro',1,'2025-03-29'),(11,'Cemento Rapido',1,'2025-03-29'),(12,'Pala da Giardino',1,'2025-03-29'),(13,'Seghetto Alternativo',1,'2025-03-29'),(14,'Punta per Trapano',1,'2025-03-29'),(15,'Lampadina LED',1,'2025-03-29'),(16,'Scatola degli Attrezzi',1,'2025-03-29'),(17,'Martello da Fabbro',12,'2025-03-29'),(18,'Martello da Fabbro',12,'2025-03-29'),(19,'Martello da Fabbro',12,'2025-03-29'),(20,'Fanta',12,'2025-03-29'),(21,'Viti in Acciaio',1,'2025-03-29'),(22,'Fanta',12,'2025-03-29'),(23,'Coca-cola',2,'2025-03-30'),(24,'Punta per Trapano',2,'2025-03-31'),(25,'Coca-cola',30,'2025-03-31'),(26,'Coca-cola',1,'2025-04-01'),(27,'Punta per Trapano',2,'2025-04-06'),(28,'Coca-cola',130,'2025-04-07'),(29,'Coca-cola',1,'2025-04-07'),(30,'Vodka',11,'2025-04-07');
/*!40000 ALTER TABLE `bar_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking` (
  `idbooking` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `room` varchar(245) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(245) NOT NULL,
  PRIMARY KEY (`idbooking`,`iduser`,`room`,`date`,`time`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (1,4,'pianoRoom','2025-03-28','14:00-15:00'),(2,4,'pianoRoom','2025-03-28','16:00-17:00'),(3,4,'room1','2025-03-26','08:00-09:00'),(4,4,'room1','2025-03-26','16:00-17:00'),(5,5,'pianoRoom','2025-03-28','15:00-16:00'),(6,5,'room2','2025-03-28','13:00-14:00'),(7,5,'room2','2025-03-28','14:00-15:00'),(8,5,'room2','2025-03-28','15:00-16:00'),(9,5,'room2','2025-03-28','16:00-17:00'),(10,5,'room2','2025-03-28','17:00-18:00'),(11,5,'recRoom','2025-03-29','09:00-10:00'),(12,5,'recRoom','2025-03-29','10:00-11:00'),(13,5,'recRoom','2025-03-29','13:00-14:00'),(14,5,'stage','2025-04-01','16:00-17:00'),(15,5,'stage','2025-04-01','17:00-18:00'),(16,5,'stage','2025-04-01','18:00-19:00'),(17,5,'stage','2025-04-01','19:00-20:00'),(18,5,'stage','2025-04-01','20:00-21:00'),(19,5,'stage','2025-04-01','21:00-22:00'),(20,5,'stage','2025-04-01','15:00-16:00'),(21,5,'stage','2025-04-01','09:00-10:00'),(22,5,'stage','2025-04-01','08:00-09:00'),(23,5,'stage','2025-04-01','10:00-11:00'),(24,5,'stage','2025-04-01','11:00-12:00'),(25,5,'stage','2025-04-01','12:00-13:00'),(26,5,'stage','2025-04-01','13:00-14:00'),(27,5,'stage','2025-04-01','14:00-15:00'),(28,5,'stage','2025-03-27','08:00-09:00'),(29,5,'stage','2025-03-27','09:00-10:00'),(30,5,'stage','2025-03-27','10:00-11:00'),(31,5,'stage','2025-03-27','11:00-12:00'),(32,5,'stage','2025-03-27','12:00-13:00'),(33,5,'stage','2025-03-27','13:00-14:00'),(34,5,'stage','2025-03-27','14:00-15:00'),(35,5,'stage','2025-03-27','15:00-16:00'),(36,5,'stage','2025-03-27','16:00-17:00'),(37,5,'stage','2025-03-27','17:00-18:00'),(38,5,'stage','2025-03-27','18:00-19:00'),(39,5,'stage','2025-03-27','19:00-20:00'),(40,5,'stage','2025-03-27','20:00-21:00'),(41,5,'stage','2025-03-27','21:00-22:00'),(42,5,'stage','2025-04-03','08:00-09:00'),(43,5,'stage','2025-04-03','09:00-10:00'),(44,5,'stage','2025-04-03','10:00-11:00'),(45,5,'stage','2025-04-03','11:00-12:00'),(46,5,'stage','2025-04-03','12:00-13:00'),(47,5,'stage','2025-04-03','13:00-14:00'),(48,5,'stage','2025-04-03','14:00-15:00'),(49,5,'stage','2025-04-03','15:00-16:00'),(50,5,'stage','2025-04-03','16:00-17:00'),(51,5,'stage','2025-04-03','17:00-18:00'),(52,5,'stage','2025-04-03','18:00-19:00'),(53,5,'stage','2025-04-03','19:00-20:00'),(54,5,'stage','2025-04-03','20:00-21:00'),(55,5,'stage','2025-04-03','21:00-22:00'),(56,5,'stage','2025-04-15','08:00-09:00'),(57,5,'stage','2025-04-15','09:00-10:00'),(58,5,'stage','2025-04-15','10:00-11:00'),(59,5,'stage','2025-04-15','11:00-12:00'),(60,5,'stage','2025-04-15','12:00-13:00'),(61,5,'stage','2025-04-15','13:00-14:00'),(62,5,'stage','2025-04-15','14:00-15:00'),(63,5,'stage','2025-04-15','15:00-16:00'),(64,5,'stage','2025-04-15','16:00-17:00'),(65,5,'stage','2025-04-15','17:00-18:00'),(66,5,'stage','2025-04-15','18:00-19:00'),(67,5,'stage','2025-04-15','19:00-20:00'),(68,5,'stage','2025-04-15','20:00-21:00'),(69,5,'stage','2025-04-15','21:00-22:00'),(70,6,'pianoRoom','2025-03-30','08:00-09:00'),(71,6,'pianoRoom','2025-03-30','09:00-10:00'),(72,7,'recRoom','2025-04-17','17:00-18:00'),(73,7,'recRoom','2025-04-17','18:00-19:00'),(74,7,'recRoom','2025-04-17','19:00-20:00'),(75,7,'recRoom','2025-04-17','20:00-21:00'),(76,5,'room1','2025-04-13','14:00-15:00'),(77,5,'drumsRoom','2025-04-01','08:00-09:00'),(78,5,'drumsRoom','2025-04-01','19:00-20:00'),(79,5,'room1','2025-04-12','10:00-11:00'),(80,5,'room1','2025-04-12','11:00-12:00'),(81,5,'room1','2025-04-12','08:00-09:00'),(82,5,'room1','2025-04-12','09:00-10:00'),(83,5,'room1','2025-04-12','12:00-13:00'),(84,5,'room1','2025-04-12','13:00-14:00'),(85,5,'room1','2025-04-12','14:00-15:00'),(86,5,'room1','2025-04-12','15:00-16:00'),(87,5,'room1','2025-04-12','16:00-17:00'),(88,5,'room1','2025-04-12','17:00-18:00'),(89,5,'room1','2025-04-12','18:00-19:00'),(90,5,'room1','2025-04-12','19:00-20:00'),(91,5,'room1','2025-04-12','20:00-21:00'),(92,5,'room1','2025-04-12','21:00-22:00'),(93,5,'room2','2025-04-17','14:00-15:00'),(94,5,'room1','2025-04-02','15:00-16:00'),(95,10,'room1','2025-04-08','09:00-10:00'),(96,10,'room1','2025-04-08','13:00-14:00'),(97,10,'room1','2025-04-08','14:00-15:00'),(98,5,'stage','2025-04-10','08:00-09:00'),(99,5,'stage','2025-04-10','09:00-10:00'),(100,5,'stage','2025-04-10','10:00-11:00'),(101,5,'stage','2025-04-10','11:00-12:00'),(102,5,'stage','2025-04-10','12:00-13:00'),(103,5,'stage','2025-04-10','13:00-14:00'),(104,5,'stage','2025-04-10','14:00-15:00'),(105,5,'stage','2025-04-10','15:00-16:00'),(106,5,'stage','2025-04-10','16:00-17:00'),(107,5,'stage','2025-04-10','17:00-18:00'),(108,5,'stage','2025-04-10','18:00-19:00'),(109,5,'stage','2025-04-10','19:00-20:00'),(110,5,'stage','2025-04-10','20:00-21:00'),(111,5,'stage','2025-04-10','21:00-22:00'),(112,5,'drumsRoom','2025-04-13','14:00-15:00'),(113,5,'drumsRoom','2025-04-13','15:00-16:00');
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposit`
--

DROP TABLE IF EXISTS `deposit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deposit` (
  `idelement` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`idelement`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposit`
--

LOCK TABLES `deposit` WRITE;
/*!40000 ALTER TABLE `deposit` DISABLE KEYS */;
INSERT INTO `deposit` VALUES (2,'Coca-cola',179),(5,'Viti in Acciaio',101),(6,'Cacciavite a Croce',100),(7,'Pinza a Becco',100),(8,'Trapano Elettrico',97),(10,'Carta Vetrata Fina',99),(11,'Colla a Presa Rapida',90),(12,'Livella a Bolla',99),(13,'Guanti da Lavoro',99),(15,'Mascherina Protettiva',99),(16,'Cacciavite a Taglio',100),(17,'Scala Alluminio',98),(18,'Cemento Rapido',99),(19,'Pennello Pittura',100),(20,'Nastro Adesivo',100),(21,'Pala da Giardino',99),(22,'Rastrello Metallico',100),(23,'Seghetto Alternativo',99),(24,'Morsetto da Banco',100),(26,'Cacciavite Elettrico',100),(28,'Punta per Trapano',95),(29,'Cavo Elettrico',52),(32,'Lampadina LED',99),(37,'Sprite',50),(39,'Grissini',10),(40,'Vodka',20);
/*!40000 ALTER TABLE `deposit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `name` varchar(45) NOT NULL,
  `hourly_rate` int(11) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES ('drumsRoom',20),('pianoRoom',20),('recRoom',30),('room1',20),('room2',20),('stage',30);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `Psw` longtext NOT NULL,
  `Role` varchar(45) NOT NULL,
  PRIMARY KEY (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-15 11:06:47
