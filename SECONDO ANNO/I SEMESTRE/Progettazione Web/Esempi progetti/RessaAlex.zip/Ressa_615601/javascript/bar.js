document.addEventListener('DOMContentLoaded', function () {
    loadInventory();
    attachSearchListener();

    function loadInventory() {
        fetch('../php/visualizzaBar.php')
            .then(response => response.json())
            .then(data => populateTable(data))
            .catch(error => console.error('Errore nel caricamento dell\'inventario:', error));
    }

    function populateTable(data) {
        const tbody = document.querySelector('#barTable tbody');
        tbody.innerHTML = '';

        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4">Nessun prodotto trovato</td></tr>';
            return;
        }

        data.forEach(item => {
            if (item.quantity > 0) {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>€ ${item.price.toFixed(2)}</td>
                    <td class="action-buttons">
                        <button class="supply-btn" data-id="${item.idproduct}" data-deposit="${item.depositQuantity}">
                            Rifornisci
                        </button>
                        <button class="sell-btn" data-id="${item.idproduct}" data-name="${item.name}" data-quantity="${item.quantity}">
                            Vendi
                        </button>
                        <button class="reprice-btn" data-id="${item.idproduct}" data-price="${item.price}" data-deposit="${item.quantity}">
                            Riprezza
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            }
        });
    }

    function attachSearchListener() {
        document.getElementById('search-bar').addEventListener('input', function () {
            const searchValue = this.value.toLowerCase();
            document.querySelectorAll('#barTable tbody tr').forEach(row => {
                const productName = row.children[0].textContent.toLowerCase();
                row.style.display = productName.includes(searchValue) ? '' : 'none';
            });
        });
    }

    document.querySelector('#barTable tbody').addEventListener('click', function (e) {
        if (e.target.classList.contains('supply-btn')) {
            handleSupply(e.target);
        } else if (e.target.classList.contains('sell-btn')) {
            handleSell(e.target);
        } else if(e.target.classList.contains('reprice-btn')){
            handleReprice(e.target);
        }
    });

    function handleSupply(button) {
        const id = button.getAttribute('data-id');
        const depositQty = parseInt(button.getAttribute('data-deposit'));

        if (!depositQty || depositQty <= 0) {
            alert('Prodotto esaurito nel deposito');
            return;
        }

        const supplyQty = prompt(`Inserisci la quantità da rifornire (massimo: ${depositQty}):`);
        if (supplyQty && !isNaN(supplyQty) && supplyQty > 0 && supplyQty <= depositQty) {
            fetch('../php/visualizzaBar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ idproduct: id, quantity: parseInt(supplyQty), action: 'supply' })
            })
                .then(response => response.json())
                .then(() => loadInventory())
                .catch(error => console.error('Errore nella richiesta di rifornimento:', error));
        }
    }

    function handleSell(button) {
        const id = button.getAttribute('data-id');
        const name = button.getAttribute('data-name');
        const availableQty = parseInt(button.getAttribute('data-quantity'));


        const sellQty = prompt(`Inserisci la quantità da vendere (massimo: ${availableQty}):`);
        if (sellQty && !isNaN(sellQty) && sellQty > 0 && sellQty <= availableQty) {
            fetch('../php/visualizzaBar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ idproduct: id, name: name, quantity: parseInt(sellQty), action: 'sell' })
            })
                .then(response => response.json())
                .then(() => loadInventory())
                .catch(error => console.error('Errore nella registrazione della vendita:', error));
        }
    }

    function handleReprice(button) {
        const id = button.getAttribute('data-id');
        const depositQty = parseInt(button.getAttribute('data-deposit')); //Non mi serve ma lo mando lo stesso per via dei controlli dei parametri
        const oldPrice = button.getAttribute('data-price');

        const newPrice = prompt(`Inserisci il nuovo prezzo:`);
        if (newPrice && !isNaN(newPrice) && newPrice > 0 && newPrice != oldPrice) {
            fetch('../php/visualizzaBar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ idproduct: id,quantity: parseInt(depositQty), newPrice:newPrice, action: 'reprice'})
            })
                .then(response => response.json())
                .then(() => loadInventory())
                .catch(error => console.error('Errore nella registrazione della vendita:', error));
        } else{
            if(newPrice === oldPrice){
                alert('Hai inserito lo stesso prezzo');
                return;
            }
        }
    }
});
