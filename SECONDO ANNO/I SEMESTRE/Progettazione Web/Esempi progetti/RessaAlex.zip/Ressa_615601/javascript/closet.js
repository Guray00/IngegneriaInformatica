document.addEventListener('DOMContentLoaded', function() {
    loadInventory();

    // Funzione per caricare l'inventario dal server
    function loadInventory() {
        fetch('magazzino.php?action=get')
            .then(response => response.json())
            .then(data => {
                populateTable(data);
            })
            .catch(error => console.error('Errore nel caricamento dell\'inventario:', error));
    }

    // Popola la tabella con i dati ricevuti
    function populateTable(data) {
        const tbody = document.querySelector('.inventory-table tbody');
        tbody.innerHTML = '';
        data.forEach(item => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>
                    <button class="delete-btn" data-id="${item.idelement}">Elimina</button>
                    <button class="add-btn" data-id="${item.idelement}">Aggiungi</button>
                    <button class="transfer-btn" data-id="${item.idelement}">Trasferisci Bar</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        attachEventListeners();
    }

    function attachEventListeners() {
        // Bottone Elimina
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                if (confirm('Sei sicuro di voler eliminare questo elemento?')) {
                    fetch('magazzino.php?action=delete', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ idelement: id })
                    })
                        .then(response => response.json())
                        .then(result => {
                            if (result.status === 'success') {
                                loadInventory();
                            } else {
                                alert('Errore: ' + result.message);
                            }
                        })
                        .catch(error => console.error('Errore nella richiesta di eliminazione:', error));
                }
            });
        });

        // Bottone Aggiungi
        document.querySelectorAll('.add-btn').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const quantityToAdd = prompt('Quante unità aggiungere?');
                if (quantityToAdd !== null && !isNaN(quantityToAdd) && quantityToAdd.trim() !== '') {
                    fetch('magazzino.php?action=update', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ idelement: id, quantity: quantityToAdd })
                    })
                        .then(response => response.json())
                        .then(result => {
                            if (result.status === 'success') {
                                loadInventory();
                            } else {
                                alert('Errore: ' + result.message);
                            }
                        })
                        .catch(error => console.error('Errore nella richiesta di aggiornamento:', error));
                }
            });
        });

        // Bottone Trasferisci Bar
        document.querySelectorAll('.transfer-btn').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const row = this.closest('tr'); // prende il primo tr che trova, quindi recupera la riga dove si trova il bottone stesso
                const currentQuantity = parseInt(row.children[1].textContent);

                // Richiedi la quantità da trasferire (tra 1 e la quantità disponibile)
                let quantityToTransfer = prompt(`Inserisci la quantità da trasferire (min 1, max ${currentQuantity}):`);
                if (quantityToTransfer !== null && !isNaN(quantityToTransfer) && quantityToTransfer.trim() !== '') {
                    quantityToTransfer = parseInt(quantityToTransfer);
                    if (quantityToTransfer < 1 || quantityToTransfer > currentQuantity) {
                        alert("Quantità non valida");
                        return;
                    }
                    // Richiedi il prezzo per il prodotto
                    let priceValue = prompt("Inserisci il prezzo per questo elemento:");
                    if (priceValue !== null && !isNaN(priceValue) && priceValue.trim() !== '') {
                        priceValue = parseFloat(priceValue);
                        fetch('magazzino.php?action=trasferisci', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ idelement: id, quantity: quantityToTransfer, price: priceValue })
                        })
                            .then(response => response.json())
                            .then(result => {
                                if (result.status === 'success') {
                                    loadInventory();
                                    alert("Trasferimento avvenuto con successo!");
                                } else {
                                    alert('Errore: ' + result.message);
                                }
                            })
                            .catch(error => console.error('Errore nella richiesta di trasferimento:', error));
                    } else {
                        alert("Prezzo non valido");
                    }
                }
            });
        });
    }

    // Gestione del form per aggiungere un nuovo elemento
    document.getElementById('add-item-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('item-name').value;
        const quantity = document.getElementById('item-quantity').value;

        fetch('magazzino.php?action=insert', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ "item-name": name, "item-quantity": quantity })
        })
            .then(response => response.json())
            .then(result => {
                if (result.status === 'success') {
                    loadInventory();
                    this.reset();
                } else {
                    alert('Errore: ' + result.message);
                }
            })
            .catch(error => console.error('Errore nella richiesta di inserimento:', error));
    });

    // Funzione per la ricerca nella tabella
    document.getElementById('search-bar').addEventListener('input', function() {
        const searchValue = this.value.toLowerCase();
        document.querySelectorAll('.inventory-table tbody tr').forEach(row => {
            const itemName = row.children[0].textContent.toLowerCase();
            row.style.display = itemName.includes(searchValue) ? '' : 'none';
        });
    });
});
