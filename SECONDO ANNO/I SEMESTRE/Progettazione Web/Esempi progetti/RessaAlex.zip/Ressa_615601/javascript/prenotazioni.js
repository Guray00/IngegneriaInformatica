document.addEventListener('DOMContentLoaded', function() {
    const roomStep = document.getElementById('roomStep');
    const dateStep = document.getElementById('dateStep');
    const timeStep = document.getElementById('timeStep');
    const summaryStep = document.getElementById('summaryStep');

    const prevDateBtn = document.getElementById('prevDateBtn');
    const prevTimeBtn = document.getElementById('prevTimeBtn');
    const prevSummaryBtn = document.getElementById('prevSummaryBtn');

    const nextRoomBtn = document.getElementById('nextRoomBtn');
    const nextDateBtn = document.getElementById('nextDateBtn');
    const confirmReservationBtn = document.getElementById('confirmReservationBtn');
    const finalConfirmBtn = document.getElementById('finalConfirmBtn');

    const roomSelect = document.getElementById('roomSelect');
    const dateSelect = document.getElementById('dateSelect');

    const summaryContent = document.getElementById('summaryContent');

    let selectedRoom = '';
    let selectedDate = '';
    let selectedTimes = [];

    roomSelect.addEventListener('change', function() {
        nextRoomBtn.disabled = roomSelect.value === '';
    });

    nextRoomBtn.addEventListener('click', function() {
        selectedRoom = roomSelect.value;
        roomStep.style.display = 'none';
        dateStep.style.display = 'block';
        popolaDate();
    });

    // Popola il select delle date
    function popolaDate() {
        const today = new Date();
        for (let i = 1; i <= 30; i++) {
            let dateOption = new Date(today);
            dateOption.setDate(today.getDate() + i);// Dal giorno successivo a quello corrente, gestisce anche gli anni bisestili
            const formattedDate = dateOption.toISOString().split('T')[0]; //Formato: yyyy-mm-dd escludendo orario
            const option = document.createElement('option');
            option.value = formattedDate;
            option.textContent = formattedDate;
            dateSelect.appendChild(option);
        }
    }

    dateSelect.addEventListener('change', function() {
        nextDateBtn.disabled = dateSelect.value === '';
    });

    prevDateBtn.addEventListener('click', function() {
        dateStep.style.display = 'none';
        roomStep.style.display = 'block';
    });

    nextDateBtn.addEventListener('click', function() {
        selectedDate = dateSelect.value;
        getAvailableTimes(selectedRoom, selectedDate);
    });

    // Funzione per ottenere gli orari disponibili
    function getAvailableTimes(room, date) {
        fetch('prenota.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                action: 'check_availability',
                room: room,
                date: date
            })
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    populateTimeOptions(data.availableTimes);
                    dateStep.style.display = 'none';
                    timeStep.style.display = 'block';
                } else {
                    alert(data.message || 'Errore nel recupero degli orari');
                }
            })
            .catch(error => {
                console.error('Errore nella richiesta:', error);
                alert('Si è verificato un errore, per favore riprova.');
            });
    }

    // Funzione per popolare le fasce orarie
    function populateTimeOptions(availableTimes) {
        const timeSelect = document.getElementById('timeSelect');
        timeSelect.innerHTML = '';

        if (availableTimes.length === 0) {
            const option = document.createElement('p');
            option.textContent = 'Nessuna fascia oraria disponibile';
            timeSelect.appendChild(option);
        } else {
            availableTimes.forEach(time => {
                const timeOption = document.createElement('div');
                timeOption.classList.add('time-option');
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.id = `time_${time}`;
                checkbox.name = 'times';
                checkbox.value = time;
                const label = document.createElement('label');
                label.setAttribute('for', `time_${time}`);
                label.textContent = time;
                timeOption.appendChild(checkbox);
                timeOption.appendChild(label);
                timeSelect.appendChild(timeOption);
            });
        }

        confirmReservationBtn.disabled = true;
        const checkboxes = document.querySelectorAll('#timeSelect input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const selectedCheckboxes = document.querySelectorAll('#timeSelect input[type="checkbox"]:checked');
                confirmReservationBtn.disabled = selectedCheckboxes.length === 0;
            });
        });
    }

    prevTimeBtn.addEventListener('click', function() {
        timeStep.style.display = 'none';
        dateStep.style.display = 'block';
    });

    // Riepilogo
    confirmReservationBtn.addEventListener('click', function() {
        const selectedCheckboxes = document.querySelectorAll('#timeSelect input[type="checkbox"]:checked');
        if (selectedCheckboxes.length > 0) {
            selectedTimes = Array.from(selectedCheckboxes).map(checkbox => checkbox.value);
            showSummary();
        } else {
            alert('Seleziona almeno una fascia oraria.');
        }
    });

    // Funzione per mostrare il riepilogo della prenotazione
    function showSummary() {
        fetch('prenota.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                action: 'get_room_price',
                room: selectedRoom
            })
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    const pricePerHour = parseFloat(data.hourly_rate);
                    let total = 0;
                    let summaryHTML = `<p><strong>Stanza:</strong> ${selectedRoom}</p>`;
                    summaryHTML += `<p><strong>Data:</strong> ${selectedDate}</p>`;
                    summaryHTML += `<ul>`;
                    selectedTimes.forEach(time => {
                        summaryHTML += `<li>${selectedRoom} ${selectedDate} ${time} - ${pricePerHour.toFixed(2)}€</li>`;
                        total += pricePerHour;
                    });
                    summaryHTML += `</ul>`;
                    summaryHTML += `<p><strong>Totale:</strong> ${total.toFixed(2)}€</p>`;
                    summaryContent.innerHTML = summaryHTML;
                    timeStep.style.display = 'none';
                    summaryStep.style.display = 'block';
                } else {
                    alert(data.message || 'Errore nel recupero del prezzo');
                }
            })
            .catch(error => {
                console.error('Errore nella richiesta:', error);
                alert('Si è verificato un errore, per favore riprova.');
            });
    }

    // Bottone per tornare dal riepilogo alla selezione degli orari
    prevSummaryBtn.addEventListener('click', function() {
        summaryStep.style.display = 'none';
        timeStep.style.display = 'block';
    });

    // Bottone per confermare la prenotazione definitivamente dal riepilogo
    finalConfirmBtn.addEventListener('click', function() {
        makeReservation(selectedRoom, selectedDate, selectedTimes);
    });

    // Funzione per effettuare la prenotazione
    function makeReservation(room, date, times) {
        fetch('prenota.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                action: 'make_reservation',
                room: room,
                date: date,
                times: times.join(',')
            })
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    alert(data.message);
                    resetForm();
                } else {
                    alert(data.message || 'Errore nella prenotazione');
                }
            })
            .catch(error => {
                console.error('Errore nella richiesta:', error);
                alert('Si è verificato un errore, per favore riprova.');
            });
    }

    // Funzione per resettare il form e tornare alla schermata iniziale
    function resetForm() {
        roomStep.style.display = 'block';
        dateStep.style.display = 'none';
        timeStep.style.display = 'none';
        summaryStep.style.display = 'none';
        roomSelect.value = '';
        dateSelect.value = '';
        confirmReservationBtn.disabled = true;
    }
});
