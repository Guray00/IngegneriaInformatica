document.addEventListener("DOMContentLoaded", function () {
    const signupBtn = document.getElementById("signup-btn");
    const loginBtn = document.getElementById("login-btn");
    const formContainer = document.querySelector(".form-container");
    const wrapper = document.querySelector(".wrapper");

    const registerForm = document.querySelector(".form-box.register form");
    const loginForm = document.querySelector(".form-container .login form");

    function clearForm(form) {
        form.reset();
    }

    if (registerForm) {
        clearForm(registerForm);
    }
    if (loginForm) {
        clearForm(loginForm);
    }

    function updateWrapperHeight() {
        if (loginForm && registerForm) {
            if (formContainer.classList.contains("active")) {
                wrapper.style.height = "650px"; // Altezza maggiore per il form di registrazione
            } else {
                wrapper.style.height = "500px"; // Altezza minore per il form di login
            }
        }
    }

    signupBtn.addEventListener("click", function (event) {
        event.preventDefault();
        if (!formContainer.classList.contains("active")) {
            formContainer.classList.add("active");
            updateWrapperHeight();
        }
    });

    loginBtn.addEventListener("click", function (event) {
        event.preventDefault();
        if (formContainer.classList.contains("active")) {
            formContainer.classList.remove("active");
            updateWrapperHeight();
        }
    });

    // Funzione di controllo della password di ruolo per l'admin
    function checkRolePassword(event) {
        const roleSelect = document.querySelector(".register select");
        const selectedRole = roleSelect.value;

        if (selectedRole === "admin") {
            const rolePassword = prompt("Inserire la password di ruolo per admin:");
            if (rolePassword === null || rolePassword === "") {
                event.preventDefault();
                alert("Prego inserire la password!");
                return false;
            }
            document.getElementById("validationPassword").value = rolePassword;
        }
        return true;
    }

    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();
            const email = loginForm.querySelector("input[type='email']").value.trim();
            const password = loginForm.querySelector("input[type='password']").value.trim();
            const role = loginForm.querySelector("select").value;

            if (email === '' || password === '' || role === "") {
                alert("Tutti i campi devono essere compilati.");
                event.preventDefault();
                return;
            }
            if (!isValidEmail(email)) {
                alert("Inserisci un'email valida.");
                event.preventDefault();
                return;
            }
            if (!isValidPassword(password)) {
                alert("La password deve avere almeno 8 caratteri, una lettera e un numero.");
                event.preventDefault();
                return;
            }

            const formData = new FormData(loginForm);  // Raccolgo i dati dal form

            fetch('../php/login.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        window.location.href = data.redirect;
                    } else {
                        alert(data.message);
                        loginForm.reset();
                    }
                })
                .catch(error => {
                    alert("Si è verificato un errore durante il login.");
                    console.error('Error:', error);
                });
        });
    }

    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const name = registerForm.querySelector("input[type='text']").value.trim();
            const email = registerForm.querySelector("input[type='email']").value.trim();
            const password = registerForm.querySelectorAll("input[type='password']")[0].value.trim();
            const confirmPassword = registerForm.querySelectorAll("input[type='password']")[1].value.trim();
            const role = registerForm.querySelector("select").value;

            if (name === "" || email === "" || password === "" || confirmPassword === "" || role === "") {
                alert("Tutti i campi devono essere compilati.");
                event.preventDefault();
                return;
            }
            if (!isValidEmail(email)) {
                alert("Inserisci un'email valida.");
                event.preventDefault();
                return;
            }
            if (!isValidPassword(password)) {
                alert("La password deve avere almeno 8 caratteri, una lettera e un numero.");
                event.preventDefault();
                return;
            }
            if (password !== confirmPassword) {
                alert("Le password non coincidono.");
                event.preventDefault();
                return;
            }
            if (!checkRolePassword(event)) {
                event.preventDefault();
                return;
            }
            const formData = new FormData(registerForm); // Prendo i dati dal form
            formData.append('validationPassword', document.getElementById("validationPassword").value); //Aggiungo a mano il validationPassword

            fetch('../php/signUp.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        window.location.href = data.redirect;
                    } else {
                        alert(data.message);
                        registerForm.reset();
                    }
                })
                .catch(error => {
                    alert("Si è verificato un errore durante la registrazione.");
                    console.error('Error:', error);
                });
        });
    }

    updateWrapperHeight();
});

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;    // testo@testo.testo
    return emailRegex.test(email);
}

function isValidPassword(password) {
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/; // Almeno 8 caratteri e ci deve essere almeno una lettera e un numero
    return passwordRegex.test(password);                                    // Utilizzo del lockhead
}
