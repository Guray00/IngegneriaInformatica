document.addEventListener("DOMContentLoaded",function (){

    function loadPrenotazioni(){
        let url = 'visualizzaPrenotazioni.php';
        fetch(url)
            .then(response => response.json())
            .then(data => {
                console.log("Dati ricevuti dal server:", data); // Debug
                if(data.status === "success" ){
                    displayPrenotazioni(data.data);
                } else {
                    document.getElementById("prenotazioni-container").innerHTML = "<p>" + (data.message || "Nessuna prenotazione trovata.") + "</p>";
                }
        })
            .catch(error => {
                console.error("Errore:",error);
                document.getElementById("prenotazioni-container").innerHTML = "<p>Errore nel recupero delle prenotazioni.</p>";
            });
    }

    function displayPrenotazioni(prenotazioni)
    {
        let html = "<ul>";
        prenotazioni.forEach(prenotazione => {
            html += `<li>
                        <span>${prenotazione.room}</span>
                        <span>${prenotazione.date}</span>
                        <span>${prenotazione.time}</span>
                     </li>`;
        });
        html += "</ul>";
        document.getElementById("prenotazioni-container").innerHTML = html;
    }

    loadPrenotazioni();
});