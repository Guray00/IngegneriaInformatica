document.addEventListener('DOMContentLoaded', function () {
    const tableBody = document.querySelector('#salesTable tbody');
    const filterTodayBtn = document.getElementById('filter-today');
    const filterAllBtn = document.getElementById('filter-all');



    function loadSales(filterToday = false) {
        const url = filterToday ? '../php/vendi.php?today=true' : '../php/vendi.php';
        fetch(url)
            .then(response => response.json())
            .then(data => {
                tableBody.innerHTML = '';

                if (data.length === 0) {
                    tableBody.innerHTML = '<tr><td colspan="3">Nessuna vendita trovata</td></tr>';
                    return;
                }

                data.forEach(sale => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${sale.name}</td>
                        <td>${sale.many}</td>
                        <td>${sale.date}</td>
                    `;
                    tableBody.appendChild(tr);
                });
            })
            .catch(error => console.error('Errore nel caricamento delle vendite:', error));
    }



    loadSales();

    filterTodayBtn.addEventListener('click', function () {
        loadSales(true);
    });

    filterAllBtn.addEventListener('click', function () {
        loadSales(false);
    });
});
