document.addEventListener("DOMContentLoaded", function() {
    function loadPrenotazioni(filter) {
        let url = 'prenotazioniAdminDisplay.php';
        if (filter === 'today') {
            url += '?filter=today';
        }
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    displayPrenotazioni(data.prenotazioni);
                } else {
                    document.getElementById("prenotazioni-container").innerHTML = "<p>" + (data.message || "Nessuna prenotazione trovata.") + "</p>";
                }
            })
            .catch(error => {
                console.error("Errore:", error);
                document.getElementById("prenotazioni-container").innerHTML = "<p>Errore nel recupero delle prenotazioni.</p>";
            });
    }

    function displayPrenotazioni(prenotazioni) {
        let html = "<ul>";
        prenotazioni.forEach(prenotazione => {
            html += `<li>
                        <span>${prenotazione.room}</span>
                        <span>${prenotazione.date}</span>
                        <span>${prenotazione.time}</span>
                     </li>`;
        });
        html += "</ul>";
        document.getElementById("prenotazioni-container").innerHTML = html;
    }

    document.getElementById("filter-today").addEventListener("click", function() {
        loadPrenotazioni('today');
    });


    document.getElementById("clear-filter").addEventListener("click", function() {
        loadPrenotazioni('');
    });

    loadPrenotazioni();
});
