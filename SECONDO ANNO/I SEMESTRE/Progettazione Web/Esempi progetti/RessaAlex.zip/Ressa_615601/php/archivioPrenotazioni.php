<?php
session_start();
if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'user') {
    header("Location: ../html/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Img/HomePage/logo.jpeg" type="image/jpeg">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/archivioPrenotazioni.css">
    <title>Prenotazioni Utente</title>
</head>
<body>
<header>
    <nav class="nav">
        <div class="logo">
            <img src="../Img/HomePage/logo_white.png" alt="Logo">
        </div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a href="user.php">ControlPanel</a>
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>
<div class="centered-box">
    <div id="prenotazioni-container">
        <!-- Generato Dinamicamente -->
    </div>
</div>
<script src="../javascript/archivioPrenotazioni.js"></script>
</body>
</html>
