<?php
session_start();

if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'admin') {
    echo json_encode(["success" => false, "message" => "Accesso negato"]);
    exit();
}

if (!isset($_SESSION['selectedRoom'])) {
    echo json_encode(["success" => false, "message" => "Nessuna room selezionata"]);
    exit();
}

$selectedRoom = $_SESSION['selectedRoom'];
$filter = $_GET['filter'] ?? '';

require_once 'db_connection.php';

$db = new db_connection();
$conn = $db->getConnection();
if($filter === 'today'){
    $query = "SELECT room, date, time FROM booking WHERE room = ? AND date = CURDATE()"; //Curdate è in formato yyyy-mm-dd funzione SQL
} else {
    $query = "SELECT room, date, time FROM booking WHERE room = ?";
}

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $selectedRoom);
$stmt->execute();
$result = $stmt->get_result();

$prenotazioni = [];
while ($row = $result->fetch_assoc()) {
    $prenotazioni[] = $row;
}

$stmt->close();
$db->closeConnection();
echo json_encode([
    "success" => true,
    "prenotazioni" => $prenotazioni
]);
