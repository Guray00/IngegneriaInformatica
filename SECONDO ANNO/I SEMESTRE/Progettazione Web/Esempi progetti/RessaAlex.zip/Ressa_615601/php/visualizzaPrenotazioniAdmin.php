<?php
session_start();

if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'admin') {
    header("Location: ../html/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Img/HomePage/logo.jpeg" type="image/jpeg" />
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/archivioPrenotazioni.css">
    <title>Prenotazioni Admin</title>
</head>
<body>
<header>
    <nav class="nav">
        <div class="logo">
            <img src="../Img/HomePage/logo_white.png" alt="Logo">
        </div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a href="admin.php">ControlPanel</a>
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>
<div class="centered-box">
    <div class="filter-buttons" style="text-align: center; margin-bottom: 10px;">
        <button id="filter-today" class="buttonA" style="width: auto; margin-right: 10px;">Prenotazioni di oggi</button>
        <button id="clear-filter" class="buttonA" style="width: auto;">Mostra tutte</button>
    </div>
    <div id="prenotazioni-container">
        <!-- Generato Dinamicamente -->
    </div>
</div>
<script src="../javascript/visualizzaPrenotazioniAdmin.js"></script>
</body>
</html>
