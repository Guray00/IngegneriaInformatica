<?php

session_start();
require_once 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'] ?? "";
    $password = $_POST["password"] ?? "";
    $role = $_POST["role"] ?? "";

    if (empty($email) || empty($password) || empty($role)) {
        echo json_encode(['status' => 'error', 'message' => 'Tutti i campi devono essere compilati.']);
        exit();
    }

    $db = new db_connection();
    $conn = $db->getConnection();
    $stmt = $conn->prepare("SELECT iduser, Name, Email, Psw, Role FROM user WHERE Email = ? AND Role = ?"); // Evitiamo l'injection
    $stmt->bind_param("ss", $email, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['Psw'])) {
            $_SESSION['userId'] = $user['iduser'];
            $_SESSION['userName'] = $user['Name'];
            $_SESSION['userRole'] = $user['Role'];

            echo json_encode([
                'status' => 'success',
                'message' => 'Login effettuato con successo!',
                'redirect' => ($user['Role'] === 'admin') ? '../php/admin.php' : '../php/user.php'
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Password errata.']);
            exit();
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Utente non trovato o ruolo errato.']);
        exit();
    }

    $stmt->close();
    $db->closeConnection();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Accesso non autorizzato.']);
    exit();
}
?>
