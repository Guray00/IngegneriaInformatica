<?php
header('Content-Type: application/json');
require 'db_connection.php';

$db = new db_connection();
$conn = $db->getConnection();

$input = file_get_contents("php://input");
$data = json_decode($input, true);


if (empty($data)) {
    $query = "SELECT b.idproduct, b.name, b.quantity, b.price, d.quantity AS depositQuantity 
              FROM bar b 
              LEFT JOIN deposit d ON b.name = d.name";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();

    $products = [];
    while ($row = $result->fetch_assoc()) {
        $row['price'] = (float) $row['price'];  // Converte price in float
        $products[] = $row;
    }

    echo json_encode($products);
    exit();
}

// Controllo superfluo ma non si sa mai
if (!isset($data['idproduct']) || !isset($data['quantity']) || !isset($data['action'])) {
    echo json_encode(["status" => "error", "message" => "Parametro mancante"]);
    exit();
}

$idproduct = intval($data['idproduct']);
$quantity = intval($data['quantity']);
$action = $data['action'];

if ($action === 'supply') {
    // Verifica la quantità disponibile nel deposito
    $queryDeposit = "SELECT d.quantity AS depositQuantity, b.name  /*Potevo mandarmi depositQty dal js ma non è sicuro*/
                     FROM bar b 
                     INNER JOIN deposit d ON b.name = d.name 
                     WHERE b.idproduct = ?";
    $stmtDeposit = $conn->prepare($queryDeposit);
    $stmtDeposit->bind_param("i", $idproduct);
    $stmtDeposit->execute();
    $resultDeposit = $stmtDeposit->get_result();
    $productData = $resultDeposit->fetch_assoc();

    if (!$productData || $productData['depositQuantity'] < $quantity) {
        echo json_encode(["status" => "error", "message" => "Quantità non disponibile nel deposito"]);
        exit();
    }

    // Aggiorna la quantità nel bar
    $queryUpdateBar = "UPDATE bar SET quantity = quantity + ? WHERE idproduct = ?";
    $stmtUpdateBar = $conn->prepare($queryUpdateBar);
    $stmtUpdateBar->bind_param("ii", $quantity, $idproduct);
    $stmtUpdateBar->execute();

    // Aggiorna la quantità nel deposito
    $queryUpdateDeposit = "UPDATE deposit SET quantity = quantity - ? WHERE name = ?";
    $stmtUpdateDeposit = $conn->prepare($queryUpdateDeposit);
    $stmtUpdateDeposit->bind_param("is", $quantity, $productData['name']);
    $stmtUpdateDeposit->execute();

    echo json_encode(["status" => "success", "message" => "Rifornimento effettuato!"]);
    exit();
}

if ($action === 'sell') {
    $name = $data['name'];

    // Controlla lo stock disponibile nel bar
    $queryCheckStock = "SELECT quantity FROM bar WHERE idproduct = ?";
    $stmtCheckStock = $conn->prepare($queryCheckStock);
    $stmtCheckStock->bind_param("i", $idproduct);
    $stmtCheckStock->execute();
    $resultCheckStock = $stmtCheckStock->get_result();
    $stock = $resultCheckStock->fetch_assoc()['quantity'];

    if ($stock < $quantity) {
        echo json_encode(["status" => "error", "message" => "Quantità non disponibile"]);
        exit();
    }

    // Registra la vendita
    $querySell = "INSERT INTO bar_sales (name, many, date) VALUES (?, ?, CURDATE())";
    $stmtSell = $conn->prepare($querySell);
    $stmtSell->bind_param("si", $name, $quantity);
    $stmtSell->execute();

    // Aggiorna la quantità nel bar
    $queryUpdateBar = "UPDATE bar SET quantity = quantity - ? WHERE idproduct = ?";
    $stmtUpdateBar = $conn->prepare($queryUpdateBar);
    $stmtUpdateBar->bind_param("ii", $quantity, $idproduct);
    $stmtUpdateBar->execute();

    // Rimuove il prodotto se la quantità arriva a zero
    $queryDeleteZero = "DELETE FROM bar WHERE quantity = 0";
    $conn->query($queryDeleteZero);

    echo json_encode(["status" => "success", "message" => "Vendita registrata!"]);
    exit();
}
if ($action === 'reprice') {
    $newPrice = doubleval($data['newPrice']);

    $queryCheckStock = "UPDATE bar SET price = ? WHERE idproduct = ?";
    $stmtCheckStock = $conn->prepare($queryCheckStock);
    $stmtCheckStock->bind_param("di", $newPrice,$idproduct);
    $stmtCheckStock->execute();

    echo json_encode(["status" => "success", "message" => "Riprezzamento avvenuto con successo!"]);
    exit();
}
?>
