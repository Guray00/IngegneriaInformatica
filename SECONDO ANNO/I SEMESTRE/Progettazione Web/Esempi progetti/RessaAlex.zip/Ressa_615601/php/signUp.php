<?php

session_start();
require_once 'db_connection.php';
$adminPassword = '$2y$10$stUUiiX7TcgeLRtu.5rvgOCMKWTkg5PE4D/gmm3ot.feLPgDajEJS'; //admin123, ovviamente non la mettiamo in chiaro

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $validationPassword = $_POST["validationPassword"] ?? "";
    $name = $_POST["name"] ?? "";
    $email = $_POST["email"] ?? "";
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirmPassword"] ?? "";
    $role = $_POST["role"] ?? "";

    // Controlliamo anche in backend i parametri
    if (empty($name) || empty($email) || empty($password) || empty($confirmPassword) || empty($role)) {
        echo json_encode(['status' => 'error', 'message' => 'Tutti i campi devono essere compilati.']);
        exit();
    }
    // Se il ruolo è admin, verifica la password di validazione
    if ($role === "admin" && !password_verify($validationPassword, $adminPassword)) {
        echo json_encode(['status' => 'error', 'message' => 'La password di validazione per il ruolo admin non è corretta.']);
        exit();
    }
    if ($password !== $confirmPassword) {
        echo json_encode(['status' => 'error', 'message' => 'Le password non coincidono.']);
        exit();
    }

    $db = new db_connection();
    $conn = $db->getConnection();
    $name = $conn->real_escape_string($name);
    $email = $conn->real_escape_string($email);
    $password = password_hash($password, PASSWORD_BCRYPT);

    // Controllo se esiste già l'utente con la stessa email
    $stmt = $conn->prepare("SELECT Name FROM user WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if ($row['Name'] !== $name) {
            echo json_encode(['status' => 'error', 'message' => 'Questa email è già registrata con un altro nome.']);
            exit();
        }
    }

    // Controlla se esiste già una combinazione di Nome, Email e Ruolo
    $stmt = $conn->prepare("SELECT * FROM user WHERE Name = ? AND Email = ? AND Role = ?");
    $stmt->bind_param("sss", $name, $email, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Un utente con lo stesso nome, email e ruolo esiste già.']);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO user (Name, Email, Psw, Role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $role);

    if ($stmt->execute()) {
        $userId = $conn->insert_id; // Ci prendiamo facilmente l'id appena inseritp (AutoIncrement del db)
        $_SESSION['userId'] = $userId;
        $_SESSION['userName'] = $name;
        $_SESSION['userRole'] = $role;
        echo json_encode([
            'status' => 'success',
            'message' => 'Registrazione avvenuta con successo!',
            'redirect' => ($role === 'admin') ? '../php/admin.php' : '../php/user.php'
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Errore nella registrazione: ' . $stmt->error]);
        exit();
    }

    $stmt->close();
    $db->closeConnection();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Accesso non autorizzato.']);
    exit();
}
?>
