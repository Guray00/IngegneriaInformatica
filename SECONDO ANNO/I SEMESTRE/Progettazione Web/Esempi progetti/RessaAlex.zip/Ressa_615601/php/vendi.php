<?php
header('Content-Type: application/json');
require 'db_connection.php';

$db = new db_connection();
$conn = $db->getConnection();

// Verifica se è richiesto il filtro per le vendite di oggi
$filterToday = isset($_GET['today']) && $_GET['today'] === 'true';

if ($filterToday) {
    $query = "SELECT name, many, date FROM bar_sales WHERE date = CURDATE() ORDER BY date DESC";
} else {
    $query = "SELECT name, many, date FROM bar_sales ORDER BY date DESC";
}

$result = $conn->query($query);
$sales = [];

while ($row = $result->fetch_assoc()) {
    $sales[] = $row;
}

echo json_encode($sales);
?>
