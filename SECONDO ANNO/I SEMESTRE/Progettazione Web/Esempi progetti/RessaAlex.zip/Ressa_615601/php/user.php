<?php
session_start();
if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'user') {
    header("Location: ../html/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/PanelControlUser.css">
    <title>User PanelControl</title>
</head>
<body>
<header>
    <nav class="nav">
        <div class="logo"><img alt="logo" src="../Img/HomePage/logo_white.png"></div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>
<div class="container">
    <div class="left">
        <button class="button"  onclick="window.location.href='prenotazione.php'" >Prenota</button>
        <button class="button"  onclick="window.location.href='archivioPrenotazioni.php'" >Visualizza Prenotazioni</button>
    </div>

    <div class="right">
        <div class="neonText">Benvenuto <?php echo explode(" ", trim($_SESSION['userName']))[0] ?></div>
    </div>
</div>
</body>
</html>
