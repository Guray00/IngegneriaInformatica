<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'user') {
    echo json_encode(['status' => 'error', 'message' => 'Accesso negato']);
    exit();
}

if (!isset($_SESSION['userId'])) {
    echo json_encode(['status' => 'error', 'message' => 'Utente non identificato']);
    exit();
}

require_once('db_connection.php');

$db = new db_connection();
$conn = $db->getConnection();

$userId = $_SESSION['userId'];

$sql = "SELECT room, date, time FROM booking WHERE iduser = ? ORDER BY date DESC, time DESC";
$stmt = $conn->prepare($sql);


$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

$stmt->close();
$db->closeConnection();

$response['status'] = 'success';
$response['data'] = $bookings;
$response['debug']['numPrenotazioni'] = count($bookings);

if (empty($bookings)) {
    $response['message'] = "Nessuna prenotazione trovata per l'utente $userId";
}

echo json_encode($response);
?>
