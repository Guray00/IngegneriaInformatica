<?php
session_start();
include('db_connection.php');
$db = new db_connection();
$conn = $db->getConnection();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';  //Operatore di coalescenza , alternativa : $action = isset($_POST['action']) ? $_POST['action'] : '';
    if ($action === 'check_availability') {
        $room = $_POST['room'] ?? '';
        $date = $_POST['date'] ?? '';
        if ($room && $date) {
            $availableTimes = checkAvailableTimes($room, $date, $conn);
            echo json_encode(['status' => 'success', 'availableTimes' => $availableTimes]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Stanza o data non specificata']);
        }
    } elseif ($action === 'make_reservation') {
        $room = $_POST['room'] ?? '';
        $date = $_POST['date'] ?? '';
        $times = explode(',', $_POST['times'] ?? '');
        if ($room && $date && count($times) > 0 && $times[0] !== '') { //Nota che count('') restituisce 1
            if (makeReservation($room, $date, $times, $conn)) {
                echo json_encode(['status' => 'success', 'message' => 'Prenotazione effettuata con successo!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Errore durante la prenotazione']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Dati di prenotazione incompleti']);
        }
    } elseif ($action === 'get_room_price') {
        $room = $_POST['room'] ?? '';
        if ($room) {
            $query = "SELECT hourly_rate FROM room WHERE LOWER(name) = LOWER(?)";  //nel select seconda parola con lettera maiuscola, nel db tutto minuscolo
            $stmt = $conn->prepare($query);
            if (!$stmt) {
                error_log("Errore nella prepare (get_room_price): " . $conn->error);
                echo json_encode(['status' => 'error', 'message' => 'Errore nel recupero del prezzo']);
                exit();
            }
            $stmt->bind_param('s', $room);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                echo json_encode(['status' => 'success', 'hourly_rate' => $row['hourly_rate']]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Stanza non trovata']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Stanza non specificata']);
        }
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Metodo di richiesta non valido']);
}


// Funzione per ottenere le fasce orarie disponibili per una data e stanza
function checkAvailableTimes($room, $date, $conn) {
    $query = "SELECT time FROM booking WHERE room = ? AND date = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Errore nella prepare (checkAvailableTimes): " . $conn->error);
        return [];
    }
    $stmt->bind_param('ss', $room, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    $reservedTimes = [];
    while ($row = $result->fetch_assoc()) {
        $reservedTimes[] = $row['time'];
    }
    $allTimes = [
        '08:00-09:00', '09:00-10:00', '10:00-11:00', '11:00-12:00',
        '12:00-13:00', '13:00-14:00', '14:00-15:00', '15:00-16:00',
        '16:00-17:00', '17:00-18:00', '18:00-19:00', '19:00-20:00',
        '20:00-21:00', '21:00-22:00'
    ];
    return array_values(array_diff($allTimes, $reservedTimes));  // Tolgo da allTimes tutti gli orari già prenotati.
}

// Funzione per effettuare la prenotazione per ogni fascia oraria selezionata
function makeReservation($room, $date, $times, $conn) {
    $success = true;
    $iduser = $_SESSION['userId'] ?? 0;
    foreach ($times as $time) {
        $query = "INSERT INTO booking (iduser, room, date, time) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            error_log("Errore nella prepare (makeReservation): " . $conn->error);
            $success = false;
            break;
        }
        $stmt->bind_param('isss', $iduser, $room, $date, $time);
        if (!$stmt->execute()) {
            error_log("Errore nell'esecuzione (makeReservation): " . $stmt->error);
            $success = false;
            break;
        }
    }
    return $success;
}
?>
