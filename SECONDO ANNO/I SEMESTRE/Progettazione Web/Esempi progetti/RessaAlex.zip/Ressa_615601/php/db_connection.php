<?php

class db_connection {
    private $conn;

    public function __construct($servername = 'localhost', $username = 'root', $password = '', $dbname = 'ressa_615601') {
        // Connessione al database
        $this->conn = new mysqli($servername, $username, $password, $dbname);

        if ($this->conn->connect_error) {
            $error_message = 'Connessione al database fallita: ' . $this->conn->connect_error;
            echo json_encode(['status' => 'error', 'message' => $error_message]);
            error_log($error_message); // Scrive l'errore nei log
            exit();
        }
    }

    public function getConnection() {
        return $this->conn;
    }

    public function closeConnection() {
        $this->conn->close();
    }
}

?>

