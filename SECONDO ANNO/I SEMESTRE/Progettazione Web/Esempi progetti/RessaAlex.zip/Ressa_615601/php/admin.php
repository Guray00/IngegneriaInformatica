<?php
session_start();

if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'admin') {
    header("Location: ../html/login.html");
    exit();
}

// Se viene cliccato un bottone, salva il nome della stanza nella sessione
if (isset($_POST['room'])) {
    $roomName = $_POST['room'];
    $roomName = strtolower(substr($roomName, 0, 1)) . substr($roomName, 1); //In pratica converto in minuscolo la prima lettera della stanza, così l'adeguo al db
    $_SESSION['selectedRoom'] = $roomName;

    if ($roomName === "closet") {
        header("Location: closet.php");
    } elseif ($roomName === "bar") {
        header("Location: bar.php");
    } else {
        header("Location: visualizzaPrenotazioniAdmin.php");
    }
    exit();
}

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/PanelControlUser.css">
    <link rel="stylesheet" href="../css/PanelControlAdmin.css">
    <title>User PanelControl</title>
</head>
<body>
<header>
    <nav class="nav">
        <div class="logo"><img alt="logo" src="../Img/HomePage/logo_white.png"></div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>
<div class="container">
    <div class="left">
        <!-- Ogni bottone invia il nome della stanza alla stessa pagina via POST -->
        <form method="POST">
            <button type="submit" name="room" value="Room1" class="buttonA">Room1</button>
            <button type="submit" name="room" value="Room2" class="buttonA">Room2</button>
            <button type="submit" name="room" value="PianoRoom" class="buttonA">PianoRoom</button>
            <button type="submit" name="room" value="DrumsRoom" class="buttonA">DrumsRoom</button>
            <button type="submit" name="room" value="RecRoom" class="buttonA">RecRoom</button>
            <button type="submit" name="room" value="Stage" class="buttonA">Stage</button>
            <button type="submit" name="room" value="Bar" class="buttonA">Bar</button>
            <button type="submit" name="room" value="Closet" class="buttonA">Closet</button>
        </form>
    </div>

    <div class="right">
        <div class="neonText">Benvenuto <?php echo explode(" ", trim($_SESSION['userName']))[0] ?></div>
    </div>
</div>
</body>
</html>
