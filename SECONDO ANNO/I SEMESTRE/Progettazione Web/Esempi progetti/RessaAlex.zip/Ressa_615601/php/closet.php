<?php
session_start();
// Se l'utente non è admin, rimanda alla pagina di login
if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'admin') {
    header("Location: ../html/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Img/HomePage/logo.jpeg" type="image/jpeg" />
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/closet.css">
    <title>Closet Inventory</title>
</head>
<body>

<header>
    <nav class="nav">
        <div class="logo"><img src="../Img/HomePage/logo_white.png" alt="Logo"></div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a href="admin.php">ControlPanel</a>
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>

<div class="container">
    <div class="left-section">
        <div class="inventory-header">
            <h2>Inventario Deposito</h2>
            <input type="text" id="search-bar" placeholder="Cerca un elemento...">
        </div>
        <div class="table-container">
            <table class="inventory-table">
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Quantità</th>
                    <th>Azioni</th>
                </tr>
                </thead>
                <tbody>
                <!-- La tabella verrà popolata dinamicamente -->
                </tbody>
            </table>
        </div>
    </div>


    <div class="right-section">
        <h2>Aggiungi Elemento</h2>
        <form class="add-item-form" id="add-item-form">
            <label for="item-name">Nome:</label>
            <input type="text" id="item-name" name="item-name" required>

            <label for="item-quantity">Quantità:</label>
            <input type="number" id="item-quantity" name="item-quantity" required>

            <button type="submit">Aggiungi</button>
        </form>
    </div>
</div>

<script src="../javascript/closet.js"></script>
</body>
</html>
