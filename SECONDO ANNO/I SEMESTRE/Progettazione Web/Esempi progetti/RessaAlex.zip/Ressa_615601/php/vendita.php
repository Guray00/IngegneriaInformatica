<?php
session_start();
// Se l'utente non è admin, rimanda alla pagina di login
if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'admin') {
    header("Location: ../html/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Img/HomePage/logo.jpeg" type="image/jpeg">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/archivioPrenotazioni.css">
    <link rel="stylesheet" href="../css/vendita.css">
    <title>Bar Sales</title>
</head>
<body>
<header>
    <nav class="nav">
        <div class="logo"><img src="../Img/HomePage/logo_white.png" alt="Logo"></div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a href="bar.php">Bar</a>
            <a href="admin.php">ControlPanel</a>
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>
<div class="centered-box">
    <h2>Storico Vendite</h2>
    <div class="button-container">
        <button id="filter-today" class="buttonA">Mostra vendite di oggi</button>
        <button id="filter-all" class="buttonA">Mostra tutte le vendite</button>
    </div>
    <div class="scrolled-table-container">
        <table id="salesTable">
            <thead>
            <tr>
                <th>Nome Prodotto</th>
                <th>Quantità Venduta</th>
                <th>Data</th>
            </tr>
            </thead>
            <tbody>
            <!-- I dati verranno dinamicamente-->
            </tbody>
        </table>
    </div>
</div>
<script src="../javascript/vendita.js"></script>
</body>
</html>
