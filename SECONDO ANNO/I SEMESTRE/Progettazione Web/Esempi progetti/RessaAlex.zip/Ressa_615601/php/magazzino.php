<?php
include 'db_connection.php';

$db = new db_connection();
$conn = $db->getConnection();

// Rileva l'azione richiesta
$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postData = json_decode(file_get_contents('php://input'), true);
}

if ($action === 'get') {
    // Recupera tutti gli elementi dalla tabella deposit con quantità maggiore di 0
    $sql = "SELECT * FROM deposit WHERE quantity > 0";
    $result = $conn->query($sql);
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);

} elseif ($action === 'delete') {
    // Elimina l'elemento specificato
    if (isset($postData['idelement'])) {
        $idelement = intval($postData['idelement']);
        $stmt = $conn->prepare("DELETE FROM deposit WHERE idelement = ?");
        $stmt->bind_param("i", $idelement);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => $conn->error]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Parametro mancante']);
    }

} elseif ($action === 'update') {
    // Aggiunge un quantitativo all'elemento esistente nel deposito
    if (isset($postData['idelement']) && isset($postData['quantity'])) {
        $idelement = intval($postData['idelement']);
        $quantityToAdd = intval($postData['quantity']);
        $stmt = $conn->prepare("UPDATE deposit SET quantity = quantity + ? WHERE idelement = ?");
        $stmt->bind_param("ii", $quantityToAdd, $idelement);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => $conn->error]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Parametro mancante']);
    }

} elseif ($action === 'insert') {
    // Inserisce un nuovo elemento nel deposito solo se il nome non esiste già
    if (isset($postData['item-name']) && isset($postData['item-quantity'])) {
        $name = $postData['item-name'];
        $quantity = intval($postData['item-quantity']);

        // Verifica se l'elemento esiste già
        $stmtCheck = $conn->prepare("SELECT idelement FROM deposit WHERE name = ?"); //utf8mb4_general_ci -> Case Insensitive
        $stmtCheck->bind_param("s", $name);
        $stmtCheck->execute();
        $checkResult = $stmtCheck->get_result();
        if ($checkResult->num_rows > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Elemento già presente']);
        } else {
            $stmtInsert = $conn->prepare("INSERT INTO deposit (name, quantity) VALUES (?, ?)");
            $stmtInsert->bind_param("si", $name, $quantity);
            if ($stmtInsert->execute()) {
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => $conn->error]);
            }
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Parametro mancante']);
    }

} elseif ($action === 'trasferisci') {
    // Trasferisce una quantità dalla tabella deposit alla tabella bar
    if (isset($postData['idelement'], $postData['quantity'], $postData['price'])) {
        $idelement = intval($postData['idelement']);
        $transfer = intval($postData['quantity']);
        $price = doubleval($postData['price']);

        // Recupera quantità e nome dell'elemento nel deposito
        $stmt = $conn->prepare("SELECT quantity, name FROM deposit WHERE idelement = ?");
        $stmt->bind_param("i", $idelement);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows == 0) {
            echo json_encode(['status' => 'error', 'message' => 'Elemento non trovato']);
            exit();
        }
        $row = $result->fetch_assoc();
        $currentQuantity = intval($row['quantity']);
        $name = $row['name'];

        // Verifica che la quantità da trasferire sia valida
        if ($transfer < 1 || $transfer > $currentQuantity) {
            echo json_encode(['status' => 'error', 'message' => 'Quantità non valida']);
            exit();
        }

        // Controlla se il prodotto è già presente in bar
        $stmtCheckBar = $conn->prepare("SELECT idproduct FROM bar WHERE name = ?");
        $stmtCheckBar->bind_param("s", $name);
        $stmtCheckBar->execute();
        $checkResult = $stmtCheckBar->get_result();
        if ($checkResult->num_rows > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Prodotto già presente nel bar, fare rischiesta di rifornimento']);
            exit();
        }

        // Inserisce un nuovo record in bar con il prezzo specificato
        $stmtInsertBar = $conn->prepare("INSERT INTO bar (name, price, quantity) VALUES (?, ?, ?)");
        $stmtInsertBar->bind_param("sdi", $name, $price, $transfer);
        if (!$stmtInsertBar->execute()) {
            echo json_encode(['status' => 'error', 'message' => 'Errore inserimento in bar: ' . $conn->error]);
            exit();
        }


        // Decrementa la quantità nel deposito
        $stmtUpdateDeposit = $conn->prepare("UPDATE deposit SET quantity = quantity - ? WHERE idelement = ?");
        $stmtUpdateDeposit->bind_param("ii", $transfer, $idelement);
        if (!$stmtUpdateDeposit->execute()) {
            echo json_encode(['status' => 'error', 'message' => 'Errore aggiornamento deposit: ' . $conn->error]);
            exit();
        }

        // Se il trasferimento ha prelevato tutta la quantità, elimina il record dal deposito
        if ($transfer === $currentQuantity) {
            $stmtDeleteDeposit = $conn->prepare("DELETE FROM deposit WHERE idelement = ?");
            $stmtDeleteDeposit->bind_param("i", $idelement);
            $stmtDeleteDeposit->execute();
        }

        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Parametro mancante']);
    }

} else {
    echo json_encode(['status' => 'error', 'message' => 'Azione non valida']);
}

$db->closeConnection();
?>
