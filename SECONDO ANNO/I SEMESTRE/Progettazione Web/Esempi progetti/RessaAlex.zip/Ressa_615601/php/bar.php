<?php
session_start();
// Se l'utente non è admin, rimanda alla pagina di login
if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'admin') {
    header("Location: ../html/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Img/HomePage/logo.jpeg" type="image/jpeg" >
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/archivioPrenotazioni.css">
    <link rel="stylesheet" href="../css/bar.css">
    <title>Bar Inventory</title>
</head>
<body>
<header>
    <nav class="nav">
        <div class="logo"><img src="../Img/HomePage/logo_white.png" alt="Logo"></div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a href="admin.php">ControlPanel</a>
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>

<div class="centered-box">
    <div class="search-vendita-container">
        <input type="text" id="search-bar" placeholder="Cerca un prodotto...">
        <a href="vendita.php" class="vendita-button">Vendi</a>
    </div>

    <div class="scrolled-table-container">
        <table id="barTable">
            <thead>
            <tr>
                <th>Nome</th>
                <th>Quantità</th>
                <th>Prezzo</th>
                <th>Azione</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

<script src="../javascript/bar.js"></script>
</body>
</html>
