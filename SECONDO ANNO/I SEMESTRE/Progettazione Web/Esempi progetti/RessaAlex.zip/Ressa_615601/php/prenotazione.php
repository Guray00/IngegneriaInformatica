<?php
session_start();
if (!isset($_SESSION['userRole']) || $_SESSION['userRole'] !== 'user') {
    header("Location: ../html/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Img/HomePage/logo.jpeg" type="image/jpeg">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/prenotazioniUtente.css">
    <title>Prenotazioni Utente</title>
</head>
<body>
<header>
    <nav class="nav">
        <div class="logo"><img alt="logo" src="../Img/HomePage/logo_white.png"></div>
        <h1>StageDive</h1>
        <div class="menu" id="menu">
            <a href="user.php">ControlPanel</a>
            <a class="a_panel" href="logout.php">Logout</a>
        </div>
    </nav>
</header>

<div id="selection-container">
    <!-- Seleziona una stanza -->
    <div class="selection-step" id="roomStep">
        <label for="roomSelect">Seleziona una stanza</label>
        <select id="roomSelect">
            <option value="">Seleziona una stanza</option>
            <option value="room1">room1</option>
            <option value="room2">room2</option>
            <option value="drumsRoom">drumsRoom</option>
            <option value="pianoRoom">pianoRoom</option>
            <option value="recRoom">recRoom</option>
            <option value="stage">stage</option>
        </select>
        <button id="nextRoomBtn" disabled>Avanti</button>
    </div>

    <!-- Selezione della data -->
    <div class="selection-step" id="dateStep" style="display:none;">
        <label for="dateSelect">Seleziona una data</label>
        <select id="dateSelect">
            <option value="">Seleziona una data</option> <!-- Le date disponibili vengono create dinamicamente -->
        </select>
        <div class="buttons">
            <button id="prevDateBtn">Indietro</button>
            <button id="nextDateBtn" disabled>Avanti</button>
        </div>
    </div>

    <!-- Selezione delle fasce orarie -->
    <div class="selection-step" id="timeStep" style="display:none;">
        <label>Seleziona le fasce orarie</label>
        <div id="timeSelect">
            <!-- Le fasce orarie vengono generate dinamicamente -->
        </div>
        <div class="buttons">
            <button id="prevTimeBtn">Indietro</button>
            <button id="confirmReservationBtn" disabled>Avanti</button>
        </div>
    </div>

    <!-- Riepilogo prenotazione -->
    <div class="selection-step" id="summaryStep" style="display:none;">
        <h2>Riepilogo Prenotazione</h2>
        <div id="summaryContent">
            <!-- Viene generato dinamicamente -->
        </div>
        <div class="buttons">
            <button id="prevSummaryBtn">Indietro</button>
            <button id="finalConfirmBtn">Conferma Prenotazione</button>
        </div>
    </div>
</div>

<script src="../javascript/prenotazioni.js"></script>
</body>
</html>
