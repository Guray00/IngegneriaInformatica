function UserMovieNavBarEventHandler(){}

UserMovieNavBarEventHandler.DEFAUL_METHOD = "GET";
UserMovieNavBarEventHandler.URL_REQUEST = "./ajax/userMovieInteraction.php";
UserMovieNavBarEventHandler.ASYNC_TYPE = true;

UserMovieNavBarEventHandler.SUCCESS_RESPONSE = "0";

UserMovieNavBarEventHandler.onWatchEvent = 
	function(movieId) {
		var flag =  getComplementaryFlag(document.getElementById("watchedItem_" + movieId))
		var queryString = "?movieId=" + movieId + "&isWatched=" + flag;
		var url = UserMovieNavBarEventHandler.URL_REQUEST + queryString;
		var responseFunction = UserMovieNavBarEventHandler.onAjaxResponse;
	
		AjaxManager.performAjaxRequest(UserMovieNavBarEventHandler.DEFAUL_METHOD, 
										url, UserMovieNavBarEventHandler.ASYNC_TYPE, 
										null, responseFunction)
	}

UserMovieNavBarEventHandler.onToWatchEvent =
	function(movieId){
		var flag =  getComplementaryFlag(document.getElementById("toWatchItem_" + movieId))
		var queryString = "?movieId=" + movieId + "&toWatch=" + flag;
		var url = UserMovieNavBarEventHandler.URL_REQUEST + queryString;
		var responseFunction = UserMovieNavBarEventHandler.onAjaxResponse;
	
		AjaxManager.performAjaxRequest(UserMovieNavBarEventHandler.DEFAUL_METHOD, 
										url, UserMovieNavBarEventHandler.ASYNC_TYPE, 
										null, responseFunction)
	}

UserMovieNavBarEventHandler.onLikeEvent = 
	function(movieId){
		var flag =  getComplementaryFlag(document.getElementById("likeItem_" + movieId))
		var queryString = "?movieId=" + movieId + "&like=" + flag;
		var url = UserMovieNavBarEventHandler.URL_REQUEST + queryString;
		var responseFunction = UserMovieNavBarEventHandler.onAjaxResponse;
	
		AjaxManager.performAjaxRequest(UserMovieNavBarEventHandler.DEFAUL_METHOD, 
										url, UserMovieNavBarEventHandler.ASYNC_TYPE, 
										null, responseFunction)
	}	

UserMovieNavBarEventHandler.onDislikeEvent = 
	function(movieId){
		var flag =  getComplementaryFlag(document.getElementById("dislikeItem_" + movieId))
		var queryString = "?movieId=" + movieId + "&dislike=" + flag;
		var url = UserMovieNavBarEventHandler.URL_REQUEST + queryString;
		var responseFunction = UserMovieNavBarEventHandler.onAjaxResponse;
	
		AjaxManager.performAjaxRequest(UserMovieNavBarEventHandler.DEFAUL_METHOD, 
										url, UserMovieNavBarEventHandler.ASYNC_TYPE, 
										null, responseFunction)
	}

UserMovieNavBarEventHandler.onAjaxResponse = 
	function(response){
		if (response.responseCode === UserMovieNavBarEventHandler.SUCCESS_RESPONSE)
			MovieDashboard.updateMovieNavBar(response.data);
		
	}

function getComplementaryFlag(item){
	var classAttribute = item.getAttribute("class"); // item.className;
	var currentFlag = parseInt(classAttribute.charAt(classAttribute.length-1)); // parseInt(classAttribute.slice(-1));
	return (currentFlag+1)%2;
}
