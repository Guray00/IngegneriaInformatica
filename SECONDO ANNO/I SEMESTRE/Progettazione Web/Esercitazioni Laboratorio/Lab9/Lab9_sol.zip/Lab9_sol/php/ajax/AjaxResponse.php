<?php  
	/*
		AjaxResponse is the class that will be sent back to the client at every Ajax request.
		The class is serialize according the Json format through the json_encode function, that 
		serialize ONLY the public property.
		
		It is possibile to serialize also protected and private property but it is out of the course scope.
	*/
	class AjaxResponse{
		public $responseCode; // 0 all ok - 1 some errors - -1 some warning
		public $message;
		public $data;
		
		function AjaxResponse($responseCode = 1, 
								$message = "Somenthing went wrong! Please try later.",
								$data = null){
			$this->responseCode = $responseCode;
			$this->message = $message;
			$this->data = null;
		}
	
	}

	class MovieUserStat {
		public $movie;
		public $userMovieStat;
	
		function MovieUserStat($movie = null, $userMovieStat = null){
			$this->movie = $movie;
			$this->userMovieStat = $userMovieStat;
		}
		
	}
	
	class Movie{
		public $movieId;
		public $posterUrl;
		public $title;
		public $director;
	
		function Movie($movieId = null, $posterUrl = null, $title = null, $director = null){
			$this->movieId = $movieId;
			$this->posterUrl = $posterUrl;
			$this->title = $title;
			$this->director = $director;
		}
		
	}
	
	class UserStat{
		public $watched;
		public $toWatch;
		public $liked;
		public $likedCount;
		public $disliked;
		public $dislikedCount;
	
		function UserStat($watched = 0, $toWatch = 0, $liked = 0, 
								$likedCount = -1, $disliked = 0, $dislikedCount = -1){
			
			$this->watched = $watched;
			$this->toWatch = $toWatch;
			$this->liked = $liked;
			$this->likedCount = $likedCount;
			$this->disliked = $disliked;
			$this->dislikedCount = $dislikedCount;
		}
		
	}

?>