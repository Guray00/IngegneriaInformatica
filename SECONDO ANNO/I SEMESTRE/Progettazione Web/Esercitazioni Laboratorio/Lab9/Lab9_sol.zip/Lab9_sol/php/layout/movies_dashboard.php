<?php
	require_once __DIR__ . "/../config.php";
    require_once DIR_UTIL . "sessionUtil.php";
	require_once DIR_UTIL . "movieManagerDb.php";	
	require_once DIR_LAYOUT . "messageUtil.php";
	
	function showUserStat($movieId, $userMovieRow){
		echo '<nav id="user_movie_nav_bar_' . $movieId . '">';	
		
		// isWatched nav bar item
		$currentFlag = false; //isWatched flag
		if ($userMovieRow != null AND $userMovieRow['isWatched'] != null AND $userMovieRow['isWatched'] == 1)
			$currentFlag = true;
		echo '<div id="watchedItem_' . $movieId . '" class="nav_movie_item check_img_' . (int)$currentFlag . '" ';
		echo 'onClick="UserMovieNavBarEventHandler.onWatchEvent(' . $movieId . ')">';
		echo '</div>';
			
		// toWatch nav bar item		
		$currentFlag = false; //toWatch flag
		if ($userMovieRow != null AND $userMovieRow['toWatch'] != null AND $userMovieRow['toWatch'] == 1)
				$currentFlag = true;
		echo '<div id="toWatchItem_' . $movieId . '" class="nav_movie_item to_watch_img_' . (int)$currentFlag . '" ';
		echo 'onClick="UserMovieNavBarEventHandler.onToWatchEvent(' . $movieId . ')">';
		echo '</div>';
		
		// like nav bar item
		$currentFlag = false; //like flag
		if ($userMovieRow != null AND $userMovieRow['isLiked'] != null AND $userMovieRow['isLiked'] == 1)
			$currentFlag = true;
		echo '<div id="likeItem_' . $movieId . '" class="nav_movie_item like_img_' . (int)$currentFlag . '" ';
		echo 'onClick="UserMovieNavBarEventHandler.onLikeEvent(' . $movieId . ')">';
		echo '</div>';
		showMovieLikes($movieId);
		
		// dislike nav bar item
		$currentFlag = false; //dislike flag
		if ($userMovieRow != null AND $userMovieRow['isLiked'] != null AND $userMovieRow['isLiked'] == 0)
			$currentFlag = true;
		echo '<div id="dislikeItem_' . $movieId . '" class="nav_movie_item dislike_img_' . (int)$currentFlag . '" ';
		echo 'onClick="UserMovieNavBarEventHandler.onDislikeEvent(' . $movieId . ')">';
		echo '</div>';
		showMovieDislikes($movieId);
		
		echo '</nav>';	
	}
	
	function showMovieLikes($movieId){
		echo '<div id="likeCountItem_' . $movieId . '" class="nav_movie_item stats_user_movie">';
		$numLikesResult = getMovieLikes($movieId);
		$numLikesRow = $numLikesResult->fetch_assoc();
		echo '(' . $numLikesRow['num'] . ')';
		echo '</div>';		
	}
	
	function showMovieDislikes($movieId){
		echo '<div id="dislikeCountItem_' . $movieId . '" class="nav_movie_item stats_user_movie">';
		$numDislikesResult = getMovieDislikes($movieId);
		$numDislikesRow = $numDislikesResult->fetch_assoc();
		echo '(' . $numDislikesRow['num'] . ')';
		echo '</div>';		
	}
	
	function showDetailedMovie($result){
		$numMovies = mysqli_num_rows($result);
		if($numMovies != 1) { 
			showError();	
			return;
		}
		
		$movieRow = $result->fetch_assoc();
		echo '<div id="detailed_movie_tab">';
		echo '<div id="left">';
		echo '<div id="detailed_poster">';
		if($movieRow['poster'] == "N/A"){
			echo '<img src="http://entertainment.ie/movie_trailers/trailers/flash/posterPlaceholder.jpg">'; 
		} else {
			echo '<img src="' . $movieRow['poster'] . '" alt="poster">';
		}
		echo '</div>';
		
		echo '<div class="content_movie_wrapper">';
		echo '<span class="title_stats">Released</span>: ' . $movieRow['released'] . '<br>';
		echo '<span class="title_stats">Rated</span>: ' . $movieRow['rated'] . '<br>';
		echo '<span class="title_stats">Runtime</span>: ' . $movieRow['runtime'] . '<br>';
		echo '<span class="title_stats">Genre</span>: ' . $movieRow['genre'] . '<br>';
		echo '</div>';		
		echo '</div>';
		echo '<div id="main">';
		$date = DateTime::createFromFormat("Y-m-d", $movieRow['released']);
		echo '<h1>' . $movieRow['title'] . '</h1><h3>(' . $date->format("Y") . ')</h3>';
		
		$userMovieStatResult = getUserMovieStat($_SESSION['userId'], $movieRow['movieId']);
		$userMovieRow = null;
		if (mysqli_num_rows($userMovieStatResult) == 1)
			$userMovieRow = $userMovieStatResult->fetch_assoc();
			
		showUserStat($movieRow['movieId'], $userMovieRow);
		
		echo '<div class="content_movie_wrapper">';
		echo '<h2>Overview:</h2>';
		echo $movieRow['plot'] . '<br>';
		echo '</div>';
		echo '<div class="content_movie_wrapper">';
		echo '<h2>Staff:</h2>';
		echo '<span><span class="title_stats">Director</span>: ' . $movieRow['director'] . '</span><br>';
		echo '<span><span class="title_stats">Writer</span>: ' . $movieRow['writer'] . '</span><br>';
		echo '<span><span class="title_stats">Cast</span>: ' . $movieRow['actors'] . '</span><br>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}
?>