<?php
	$dbHostname = "localhost";
	$dbUsername = "root"; 
	$dbPassword = ""; 
	$dbName = "track_my_movies";	
?>