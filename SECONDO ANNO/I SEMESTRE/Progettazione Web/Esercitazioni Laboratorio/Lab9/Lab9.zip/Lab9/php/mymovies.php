<?php
	session_start();
    require_once __DIR__ . "/config.php";
    include DIR_UTIL . "sessionUtil.php";

    if (!isLogged()){
		    header('Location: ./../index.php');
		    exit;
    }	
?>
<!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8"> 
    	<meta name = "author" content = "PWEB">
    	<meta name = "keywords" content = "game">
   	 	<link rel="shortcut icon" type="image/x-icon" href="./../css/img/favicon.ico" />
		<link rel="stylesheet" href="./../css/trackMyMovies_menu.css" type="text/css" media="screen">
		<link rel="stylesheet" href="./../css/trackMyMovies.css" type="text/css" media="screen">
		<script type="text/javascript" src="./../js/ajax/ajaxManager.js"></script>	
		<script type="text/javascript" src="./../js/ajax/userMovieNavBarEventHandler.js"></script>	
		<script type="text/javascript" src="./../js/ajax/MovieLoader.js"></script>
		<script type="text/javascript" src="./../js/ajax/MovieDashboard.js"></script>		
		<title>Track My Movies - Movie</title>
	</head>
	<?php
		$searchType = MY_MOVIES_SEARCH;
		echo '<body onload="MovieLoader.init(); ';
		echo 'MovieLoader.loadData(' . $searchType . ')">'; 
		
			include DIR_LAYOUT . "menu.php";
			
	?>	
				
		<script type="text/javascript">
			document.getElementById("myMoviesImgLink").setAttribute("class", "menu_item_img my_movies_img_1");
			document.getElementById("myMoviesLabelLink").setAttribute("class", "gold_label");
		</script>	
			
	<?php	
					
			echo '<div id="content">';
		
			include DIR_LAYOUT . "navigation_page.php";
		
			echo '<section id="movieDashboard" class="movie_dashboard"></section>'; // Fill dinamically with Ajax Request 
			
			include DIR_LAYOUT . "navigation_page.php";
			
			echo '</div>';
	?>
	</body>
</html>