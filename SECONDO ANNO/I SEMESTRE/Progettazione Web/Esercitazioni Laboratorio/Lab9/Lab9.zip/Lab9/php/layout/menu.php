<div id="menu">
	<div id="menu_home" class="menu_single_section">
		<a href="./../php/homeLatest.php">
			<div class="logo_img"></div>	
		</a>
		<?php
			echo $_SESSION['username'];
		?>
	</div>
	
	<div id="user_menu" class="menu_single_section">
	 	<ul>
	 		<li>
				<a href="">
					<span class="menu_item_img profile_img"></span>
					<span>Profile</span>
				</a>
	 		<li>
	 			<a href="">
					<div class="menu_item_img settings_img"></div>	
					<span>Settings</span>
				</a>
	 	</ul>
	</div>
	<div id="movie_menu" class="menu_single_section">
		<ul>	
			<li>
				<a href="./toWatch.php">
					<div id="toWatchImgLink" class="menu_item_img to_watch_img_0"></div>	
					<span id="toWatchLabelLink" class="normal_label">To-Watch</span>
				</a>
	 		<li>
	 			<a href="./mymovies.php">
					<div id="myMoviesImgLink" class="menu_item_img my_movies_img_0"></div>	
					<span id="myMoviesLabelLink" class="normal_label">My Movies</span>
				</a>
			<li>
	 			<a href="./explore.php">
					<div id="exploreImgLink" class="menu_item_img explore_img_0"></div>	
					<span id="exploreLabelLink" class="normal_label">Explore</span>
				</a>	
		</ul>
	</div>
	<div id="sign_out_menu" class="menu_single_section">
		<ul>	
			<li>
				<a href="./logout.php">
					<div class="menu_item_img sign_out_img"></div>	
					<span>Sign out</span>
				</a>
		</ul>
	</div>
</div>