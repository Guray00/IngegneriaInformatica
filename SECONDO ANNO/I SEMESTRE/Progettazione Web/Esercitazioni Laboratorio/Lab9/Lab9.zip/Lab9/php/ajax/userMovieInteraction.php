<?php
	session_start();
	
	require_once __DIR__ . "/../config.php";
	require_once DIR_UTIL . "movieManagerDb.php";
	require_once DIR_AJAX_UTIL . "AjaxResponse.php";
	
	$response = new AjaxResponse();
	$message = "OK";
	
	$movieId = null;
	if (!isset($_GET['movieId'])){
		echo json_encode($response);
		return;
	}		
	
	$movieId = $_GET['movieId'];
		
	$currentFlag = 0;	
	// check isWatched flag
	if (isset($_GET['isWatched'])){
		$currentFlag = $_GET['isWatched'];
		if (setWatchedUserStat($movieId, $currentFlag))
			$response = setCorrectResponse($movieId, $message);
				
		echo json_encode($response);
		return;
	}	
		
	// check toWatch flag
	if (isset($_GET['toWatch'])){
		$currentFlag = $_GET['toWatch'];
		if (setToWatchUserStat($movieId, $currentFlag))
			$response = setCorrectResponse($movieId, $message);
		
		echo json_encode($response);
		return;
	}	

	// check like flag		
	if (isset($_GET['like'])){
		$currentFlag = $_GET['like'];
		if (setLikeUserStat($movieId, $currentFlag))
			$response = setCorrectResponse($movieId, $message);
			
		echo json_encode($response);
		return;
	}	

	// check dislike flag		
	if (isset($_GET['dislike'])){
		$currentFlag = $_GET['dislike'];
		if (setDislikeUserStat($movieId, $currentFlag))
			$response = setCorrectResponse($movieId, $message);
				
		echo json_encode($response);
		return;
	}		
	
	function isUserMovieStatInDb($movieId, $userId){
		$result = getUserMovieStat($userId, $movieId);
		$numRows = $result->num_rows;
		return $numRows === 1;
	}
	
	function setWatchedUserStat($movieId, $isWatchedFlag){
		if(isUserMovieStatInDb($movieId, $_SESSION['userId']))
			$result = updateWatchedUserMovieStat($movieId, $_SESSION['userId'], $isWatchedFlag);
		else
			$result = insertWatchedUserMovieStat($movieId, $_SESSION['userId'], $isWatchedFlag);
		
		return $result;
	}
	
	function setToWatchUserStat($movieId, $toWatchFlag){
		if(isUserMovieStatInDb($movieId, $_SESSION['userId'])) 
			$result = updateToWatchUserMovieStat($movieId, $_SESSION['userId'], $toWatchFlag);
		else
			$result = insertToWatchUserMovieStat($movieId, $_SESSION['userId'], $toWatchFlag);
		
		return $result;
	}
	
	function setLikeUserStat($movieId, $isLiked){
		if (!$isLiked) // if isLiked flag is equal to 0 (user remove the like flag)
			$isLiked = null;
					
		return setLikeDislikeUserStat($movieId, $isLiked);
	}
	
	function setDislikeUserStat($movieId, $isDisliked){
		if (!$isDisliked) // if isDisiked flag is equal to 0 (user remove the dislike flag)
			$isDisliked = null;
		else
			$isDisliked = 0; // In the DB the 'isLiked' column is set to: NUll -> no user preferences; 0 -> dislike; 1 -> like
	
		return setLikeDislikeUserStat($movieId, $isDisliked);
	}
	
	function setLikeDislikeUserStat($movieId, $preference){
		if(isUserMovieStatInDb($movieId, $_SESSION['userId']))
			$result = updateLikeDislikeUserMovieStat($movieId, $_SESSION['userId'], $preference);
		else
			$result = insertLikeDislikeUserMovieStat($movieId, $_SESSION['userId'], $preference);
	
		return $result;
	}
	
	function setCorrectResponse($movieId, $message){
		$response = new AjaxResponse("0", $message);
		$result = getUserMovieStat($_SESSION['userId'], $movieId);
		$userMovieRow = $result->fetch_assoc();
		
		// Set UserStat class
		$userStat = new UserStat();
		$userStat->watched = $userMovieRow['isWatched'];
		$userStat->toWatch = $userMovieRow['toWatch'];
		$userStat->liked = ($userMovieRow['isLiked'] === null)? 0 : (int)$userMovieRow['isLiked'];
		$userStat->disliked = ($userMovieRow['isLiked'] === null)? 0 : (int)!$userMovieRow['isLiked'];
		$likedCountResult = getMovieLikes($movieId);
		$likedCountRow = $likedCountResult->fetch_assoc();
		$userStat->likedCount = $likedCountRow['num'];
		$dislikedCountResult = getMovieDislikes($movieId);
		$dislikedCountRow = $dislikedCountResult->fetch_assoc();
		$userStat->dislikedCount = $dislikedCountRow['num'];
		
		// Set Movie class
		$movie = new Movie();
		$movie->movieId = $movieId;

		// Set MovieUserStat class		
		$movieUserStat = new MovieUserStat($movie, $userStat);
		
		$response->data = $movieUserStat;
		
		return $response;
	}

?>
