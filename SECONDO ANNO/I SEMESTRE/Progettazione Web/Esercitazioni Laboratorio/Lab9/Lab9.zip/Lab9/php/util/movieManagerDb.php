<?php
	require_once __DIR__ . "/../config.php";
    require_once DIR_UTIL . "trackMyMoviesDbManager.php"; //includes Database Class
 	
	function getLatestMovies($offset, $numRecord){  
		global $trackMyMoviesDb;
//		$today = date('Y-m-d');
		$today = DateTime::createFromFormat('m-d-Y', '12-01-2014')->format('Y-m-d');
		$today = $trackMyMoviesDb->sqlInjectionFilter($today);
		$offset = $trackMyMoviesDb->sqlInjectionFilter($offset);
		$numRecord = $trackMyMoviesDb->sqlInjectionFilter($numRecord);
		$queryText = 'SELECT * '
						. 'FROM movie '
						. 'WHERE released <= \'' . $today . '\' '
						. 'ORDER BY released DESC '
						. 'LIMIT ' . $offset . ',' . $numRecord;
						
		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; ;
	}

	function getMovieById($movieId){
		global $trackMyMoviesDb;
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$queryText = 'SELECT * '
						. 'FROM movie '
						. 'WHERE movieId = \'' . $movieId . '\'';

		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	
	function getUpcomingMovies($offset, $numRecord){
		global $trackMyMoviesDb;
//		$today = date('Y-m-d');
		$today = DateTime::createFromFormat('m-d-Y', '12-01-2014')->format('Y-m-d');
		$today = $trackMyMoviesDb->sqlInjectionFilter($today);
		$offset = $trackMyMoviesDb->sqlInjectionFilter($offset);
		$numRecord = $trackMyMoviesDb->sqlInjectionFilter($numRecord);
		$queryText = 'SELECT * '
					. 'FROM movie '
					. 'WHERE released > \'' . $today . '\' '
					. 'ORDER BY released ASC '
					. 'LIMIT ' . $offset . ',' . $numRecord;
					
		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}

	function getUserMovieStat($userId, $movieId){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
 		$queryText = 'SELECT * '
					. 'FROM user_movie '
					. 'WHERE userId = \'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}	
	
	function getToWatchMovies($userId, $offset, $numRecord){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
 		$offset = $trackMyMoviesDb->sqlInjectionFilter($offset);
		$numRecord = $trackMyMoviesDb->sqlInjectionFilter($numRecord);
		$queryText = 'SELECT m.* '
					. 'FROM user_movie um JOIN movie m ON um.movieId = m.movieId '
					. 'WHERE um.userId = \'' . $userId . '\' AND um.toWatch = 1 '
					. 'LIMIT ' . $offset . ',' . $numRecord ;

 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function getViewedMovies($userId, $offset, $numRecord){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
 		$offset = $trackMyMoviesDb->sqlInjectionFilter($offset);
		$numRecord = $trackMyMoviesDb->sqlInjectionFilter($numRecord);
		$queryText = 'SELECT m.* '
					. 'FROM user_movie um JOIN movie m ON um.movieId = m.movieId '
					. 'WHERE um.userId = \'' . $userId . '\' AND um.isWatched = 1 '
					. 'LIMIT ' . $offset . ',' . $numRecord ;
 		
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function getMovieLikesOrDislikes($movieId, $like_dislake){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$like_dislake = $trackMyMoviesDb->sqlInjectionFilter($like_dislake);
 		$queryText = 'SELECT COUNT(*) as num '
					. 'FROM user_movie '
					. 'WHERE movieId = \'' . $movieId . '\' AND isLiked = ' . $like_dislake;
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function getMovieLikes($movieId){
 		return getMovieLikesOrDislikes($movieId, 1);
	}
	
	function getMovieDislikes($movieId){
		 return getMovieLikesOrDislikes($movieId, 0);
	}
	
	function insertWatchedUserMovieStat($movieId, $userId, $isWatchedFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
 		$isWatchedFlag = $trackMyMoviesDb->sqlInjectionFilter($isWatchedFlag);
		$queryText = 'INSERT INTO user_movie (id, userId, movieId, isWatched, toWatch, isLiked) ' 
						. 'VALUES (NULL, \'' . $userId . '\', \'' . $movieId . '\', ' . $isWatchedFlag . ', 0, NULL)';
 	
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function updateWatchedUserMovieStat($movieId, $userId, $isWatchedFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
 		$isWatchedFlag = $trackMyMoviesDb->sqlInjectionFilter($isWatchedFlag);
 		$queryText = 'UPDATE user_movie '
					. 'SET isWatched=' . $isWatchedFlag . ', toWatch=0, isLiked=null '
					. 'WHERE userId=\'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 		
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function insertToWatchUserMovieStat($movieId, $userId, $toWatchFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$toWatchFlag = $trackMyMoviesDb->sqlInjectionFilter($toWatchFlag);
		$queryText = 'INSERT INTO user_movie (id, userId, movieId, isWatched, toWatch, isLiked) ' 
						. 'VALUES (NULL, \'' . $userId . '\', \'' . $movieId . '\', 0, ' . $toWatchFlag . ', NULL)';
 	
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function updateToWatchUserMovieStat($movieId, $userId, $toWatchFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$toWatchFlag = $trackMyMoviesDb->sqlInjectionFilter($toWatchFlag);
		$queryText = 'UPDATE user_movie '
					. 'SET isWatched=0, toWatch=' . $toWatchFlag . ', isLiked=null '
					. 'WHERE userId=\'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 	
 		return $trackMyMoviesDb->performQuery($queryText);
	}
	
	function insertLikeDislikeUserMovieStat($movieId, $userId, $preference){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$preference = $trackMyMoviesDb->sqlInjectionFilter($preference);
		$queryText = 'INSERT INTO user_movie (id, userId, movieId, isWatched, toWatch, isLiked) ' 
						. 'VALUES (NULL, \'' . $userId . '\', \'' . $movieId . '\', 1, 0, ' . $preference . ')';
 		
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function updateLikeDislikeUserMovieStat($movieId, $userId, $preference){
		if ($preference === null)
			$preference = "null";
			
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$preference = $trackMyMoviesDb->sqlInjectionFilter($preference);
		$queryText = 'UPDATE user_movie '
					. 'SET isWatched=1, toWatch=0, isLiked= ' . $preference . ' '
					. 'WHERE userId = \'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 	
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
?>
