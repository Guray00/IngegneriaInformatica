// marge.js


// Contiene i valore dell'attributo class 
// in modo da indicare in quale stato si trova lo specifico elemento
STYLE_TYPE = ["error", "warning", ""]; 

function showValue(newVal) {
	document.mio_form.votoDisplay.value = newVal;
}

// La funzione 'detail' aggiunge i dettagli di un evento
// all'elemento area di testo "area_testo" presente nel form
// "mio_form". Viene invocata da vari gestori evento.

function detail(field, eventName) {
    var eventTextArea = document.mio_form.area_testo;
    var fieldName = field.name;
	var newValue = " ";
    if ((field.type == "select-one") || (field.type == "select-multiple")){
        for(var i = 0; i < field.options.length; i++)
            if (field.options[i].selected) 
                newValue += field.options[i].value + " ";
    }
    else 
    	if (field.type == "textarea") 
    		newValue = "...";
		else 
			if (field.type == "fieldset") newValue = "!";
   		 else 
   		 	newValue = field.value;
    
    var message = eventName + ": " + fieldName + ' (' + newValue + ')\n';
	eventTextArea.value += message;
}

function setStyle(field, styTypeIndex){
	var parent = field.parentNode;
	parent.className = STYLE_TYPE[styTypeIndex];
	field.className = STYLE_TYPE[styTypeIndex];
}

function invalidHandler(evt){
	// evt.preventDefault();
	var field = evt.target;
	var validity = field.validity;
	// field.setCustomValidity("");
	if (validity.valueMissing) {
		setStyle(field, 1);
		// field.setCustomValidity("Il campo " + field.name + " non può essere vuoto. Per favore inserisci un valore corretto!");		
		return;
	}
	
	if (validity.patternMismatch || validity.typeMismatch){
		setStyle(field, 0);		
		return;
	}
}

function checkConstraint(evt){
	var field = evt.target;
	// field.setCustomValidity("");
	if (!field.checkValidity()){
		invalidHandler(evt);
		return;
	}
	
	setStyle(field, 2);
}

function refreshStyle(form){
	 for(var i = 0; i < form.elements.length; i++) {
	 	var field = form.elements[i];
	 	setStyle(field, 2);
	 }
}

function send(form){
	 var formOk = true;

	 alert("Form Inviata");
	 return formOk;
}

// La funzione aggiungi_gestori installa un insieme di gestori di eventi su
// ogni elemento di un form f, senza controllare se l'elemento supporta
// tutti questi tipi di eventi

function addHandlers(form) {
    var clickHandler		= new Function("detail(this, 'Click')");
    var changeHandler   	= new Function("detail(this, 'Change')");
    var focusHandler    	= new Function("detail(this, 'Focus')");
    var blurHandler     	= new Function("detail(this, 'Blur')");
    var selectHandler   	= new Function("detail(this, 'Select')");
	var dblclickHandler 	= new Function("detail(this, 'dblClick')");
	var invalidHandlerDetail  = new Function("detail(this, 'Invalid')");
	     
    for(var i = 0; i < form.elements.length; i++) {
        var e = form.elements[i];
        e.onclick    = clickHandler;
        e.onchange   = changeHandler;
        e.onfocus    = focusHandler;
        e.onblur     = blurHandler;
        // e.addEventListener("blur", checkConstraint, false);
        e.onselect   = selectHandler;
		e.ondblclick = dblclickHandler;
		e.oninvalid  = invalidHandlerDetail;
		e.addEventListener("invalid", invalidHandler, false);
	}

 	// Gestori speciali per i bottoni:
    form.bottone_svuota.onclick = new Function("this.form.area_testo.value=''; detail(this, 'Click');");	
	// form.bottone_sottometti.onclick =  
		// new Function("refreshStyle(document.mio_form); detail(this, 'Click');");
    form.bottone_azzera.onclick = 
        new Function("this.form.reset(); detail(this, 'Click'); refreshStyle(document.mio_form);");

	form.onsubmit = new Function("return send(document.mio_form)");
}
// Attiviamo il form aggiungendo i possibili gestori
addHandlers(document.mio_form);