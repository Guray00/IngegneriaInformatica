// orologio.js

var MONTH = [
			"gennaio",			"febbraio",        "marzo",
			"aprile",       "maggio",          "giugno",
			"luglio", 			"agosto",     		 "settembre",
			"ottobre", 			"novembre",   		 "dicembre"
];

var DAY = [
			"domenica",	 		"luned\u00EC",					 "marted\u00EC",
			"mercoled\u00EC",		"gioved\u00EC",				 "venerd\u00EC'",
			"sabato"
];

// sistema lo stile della casella di testo "orologio"
var s = document.mio_form.orologio.style;
s.borderStyle = "none";
s.fontFamily  = "monospace";
s.fontWeight  = "bolder";
s.fontSize    = "x-large";

// Visualizza l'ora nella casella di testo "orologio"
function clock() {
    var now = new Date();		// istante corrente

	var m = now.getMonth();		// 0 = gennaio,  1 = febbraio, ...
	var d = now.getDate();		// 1 = primo del mese,...
	var g = now.getDay();		// 0 = domenica, 1 = luned�, ...
	var a = now.getFullYear();					  
	var time = now.toLocaleTimeString();
	/****************************************************************************
	var o = adesso.getHours();          // 0 = mezzanotte, ...
    var p = adesso.getMinutes();            
    var s = adesso.getSeconds();
    ******************************************************************************/
    var dateValue = "Oggi \u00e8 " + DAY[g] + ' ' + d + ' ' + MONTH[m] +
		    ' ' + a + ", ore " + time;
		    
    document.mio_form.orologio.value = dateValue; // aggiorna il testo
}
