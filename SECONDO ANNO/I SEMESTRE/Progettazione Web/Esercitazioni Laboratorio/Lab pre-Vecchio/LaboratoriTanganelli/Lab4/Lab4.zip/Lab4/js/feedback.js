// sms.js

var MAX_CHAR = document.mio_form.contatore.value; // inizializzato la prima volta
document.mio_form.messaggio_testo.onmouseover = 
function() {
    var feedbackAreaTesto = document.mio_form.messaggio_testo;
		feedbackAreaTesto.style.backgroundColor = "blue";
		feedbackAreaTesto.style.color = "white";
}

document.mio_form.messaggio_testo.onmouseout = 
function() {
    var feedbackAreaTesto = document.mio_form.messaggio_testo;
		feedbackAreaTesto.style.backgroundColor = "white";
		feedbackAreaTesto.style.color = "black";
}

function update(form) {
    if (form.messaggio_testo.value.length > MAX_CHAR) {
        form.messaggio_testo.value = form.messaggio_testo.value.substring(0, MAX_CHAR);
        form.contatore.value = 0;
		}
		else {
			  form.contatore.value = MAX_CHAR - form.messaggio_testo.value.length;
		}
}
