var game1 = null;
var game2 = null;

function begin(){
	game1 = new Game(document.getElementById('playgroundWrapper_1'));
	game2 = new Game(document.getElementById('playgroundWrapper_2'));
}

function Game(playgroundWrapper){
	if (playgroundWrapper.childNodes.length != 5)
		return;
	
	var playground = playgroundWrapper.childNodes[1];
	playground.addEventListener('click', this.explode.bind(this), false);
	playground.addEventListener('mousemove', this.playerMoveHandler.bind(this), false);
	playground.addEventListener('mouseenter', this.start.bind(this), false);
	playground.addEventListener('mouseleave', this.pause.bind(this), false);
	
	this.gameStateFlag = new GameStateFlag();
	this.scoreStat = new ScoreStat();
	this.player = new Player(-100, -100, PLAYER_RADIUS);
	this.prey = null;
	this.balls = new Array();
	this.playground = new Playground(playground);
	this.sketcher = new Sketcher(playgroundWrapper);
	
	this.sketcher.updateStat(this.scoreStat);
}

Game.prototype.clock = 
	function(){
		for (var i = 0; i < this.balls.length; i++) {
 			this.balls[i].move(this.playground);
 			this.sketcher.drawBall(this.balls[i], i, this.gameStateFlag);
			if (this.balls[i].isPlayerHit(this.player)) {
 				if (this.balls[i].type === 0) {
 					this.gameover();
				} else {
					if (!this.gameStateFlag.isTransparencyActive())
						this.gameStateFlag.activateTransparency();
				}
			}
		}
	}	
	
Game.prototype.gameover = 
	function(){
		this.sketcher.createPopup(this.scoreStat);
		this.sketcher.removeAll();
		this.balls = new Array();
		this.gameStateFlag.reset();	
 		this.scoreStat.updateScore();
 		this.sketcher.updateStat(this.scoreStat);
	}

Game.prototype.pause = 
	function(evt){
		this.gameStateFlag.pause();
		this.gameStateFlag.removeTransparency();
		
	}
	
Game.prototype.start = 
	function(evt){
		if (this.prey === null)
			this.createPrey();

		this.sketcher.drawPrey(this.prey);
		if (this.gameStateFlag.isPause())
			this.gameStateFlag.start(this.clock.bind(this));
				
	}

Game.prototype.playerMoveHandler = 
	function(evt){	
		if (this.gameStateFlag.isPause())
			return; 
			
		this.player.move(evt.clientX, evt.clientY, this.playground);
		this.sketcher.drawPlayer(this.player);	
		 		
 		if (this.prey.isPlayerHit(this.player)) {
 		 	this.scoreStat.incrementScore(this.gameStateFlag.isTransparencyActive()? 2 : 1);
 		 	this.sketcher.updateScore(this.scoreStat.currentScore);
			this.createPrey();
			this.sketcher.drawPrey(this.prey);
			this.createBall();
 		}
	}
	
Game.prototype.explode =
	function(evt){
		for (var i = 0; i < this.balls.length; i++) {
			var currentBall = this.balls[i];
			var squareDistance = MathUtil.squareDistance(currentBall.point, this.player.point);
	
			currentBall.stepX += (currentBall.point.x - this.player.point.x) / squareDistance * (this.playground.width/2);
			currentBall.stepY += (currentBall.point.y - this.player.point.y) / squareDistance * (this.playground.height/2);
	 	}
	}
	
Game.prototype.createPrey = 
	function(){
		var x, y;	
		x = Math.round(Math.random() * (this.playground.width - PREY_HALF * 2) + PREY_HALF + this.playground.offsetLeft);
		y = Math.round(Math.random() * (this.playground.height- PREY_HALF * 2) + PREY_HALF + this.playground.offsetTop);
		this.prey = new SquarePrey(x, y, PREY_HALF);
	}
		
Game.prototype.createBall =
	function(){
		var x, y;
		var index = this.balls.length;
	
		x = Math.round(Math.random() * (this.playground.width - BALL_RADIUS * 2) + BALL_RADIUS + this.playground.offsetLeft);
		y = Math.round(Math.random() * (this.playground.height- BALL_RADIUS * 2) + BALL_RADIUS + this.playground.offsetTop);
	
		var ball = new Ball(x, y, 
							Math.random() * NEXT_STEP_FACTOR - NEXT_STEP_FACTOR/2, 
							Math.random() * NEXT_STEP_FACTOR - NEXT_STEP_FACTOR/2,
							BALL_RADIUS);
	
		this.balls.push(ball);
		this.sketcher.drawBall(ball, index, this.gameStateFlag);
	}
 