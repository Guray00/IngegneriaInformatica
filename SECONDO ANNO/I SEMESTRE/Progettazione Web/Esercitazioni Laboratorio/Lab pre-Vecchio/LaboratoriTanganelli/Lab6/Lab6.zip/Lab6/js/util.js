/***************************
		 Constants
****************************/
var CLOCK_INTERVAL = 20; 
var PLAYER_RADIUS = 10;
var PREY_HALF = 10;
var BALL_RADIUS = 5;
var NEXT_STEP_FACTOR = 5;
var MIN_PREY_PLAYER_DISTANCE_SQUARE = 484;

var TRASPARENCY_PERIOD = 2000;

/***************************
		 Util
****************************/
function Point(x, y){
	this.x = x;
	this.y = y;
}

function MathUtil(){}

MathUtil.distance =
	function(point1, point2){
		return Math.sqrt(MathUtil.squareDistance(point1, point2))
	}
	
MathUtil.squareDistance =
	function(point1, point2){
		return ((point1.x - point2.x) * (point1.x - point2.x) 
				+ (point1.y - point2.y) * (point1.y - point2.y));
	}
	

function checkLocalStorageSupport() { 
	return (window.localStorage);
}