var PREY_ID = 'prey';
var PLAYER_ID = 'player';
var BALL_BASE_ID = ''; // + index of the array

function Sketcher(playgroundWrapper){
	this.playground = playgroundWrapper.childNodes[1];
	this.gameStat =  playgroundWrapper.childNodes[3];
	this.baseElementsId = playgroundWrapper.id + '_';
}

Sketcher.prototype.drawPrey =
	function(prey){
		var preyNode = document.getElementById(this.baseElementsId + PREY_ID);
		if (preyNode === null){
			preyNode = document.createElement('div');
			preyNode.setAttribute('id', this.baseElementsId + PREY_ID);
			preyNode.setAttribute('class', PREY_ID);
			this.playground.appendChild(preyNode);
		}
	
		preyNode.style.left = (prey.point.x - prey.halfLength)+ 'px';
		preyNode.style.top = (prey.point.y - prey.halfLength) + 'px';
	}

Sketcher.prototype.drawPlayer =
	function(player){
		var playerNode = document.getElementById(this.baseElementsId + PLAYER_ID);
		if (playerNode === null){
			playerNode = document.createElement('div');
			playerNode.setAttribute('id', this.baseElementsId + PLAYER_ID);
			playerNode.setAttribute('class', PLAYER_ID);
			this.playground.appendChild(playerNode);
		}
	
		playerNode.style.left = (player.point.x -  player.radius)+ 'px';
		playerNode.style.top = (player.point.y - player.radius) + 'px';
	}

Sketcher.prototype.drawBall =
	function(ball, indexBall, gameStateFlag){
 		var ballNodeId = this.baseElementsId + BALL_BASE_ID + indexBall;
		var ballNode = document.getElementById(this.baseElementsId + ballNodeId);
		if (ballNode === null){
			ballNode = document.createElement('div');
			ballNode.id = this.baseElementsId + ballNodeId;
			ballNode.setAttribute('class', 'ball');
			ballNode.style.backgroundImage = "url('./css/img/ball" + ball.type + ".png')";
			this.playground.appendChild(ballNode);
		}
	
		ballNode.style.left = (ball.point.x - ball.radius) + 'px';
		ballNode.style.top = (ball.point.y - ball.radius) + 'px';
		
		if (gameStateFlag.isTransparencyActive()) {
			var now = Date.now();
			var alphaTimeMeasure = (now - gameStateFlag.lastTransparencyBallTime) / TRASPARENCY_PERIOD;

			if (alphaTimeMeasure >= 1) {
				gameStateFlag.removeTransparency();
				alphaTimeMeasure = 1;
			}
 
 			ballNode.style.opacity = (1 - 2*alphaTimeMeasure)*(1 - 2*alphaTimeMeasure);
		}
		else{
			ballNode.style.opacity = 1.0;
		}
	
	}

Sketcher.prototype.updateStat =
	function(scoreStat) {
		var gameStats = this.gameStat.getElementsByTagName('span');
		gameStats[0].firstChild.nodeValue = scoreStat.currentScore;
 		gameStats[1].firstChild.nodeValue = scoreStat.bestScore;
 		gameStats[2].firstChild.nodeValue = scoreStat.playCount;
	}

Sketcher.prototype.updateScore =
	function(currentScore) {
		var gameStats = this.gameStat.getElementsByTagName('span');
		gameStats[0].firstChild.nodeValue = currentScore;
	}	

Sketcher.prototype.removeAll =
	function() {
		var elements = this.playground.getElementsByTagName('div');
		// for (var i = 0; i < elements.length; i++) Wrong solution
		for (var i = elements.length-1; i >=0; i--)
			this.playground.removeChild(elements[i]);

	}
	
Sketcher.prototype.createPopup =
	function(scoreStat){
		createPopup(scoreStat);
	}
