var GAME_ID = 'game'

function ScoreStat() {
	this.playCount = 1;
	this.bestScore = 0;
	this.currentScore = 0;
	
	this.load();
}

ScoreStat.prototype.updateScore = 
	function(){
		if (this.bestScore < this.currentScore){
			this.bestScore = this.currentScore;
			this.save();
		}
 		this.currentScore = 0;
 		this.playCount++;
	}
	
ScoreStat.prototype.incrementScore = 
	function(valueToAdd){
		this.currentScore += valueToAdd;
	}

ScoreStat.prototype.save =
	function(){
		if (!checkLocalStorageSupport())
			return;
		
		window.localStorage.setItem(GAME_ID, this.bestScore);
	}

ScoreStat.prototype.load =
	function(){
		if (!checkLocalStorageSupport())
			return;
		
		var bestScore = window.localStorage.getItem(GAME_ID);
		if (bestScore !== null)
			this.bestScore = bestScore;
			
	}
	
	
function resetMaxScore(){
	if (!checkLocalStorageSupport())
			return;
			
	window.localStorage.setItem(GAME_ID, 0);
	location.reload();
}