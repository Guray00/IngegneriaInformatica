function GameStateFlag() {
	this.gameTimer = null;
	this.lastTransparencyBallTime = -1;
}

GameStateFlag.prototype.start = 
	function(clockFuction){
		if (this.gameTimer === null)
			this.gameTimer = setInterval(clockFuction, CLOCK_INTERVAL);
	}

GameStateFlag.prototype.pause = 
	function(){
		clearInterval(this.gameTimer); 
		this.gameTimer = null;
	}
	
GameStateFlag.prototype.isPause =
	function(){
		return this.gameTimer === null;
	}
	
GameStateFlag.prototype.activateTransparency = 
	function(){
		this.lastTransparencyBallTime = Date.now();
	}

GameStateFlag.prototype.removeTransparency = 
	function(){
		this.lastTransparencyBallTime = -1;
	}

GameStateFlag.prototype.isTransparencyActive = 
	function(){
		return this.lastTransparencyBallTime !== -1;
	}
	
GameStateFlag.prototype.reset =
	function(){
		this.removeTransparency();
		this.pause();
	}
