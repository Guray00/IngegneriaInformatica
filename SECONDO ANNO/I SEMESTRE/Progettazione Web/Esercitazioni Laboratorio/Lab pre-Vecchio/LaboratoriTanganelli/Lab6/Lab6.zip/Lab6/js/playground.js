function Playground(playground) {
	this.offsetLeft = playground.offsetLeft;
	this.offsetTop = playground.offsetTop;
	this.width = parseInt(playground.style.width);
	this.height = parseInt(playground.style.height);
}