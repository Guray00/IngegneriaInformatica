var PLAYGROUND_WIDTH;
var PLAYGROUND_HEIGHT;

var BALL_RADIUS = 5;
var PLAYER_RADIUS = 10;
var PREY_HALF = 10;

// Cache values
var MIN_BALL_PLAYER_DISTANCE = 15;
var MIN_BALL_PLAYER_DISTANCE_SQUARE = 225; // Cache for the MIN_BALL_PLAYER_DISTANCE square
var MIN_PREY_PLAYER_DISTANCE = 20;
var MIN_SQUARE_PREY_PLAYER_DISTANCE_SQUARE = 484; // Cache for the MIN_PREY_PLAYER_DISTANCE 
var MIN_BALL_PREY_PLAYER_DISTANCE_SQUARE = 400;

var gameTimer = null;
var ballPreyTimeout = null;
var playground = null;
var playgroundOffsetX = null;
var playgroundOffsetY = null;

// player position cache
var playerX = -100;
var playerY = -100; 
// square position cache
var preyX = -100;
var preyY = -100;
var preyType = -1; // 0: Square; 1: Ball

// our ball object holder
var balls = new Array();
var NEXT_STEP_FACTOR = 5;
var MAX_EXPLODE_COUNT = 3;

var playCount = 1;
var currentScore = 0;
var bestScore = 0;

var lastTransparencyBallTime = -1;
var availableExplodeAbility = MAX_EXPLODE_COUNT;

function begin(){
	createSpecialAbilityImages(document.getElementById('playgroundWrapper'));
	
	playground = document.getElementById('playground');
	
	PLAYGROUND_WIDTH = parseInt(playground.style.width);
	PLAYGROUND_HEIGHT = parseInt(playground.style.height);
	
	playground.onclick = explode;
	playground.onmouseenter = start;
	playground.onmouseleave = pause;
	playground.onmousemove = playerMoveHandler;
	
	createPrey();
}

function createSpecialAbilityImages(playgroundWrapper){
	var specialAbilitiesElement = playgroundWrapper.childNodes[1];
	for(var i = 0; i < MAX_EXPLODE_COUNT; i++){
		var img = new Image();
		img.src = './css/img/explosion.png';
		img.alt = 'special ability number ' + (i+1);
		specialAbilitiesElement.appendChild(img);
	}
}

function clock() {
	for (var i = 0; i < balls.length; i++) {
 		moveBall(balls[i]);
 		drawBall(i);
		if (isBallHit(balls[i])) {
 			if (balls[i].type === 0) {
 				gameover();
			} else {
				if (lastTransparencyBallTime === -1)
					lastTransparencyBallTime = Date.now();
			}
		}
	}
}

function createPrey(){
	preyX = Math.round(Math.random() * (PLAYGROUND_WIDTH-PREY_HALF*2) + PREY_HALF + playground.offsetLeft);
	preyY = Math.round(Math.random() * (PLAYGROUND_HEIGHT-PREY_HALF*2) + PREY_HALF + playground.offsetTop);
	preyType = Math.floor(Math.random() + 0.25); // change the value to 0.05 if you want set a probability of 5%
	if (preyType === 1)
		ballPreyTimeout = setTimeout(removePrey, 2000);
}

function removePrey(){
	createPrey();
	drawPrey();
}

function createBall() {
	var x, y;
	var index = balls.length;
	
	x = Math.round(Math.random() * (PLAYGROUND_WIDTH-BALL_RADIUS * 2) + BALL_RADIUS + playground.offsetLeft);
	y = Math.round(Math.random() * (PLAYGROUND_HEIGHT-BALL_RADIUS * 2) + BALL_RADIUS + playground.offsetTop);

	balls.push(new Ball(x, y, 
				Math.random() * NEXT_STEP_FACTOR - NEXT_STEP_FACTOR/2, 
				Math.random() * NEXT_STEP_FACTOR - NEXT_STEP_FACTOR/2));
	drawBall(index);
}
 
function explode(ev) {
	if (availableExplodeAbility <= 0)
		return;
		
	var x = ev.clientX;
	var y = ev.clientY;

	for (var i = 0; i < balls.length; i++) {
		var currentBall = balls[i];
		var distance = ((currentBall.x - x) * (currentBall.x - x) + (currentBall.y - y) * (currentBall.y - y));

		currentBall.stepX += (currentBall.x - x) / distance * (PLAYGROUND_WIDTH/2);
		currentBall.stepY += (currentBall.y - y) / distance * (PLAYGROUND_HEIGHT/2);
 	}
 
 	availableExplodeAbility--;
 	updateSpecialAbilities();
}

function gameover(){	
	removeGameTimer();
	lastTransparencyBallTime = -1;
	availableExplodeAbility = MAX_EXPLODE_COUNT;
	removeBallPreyTimeout();
		
	createPopup();
	removeAll();
	balls = new Array();
	
	if (bestScore < currentScore) {
		bestScore = currentScore;
	}
 	currentScore = 0;
 	playCount++;

 	updateStat();
 
}

function moveBall(ball){
	if (ball.x > (PLAYGROUND_WIDTH-BALL_RADIUS + playground.offsetLeft)) {
		ball.x = PLAYGROUND_WIDTH-BALL_RADIUS + playground.offsetLeft;
		ball.stepX = -ball.stepX;
	} else if (ball.x < (BALL_RADIUS + playground.offsetLeft)) {
		ball.x = BALL_RADIUS + playground.offsetLeft;
		ball.stepX = -ball.stepX;
	}
		
	if (ball.y > (PLAYGROUND_HEIGHT-BALL_RADIUS + playground.offsetTop)) {
		ball.y = PLAYGROUND_HEIGHT-BALL_RADIUS + playground.offsetTop;
		ball.stepY = -ball.stepY;
	} else if (ball.y < (BALL_RADIUS + playground.offsetTop)) {
		ball.y = BALL_RADIUS + playground.offsetTop;
		ball.stepY = -ball.stepY;
	}

	ball.x += ball.stepX;
	ball.y += ball.stepY;
}

function isBallHit(ball){
	return (((playerX - ball.x) * (playerX - ball.x) 
 		   + (playerY - ball.y) * (playerY - ball.y)) <= MIN_BALL_PLAYER_DISTANCE_SQUARE);
}

function isPreyHit(){
	if (preyType === 0)
		return  !(Boolean(Math.floor(Math.abs(playerX - preyX)/MIN_PREY_PLAYER_DISTANCE)
					+ Math.floor(Math.abs(playerY - preyY)/MIN_PREY_PLAYER_DISTANCE)))
					&&
					((playerX - preyX) * (playerX - preyX) + (playerY - preyY) * (playerY - preyY)) 
						<= MIN_SQUARE_PREY_PLAYER_DISTANCE_SQUARE;
	else
		return ((playerX - preyX) * (playerX - preyX) + (playerY - preyY) * (playerY - preyY)) 
						<= MIN_BALL_PREY_PLAYER_DISTANCE_SQUARE;
}

function playerMoveHandler(evt) {
	if (gameTimer === null)
		return;
	
	playerX = evt.clientX;
	playerY = evt.clientY;

	if (playerX > (PLAYGROUND_WIDTH-PLAYER_RADIUS + playground.offsetLeft)) {
		playerX = PLAYGROUND_WIDTH-PLAYER_RADIUS + playground.offsetLeft;
	} else if (playerX < (PLAYER_RADIUS + playground.offsetLeft)) {
		playerX = PLAYER_RADIUS + playground.offsetLeft;
	}
		
	if (playerY > (PLAYGROUND_HEIGHT-PLAYER_RADIUS + playground.offsetTop)) {
		playerY = PLAYGROUND_HEIGHT-PLAYER_RADIUS + playground.offsetTop;
	} else if (playerY < (PLAYER_RADIUS + playground.offsetTop)) {
		playerY = PLAYER_RADIUS + playground.offsetTop;
	}
	
	drawPlayer();	
	
 	if (isPreyHit()) {
 		if (preyType === 0)
 			 currentScore += lastTransparencyBallTime === -1 ? 1 : 2;
 		else{
 			clearTimeout(ballPreyTimeout);
			ballPreyTimeout = null;
 		 	currentScore += 5;
 		 	if (availableExplodeAbility < MAX_EXPLODE_COUNT)
 		 		availableExplodeAbility++;
 		 
 		 	updateSpecialAbilities();
 		}
 		
 		updateStat();

		createPrey();
		drawPrey();
		createBall();
   	}
 
} 	

function start(){
	if (preyType === -1)
		createPrey();
		
	drawPrey();
	updateSpecialAbilities();
	if (gameTimer === null)
		gameTimer = setInterval(clock, 20);
}

function pause(evt){
	removeGameTimer();
	lastTransparencyBallTime = -1;
	if (preyType === 1){
		removeBallPreyTimeout();
		preyType = -1;
	}
}
	
function removeBallPreyTimeout(){
	clearTimeout(ballPreyTimeout);
	ballPreyTimeout = null;
}

function removeGameTimer(){
	clearInterval(gameTimer); 
	gameTimer = null;
}
