function Ball(x, y, stepX, stepY) {
	this.x = x;
	this.y = y;
	this.stepX = stepX;
	this.stepY = stepY;

	this.type = Math.floor(Math.random() + 0.2); // 0: nemico;  1: malus
}
 