// libretto.js

MEDIA_QUALITATIVA = [
	"sufficiente",
	"discreta",
	"buona",
	"distinta",
	"ottima",
	"eccellente"
];

VARIABILITA_QUALITATIVA = [
	"nessuna",
	"bassa",
	"normale",
	"alta"
];

// Oggetto Statistico, costruttore con propriet�, metodi
function Statistico(dati) {
    this.esami 	= this.analizzaDati(dati);
    this.min	= 0;
    this.mas 	= 0;
    this.med	= null;
    this.medPes = null
    this.variab	= null;
}	

Statistico.prototype.analizzaDati =
	function(datiInput) {
		// Array contenente i voti degli esami inseriti dall'utente (gli elementi sono delle stringhe)
   		var dati = datiInput.split(";"); 
   		// Array da restituire contenenti i voti degli esami (gli elementi sono degli interi)
   		var esami = new Array();   	
    	// Per ogni esame inserito dall'utente
    	for (var i = 0; i < dati.length; i++)
	     	esami[i] = new Esame(dati[i]);
    	
    	return esami;
	}

Statistico.prototype.datiOk = 
	function() {
		for (var i = 0; i < this.esami.length; i++)
			if (this.esami[i].voto == null)
				return false;
		return true;
	}

Statistico.prototype.calcolaMinimo =
	function() {
    	var minimo = this.esami[0].voto;
    	for (var i = this.esami.length-1; i > 0 ; i--)
        	minimo = Math.min(minimo, this.esami[i].voto);
    	this.min = minimo;
	}	

Statistico.prototype.calcolaMassimo =
	function() {
    	var massimo = this.esami[0].voto;
    	for (var i = this.esami.length-1; i > 0 ; i--)
        	massimo = Math.max(massimo, this.esami[i].voto);
        
    	this.mas = massimo;
	}	

Statistico.prototype.calcolaMedia =
	function() {   
		/*********************************
			CALCOLO MEDIA QUANTITATIVA
		*********************************/
    	var i = 0, media = 0;
    	while (i < this.esami.length) {
        	media += this.esami[i].voto;
        	i++;
    	}
    	media /= this.esami.length;
    	media = Math.round(media*100)/100;
    	
    	/*********************************
			CALCOLO MEDIA QUALITATIVA
		*********************************/
    	var mediaQual = MEDIA_QUALITATIVA[Math.floor((media-18)/3)];    	
    	this.med = { numerica:media, qualitativa: mediaQual };
	}	

Statistico.prototype.calcolaMediaPesata =
	function() {   
		/***************************************
			CALCOLO MEDIA PESATA QUANTITATIVA
		***************************************/
    	var creditiTotali = 0, mediaPes = 0;
    	for (var i = 0; i < this.esami.length; i++) {
        	mediaPes += this.esami[i].voto * this.esami[i].crediti;
        	creditiTotali += this.esami[i].crediti;
    	}
    	
    	mediaPes /= creditiTotali;
    	mediaPes = Math.round(mediaPes*100)/100;
    	
    	/***************************************
			CALCOLO MEDIA PESATA QUALITATIVA
		***************************************/
    	var mediaQual = MEDIA_QUALITATIVA[Math.floor((mediaPes-18)/3)]; 	
    	this.medPes = { numerica:mediaPes, qualitativa: mediaQual };
	}
	
Statistico.prototype.calcolaVariabilita =
	function() {
		/**************************************
			CALCOLO VARIABILTA' QUANTITATIVA
		**************************************/
    	var i = 0, varia = 0;
    	do {
       		varia += Math.abs(this.esami[i].voto - this.med.numerica);
        	i++;
    	}while (i < this.esami.length);
    		
    	varia /= this.esami.length;
    	varia = Math.round(varia*100)/100;
   
    	/**************************************
			CALCOLO VARIABILTA' QUANTITATIVA
		**************************************/
    	var variabQual = VARIABILITA_QUALITATIVA[Math.ceil(varia/7.5*3)];
    	this.variab = { numerica: varia, qualitativa: variabQual };
	}	


Statistico.prototype.stampaDatiStatistici = 
	function() {
		document.writeln("<div id=\"datiStatistici\">");
		document.writeln("Minimo: " +      this.min + "<br>");
    	document.writeln("Massimo: " +     this.mas + "<br>");	
    	document.writeln("Media: " + 	  this.med.numerica + " (" + 
        	                               this.med.qualitativa +")<br>");
        document.writeln("Media Pesata: " + this.medPes.numerica + " (" +
        									 this.medPes.qualitativa + ")<br>");
    	document.writeln("Variabilit&agrave;: " + this.variab.numerica + " (" +
            	                                  this.variab.qualitativa +")");
        document.writeln("</div>");
         
	}

Statistico.prototype.stampaTabellaEsami = 
	function() {
		document.writeln("<div id=\"tabellaVoti\">");
    	document.writeln("<table>")
    	document.writeln("<caption>Elenco Esami</caption>");
    	document.writeln("<tr><th>Materia<th>Crediti<th>Voti");
		
		for (var i = 0; i < this.esami.length; i++)
    		document.writeln("<tr><td>" + this.esami[i].materia + 
    								"<td>" + this.esami[i].crediti +
    								"<td>" + this.esami[i].voto);
    	
    	document.writeln("</table>");
    	document.writeln("</div>")
	}

Statistico.prototype.stampa =
	function() {
		// Stampa intestazione pagina HTML (doctype e head)
		document.writeln("<!DOCTYPE hmtl>");
		document.writeln("<html><head><meta charset=\"utf-8\">");
		document.writeln("<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"./css/img/favicon.ico\"/>");
    	document.writeln("<title>Libretto universitario</title>");
    	document.writeln("<link rel=\"stylesheet\" href=\"./css/libretto.css\" type=\"text/css\" media=\"screen\"> <!-- css --></head>");
    	
    	// Qua inizia il <body>
    	document.writeln("<body>");
    	document.writeln("<div id=\"wrapper\">");
    	document.writeln("<div id=\"topnav\"><img src=\"./css/img/unipi_logo.png\" alt=\"Logo\"></div>");
    	document.writeln("<p>Libretto Universitario</p>");
    	
    	this.stampaTabellaEsami();
		this.stampaDatiStatistici();
    	
    	document.writeln("</div>");
    	document.writeln("</body>");
    	document.writeln("</html");
            
	}
