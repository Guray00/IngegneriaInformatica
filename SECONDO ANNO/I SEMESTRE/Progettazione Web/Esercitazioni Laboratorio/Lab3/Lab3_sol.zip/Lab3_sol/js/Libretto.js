// Libretto.js

// Array di messaggi utente, istanziati prima che la pagina venga visualizzata
MESSAGGI_UTENTE = [
  "Inserisci una sequenza di voti tra 18 e 33",
  " non e` un numero",
  " e` un numero minore di 18 o maggiore di 33",
  " e` un numero minore di 1 o maggiore di 12",
  " non e` un nome valido per la materia"
];

// Gestore dei messaggi di errore
function stampaErrore(dato, codMess) {
    window.alert("Errore: '" + dato + "' " + MESSAGGI_UTENTE[codMess]);
}

// Funzione eseguita al caricamento della pagina
function main() {
	var voti = window.prompt(MESSAGGI_UTENTE[0]);
    if (voti == null)
		return;
	
	var stat = new Statistico(voti);
    if (!stat.datiOk())				
        return;
	
	stat.calcolaMinimo();	
    stat.calcolaMassimo();
    stat.calcolaMedia();
    stat.calcolaMediaPesata();
    stat.calcolaVariabilita();
    stat.stampa();
}
