// Esame.js

// Oggetto Esame, costruttore con proprieta' 
function Esame(datiEsame) {
	var infoEsame = this.analizzaInfo(datiEsame);
	if (infoEsame != null){
		this.materia = infoEsame[0];
		this.voto = infoEsame[1];
		this.crediti = infoEsame[2];
	}else{
		this.materia = null;
		this.voto = null;
		this.crediti = null;
	}	
}


Esame.prototype.analizzaInfo =
	function(datiEsame) {
		// Array contenente i voti degli esami inseriti dall'utente (gli elementi sono delle strighe)
   		var info = datiEsame.split(","); 
   		// Array da restituire contenenti le informazioni degli esami (gli elementi sono degli interi)
		var infoEsame = new Array();
		    	
		if (info.length != 3)
			return null;
	   	
	   	// Inizializzo materia
	   	if (!this.analizzaMateria(info[0]))
	   		return null;
	   		   	
	   	infoEsame[0] = info[0];
	   		   	
	   	// Inizializzo voto
	   	infoEsame[1] = this.analizzaVoto(info[1]);
	   	if (infoEsame[1] == null)
	   		return null;	
	   		
	   	// Inizializzo crediti
	   	infoEsame[2] = this.analizzaCrediti(info[2]);
	   	if (infoEsame[2] == null)
	   		return null;
		
	   	
		return infoEsame;
	   	
	}
	
Esame.prototype.analizzaMateria = 
	function(infoMateria){
		var regExp = new RegExp(/[^a-zA-Z\s]+/);
		if (regExp.test(infoMateria)){
			stampaErrore(infoMateria,4);
			return false;
		}
		return true;	
	}	
	
Esame.prototype.analizzaVoto = 
	function(infoVoto){
	 	var voto = this.controllaNumero(infoVoto);	
	 	if (voto == null)
	 		return null;
	 		
	 	if (voto<18 || voto>33){ // controllo se � compreso tra 18 e 33
	     	stampaErrore(voto,2);	
	     	return null;
	     }
    	
    	return voto;
	}
		
Esame.prototype.analizzaCrediti = 
	function(infoCrediti){
	 	var crediti = this.controllaNumero(infoCrediti);	
	 	if (crediti == null)
	 		return null;
	 		
		if (crediti<1 || crediti>12){ // controllo se � compreso tra 1 e 12
	     	stampaErrore(crediti,3);	
	     	return null;
	     }
    	
    	return crediti;
	}	
	
Esame.prototype.controllaNumero = 
	function(numeroStringa){
		var numero = Number(numeroStringa);
		if (isNaN(numero)){ // controllo se � un numero
			stampaErrore(numeroStringa,1);
	     	return null;
		}
		return numero;
	}
	
	