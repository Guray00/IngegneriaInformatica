<nav id="content_nav">			
	<a id="latest_movies_tab_link" href="./homeLatest.php" class="normal_text">Latest</a>
	<a id="upcoming_movies_tab_link" href="./homeUpcoming.php" class="normal_text">Upcoming</a>
	<a id="toprated_movies_tab_link" href="./homeTopRated.php" class="normal_text">Top Rated</a>
</nav>