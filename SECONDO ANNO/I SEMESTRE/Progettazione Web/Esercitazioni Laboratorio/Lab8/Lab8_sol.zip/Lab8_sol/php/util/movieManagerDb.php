<?php

    require_once "./util/trackMyMoviesDbManager.php"; //includes Database Class
 	
	function getLatestMovies(){  
		global $trackMyMoviesDb;
		$today = date('Y-m-d');
		$today = $trackMyMoviesDb->sqlInjectionFilter($today);
		$queryText = 'SELECT * FROM movie WHERE released <= \'' . $today . '\' ORDER BY released DESC';
		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; ;
	}

	function getMovieById($movieId){
		global $trackMyMoviesDb;
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$queryText = 'SELECT * FROM movie WHERE movieId = \'' . $movieId . '\'';
		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	
	function getUpcomingMovies(){
		global $trackMyMoviesDb;
		$today = date('Y-m-d');
		$today = $trackMyMoviesDb->sqlInjectionFilter($today);
		$queryText = 'SELECT * '
					. 'FROM movie '
					. 'WHERE released > \'' . $today . '\''
					. 'ORDER BY released ASC';
					
		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function getTopRatedMovies(){
		global $trackMyMoviesDb;
		$queryText = ' SELECT *, COUNT(um.isWatched) as topRated '
					. 'FROM movie m JOIN user_movie um ON m.movieId = um.movieId '
					. 'WHERE um.isLiked = 1 '
					. 'GROUP BY m.movieid '
					. 'ORDER BY topRated DESC';
					
		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}

	function getUserMovieStat($userId, $movieId){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
 		$queryText = 'SELECT * '
					. 'FROM user_movie '
					. 'WHERE userId = \'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}	
	
	function getToWatchMovies($userId){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
 		$queryText = 'SELECT * '
					. 'FROM user_movie um JOIN movie m ON um.movieId = m.movieId '
					. 'WHERE um.userId = \'' . $userId . '\' AND um.toWatch = 1';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function getViewedMovies($userId){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
 		$queryText = 'SELECT * '
					. 'FROM user_movie um JOIN movie m ON um.movieId = m.movieId '
					. 'WHERE um.userId = \'' . $userId . '\' AND um.isWatched = 1';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function getTimeWatched($userId){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$queryText = 'SELECT SUM(m.runtime) AS totalRuntime ' . 
					 'FROM user_movie u JOIN movie m ON u.movieId = m.movieId ' .
					 'WHERE u.userId = \'' . $userId . '\' AND u.isWatched = 1';
		$result = $trackMyMoviesDb->performQuery($queryText);
		return $result;
	}
	
	function getMovieLikesOrDislikes($movieId, $like_dislake){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$like_dislake = $trackMyMoviesDb->sqlInjectionFilter($like_dislake);
 		$queryText = 'SELECT COUNT(*) as num '
					. 'FROM user_movie '
					. 'WHERE movieId = \'' . $movieId . '\' AND isLiked = ' . $like_dislake;
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function getMovieLikes($movieId){
 		return getMovieLikesOrDislikes($movieId, 1);
	}
	
	function getMovieDislikes($movieId){
		 return getMovieLikesOrDislikes($movieId, 0);
	}
	
	function insertWatchedUserMovieStat($movieId, $userId, $isWatchedFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
 		$isWatchedFlag = $trackMyMoviesDb->sqlInjectionFilter($isWatchedFlag);
		$queryText = 'INSERT INTO user_movie (id, userId, movieId, isWatched, toWatch, isLiked) ' 
						. 'VALUES (NULL, \'' . $userId . '\', \'' . $movieId . '\', ' . $isWatchedFlag . ', 0, NULL)';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function updateWatchedUserMovieStat($movieId, $userId, $isWatchedFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
 		$isWatchedFlag = $trackMyMoviesDb->sqlInjectionFilter($isWatchedFlag);
 		$queryText = 'UPDATE user_movie '
					. 'SET isWatched=' . $isWatchedFlag . ', toWatch=0, isLiked=null '
					. 'WHERE userId=\'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function insertToWatchUserMovieStat($movieId, $userId, $toWatchFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$toWatchFlag = $trackMyMoviesDb->sqlInjectionFilter($toWatchFlag);
		$queryText = 'INSERT INTO user_movie (id, userId, movieId, isWatched, toWatch, isLiked) ' 
						. 'VALUES (NULL, \'' . $userId . '\', \'' . $movieId . '\', 0, ' . $toWatchFlag . ', NULL)';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function updateToWatchUserMovieStat($movieId, $userId, $toWatchFlag){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$toWatchFlag = $trackMyMoviesDb->sqlInjectionFilter($toWatchFlag);
		$queryText = 'UPDATE user_movie '
					. 'SET isWatched=0, toWatch=' . $toWatchFlag . ', isLiked=null '
					. 'WHERE userId=\'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 		return $trackMyMoviesDb->performQuery($queryText);
	}
	
	function insertLikeDislikeUserMovieStat($movieId, $userId, $preference){
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$preference = $trackMyMoviesDb->sqlInjectionFilter($preference);
		$queryText = 'INSERT INTO user_movie (id, userId, movieId, isWatched, toWatch, isLiked) ' 
						. 'VALUES (NULL, \'' . $userId . '\', \'' . $movieId . '\', 1, 0, ' . $preference . ')';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
	
	function updateLikeDislikeUserMovieStat($movieId, $userId, $preference){
		if ($preference === null)
			$preference = "null";
			
		global $trackMyMoviesDb;
		$userId = $trackMyMoviesDb->sqlInjectionFilter($userId);
		$movieId = $trackMyMoviesDb->sqlInjectionFilter($movieId);
		$preference = $trackMyMoviesDb->sqlInjectionFilter($preference);
		$queryText = 'UPDATE user_movie '
					. 'SET isWatched=1, toWatch=0, isLiked= ' . $preference . ' '
					. 'WHERE userId = \'' . $userId . '\' AND movieId = \'' . $movieId . '\'';
 		$result = $trackMyMoviesDb->performQuery($queryText);
		$trackMyMoviesDb->closeConnection();
		return $result; 
	}
?>
