<?php
	session_start();
    include "./util/sessionUtil.php";

    if (!isLogged()){
		    header('Location: ./../index.php');
		    exit;
    }	
?>
<!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8"> 
    	<meta name = "author" content = "PWEB">
    	<meta name = "keywords" content = "game">
   	 	<link rel="shortcut icon" type="image/x-icon" href="./../css/img/favicon.ico" />
		<link rel="stylesheet" href="./../css/trackMyMovies_menu.css" type="text/css" media="screen">
		<link rel="stylesheet" href="./../css/trackMyMovies.css" type="text/css" media="screen">
		<title>Track My Movies - Home</title>
	</head>
	<body>
		<?php
			include "./layout/menu.php";
			
			echo '<div id="content">';

			include "./layout/home_nav.php";
		?>	
				
			<script type="text/javascript">
				document.getElementById("latest_movies_tab_link").setAttribute("class", "highlighted_text");
			</script>	
			
		<?php	
			require "./util/movieManagerDb.php";	
			require "./layout/movies_dashboard.php";
			require "./util/userMovieInteraction.php";
						
			checkUserMovieFlagStat();

			$result = getLatestMovies();
			showMovies($result);
			$result->close();
			echo '</div>';
		?>
	</body>
</html>