<?php
	session_start();
    include "./util/sessionUtil.php";

    if (!isLogged()){
		    header('Location: ./../index.php');
		    exit;
    }	
?>
<!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8"> 
    	<meta name = "author" content = "PWEB">
    	<meta name = "keywords" content = "game">
   	 	<link rel="shortcut icon" type="image/x-icon" href="./../css/img/favicon.ico" />
		<link rel="stylesheet" href="./../css/trackMyMovies_menu.css" type="text/css" media="screen">
		<link rel="stylesheet" href="./../css/trackMyMovies.css" type="text/css" media="screen">
		<title>Track My Movies - To Watch</title>
	</head>
	<body>
		<?php
			include "./layout/menu.php";
			
			?>	
				
			<script type="text/javascript">
				document.getElementById("toWatchImgLink").setAttribute("class", "menu_item_img to_watch_img_1");
				document.getElementById("toWatchLabelLink").setAttribute("class", "gold_label");
			</script>	
			
			<?php	
			include "./util/movieManagerDb.php";	
			include "./layout/movies_dashboard.php";
			
			echo '<div id="content">';
			
			require "./util/userMovieInteraction.php";
						
			checkUserMovieFlagStat();
			
			$result = getToWatchMovies($_SESSION['userId']);
			$numRecord = mysqli_num_rows($result);		
				if($numRecord <= 0) { 
				echo '<p class="warning">Really do you have no movies that you would like to watch?<br>';
				echo 'You can find the upcoming movies in your <a href="./homeUpcoming.php">home</a>. Check it out!</p></section>';
				echo '</div>';
				return;
			}	
			
			showMoviesWithUserStat($result);
			$result->close();
			echo '</div>';
		?>
	</body>
</html>