<?php
	require_once "./util/movieManagerDb.php";
	require_once "./layout/messageUtil.php";
	
	function checkUserMovieFlagStat(){  
		$movieId = null;
		if (!isset($_GET['movieId']))
			return;
		
		$movieId = $_GET['movieId'];
		
		$currentFlag = 0;	
		// check isWatched flag
		if (isset($_GET['isWatched'])){
			$currentFlag = $_GET['isWatched'];
			if (!setWatchedUserStat($movieId, $currentFlag))
				showError();
				
			return;
		}	
		
		// check toWatch flag
		if (isset($_GET['toWatch'])){
			$currentFlag = $_GET['toWatch'];
			if (!setToWatchUserStat($movieId, $currentFlag))
				showError();
			
			return;
		}	

		// check like flag		
		if (isset($_GET['like'])){
			$currentFlag = $_GET['like'];
			if (!setLikeUserStat($movieId, $currentFlag))
				showError();
			
			return;
		}	

		// check dislike flag		
		if (isset($_GET['dislike'])){
			$currentFlag = $_GET['dislike'];
			if (!setDislikeUserStat($movieId, $currentFlag))
				showError();
				
			return;
		}		
	}
	
	function isUserMovieStatInDb($movieId, $userId){
		$result = getUserMovieStat($userId, $movieId);
		$numRows = $result->num_rows;
		return $numRows === 1;
	}
	
	function setWatchedUserStat($movieId, $isWatchedFlag){
		if(isUserMovieStatInDb($movieId, $_SESSION['userId']))
			$result = updateWatchedUserMovieStat($movieId, $_SESSION['userId'], $isWatchedFlag);
		else
			$result = insertWatchedUserMovieStat($movieId, $_SESSION['userId'], $isWatchedFlag);
		
		return $result;
	}
	
	function setToWatchUserStat($movieId, $toWatchFlag){
		if(isUserMovieStatInDb($movieId, $_SESSION['userId'])) 
			$result = updateToWatchUserMovieStat($movieId, $_SESSION['userId'], $toWatchFlag);
		else
			$result = insertToWatchUserMovieStat($movieId, $_SESSION['userId'], $toWatchFlag);
		
		return $result;
	}
	
	function setLikeUserStat($movieId, $isLiked){
		if (!$isLiked) // if isLiked flag is equal to 0 (user remove the like flag)
			$isLiked = null;
					
		return setLikeDislikeUserStat($movieId, $isLiked);
	}
	
	function setDislikeUserStat($movieId, $isDisliked){
		if (!$isDisliked) // if isDisiked flag is equal to 0 (user remove the dislike flag)
			$isDisliked = null;
		else
			$isDisliked = 0; // In the DB the 'isLiked' column is set to: NUll -> no user preferences; 0 -> dislike; 1 -> like
	
		return setLikeDislikeUserStat($movieId, $isDisliked);
	}
	
	function setLikeDislikeUserStat($movieId, $preference){
		if(isUserMovieStatInDb($movieId, $_SESSION['userId']))
			$result = updateLikeDislikeUserMovieStat($movieId, $_SESSION['userId'], $preference);
		else
			$result = insertLikeDislikeUserMovieStat($movieId, $_SESSION['userId'], $preference);
	
		return $result;
	}

?>
