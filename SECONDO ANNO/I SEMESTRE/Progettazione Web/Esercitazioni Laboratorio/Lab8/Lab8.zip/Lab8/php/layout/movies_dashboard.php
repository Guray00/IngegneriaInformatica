<?php
	require_once "./util/movieManagerDb.php";	
	require_once "./util/sessionUtil.php";
	require_once "./layout/messageUtil.php";
	
	function showMovies($result){
		echo '<section class="movie_dashboard">';
		
		$numMovies = mysqli_num_rows($result);		
		if($numMovies <= 0) { 
			showError();	
			return;
		}	
		
		echo '<ul class="poster_movies_list">';
		while($movieRow = $result->fetch_assoc()){
			echo '<li class="poster_movie_item_wrapper">';
			
			$userMovieStatResult = getUserMovieStat($_SESSION['userId'], $movieRow['movieId']);
			$userMovieRow = null;
			if (mysqli_num_rows($userMovieStatResult) == 1)
				$userMovieRow = $userMovieStatResult->fetch_assoc();
			
			showUserStat($movieRow['movieId'], $userMovieRow);
			showMoviePoster($movieRow); 	 				
		}
		
		echo '</ul>';
		echo '</section>';
	} 
	
	function showMoviesWithUserStat($result){
		echo '<section class="movie_dashboard">';
		
		echo '<ul class="poster_movies_list">';
		while($userMovieRow = $result->fetch_assoc()){
			echo '<li class="poster_movie_item_wrapper">';
			showUserStat($userMovieRow['movieId'], $userMovieRow);
			showMoviePoster($userMovieRow); 	 				
		}
		
		echo '</ul>';
		echo '</section>';
		
		
	}
	
	function  showMoviePoster($movieRow){
		// Poster	
		echo '<div class="poster_movie_item"><a href="./detailedmovie.php?movieId=' . $movieRow['movieId'] . '">';
		if($movieRow['poster'] == "N/A"){
			echo '<img src="http://entertainment.ie/movie_trailers/trailers/flash/posterPlaceholder.jpg">'; 
		} else {
			echo '<img src="' . $movieRow['poster'] . '" alt="poster">';
		}
		echo '</a></div>';
		
		// Detail movie
		echo '<div class="detail_movie_item">';
		echo '<a href="./detailedmovie.php?movieId=' . $movieRow['movieId'] . '">' . $movieRow['title'] . '</a>';
		echo '<p>' . $movieRow['director'] . '</p>';
		echo '</div>';										
	}
	
	function showUserStat($movieId, $userMovieRow){
		echo '<nav>';	
		
		// isWatched link
		$currentFlag = false; //isWatched flag
		if ($userMovieRow != null AND $userMovieRow['isWatched'] != null AND $userMovieRow['isWatched'] == 1)
			$currentFlag = true;
		echo '<a href="' . $_SERVER["PHP_SELF"] . '?movieId=' . $movieId .  '&amp;isWatched=' . (int)!$currentFlag . '">';
		echo '<div class="nav_movie_item check_img_' . (int)$currentFlag . '"></div></a>';
			
		// toWatch link		
		$currentFlag = false; //toWatch flag
		if ($userMovieRow != null AND $userMovieRow['toWatch'] != null AND $userMovieRow['toWatch'] == 1)
				$currentFlag = true;
		echo '<a href="' . $_SERVER["PHP_SELF"] . '?movieId=' . $movieId .  '&amp;toWatch=' . (int)!$currentFlag . '">';
		echo '<div class="nav_movie_item to_watch_img_' . (int)$currentFlag . '"></div></a>';
		
		// like link
		$currentFlag = false; //like flag
		if ($userMovieRow != null AND $userMovieRow['isLiked'] != null AND $userMovieRow['isLiked'] == 1)
			$currentFlag = true;
		echo '<a href="' . $_SERVER["PHP_SELF"] . '?movieId=' . $movieId .  '&amp;like=' . (int)!$currentFlag . '">';
		echo '<div class="nav_movie_item like_img_' . (int)$currentFlag . '"></div></a>';
		showMovieLikes($movieId);
		
		// dislike link
		$currentFlag = false; //dislike flag
		if ($userMovieRow != null AND $userMovieRow['isLiked'] != null AND $userMovieRow['isLiked'] == 0)
			$currentFlag = true;
		echo '<a href="' . $_SERVER["PHP_SELF"] . '?movieId=' . $movieId .  '&amp;dislike=' . (int)!$currentFlag .'">';
		echo '<div class="nav_movie_item dislike_img_' . (int)$currentFlag . '"></div></a>';
		showMovieDislikes($movieId);
		
		echo '</nav>';	
	}
	
	function showMovieLikes($movieId){
		echo '<div class="nav_movie_item stats_user_movie">';
		$numLikesResult = getMovieLikes($movieId);
		$numLikesRow = $numLikesResult->fetch_assoc();
		echo '(' . $numLikesRow['num'] . ')';
		echo '</div>';		
	}
	
	function showMovieDislikes($movieId){
		echo '<div class="nav_movie_item stats_user_movie">';
		$numDislikesResult = getMovieDislikes($movieId);
		$numDislikesRow = $numDislikesResult->fetch_assoc();
		echo '(' . $numDislikesRow['num'] . ')';
		echo '</div>';		
	}
	
	function showDetailedMovie($result){
		$numMovies = mysqli_num_rows($result);
		if($numMovies != 1) { 
			showError();	
			return;
		}
		
		$movieRow = $result->fetch_assoc();
		echo '<div id="detailed_movie_tab">';
		echo '<div id="left">';
		echo '<div id="detailed_poster">';
		if($movieRow['poster'] == "N/A"){
			echo '<img src="http://entertainment.ie/movie_trailers/trailers/flash/posterPlaceholder.jpg">'; 
		} else {
			echo '<img src="' . $movieRow['poster'] . '" alt="poster">';
		}
		echo '</div>';
		
		echo '<div class="content_movie_wrapper">';
		echo '<span class="title_stats">Released</span>: ' . $movieRow['released'] . '<br>';
		echo '<span class="title_stats">Rated</span>: ' . $movieRow['rated'] . '<br>';
		echo '<span class="title_stats">Runtime</span>: ' . $movieRow['runtime'] . '<br>';
		echo '<span class="title_stats">Genre</span>: ' . $movieRow['genre'] . '<br>';
		echo '</div>';		
		echo '</div>';
		echo '<div id="main">';
		$date = DateTime::createFromFormat("Y-m-d", $movieRow['released']);
		echo '<h1>' . $movieRow['title'] . '</h1><h3>(' . $date->format("Y") . ')</h3>';
		
		$userMovieStatResult = getUserMovieStat($_SESSION['userId'], $movieRow['movieId']);
		$userMovieRow = null;
		if (mysqli_num_rows($userMovieStatResult) == 1)
			$userMovieRow = $userMovieStatResult->fetch_assoc();
			
		showUserStat($movieRow['movieId'], $userMovieRow);
		
		echo '<div class="content_movie_wrapper">';
		echo '<h2>Overview:</h2>';
		echo $movieRow['plot'] . '<br>';
		echo '</div>';
		echo '<div class="content_movie_wrapper">';
		echo '<h2>Staff:</h2>';
		echo '<span><span class="title_stats">Director</span>: ' . $movieRow['director'] . '</span><br>';
		echo '<span><span class="title_stats">Writer</span>: ' . $movieRow['writer'] . '</span><br>';
		echo '<span><span class="title_stats">Cast</span>: ' . $movieRow['actors'] . '</span><br>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}
?>