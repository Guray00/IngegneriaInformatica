<?php
	session_start();
    include "./util/sessionUtil.php";

    if (!isLogged()){
		    header('Location: ./../index.php');
		    exit;
    }	
?>
<!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8"> 
    	<meta name = "author" content = "PWEB">
    	<meta name = "keywords" content = "game">
   	 	<link rel="shortcut icon" type="image/x-icon" href="./../css/img/favicon.ico" />
		<link rel="stylesheet" href="./../css/trackMyMovies_menu.css" type="text/css" media="screen">
		<link rel="stylesheet" href="./../css/trackMyMovies.css" type="text/css" media="screen">
		<title>Track My Movies - Movie</title>
	</head>
	<body>
		<?php
			include "./layout/menu.php";
			include "./util/movieManagerDb.php";	
			include "./layout/movies_dashboard.php";
			include "./util/userMovieInteraction.php";

			checkUserMovieFlagStat();

			echo '<div id="content">';
			$movieId = $_GET['movieId'];
			$result = getMovieById($movieId);	
			showDetailedMovie($result);
			echo '</div>';
		?>
	</body>
</html>