<?php
	session_start();
    include "./php/util/sessionUtil.php";

    if (isLogged()){
		    header('Location: ./php/homeLatest.php');
		    exit;
    }	
?>
<!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8"> 
    	<meta name = "author" content = "PWEB">
    	<meta name = "keywords" content = "game">
   	 	<link rel="shortcut icon" type="image/x-icon" href="./css/img/favicon.ico" />
		<link rel="stylesheet" href="./css/trackMyMovies_login.css" type="text/css" media="screen">
		<script type="text/javascript" src="./js/effects.js"></script>
		<script type="text/javascript" src="./js/trackMyMovies.js"></script>		
		<title>Track My Movies</title>
	</head>
	<body onLoad="begin()">
		<section id="sign_in_content">
		<div id="sign_in_content_header">
			Track My Movies
		</div>
		<div id="login_form">
			<form name="login" action="./php/login.php" method="post">
				<div>
					<label>Username</label>
					<input type="text" placeholder="Username" name="username" required autofocus>
				</div>
				<div>
					<label>Password</label>
					<input type="password" placeholder="Password" name="password" required>
				</div>	
				<input type="submit" value="Enter">
				<?php
					if (isset($_GET['errorMessage'])){
						echo '<div class="sign_in_error">';
						echo '<span>' . $_GET['errorMessage'] . '</span>';
						echo '</div>';
					}
				?>
			</form>
		</div>
		</section>
		<footer id="sign_in_footer">
			<div class="legal_form">
				<a href="./html/terms.html" target="_blank">Terms of Service</a>
				<a href="./html/privacy.html" target="_blank">Privacy</a>
			</div>
		</footer>
	</body>
</html>
