<?php

    header('Location: ./html/home.php');

?>