function Ball(x, y, stepX, stepY, radius) {
	this.point = new Point(x, y);
	this.stepX = stepX;
	this.stepY = stepY;
	this.radius = radius;

	this.type = Math.floor(Math.random() + 0.2); // 0: nemico;  1: malus
}
 
Ball.prototype.move = 
	function(playground){
		if (this.point.x > (playground.width - this.radius + playground.offsetLeft)) {
			this.point.x = playground.width - this.radius + playground.offsetLeft;
			this.stepX = -this.stepX;
		} else if (this.point.x < (this.radius + playground.offsetLeft)) {
			this.point.x = this.radius + playground.offsetLeft;
			this.stepX = -this.stepX;
		}
		
		if (this.point.y > (playground.height - this.radius + playground.offsetTop)) {
			this.point.y = playground.height - this.radius + playground.offsetTop;
			this.stepY = -this.stepY;
		} else if (this.point.y < (this.radius + playground.offsetTop)) {
			this.point.y = this.radius + playground.offsetTop;
			this.stepY = -this.stepY;
		}

		this.point.x += this.stepX;
		this.point.y += this.stepY;
	}
	
	
Ball.prototype.isPlayerHit = 
	function(player){
		return MathUtil.squareDistance(player.point, this.point) 
				<= (this.radius + player.radius) * (this.radius + player.radius);
	}
