function GameStateFlag() {
	this.gameTimer = null;
	this.ballPreyTimeout = null;
	this.lastTransparencyBallTime = -1;
	this.availableExplodeAbility = MAX_EXPLODE_COUNT;
}

GameStateFlag.prototype.start = 
	function(clockFuction){
		if (this.gameTimer === null)
			this.gameTimer = setInterval(clockFuction, CLOCK_INTERVAL);
	}

GameStateFlag.prototype.pause = 
	function(){
		clearInterval(this.gameTimer); 
		this.gameTimer = null;
	}
	
GameStateFlag.prototype.isPause =
	function(){
		return this.gameTimer === null;
	}
	
GameStateFlag.prototype.activateTransparency = 
	function(){
		this.lastTransparencyBallTime = Date.now();
	}

GameStateFlag.prototype.removeTransparency = 
	function(){
		this.lastTransparencyBallTime = -1;
	}

GameStateFlag.prototype.isTransparencyActive = 
	function(){
		return this.lastTransparencyBallTime !== -1;
	}

GameStateFlag.prototype.incrementAvailableExplodeAbility =
	function(){
		if (this.availableExplodeAbility < MAX_EXPLODE_COUNT)
			this.availableExplodeAbility++;
	}

GameStateFlag.prototype.decrementAvailableExplodeAbility =
	function(){
		if (this.availableExplodeAbility > 0)
			this.availableExplodeAbility--;
	}

GameStateFlag.prototype.isAvailableExplodeAbilityEmpty =
	function(){
		return (this.availableExplodeAbility <= 0);
	}
	
GameStateFlag.prototype.activateBallPreyTimeout = 
	function(functionTimeout){
		this.ballPreyTimeout = setTimeout(functionTimeout, CLOCK_TIMEOUT_INTERVAL);
	}

GameStateFlag.prototype.removeBallPreyTimeout = 
	function(){
		clearTimeout(this.ballPreyTimeout);
		this.ballPreyTimeout = null;
	}

GameStateFlag.prototype.reset =
	function(){
		this.removeTransparency();
		this.pause();
		this.removeBallPreyTimeout();
		this.availableExplodeAbility = MAX_EXPLODE_COUNT;
	}
	