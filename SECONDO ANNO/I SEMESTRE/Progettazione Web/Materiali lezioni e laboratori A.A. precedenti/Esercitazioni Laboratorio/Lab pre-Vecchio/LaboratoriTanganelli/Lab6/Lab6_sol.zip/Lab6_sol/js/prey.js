var SQUARE_TYPE = 0;
var BALL_TYPE = 1;

function Prey(x, y, halfLength) {
	this.point = new Point(x, y);
	this.halfLength = halfLength;
}
	
function SquarePrey(x, y, halfLength){
	this.base = Prey;
	this.base(x, y, halfLength);
	
	this.type = SQUARE_TYPE;
}

SquarePrey.prototype = new Prey;

SquarePrey.prototype.isPlayerHit = 
	function(player){
		return  !(Boolean(Math.floor(Math.abs(player.point.x - this.point.x)/(this.halfLength + player.radius))
				+ Math.floor(Math.abs(player.point.y - this.point.y)/(this.halfLength + player.radius))))
					&& 
				(MathUtil.squareDistance(player.point, this.point)) <= MIN_SQUARE_PREY_PLAYER_DISTANCE_SQUARE;
	}	
	
function BallPrey(x, y, halfLength){
	this.base = Prey;
	this.base(x, y, halfLength);
	
	this.type = BALL_TYPE;
}

BallPrey.prototype = new Prey;

BallPrey.prototype.isPlayerHit = 
	function(player){
		return  (MathUtil.squareDistance(player.point, this.point)) 
			<= ((player.radius + this.halfLength) * (player.radius + this.halfLength));
	}	
	