function Player(x, y, radius) {
	this.point = new Point(x, y);
	this.radius = radius;
}
 
Player.prototype.move = 
	function(x, y, playground){
		this.point.x = x;
		this.point.y = y;
	
		if (this.point.x > (playground.width - this.radius + playground.offsetLeft)) {
			this.point.x = playground.width - this.radius + playground.offsetLeft;
		} else if (this.point.x < (this.radius + playground.offsetLeft)) {
			this.point.x = this.radius + playground.offsetLeft;
		}
		
		if (this.point.y > (playground.height - this.radius + playground.offsetTop)) {
			this.point.y = playground.height - this.radius + playground.offsetTop;
		} else if (this.point.y < (this.radius + playground.offsetTop)) {
			this.point.y = this.radius + playground.offsetTop;
		}
	
	}
	