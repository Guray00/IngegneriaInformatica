function ajaxHandler() 
{  
		var xmlHttp;  
		try { xmlHttp=new XMLHttpRequest(); }
		catch (e) 
		{	try 
		{ xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); }
		catch (e) 
		{   try { xmlHttp=new ActiveXObject("Microsoft.XMLHTTP"); }      
		     catch (e) 
		    {	window.alert("Your browser does not support AJAX!");        
			return;      
		     }   
			} 
		} 
		xmlHttp.open("GET","date.php",true);
		xmlHttp.onreadystatechange = useHttpResponse;
		xmlHttp.send(null);
		 
		function useHttpResponse() 
		{	if(xmlHttp.readyState == 4) 					
			document.mymodule.day.value = xmlHttp.responseText; 
		}		 			   
}						
