function visit(node,obj)
{ 
 if (node.hasChildNodes())
 {
 	for (var i=0; i<node.childNodes.length; i++)
	{
			
			obj.txt+="CHILD " + i + " of " + node.nodeName  + " - .#" + node.childNodes[i].nodeType + "." + node.childNodes[i].nodeName 
					+ "=" + node.childNodes[i].nodeValue +  "<br>"; 
			visit(node.childNodes[i],obj);
	}
	}
}	
var node=document.documentElement;
var obj=new Object;
obj.txt="";
visit(node,obj);
document.write(obj.txt);