<?php  	$oggi = date("D M Y G:i:s");   echo($oggi); ?>

