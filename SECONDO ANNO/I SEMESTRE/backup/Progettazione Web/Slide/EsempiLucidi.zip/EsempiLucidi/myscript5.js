var infobrowser = "<h1>Information on your browser</h1><p>";
for (var proprietyName in navigator)  
	infobrowser += "<strong>" + proprietyName + ":</strong>" + 
	navigator[proprietyName] + "<br>";
	infobrowser += "</p>";
document.writeln(infobrowser);
if (navigator.appName.indexOf("Netscape") != -1)
	window.alert("Your browser is Netscape");
else if (navigator.appName.indexOf("Microsoft Internet Explorer") != -1)
	window.alert("Your browser is Internet Explorer");