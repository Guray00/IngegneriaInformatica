<?php
	// Start up your PHP Session 
	session_start();
	// If the user is not logged in send him/her to the login form
	if ($_SESSION["Login"] != "YES") {
	  header("Location: form.php");
	}
	?>
<!DOCTYPE html>
 <html lang="en">
  <head>
	<meta charset="utf-8"> 
    <title>Protected File</title>
    <style type="text/css"> p { font-size: 30pt;} </style>
  </head>
  <body>
	<h1>This document is protected</h1>
	<p>You can only see it if you are logged in.</p>
	<a href='logout.php'>Exit</a> </p>
	</body>
	</html>	
