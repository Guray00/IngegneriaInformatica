function visit(node,obj)
{ 
 if (node==null) return;
 if (node.firstChild)
 {
 		obj.txt+=node.firstChild.nodeType + "." + node.firstChild.nodeName 
					+ "=" + node.firstChild.nodeValue + "<br>"; 
			visit(node.firstChild,obj);
	}
	if (node.nextSibling)
	{
	 obj.txt+=node.nextSibling.nodeType + "." + node.nextSibling.nodeName 
					+ "=" + node.nextSibling.nodeValue + "<br>"; 
			visit(node.nextSibling,obj);
	}
}

var node=document.documentElement;
var obj=new Object;
obj.txt="";
visit(node,obj);
document.write(obj.txt);