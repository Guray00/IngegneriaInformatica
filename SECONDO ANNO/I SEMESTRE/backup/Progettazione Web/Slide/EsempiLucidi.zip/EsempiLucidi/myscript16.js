var fields = document.getElementsByTagName("INPUT");
var shouldBeALPHANUMERICAL = [0, 1, 4];   //(1)
var shouldBeNUMERICAL     = [2, 4];
var shouldBeALPHABETICAL   = [0, 1, 3];
var shouldBe5NUMBERS    = [4];
var MESSAGES = [  "The following field does not have valid symbols: ",  
						 	 		"The following field is not exclusively numerical: ",  
									"The following field must have five digits: ",
									"The following field must have only letters: ",   
									"...",  
									"OK"];
var existALPHANUMERICAL    = /\w/; //(2)
var existNONALPHANUMERICAL = /\W/; //(3)
var existNONNUMERICAL     = /\D/; //(4)
var existNUMERICAL        = /\d/; //(5)
var exist5NUMERICAL       = /\d{5}/; //(6)
function error(idmess, field) {  window.alert(MESSAGES[idmess] + field.name);  
field.focus();   field.select();  
} 
function isTrue(COND, ELEM, BOOL, MESS) { //(7)   
for (var i=0; i<ELEM.length; i++) {
      var j = ELEM[i];      
			field = fields[j];      
			if (COND.test(field.value) == BOOL) {   //(8)        
			error(MESS, field); 
       return true;      
			 }    
			 } 
			 return false;
}    
function validate() {  
if (isTrue(existALPHANUMERICAL,    shouldBeALPHANUMERICAL, false, 0))    return;//(9)  
if (isTrue(existNONALPHANUMERICAL, shouldBeALPHANUMERICAL, true,  0))    return;//(10)  
if (isTrue(existNONNUMERICAL,     shouldBeNUMERICAL,     true,  1))    return;//(11)  
if (isTrue(exist5NUMERICAL,       shouldBe5NUMBERS,    false, 2))    return;//(12)  
if (isTrue(existNUMERICAL,        shouldBeALPHABETICAL,   true,  3))    return;//(13)  
if (isTrue(existNONALPHANUMERICAL, shouldBeALPHABETICAL,   true,  3))    return;//(14)  
window.alert(MESSAGES[MESSAGES.length-1]);
}