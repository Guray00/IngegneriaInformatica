var text =  document.getElementById("mypar1").firstChild.nodeValue;
window.alert("The paragraph has the text '" + text +"'");
var body = document.getElementById("mybody");
var textNode = body.childNodes[0].firstChild;       //Explorer 
if (!textNode) window.alert("Mozilla Firefox");
else window.alert("Microsoft Explorer");
text = textNode ? textNode.nodeValue :                  
body.childNodes[1].firstChild.nodeValue;      	      //Mozilla
window.alert("The paragraph has the text '" + text + "'");