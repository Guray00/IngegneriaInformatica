var text = "Example of Sliding Text ..............";
function slide() {  //(1)    
var firstchar = text.charAt(0);    
text = text.slice(1,text.length) + firstchar;    
document.forms[0].mytext.value = text;            //(2)
}