var elems = document.getElementsByTagName("p");
var text =  elems[0].firstChild.nodeValue;
window.alert("The paragraph has the text '" + text +"'");
