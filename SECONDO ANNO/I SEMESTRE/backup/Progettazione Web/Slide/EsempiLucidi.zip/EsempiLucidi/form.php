<!DOCTYPE html>
<html lang="en">
  <head>
	<meta charset="utf-8"> 
   <title>Login</title>
    <style type="text/css"> p { font-size: 30pt;} </style>
  </head>
  <body>
	<form method="post" action="login.php">
	<p>Username: <input type="text" name="username"></p>
	<p>Password: <input type="text" name="password"></p>
	<p><input type="submit" value="Let me in"></p>
	</form>
	</body>
	</html>

