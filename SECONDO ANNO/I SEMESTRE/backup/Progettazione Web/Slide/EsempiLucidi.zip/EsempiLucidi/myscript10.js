var but = document.getElementById('but');
var diff = [150, 0, -150, 0];
var i = 0;
function moveMouse() 
{ but.style.top= (parseInt(but.style.top)+ diff[(i+3)%4]) + "px"; 
	but.style.left=(parseInt(but.style.left)+ diff[(i++)%4])+ "px";}