<?php
phpInfo();