var PREY_ID = 'prey';
var PLAYER_ID = 'player';
var BALL_BASE_ID = ' '; // + index of the array
 
var playerNode = null;
var preyNode = null;

var TRANSPARENCY_PERIOD = 2000;

function drawPrey(){
	if (preyNode === null){
		preyNode = document.createElement('div');
		preyNode.setAttribute('id', PREY_ID);
		playground.appendChild(preyNode);
	}
	preyNode.style.left = (preyX-PREY_HALF)+ 'px';
	preyNode.style.top = (preyY-PREY_HALF) + 'px';
	
}

function drawPlayer(){
	if (playerNode === null){
		playerNode = document.createElement('div');
		playerNode.setAttribute('id', PLAYER_ID);
		playground.appendChild(playerNode);
	}
	playerNode.style.left = (playerX-PLAYER_RADIUS)+ 'px';
	playerNode.style.top = (playerY-PLAYER_RADIUS) + 'px';
	
}

function drawBall(index){
 	var ballNodeId = '' + BALL_BASE_ID + index;
	var ballNode = document.getElementById(ballNodeId);
	if (ballNode === null){
		ballNode = document.createElement('div');
		ballNode.id = ballNodeId;
		ballNode.setAttribute('class', 'ball');
		ballNode.style.backgroundImage = "url('./css/img/ball" + balls[index].type + ".png')";
		playground.appendChild(ballNode);
	}
	
	ballNode.style.left = (balls[index].x-BALL_RADIUS) + 'px';
	ballNode.style.top = (balls[index].y-BALL_RADIUS) + 'px';
	
	if (lastTransparencyBallTime !== -1) {
		var now = Date.now();
		var alphaTimeMeasure = (now - lastTransparencyBallTime) / TRANSPARENCY_PERIOD;

		if (alphaTimeMeasure >= 1) {
			lastTransparencyBallTime = -1;
			alphaTimeMeasure = 1;
		}
 
 		ballNode.style.opacity = (1 - 2*alphaTimeMeasure)*(1 - 2*alphaTimeMeasure);
	} else{
		ballNode.style.opacity = 1;
	}
	
}

function updateStat() {
	var gameStats = document.getElementById('gameStat').getElementsByTagName('span');
	gameStats[0].firstChild.nodeValue = currentScore;
 	gameStats[1].firstChild.nodeValue = bestScore;
 	gameStats[2].firstChild.nodeValue = playCount;
 }
 
function removeAll(){
	var elements = playground.getElementsByTagName('div');
	// for (var i = 0; i < elements.length; i++) Wrong solution
	for (var i = elements.length-1; i >=0; i--)
		playground.removeChild(elements[i]);
	
	playerNode = null;
	preyNode = null;
	
}


 