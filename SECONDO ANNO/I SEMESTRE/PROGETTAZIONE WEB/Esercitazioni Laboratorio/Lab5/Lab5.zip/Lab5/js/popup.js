GAMEOVER_POPUP_ID = 'gameoverPopup';
GAMEOVER_POPUP_CONTENT_ID= 'gameoverPopupContent' ;

function createNewBestScoreLabel(){
	var newHighScore = document.createElement('div');
	newHighScore.setAttribute('id', 'highScoreText');
	var newHighScoreText = document.createTextNode('NEW HIGH SCORE!!!');
	newHighScore.appendChild(newHighScoreText);	
	return newHighScore;
}

function createScoreLabel(){
	var scorePopup = document.createElement('div');	
	if (currentScore > bestScore)
		scorePopup.appendChild(createNewBestScoreLabel());
	
	var textScorePopup = document.createTextNode('Your score is: ' + currentScore);
	scorePopup.appendChild(textScorePopup);  
	return scorePopup;
}

function createCloseButtonPopup(){
	var closeButtonPopup = document.createElement("a");
	closeButtonPopup.setAttribute('onClick', 'closePopup()');
	return closeButtonPopup;
}


function createPopup(){
	var gameoverPopup = document.getElementById(GAMEOVER_POPUP_ID);
	if (gameoverPopup !== null)
		return;
		
	// create popup
	var gameoverPopup = document.createElement('div');		
	gameoverPopup.setAttribute('id', GAMEOVER_POPUP_ID);
	
	// create content of popup
	var content = document.createElement('div');		
	content.setAttribute('id', GAMEOVER_POPUP_CONTENT_ID);
	
	// Add content to content div
	content.appendChild(createCloseButtonPopup());
	content.appendChild(createScoreLabel());	
	
	// Add content and close button to the div
	gameoverPopup.appendChild(content);
	
	// Add all to the document
	document.body.appendChild(gameoverPopup);
} 

function closePopup(){
	var gameoverPopup = document.getElementById(GAMEOVER_POPUP_ID);
	if (gameoverPopup === null)
		return;
	
	document.body.removeChild(gameoverPopup);
}