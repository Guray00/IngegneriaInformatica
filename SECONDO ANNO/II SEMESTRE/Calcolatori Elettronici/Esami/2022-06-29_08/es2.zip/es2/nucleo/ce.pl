use threads;
use threads::shared;
use strict;
use JSON::XS;
use Data::Dumper;
use IO::Handle;
use Time::HiRes qw(usleep);
use Thread::Queue;

my $debug = 0;

my $ID = $ARGV[0];
my $NCHAN = $ARGV[1];
my $DEV = "ce$ID";

my ($in, $out, $ain, $aout);

open $in, "<", "$DEV.out";
open $out, ">", "$DEV.in";
open $ain, "<", "${DEV}a.out";
open $aout, ">", "${DEV}a.in";

$out->autoflush(1);
$aout->autoflush(1);

my $json = JSON::XS->new->allow_nonref;

my $config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 16,
			}
		],
		'interrupt-pin' => 2
	};


my $CHN = int(0);
my $iCHN = 0;
my $STS :shared = int(0);
my $iSTS = 4;
my $BMPTR = int(0);
my $iBMPTR = 8;
my $BMLEN = int(0);
my $iBMLEN = 12;
my $pend_intr :shared = 0;

my $dout;
if ($debug) {
	open $dout, ">", "debug.$ID";
	$dout->autoflush(1);
}

sub dbg {
	my $msg = shift;
	if ($debug) {
		printf $dout "$DEV: $msg", @_;
	}
}

sub send {
	my ($ch, $msg) = @_;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on $ch\n");
	if ($ch eq "sync") {
		print $out "$r\n";
	} else {
		print $aout "$r\n";
	}
	&dbg("### $0: done sending\n");
}

my $thr;
my $queue = Thread::Queue->new();

sub send_cmd {
	my ($c, $b, $l) = @_;
	&dbg("### $0: enqueing $c, $b, $l\n");
	$queue->enqueue("$c,$b,$l");
}

sub receive {
	my $ch = shift || "sync";
	my $i = \*$in;
	my $obj;
	if ($ch eq "async") {
		$i = \*$ain;
	}
	&dbg("### $0: receiving from $ch\n");
	while (<$i>) {
	       	if ($obj = $json->incr_parse($_)) {
			&dbg("<-" . Dumper($obj));
			return $obj;
		}
	}
	&dbg("### $0: exiting...\n");
	&stop_running;
	$thr->join();
	exit;
}

sub send_ret {
	my $arg = shift || 0;
	&send('sync', { return => int($arg)});
}

sub send_intr {
	lock($pend_intr);
	if (!$pend_intr) {
		&send('async', { "raise-irq" => 1 });
		&receive('async');
		$pend_intr = 1;
	}
}

sub clear_intr {
	lock($pend_intr);
	if ($pend_intr) {
		&send('async', { "lower-irq" => 1 });
		&receive('async');
		$pend_intr = 0;
	}
}

sub stop_running
{
	$queue->enqueue('-1');
}

sub process_cmd {
	my (@chans, @bmptr, @bmlen, @choff);

	for my $c (0 .. $NCHAN) {
		$choff[$c] = int($c);
	}

	while (1) {
		my $m = $queue->dequeue_nb();
		if (defined($m)) {
			&dbg("### $0: dequeued $m\n");
			# exit or start new channel
			my ($c, $b, $l) = split /,/, $m;
			if ($c < 0) {
				last;
			}
			if ($c < $NCHAN && $l > 0) {
				$bmptr[$c] = int($b);
				$bmlen[$c] = int($l);
				push @chans, $c;
			}
		}
		# process all active channels
		my @nextchans = ();
		while (@chans) {
			my $c = shift @chans;
			my $tosend = $bmlen[$c];
			if ($tosend > 1024) {
				$tosend = 1024;
			}
			my $beg = int($choff[$c]);
			my $end = $beg + $tosend - 1;
			&send('async', { 'dma-write' => { addr => $bmptr[$c], len => $tosend, bytes => [ map { $_ % 26 + 65 } $beg .. $end ]} });
			&receive('async');
			$choff[$c] = $end + 1;
			$bmptr[$c] += $tosend;
			$bmlen[$c] -= $tosend;
			if (!$bmlen[$c]) {
				lock($STS);
				$STS &= ~(1 << $c);
				&send_intr;
			} else {
				push @nextchans, $c;
			}
		}
		@chans = @nextchans;
		usleep(10000);
	}
}

$thr = threads->create(\&process_cmd);

while (1) {
	my $obj = &receive;
	if ($$obj{'get-config'}) {
		&send('sync', $config);
		&send_ret;
	} elsif (my $i = $$obj{'write'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		my $v = $i->{'val'};
		&dbg("### writing $v at $a\n");
		if      ($a == $iCHN) {
			$CHN = $v;
			# activate channel if not already active
			lock($STS);
			if ($STS & (1 << $v)) {
				next;
			}
			$STS |= (1 << $v);
			&send_cmd($v, $BMPTR, $BMLEN);
		} elsif ($a == $iSTS) {
			# readonly
		} elsif ($a == $iBMPTR) {
			$BMPTR = $v;
		} elsif ($a == $iBMLEN) {
			$BMLEN = $v;
		}
		&send_ret;
	} elsif (my $i = $$obj{'read'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		&dbg("### reading from $a\n");
		my $ret;
		if      ($a == $iCHN) {
			$ret = $CHN;
		} elsif ($a == $iSTS) {
			lock($STS);
			$ret = $STS;
			&clear_intr;
		} elsif ($a == $iBMPTR) {
			$ret = $BMPTR;
		} elsif ($a == $iBMLEN) {
			$ret = $BMLEN;
		}
		&send_ret($ret);
	}
}
