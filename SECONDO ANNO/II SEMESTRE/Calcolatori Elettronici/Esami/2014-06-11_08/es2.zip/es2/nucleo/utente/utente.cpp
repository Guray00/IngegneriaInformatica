#include <all.h>


extern natl pbarrier;
extern natl sync1;
extern natl sync2;
extern natl sync3;
void notreg(natq a)
{
	barrier();
	printf("processo errato %lu\n", a);
	terminate_p();
}

void b1(natq a)
{
	reg();
	sem_wait(sync1);
	barrier();
	printf("processo %lu\n", a);
	terminate_p();
}

void b2(natq a)
{
	reg();
	sem_wait(sync2);
	barrier();
	printf("processo %lu\n", a);
	terminate_p();
}

void b3(natq a)
{
	reg();
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	barrier();
	printf("processo %lu\n", a);
	pause();
	terminate_p();
}

void late(natq a)
{
	reg();
	printf("processo errato %lu\n", a);
	terminate_p();
}

void main_body(natq a)
{
	reg();

	activate_p(notreg, 1, 50, LIV_UTENTE);
	activate_p(b1, 1, 30, LIV_UTENTE);
	activate_p(b2, 2, 29, LIV_UTENTE);
	activate_p(b3, 3, 28, LIV_UTENTE);
	activate_p(late, 2, 10, LIV_UTENTE);
	sem_wait(sync3);
	barrier();

	terminate_p();
}
natl pbarrier;
natl sync1;
natl sync2;
natl sync3;

extern "C" void main()
{
	pbarrier = activate_p(main_body, 0, 100, LIV_UTENTE);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);

	terminate_p();
}
