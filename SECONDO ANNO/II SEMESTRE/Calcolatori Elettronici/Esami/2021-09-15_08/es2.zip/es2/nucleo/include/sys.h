/// @file sys.h
/// @brief Primitive comuni definite dal modulo sistema
///
/// Queste primitive possono essere usate sia dal modulo utente che
/// dal modulo I/O.

/// @name Primitive per la gestione dei processi
/// @{

/**
 * @brief Crea un nuovo processo
 *
 * Il nuovo processo eseguirà _f(a)_ con priorità _prio_ e a livello _liv_.
 *
 * Un processo non può usare questa primitiva per creare un processo a priorità
 * o livello maggiori dei propri.
 *
 * @param f		corpo del processo
 * @param a		parametro per il corpo del processo 
 * @param prio		priorità del processo 
 * @param liv		livello del processo (LIV_UTENTE o LIV_SISTEMA)
 *
 * @return 		id del nuovo processo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl activate_p(void f(natq), natq a, natl prio, natl liv);

/**
 * @brief Termina il processo corrente.
 *
 * I processi devono invocare questa primitiva per poter terminare.
 */
extern "C" void terminate_p();

/**
 * @brief Abortisce il processo corrente.
 *
 * Come terminate_p(), ma mostra lo stato del processo sul log.
 */
extern "C" void abort_p();

/// @}

/// @name Primitive per l'utilizzo dei semafori
/// @{

/**
 * @brief Crea un nuovo semaforo.
 *
 * @param val		numero di gettoni iniziali
 *
 * @return 		id del nuovo semaforo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl sem_ini(int val);

/**
 * @brief Estrae un gettone da un semaforo.
 *
 * @param sem		id del semaforo.
 */
extern "C" void sem_wait(natl sem);

/**
 * @brief Inserisce un gettone in un semaforo.
 *
 * @param sem		id del semaforo
 */
extern "C" void sem_signal(natl sem);

/// @}

/// @name Primitive per l'utilizzo del timer
/// @{

/**
 * @brief Sospende il processo corrente.
 *
 * @param n		numero di intervalli di tempo
 */
extern "C" void delay(natl n);

/// @}

/// @name Primitive di supporto al debugging
/// @{

/**
 * @brief Informazioni di debug
 *
 * Questa struttura contiene delle informazioni che sono usate nei testi d'esame
 * per eseguire alcuni controlli.
 */
struct meminfo {
	/// numero di byte liberi nello heap di sistema
	natl heap_libero;
	/// numero di frame liberi in M2
	natl num_frame_liberi;
	/// id del processo corrente
	natl pid;
};

/**
 * @brief Estrae informazioni di debug.
 *
 * @return		struttura contenente le informazioni
 */
extern "C" meminfo getmeminfo();

/**
 * @brief Invia un messaggio al log.
 *
 * Questa primitiva è usata dai moduli I/O e utente per inviare i propri
 * messaggi al log di sistema. 
 *
 * @note Il modulo sistema usa direttamente la do_log() definita in libce.
 *
 * @param sev		severità del messaggio
 * @param buf		buffer contenente il messaggio
 * @param quanti	lunghezza del messaggio
 */
extern "C" void do_log(log_sev sev, const char* buf, natl quanti);
/// @}

// ( ESAME 2021-09-15


/**
 * @brief	Crea una nuova msg-area con una view.
 * @pre 	Il numero di pagine non può essere zero.
 *
 * @param npag	dimensione della msg-area (in pagine)
 *
 * @return 	base della view, o nullptr in caso di errore
 */
extern "C" void*   macreate(natq npag);

/**
 * @brief 	Condivide una msg-area con un processo.
 *
 * Crea, nel processo destinatario, una nuova view per la msg-area
 * che è visibile, nel processo corrente, a partire dall'indirizzo _vv_.
 *
 * @pre		Il processo destinatario non deve essere di livello sistema.
 *
 * @param vv	indirizzo base di una view della msg-area da condividere
 * @param pid	id del processo con cui condividere
 *
 * @return 	indirizzo base della nuova view (nel processo destinatario),
 * 		o nullptr in caso di fallimento
 */
extern "C" void*   mashare(void *vv, natl pid);

/**
 * @brief 	Revoca la condivizione di una msg-area con un processo.
 *
 * Elimina dal processo destinatario tutte le view corrispondenti alla
 * msg-area visibile, nel processo corrente, a partire dall'indirizzo _vv_.
 *
 * Il processo destinatario può coincidere con il processo corrente.
 *
 * @param vv	indirizzo base di una view della msg-area da revocare
 * @param pid	id del processo a cui revocare
 *
 * @return 	true in caso di successo, false in caso di fallimento
 */
extern "C" bool    marevoke(void *vv, natl pid);
//   ESAME 2021-09-15 )
