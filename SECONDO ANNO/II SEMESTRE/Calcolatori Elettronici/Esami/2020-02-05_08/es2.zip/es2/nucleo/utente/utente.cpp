#include <all.h>

const int NSLAVES = 6;
const int NPROCS = 9;


extern natl first;

extern natl usr0;

extern natl usr1;

extern natl usr2;

extern natl usr3;

extern natl usr4;

extern natl usr5;

extern natl dbg0;

extern natl dbg1;

extern natl dbg2;

extern natl dbg5;

extern natl dbg6;

extern natl dbg7;

extern natl dbg9;

extern natl last;
extern natl sync0;
extern natl sync1;
extern natl sync2;
extern natl sync3;
extern natl sync4;
extern natl sync5;
extern natl sync6;
extern natl sync7;
extern natl sync8;
natl sems[NPROCS];
natl slaves[NSLAVES];
natq masters[NSLAVES];

int getallocdiff()
{
	return getmeminfo().heap_libero;
}

void first_body(natq a)
{
	sems[0] = sync0;
	sems[1] = sync1;
	sems[2] = sync2;
	sems[3] = sync3;
	sems[4] = sync4;
	sems[5] = sync5;
	sems[6] = sync6;
	sems[7] = sync7;
	sems[8] = sync8;
	slaves[0] = usr0;
	slaves[1] = usr1;
	slaves[2] = usr2;
	slaves[3] = usr3;
	slaves[4] = usr4;
	slaves[5] = usr5;
	masters[0] = 10;
	masters[1] = 10;
	masters[2] = 11;
	masters[3] = 11;
	masters[4] = 12;
	masters[5] = 12;

	terminate_p();
}
#define MSG(fmt, ...)	do { printf("proc %d: " fmt "\n", getpid(), ## __VA_ARGS__); } while (0)

int zero = 0;
int b;

void usr_div(natq a)
{
	sem_wait(sems[a]);
	MSG("eseguo 42/0");
	b = 42 / zero;
	MSG("sopravvissuto a divisione per zero");

	terminate_p();
}
void usr_pf(natq a)
{
	sem_wait(sems[a]);
	*(int *)0 = 0;

	terminate_p();
}
void usr_bp(natq a)
{
	sem_wait(sems[a]);
	MSG("termino normalmente");

	terminate_p();
}
void usr_prot(natq a)
{
	sem_wait(sems[a]);
	MSG("eseguo mov %%rax, %%cr3");
	asm("mov %rax, %cr3");
	MSG("sopravvissuto a scrittura in %%cr3");

	terminate_p();
}
void bad1(natq a)
{
	if (proc_attach(getpid())) {
		MSG("errore: proc_attach ricorsiva riuscita");
	}

	terminate_p();
}
void bad2(natq a)
{
	if (proc_attach(100)) {
		MSG("errore: proc_attach su processo non esistente riuscita");
	}

	terminate_p();
}
void bad3(natq a)
{
	proc_wait();
	MSG("errore: proc_wait() da non-master riuscita");

	terminate_p();
}
void bad5(natq a)
{
	if (proc_attach(a)) {
		MSG("errore: proc_attach() duplicata su slave riuscita");
	}

	terminate_p();
}
static const char *eccezioni[] = {
	"errore di divisione", 		// 0
	"debug",			// 1
	"interrupt non mascherabile",	// 2
	"breakpoint",			// 3
	"overflow",			// 4
	"bound check",			// 5
	"codice operativo non valido",	// 6
	"dispositivo non disponibile",	// 7
	"doppio fault",			// 8
	"coprocessor segment overrun",	// 9
	"TSS non valido",		// 10
	"segmento non presente",	// 11
	"errore sul segmento stack",	// 12
	"errore di protezione",		// 13
	"page fault",			// 14
	"riservato",			// 15
	"errore su virgola mobile",	// 16
	"errore di allineamento",	// 17
	"errore interno",		// 18
	"errore SIMD",			// 19
	"20??",
	"21??",
	"22??",
	"23??",
	"24??",
	"25??",
	"26??",
	"27??",
	"28??",
	"29??",
	"30??",
	"31??",
	"normale"
};

void debugger(natq a)
{
	int nslaves = 0;

	for (int i = 0; i < NSLAVES; i++) {
		if (masters[i] == a) {
			nslaves++;
			MSG("chiamo proc_attach(%d)", slaves[i]);
			if (!proc_attach(slaves[i])) {
				MSG("proc_attach(%d) fallita", slaves[i]);
				terminate_p();
			}
		}
	}
	for (int i = 0; i < nslaves; i++) {
		sem_wait(sems[a - 10 + NSLAVES]);
		natl v = proc_wait();
		if (v > 32) {
			MSG("codice terminazione non riconosciuto: %d", v);
		} else  {
			MSG("motivo terminazione: %s", eccezioni[v]);
		}
	}

	terminate_p();
}
void last_body(natq a)
{
	// proc_wait prima di entrambi
	sem_signal(sync6);
	sem_signal(sync0);
	sem_signal(sync6);
	sem_signal(sync1);
	// proc_wait alternata
	sem_signal(sync2);
	sem_signal(sync7);
	sem_signal(sync7);
	sem_signal(sync3);
	// proc_wait dopo entrambi
	sem_signal(sync4);
	sem_signal(sync5);
	sem_signal(sync8);
	sem_signal(sync8);

	printf("heap sistema disponibile: %d\n", getallocdiff());
	pause();

	terminate_p();
}
natl first;
natl usr0;
natl usr1;
natl usr2;
natl usr3;
natl usr4;
natl usr5;
natl dbg0;
natl dbg1;
natl dbg2;
natl dbg5;
natl dbg6;
natl dbg7;
natl dbg9;
natl last;
natl sync0;
natl sync1;
natl sync2;
natl sync3;
natl sync4;
natl sync5;
natl sync6;
natl sync7;
natl sync8;

extern "C" void main()
{
	first = activate_p(first_body, 0, 100, LIV_UTENTE);
	usr0 = activate_p(usr_div, 0, 20, LIV_UTENTE);
	usr1 = activate_p(usr_prot, 1, 21, LIV_UTENTE);
	usr2 = activate_p(usr_bp, 2, 22, LIV_UTENTE);
	usr3 = activate_p(usr_prot, 3, 23, LIV_UTENTE);
	usr4 = activate_p(usr_div, 4, 24, LIV_UTENTE);
	usr5 = activate_p(usr_bp, 5, 25, LIV_UTENTE);
	dbg0 = activate_p(debugger, 10, 40, LIV_UTENTE);
	dbg1 = activate_p(debugger, 11, 41, LIV_UTENTE);
	dbg2 = activate_p(debugger, 12, 42, LIV_UTENTE);
	dbg5 = activate_p(bad1, 20, 51, LIV_UTENTE);
	dbg6 = activate_p(bad2, 21, 52, LIV_UTENTE);
	dbg7 = activate_p(bad3, 22, 53, LIV_UTENTE);
	dbg9 = activate_p(bad5, usr1, 11, LIV_UTENTE);
	last = activate_p(last_body, 0, 1, LIV_UTENTE);
	sync0 = sem_ini(0);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);
	sync4 = sem_ini(0);
	sync5 = sem_ini(0);
	sync6 = sem_ini(0);
	sync7 = sem_ini(0);
	sync8 = sem_ini(0);

	terminate_p();
}
