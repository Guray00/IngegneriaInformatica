#include <all.h>


extern natl hello;
void loop(natq a)
{
	while (true)
		;
}

void good(natq a)
{
	printf("proc%lu: termino\n", a);
	terminate_p();
}

void last(natq a)
{
	pause();
	terminate_p();
}


void hello_body(natq a)
{
	newproc(loop, 0, 40, 1);
	newproc(good, 1, 35, 1);
	newproc(good, 2, 30, 1);
	newproc(good, 3, 25, 1);
	newproc(loop, 4, 20, 1);
	activate_p(last, 6, 5, LIV_UTENTE);

	terminate_p();
}
natl hello;

extern "C" void main()
{
	hello = activate_p(hello_body, 0, 50, LIV_UTENTE);

	terminate_p();
}
