#include <all.h>


extern natl bad1;

extern natl bad2;

extern natl usr1;

extern natl usr2;

extern natl usr3;

extern natl usr5;

extern natl usr8;

extern natl dbg1;

extern natl dbg2;

extern natl dbg3;

extern natl last;
extern natl sync;
extern natl sync2;
void bad(natq a)
{
	asm("int3");
	printf("processo errato %lu\n", a);

	terminate_p();
}
void catch_me(int a)
{
	printf("proc%d: eseguo funzione\n", a);
}

vaddr bad_addr[] = { 1000, 0xffffc00000000000 };

void badb(natq a)
{

	terminate_p();
}
void usr(natq a)
{
	if (a % 2 == 0) {
		sem_wait(sync);
	}
	printf("proc%lu: prima della funzione\n", a);
	catch_me(a);
	printf("proc%lu: dopo la funzione\n", a);

	terminate_p();
}
void debugger(natq a)
{
	printf("debugger %lu: chiamo bpadd\n", a);
	if (!bpadd(reinterpret_cast<natq>(catch_me))) {
		printf("debugger %lu: occupato\n", a);
	} else {
		for (int i = 0; i < 2; i++) {
			natl proc = bpwait();
			printf("debugger %lu: breapoint intercettato, processo: %d\n", a, proc);
			if (i == 0)
				sem_signal(sync);
		}
		if (a == 2)
			delay(10);
		bpremove();
	}

	terminate_p();
}
void last_body(natq a)
{
	pause();

	terminate_p();
}
natl bad1;
natl bad2;
natl usr1;
natl usr2;
natl usr3;
natl usr5;
natl usr8;
natl dbg1;
natl dbg2;
natl dbg3;
natl last;
natl sync;
natl sync2;

extern "C" void main()
{
	bad1 = activate_p(bad, 1, 40, LIV_UTENTE);
	bad2 = activate_p(bad, 2, 16, LIV_UTENTE);
	usr1 = activate_p(usr, 1, 10, LIV_UTENTE);
	usr2 = activate_p(usr, 2, 30, LIV_UTENTE);
	usr3 = activate_p(usr, 3, 6, LIV_UTENTE);
	usr5 = activate_p(usr, 5, 5, LIV_UTENTE);
	usr8 = activate_p(usr, 8, 9, LIV_UTENTE);
	dbg1 = activate_p(debugger, 0, 20, LIV_UTENTE);
	dbg2 = activate_p(debugger, 1, 22, LIV_UTENTE);
	dbg3 = activate_p(debugger, 2, 8, LIV_UTENTE);
	last = activate_p(last_body, 0, 1, LIV_UTENTE);
	sync = sem_ini(0);
	sync2 = sem_ini(0);

	terminate_p();
}
