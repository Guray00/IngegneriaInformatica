#include <all.h>


extern natl bad1;

extern natl bad2;

extern natl usr1;

extern natl usr2;

extern natl usr3;

extern natl dbg1;

extern natl dbg2;

extern natl last;
extern natl sync;
extern natl sync2;
natq nframes;

#define MSG(fmt, ...)	do { printf("proc %u: " fmt "\n", getpid(), ## __VA_ARGS__); } while (0)

void bad(natq a)
{
	asm("int3");
	MSG("processo errato");

	terminate_p();
}
void catch_me(natq a)
{
	MSG("eseguo catch_me(%lu)", a);
}

vaddr bad_addr[] = { 1000, 0xffffc00000000000 };

void badb(natq a)
{

	terminate_p();
}
void usr(natq a)
{
	for (natq i = 0; i < a; i++) {
		MSG("prima di catch_me()");
		catch_me(i);
		MSG("dopo catch_me()");
	}

	terminate_p();
}
void debugger(natq a)
{
	MSG("debugger di %lu: chiamo bpadd", a);
	if (!bpattach(a, reinterpret_cast<natq>(catch_me))) {
		MSG("debugger di %lu: occupato", a);
	} else {
		bpwait();
		MSG("debugger di %lu: breapoint intercettato", a);
		bpdetach();
	}

	terminate_p();
}
void last_body(natq a)
{
	printf("frame liberi: %d\n", getmeminfo().num_frame_liberi);
	pause();

	terminate_p();
}
natl bad1;
natl bad2;
natl usr1;
natl usr2;
natl usr3;
natl dbg1;
natl dbg2;
natl last;
natl sync;
natl sync2;

extern "C" void main()
{
	bad1 = activate_p(bad, 1, 40, LIV_UTENTE);
	bad2 = activate_p(bad, 2, 16, LIV_UTENTE);
	usr1 = activate_p(usr, 1, 10, LIV_UTENTE);
	usr2 = activate_p(usr, 1, 15, LIV_UTENTE);
	usr3 = activate_p(usr, 2, 6, LIV_UTENTE);
	dbg1 = activate_p(debugger, usr1, 20, LIV_UTENTE);
	dbg2 = activate_p(debugger, usr3, 22, LIV_UTENTE);
	last = activate_p(last_body, 0, 1, LIV_UTENTE);
	sync = sem_ini(0);
	sync2 = sem_ini(0);

	terminate_p();
}
