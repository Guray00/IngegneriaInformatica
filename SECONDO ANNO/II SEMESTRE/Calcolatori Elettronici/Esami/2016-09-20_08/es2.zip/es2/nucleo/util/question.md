Introduciamo un meccanismo di *broadcast* tramite il quale un processo
può inviare un messagio ad un insieme di processi. Per ricevere un
broadcast i processi si devono preventivamente registrare. Un processo
può inviare un brodcast tramite la primitiva `broadcast(msg)`, la quale
attende anche che tutti i processi che risultano registrati ricevano il
messaggio. Un processo registrato può ricevere un broadcast invocando la
primitiva `listen()`, che attende che sia disponibile il prossimo
messaggio.

Per realizzare i broadcast introduciamo la seguente struttura dati:

        struct broadcast {
            int registered;
            int nlisten;
            natl msg;
            des_proc *listeners;
            des_proc *broadcaster;
        };

Dove: `registered` è il numero di processi registrati; `nlisten` conta i
processi che hanno invocato `listen()` dall'ultimo completamento di una
operazione di broadcast; `msg` contiene l'ultimo messaggio di broadcast;
`listeners` è la coda dei processi in attesa del prossimo messaggio;
`broadcaster` è la coda in cui attende il processo che vuole inviare il
broadcast, in attesa che tutti i processi registrati invochino
`listen()`.

Aggiungiamo inoltre le seguenti primitive (abortiscono il processo in
caso di errore):

-   `void reg()` (tipo 0x2a, già realizzata): registra il processo per
    la ricezione dei broadcast; non fa niente se il processo è già
    registrato;

-   `natl listen()` (tipo 0x2b, da realizzare): riceve il prossimo
    messagio di broadcast; è un errore se il processo non è registrato;

-   `void broadcast(natl msg)` (tipo 0x2c, da realizzare): invia in
    broadcast il messaggio `msg`; è un errore se il processo è
    registrato.

Le primitive tengono conto della priorità tra i processi.

Per semplicità si assuma che, durante tutta la sua esecuzione, ogni
processo provi al più una sola volta a inviare un broadcast o ad
ascoltare un messaggio. Inoltre, al più un processo alla volta tenta di
eseguire un broadcast.

Modificare i file `sistema.cpp` e `sistema.S` in modo da realizzare le
primitive mancanti.
