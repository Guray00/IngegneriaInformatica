#include <all.h>


extern natl pbarrier;
extern natl sync1;
extern natl sync2;
extern natl sync3;
void notreg(natq a)
{
	listen();
	printf("processo errato %lu\n", a);
	terminate_p();
}

void breg(natq a)
{
	reg();
	broadcast(1);
	printf("processo errato %lu\n", a);
	terminate_p();
}

void l1(natq a)
{
	reg();
	sem_signal(sync1);
	natl m = listen();
	printf("processo %lu mess %u\n", a, m);
	sem_signal(sync3);
	terminate_p();
}

void l2(natq a)
{
	reg();
	sem_signal(sync2);
	natl m = listen();
	printf("processo %lu mess %u\n", a, m);
	sem_signal(sync3);
	terminate_p();
}

void b3(natq a)
{
	sem_wait(sync1);
	sem_wait(sync2);
	broadcast(a + 100);
	printf("processo %lu\n", a);
	sem_signal(sync3);
	terminate_p();
}

void main_body(natq a)
{
	activate_p(notreg, 1, 50, LIV_UTENTE);
	activate_p(breg, 1, 51, LIV_UTENTE);
	activate_p(l1, 1, 30, LIV_UTENTE);
	activate_p(l2, 2, 29, LIV_UTENTE);
	activate_p(b3, 3, 28, LIV_UTENTE);
	for (int i = 0; i < 3; i++)
		sem_wait(sync3);
	activate_p(l1, 4, 27, LIV_UTENTE);
	activate_p(b3, 5, 26, LIV_UTENTE);
	activate_p(l2, 6, 25, LIV_UTENTE);
	for (int i = 0; i < 3; i++)
		sem_wait(sync3);
	activate_p(b3, 7, 24, LIV_UTENTE);
	activate_p(l1, 8, 23, LIV_UTENTE);
	activate_p(l2, 9, 22, LIV_UTENTE);
	for (int i = 0; i < 3; i++)
		sem_wait(sync3);
	pause();

	terminate_p();
}
natl pbarrier;
natl sync1;
natl sync2;
natl sync3;

extern "C" void main()
{
	pbarrier = activate_p(main_body, 0, 100, LIV_UTENTE);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);

	terminate_p();
}
