Vogliamo aggiungere al nucleo il meccanismo dei *segnali*. Un qualunque
processo può inviare un segnale ad un altro processo (di livello utente)
di cui conosce l'identificatore. I segnali sono caratterizzati da un
*tipo*, dove il tipo è un numero che va da 0 a $\mathit{MAX\_SEGNALI}$.
Ogni processo di livello utente può associare un *gestore* diverso per
ciascun tipo di segnale, dove per gestore si intende una qualunque
funzione `void` e senza argomenti. Definiamo per comodità il seguente
tipo per i puntatori a gestore:

        typedef void (*gestore)();

(Puntatore a una funzione senza argomenti che non restituisce niente).
Il gestore associato ad un certo segnale verrà eseguito dal processo
ogni volta che il segnale viene ricevuto. Se il processo non aveva
associato alcun gestore a quel segnale, il segnale viene ignorato.

Per realizzare tale meccanismo procediamo come segue. Supponiamo che il
processo $P$ invii un segnale al processo utente $Q$, che vi aveva
associato il gestore $g$. In fondo alla pila sistema di $Q$ troveremo le
5 parole quadruple che permettono a $Q$ di tornare al punto del codice
di livello utente che stava eseguendo prima di interrompersi. Per fare
in modo che $Q$ esegua il gestore $g$, modifichiamo queste parole
quadruple (salvandone il vecchio valore) in modo che $Q$ salti alla
prima istruzione di $g$ la prossima volta che tornerà a livello utente.
Il gestore $g$, prima di terminare, dovrà chiamare una particolare
primitiva che ripristini il valore precedentemente salvato per le 5
parole quadruple, in modo che al ritorno dalla primitiva stessa $Q$
ritorni al punto in cui si trovava prima di ricevere il segnale. (Per
permettere un corretto ritorno, salviamo e ripristiniamo l'intero
stato). Per svolgere le operazioni appena descritte aggiungiamo le
seguenti funzioni di utilità:

-   `void salva_ritorno(natl id)`: salva lo stato corrente del processo
    `id`.

-   `void forza_ritorno(natl id, gestore g)`: cambia lo stato del
    processo `id` in modo da fargli eseguire il gestore `g`.

-   `void ripristina_ritorno(natl id)`: ripristina lo stato salvato da
    `salva_ritorno(id)`.

Si noti che $Q$ potrebbe ricevere più di un segnale prima di avere
l'opportunità di eseguire un gestore, quindi dobbiamo tener conto dei
segnali pendenti. Per semplificare l'implementazione stabiliamo che ci
possa essere al più un segnale pendente per ogni tipo di segnale (se
viene ricevuto un segnale di un tipo che era già pendente il nuovo
segnale viene ignorato). Stabiliamo inoltre una priorità tra i segnali,
data dall'ordine numerico del loro tipo: 0 è la priorità massima e
$\mathit{MAX\_SEGNALI} - 1$ la minima. All'invio di un segnale eseguiamo
le operazioni di salvataggio solo se non c'erano già altri segnali
pendenti, e forziamo il nostro gestore solo se il nostro segnale è
quello a priorità massima; al termine di un gestore bisogna controllare
se ci sono altri segnali pendenti (nel qual caso andrà eseguito il
gestore a priorità massima tra questi) oppure no (nel qual caso bisogna
ripristinare lo stato salvato).

Aggiungiamo i seguenti campi al descrittore di ogni processo:

            gestore gest[MAX_SEGNALI];
            bool    pendenti[MAX_SEGNALI];
            //    salva_contesto

Il campo `gest` è mantiene l'associazione tra tipo di segnale e gestore
(`nullptr` se nessun gestore è stato associato ad un particolare tipo).
Il campo `pendenti` tiene traccia dei segnali ricevuti e non ancora
gestiti, per ogni tipo di segnale. Il campo `salva_contesto` contiene lo
stato salvato da `salva_ritorno()`.

Aggiungiamo infine le seguenti primitive (in caso di errore abortiscono
il processo):

-   `void gestisci(natl signo, gestore gest)` (già realizzata): associa
    il gestore `gest` al segnale di tipo `signo`. Azzera eventuali
    segnali pendenti di quel tipo. (`gest` può essere $0$).

-   `bool segnala(natl signo, natl id)`: Invia un nuovo segnale di tipo
    `signo` al processo di identificatore `id`. Se tale processo non
    esiste o non ha associato un gestore, non fa altro. Se il processo
    `id` non esiste restituisce `false`, altrimenti restituisce `true`.
    È un errore se il processo di identificatore `id` non è un processo
    di livello utente. È un errore se `signo` non è minore di
    $\mathit{MAX\_SEGNALI}$.

-   `void termina_gestore(natl signo)`: Primitiva che deve essere
    chiamata dai gestori di segnali di tipo `signo` prima di terminare.
    È un errore se la primitiva viene chiamata senza che ci siano
    segnali di tipo `signo` pendenti.

Modificare i file `sistema.cpp` e `sistema.s` in modo da realizzare le
primitive mancanti.
