/// @file io.cpp
/// @brief Parte C++ del modulo I/O
/// @addtogroup io Modulo I/O
///
/// Dispensa: <https://calcolatori.iet.unipi.it/resources/modulo-io.pdf>
///
/// @{
#include <costanti.h>
#include <libce.h>
#include <sys.h>
#include <sysio.h>
#include <io.h>

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ioheap		Memoria Dinamica
/// @brief Funzioni per l'utilizzo dello heap da parte del modulo I/O
///
/// Dal momento che le funzioni del modulo I/O sono eseguite con le interruzioni
/// esterne mascherabili abilitate, dobbiamo proteggere lo heap I/O con un
/// semaforo di mutua esclusione.
///
/// @{
////////////////////////////////////////////////////////////////////////////////

/// Indice del semaforo di mutua esclusione per lo heap I/O
natl ioheap_mutex;

/*! @brief Alloca un oggetto nello heap I/O.
 *  @param s		dimensione dell'oggetto
 *  @return		puntatore all'oggetto (nullptr se heap esaurito)
 */
void* operator new(size_t s)
{
	void* p;

	sem_wait(ioheap_mutex);
	p = alloc(s);
	sem_signal(ioheap_mutex);

	return p;
}

/*! @brief Alloca un oggetto nello heap I/O, con vincoli di allineamento.
 *  @param s		dimensione dell'oggetto
 *  @param a		allineamento richiesto
 *  @return		puntatore all'oggetto (nullptr se heap esaurito)
 *
 *  Lo heap del modulo I/O si trova in memoria virtuale (parte I/O condivisa),
 *  quindi non possiamo garantire allineamenti maggiori di DIM_PAGINA.
 *  In quel caso ricorriamo a phys_alloc(), che usa lo heap del modulo sistema.
 */
void* operator new(size_t s, std::align_val_t a)
{
	void* p;

	if (static_cast<natq>(a) > DIM_PAGINA)
		return phys_alloc(s, a);

	sem_wait(ioheap_mutex);
	p = alloc_aligned(s, a);
	sem_signal(ioheap_mutex);
	return p;
}

/*! @brief Dealloca un oggetto restituendolo all'heap I/O.
 *  @param p		puntatore all'oggetto
 */
void operator delete(void* p)
{
	sem_wait(ioheap_mutex);
	dealloc(p);
	sem_signal(ioheap_mutex);
}

/**
 * @brief Dealloca un oggetto con vincoli di allineamento.
 *
 * @param p		puntatore all'oggetto
 * @param a		allineamento dell'oggetto
 */
void operator delete(void *p, std::align_val_t a)
{
	if (static_cast<natq>(a) > DIM_PAGINA)
		return phys_dealloc(p);

	sem_wait(ioheap_mutex);
	dealloc(p);
	sem_signal(ioheap_mutex);
}
/// @}

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup console 		Console
/// @brief Primitive per l'utilizzo di tastiera e video
///
/// @note consideriamo esclusivamente il caso di video in modalità testo.
///
/// @{
////////////////////////////////////////////////////////////////////////////////

/// Descrittore della console
struct des_console {
	/// Semaforo di mutua esclusione per l'accesso alla console
	natl mutex;
	/// Semafor di sincronizzazione (per le letture da tastiera)
	natl sincr;
	/// Dove scrivere il prossimo carattere letto
	char* punt;
	/// Quanti caratteri resta da leggere
	natq cont;
	/// Dimensione del buffer passato a @ref readconsole()
	natq dim;
};

/// Unica istanza di des_console
des_console console;

/// @addtogroup consolesyscall Parti C++/Assembler delle primitive
/// @{

/*! @brief Parte C+++ della primitiva writeconsole()
 *  @param buff		buffer contenente i caratteri da scrivere
 *  @param quanti	numero di caratteri da scrivere
 */
extern "C" void c_writeconsole(const char* buff, natq quanti)
{
	des_console* p_des = &console;

	if (!access(buff, quanti, false, false)) {
		flog(LOG_WARN, "writeconsole: parametri non validi: %p, %lu:", buff, quanti);
		abort_p();
	}

	sem_wait(p_des->mutex);
#ifndef AUTOCORR
	for (natq i = 0; i < quanti; i++)
		vid::char_write(buff[i]);
#else /* AUTOCORR */
	if (quanti > 0 && buff[quanti - 1] == '\n')
		quanti--;
	if (quanti > 0)
		flog(LOG_USR, "%.*s", static_cast<int>(quanti), buff);
#endif /* AUTOCORR */
	sem_signal(p_des->mutex);
}
/// @}

/*! @brief Avvia una operazione di lettura dalla tastiera
 *  @param d		descrittore della console
 *  @param buff		buffer che deve ricevere i caratteri
 *  @param dim		dimensione di _buff_
 */
void startkbd_in(des_console* d, char* buff, natq dim)
{
	d->punt = buff;
	d->cont = dim;
	d->dim  = dim;
	kbd::enable_intr();
}

/// @addtogroup consolesyscall
/// @{

/*! @brief Parte C++ della primitiva readconsole()
 *  @param buff		buffer che deve ricevere i caratteri letti
 *  @param quanti	dimensione di _buff_
 *  @return		numero di caratteri effettivamente letti
 */
extern "C" natq c_readconsole(char* buff, natq quanti)
{
	des_console* d = &console;
	natq rv;

	if (!access(buff, quanti, true)) {
		flog(LOG_WARN, "readconsole: parametri non validi: %p, %lu:", buff, quanti);
		abort_p();
	}

#ifdef AUTOCORR
	return 0;
#endif

	if (!quanti)
		return 0;

	sem_wait(d->mutex);
	startkbd_in(d, buff, quanti);
	sem_wait(d->sincr);
	rv = d->dim - d->cont;
	sem_signal(d->mutex);
	return rv;
}
/// @}

/// Processo esterno associato alla tastiera
void estern_kbd(natq)
{
	des_console* d = &console;
	char a;
	bool fine;

	for(;;) {
		kbd::disable_intr();

		a = kbd::char_read_intr();

		fine = false;
		switch (a) {
		case 0:
			break;
		case '\b':
			if (d->cont < d->dim) {
				d->punt--;
				d->cont++;
				vid::str_write("\b \b");
			}
			break;
		case '\r':
		case '\n':
			fine = true;
			*d->punt = '\0';
			vid::str_write("\r\n");
			break;
		default:
			*d->punt = a;
			d->punt++;
			d->cont--;
			vid::char_write(a);
			if (d->cont == 0) {
				fine = true;
			}
			break;
		}
		if (fine)
			sem_signal(d->sincr);
		else
			kbd::enable_intr();
		wfi();
	}
}

/// @addtogroup consolesyscall
/// @{

/*! @brief Parte C++ della primitiva iniconsole()
 *  @param cc		Attributo colore per il video
 */
extern "C" void c_iniconsole(natb cc)
{
	vid::clear(cc);
}
/// @}

/// Piedino dell'APIC per le richieste di interruzione della tastiera
const int KBD_IRQ = 1;

/*! @brief Inizializza la tastiera
 *  @return		true in caso di successo, false altrimenti
 */
bool kbd_init()
{
	// blocchiamo subito le interruzioni generabili dalla tastiera
	kbd::disable_intr();

	// svuotiamo il buffer interno della tastiera
	kbd::drain();

	if (activate_pe(estern_kbd, 0, MIN_EXT_PRIO + INTR_TIPO_KBD, LIV_SISTEMA, KBD_IRQ) == 0xFFFFFFFF) {
		flog(LOG_ERR, "kbd: impossibile creare estern_kbd");
		return false;
	}
	flog(LOG_INFO, "kbd: tastiera inizializzata");
	return true;
}

/*! @brief Inizializza il video (modalità testo)
 *  @return		true in caso di successo, false altrimenti
 */
bool vid_init()
{
	vid::clear(0x07);
	flog(LOG_INFO, "vid: video inizializzato");
	return true;
}

/*! @brief Inizializza la console (tastiera + video)
 *  @return		true in caso di successo, false altrimenti
 */
bool console_init()
{
	des_console* d = &console;

	if ( (d->mutex = sem_ini(1)) == 0xFFFFFFFF) {
		flog(LOG_ERR, "console: impossibile creare mutex");
		return false;
	}
	if ( (d->sincr = sem_ini(0)) == 0xFFFFFFFF) {
		flog(LOG_ERR, "console: impossibile creare sincr");
		return false;
	}
	return kbd_init() && vid_init();
}
/// @}

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ata 		Interfacce ATA
/// @brief Primitive per l'utilizzo dell'hard disk
/// @{
////////////////////////////////////////////////////////////////////////////////

// ( ESAME 2023-02-15


/// Descrittore di un elemento della buffer cache
struct buf_des {
	/// id del blocco contenuto in buf_des::buf (se buf_des::full è true)
	natl block;
	/// true se buf_des::buf contiene dati validi
	bool full;
	int next,	///< indice del prossimo buffer nella coda LRU
	    prev;	///< indice del buffer precedente nella coda LRU
	/// copia del blocco con id buf_des::block (se buf_des::full è true)
	natb buf[DIM_BLOCK];
	/// true se il buffer è stato modificato rispetto alla copia sull hard disk
	bool dirty;
};
//   ESAME 2023-02-15 )

/// Descrittore di interfaccia ATA
struct des_ata {
	/// Ultimo comando inviato all'interfaccia
	natb comando;
	/// Indice di un semaforo di mutua esclusione
	natl mutex;
	/// Indice di un semaforo di sincronizzazione
	natl sincr;
	/// Quanti settori resta da leggere o scrivere
	natb cont;
	/// Da dove leggere/dove scrivere il prossimo settore
	natb* punt;
	/// Array dei descrittori per il Bus Mastering
	natl* prd;

// ( ESAME 2023-02-15


	/// buffer cache
	buf_des bufcache[MAX_BUF_DES];
	int lru,	///< indice del prossimo buffer da rimpiazzare
	    mru;	///< indice del buffer acceduto più di recente
	natl rd_count;	///< non usare: solo per debug e test
	natl wr_count;	///< non usare: solo per debug e test
//   ESAME 2023-02-15 )
};

/// Descrittore dell'unico hard disk installato nel sistema
des_ata hard_disk;

// ( ESAME 2023-02-15


/**
 * @brief 	Promuove un buffer nella coda LRU.
 *
 * La funzione mette il buffer in coda alla lista lru (facendolo quindi
 * diventare l'mru), eventualmente estraendolo dalla sua posizione corrente.
 *
 * @param b	descrittore del buffer da promuovere
 */
void bufcache_promote(buf_des *b)
{
	des_ata *d = &hard_disk;
	int i = b - d->bufcache;

	if (b->next >= 0 || b->prev >= 0) {
		// d era già in lista: estraiamolo
		if (b->next >= 0)
			d->bufcache[b->next].prev = b->prev;
		else
			d->mru = b->prev;
		if (b->prev >= 0)
			d->bufcache[b->prev].next = b->next;
		else
			d->lru = b->next;
	}
	if (d->mru >= 0)
		d->bufcache[d->mru].next = i;
	else
		d->lru = i;
	b->prev = d->mru;
	b->next = -1;
	d->mru = i;
}

/// Non usare: serve al programma di test.
extern "C" int c_bufcache_status(natl *blocks, natl *read_count, natl *write_count)
{
	if (   (blocks      && !access(blocks, sizeof(*blocks) * MAX_BUF_DES, true, false))
	    || (read_count  && !access(read_count, sizeof(*read_count), true, false))
	    || (write_count && !access(write_count, sizeof(*write_count), true, false))
	   ) {
		flog(LOG_WARN, "bufcache_status: puntatore non valido");
		abort_p();
	}

	des_ata *d = &hard_disk;
	int c = 0;
	sem_wait(d->mutex);
	for (int i = 0; i < MAX_BUF_DES; i++) {
		buf_des *b = &d->bufcache[i];
		if (b->full) {
			if (blocks)
				blocks[c] = b->block;
			c++;
		}
	}
	if (read_count)
		*read_count = d->rd_count;
	if (write_count)
		*write_count = d->wr_count;
	sem_signal(d->mutex);
	return c;
}

/**
 * @brief 	Cerca un blocco nella buffer cache.
 *
 * @param block	id del blocco da cercare
 *
 * @return 	puntatore al descrittore di buffer, o nullprt se non trovato
 */
buf_des* bufcache_search(natl block)
{
	des_ata *d = &hard_disk;

	for (int i = 0; i < MAX_BUF_DES; i++) {
		buf_des *b = &d->bufcache[i];
		if (b->full && b->block == block)
			return b;
	}
	return nullptr;
}

// forward
void starthd_out(des_ata *d, natb vetto[], natl primo, natb quanti);
//   ESAME 2023-02-15 )
/// Piedino dell'APIC per le richieste di interruzione dell'hard disk
const natb HD_IRQ = 14;

/*! @brief Prepara i descrittori per il Bus Mastering
 *  @param d		descrittore dell'hard disk
 *  @param vett		buffer coinvolto nel trasferimento DMA
 *  @param quanti	numero di settori da trasferire
 *  @return		false se i PRD non sono sufficienti per
 *  			trasferire tutti i byte richiesti,
 *  			true altrimenti
 */
bool prepare_prd(des_ata *d, natb* vett, natb quanti)
{
	natq n = quanti * DIM_BLOCK;
	int i = 0;

	while (n && i < MAX_PRD) {
		paddr p = trasforma(vett);
		natq  r = DIM_PAGINA - (p % DIM_PAGINA);
		if (r > n)
			r = n;
		d->prd[i] = p;
		d->prd[i + 1] = r;

		n -= r;
		vett += r;
		i += 2;
	}
	if (n)
		return false;
	d->prd[i - 1] |= 0x80000000;
	return true;
}

/*! @brief Avvia una operazione di ingresso dall'hard disk.
 *  @param d		descrittore dell'hard disk
 *  @param vetti	buffer che dovrà ricevere i settori letti
 *  @param primo	LBA del primo settore da leggere
 *  @param quanti	numero di settori da leggere
 */
void starthd_in(des_ata* d, natb vetti[], natl primo, natb quanti)
{
	d->cont = quanti;
	d->punt = vetti;
	d->comando = hd::READ_SECT;
	hd::start_cmd(primo, quanti, hd::READ_SECT);
}

/// @addtogroup atasyscall Parti C++/Assembler delle primitive
/// @{

/*! @brief Parte C++ della primitiva readhd_n().
 *  @param vetti	buffer che dovrà ricevere i settori letti
 *  @param primo	LBA del primo settore da leggere
 *  @param quanti	numero di settori da leggere
 */
extern "C" void c_readhd_n(natb vetti[], natl primo, natb quanti)
{
	des_ata* d = &hard_disk;

	if (!access(vetti, quanti * DIM_BLOCK, true)) {
		flog(LOG_WARN, "readhd_n: parametri non validi: %p, %d", vetti, quanti);
		abort_p();
	}

	if (!quanti)
		return;

	sem_wait(d->mutex);
	starthd_in(d, vetti, primo, quanti);
	sem_wait(d->sincr);
	sem_signal(d->mutex);
}
/// @}

/*! @brief Avvia una operazione di uscita verso l'hard disk.
 *  @param d		descrittore dell'hard disk
 *  @param vetto	buffer che contiene i settori da scrivere
 *  @param primo	LBA del primo settore da scrivere
 *  @param quanti	numero di settori da scrivere
 */
void starthd_out(des_ata* d, natb vetto[], natl primo, natb quanti)
{
	d->cont = quanti;
	d->punt = vetto + DIM_BLOCK;
	d->comando = hd::WRITE_SECT;
	hd::start_cmd(primo, quanti, hd::WRITE_SECT);
	hd::output_sect(vetto);
}

/// @addtogroup atasyscall Parti C++/Assembler delle primitive
/// @{

/*! @brief Parte C++ della primitiva writehd_n().
 *  @param vetto	buffer che contiene i settori da scrivere
 *  @param primo	LBA del primo settore da scrivere
 *  @param quanti	numero di settori da scrivere
 */
extern "C" void c_writehd_n(natb vetto[], natl primo, natb quanti)
{
	des_ata* d = &hard_disk;

	if (!access(vetto, quanti * DIM_BLOCK, false)) {
		flog(LOG_WARN, "writehd_n: parametri non validi: %p, %d", vetto, quanti);
		abort_p();
	}

	if (!quanti)
		return;

	sem_wait(d->mutex);
	starthd_out(d, vetto, primo, quanti);
	sem_wait(d->sincr);
	sem_signal(d->mutex);
}
/// @}

/*! @brief Avvia una operazione di ingresso in DMA dall'hard disk.
 *  @param d		descrittore dell'hard disk
 *  @param vetti	buffer che dovrà ricevere i settori letti
 *  @param primo	LBA del primo settore da leggere
 *  @param quanti	numero di settori da leggere
 */
void dmastarthd_in(des_ata* d, natb vetti[], natl primo, natb quanti)
{
	if (!prepare_prd(d, vetti, quanti)) {
		flog(LOG_ERR, "dmastarthd_in: numero di PRD insufficiente");
		sem_signal(d->sincr);
		return;
	}

	d->comando = hd::READ_DMA;
	d->cont = 1;
	paddr prd = trasforma(d->prd);
	bm::prepare(prd, false);
	hd::start_cmd(primo, quanti, hd::READ_DMA);
	bm::start();
}

/// @addtogroup atasyscall Parti C++/Assembler delle primitive
/// @{

/*! @brief Parte C++ della primitiva dmareadhd_n().
 *  @param vetti	buffer che dovrà ricevere i settori letti
 *  @param primo	LBA del primo settore da leggere
 *  @param quanti	numero di settori da leggere
 */
extern "C" void c_dmareadhd_n(natb vetti[], natl primo, natb quanti)
{
	des_ata* d = &hard_disk;

	if (quanti * DIM_BLOCK > MAX_PRD * DIM_PAGINA) {
		flog(LOG_WARN, "readhd_n: quanti %d troppo grande", quanti);
		abort_p();
	}

	if (!access(vetti, quanti * DIM_BLOCK, true)) {
		flog(LOG_WARN, "dmareadhd_n: parametri non validi: %p, %d", vetti, quanti);
		abort_p();
	}

	if (!quanti)
		return;

	sem_wait(d->mutex);
	dmastarthd_in(d, vetti, primo, quanti);
	sem_wait(d->sincr);
	sem_signal(d->mutex);
}
/// @}

/*! @brief Avvia una operazione di uscita in DMA verso l'hard disk.
 *  @param d		descrittore dell'hard disk
 *  @param vetto	buffer che contiene i settori da scrivere
 *  @param primo	LBA del primo settore da scrivere
 *  @param quanti	numero di settori da scrivere
 */
void dmastarthd_out(des_ata* d, natb vetto[], natl primo, natb quanti)
{
	if (!prepare_prd(d, vetto, quanti)) {
		flog(LOG_ERR, "dmastarthd_out: numero di PRD insufficiente");
		sem_signal(d->sincr);
		return;
	}

	d->comando = hd::WRITE_DMA;
	d->cont = 1; 				// informazione per il driver
	paddr prd = trasforma(d->prd);
	bm::prepare(prd, true);
	hd::start_cmd(primo, quanti, hd::WRITE_DMA);
	bm::start();
}

/// @addtogroup atasyscall Parti C++/Assembler delle primitive
/// @{

/*! @brief Parte C++ della primitiva dmawritehd_n().
 *  @param vetto	buffer che contiene i settori da scrivere
 *  @param primo	LBA del primo settore da scrivere
 *  @param quanti	numero di settori da scrivere
 */
extern "C" void c_dmawritehd_n(natb vetto[], natl primo, natb quanti)
{
	des_ata* d = &hard_disk;

	if (quanti * DIM_BLOCK > MAX_PRD * DIM_PAGINA) {
		flog(LOG_WARN, "readhd_n: quanti %d troppo grande", quanti);
		abort_p();
	}

	if (!access(vetto, quanti * DIM_BLOCK, false)) {
		flog(LOG_WARN, "dmawritehd_n: parametri non validi: %p, %d", vetto, quanti);
		abort_p();
	}

	if (!quanti)
		return;

	sem_wait(d->mutex);
	dmastarthd_out(d, vetto, primo, quanti);
	sem_wait(d->sincr);
	sem_signal(d->mutex);
}
/// @}

/// Processo esterno per le richieste di interruzione dell'hard disk
void estern_hd(natq)
{
	des_ata* d = &hard_disk;
	for(;;) {
		d->cont--;
		hd::ack();
		switch (d->comando) {
		case hd::READ_SECT:
// [ ESAME 2023-02-15
			// solo per debug e test
			d->rd_count++;
//   ESAME 2023-02-15 ]
			hd::input_sect(d->punt);
			d->punt += DIM_BLOCK;
			break;
		case hd::WRITE_SECT:
// [ ESAME 2023-02-15
			// solo per debug e test
			d->wr_count++;
//   ESAME 2023-02-15 ]
			if (d->cont != 0) {
				hd::output_sect(d->punt);
				d->punt += DIM_BLOCK;
			}
			break;
		case hd::READ_DMA:
// [ ESAME 2023-02-15
			// solo per debug e test
			d->rd_count++;
			bm::ack();
			break;
//   ESAME 2023-02-15 ]
		case hd::WRITE_DMA:
// [ ESAME 2023-02-15
			// solo per debug e test
			d->wr_count++;
//   ESAME 2023-02-15 ]
			bm::ack();
			break;
		}
		if (d->cont == 0)
			sem_signal(d->sincr);
		wfi();
	}
}

// ( SOLUZIONE 2023-02-15
//   SOLUZIONE 2023-02-15 )

/*! @brief Inizializza la gestione dell'hard disk
 *  @return 		true in caso di successo, false altrimenti
 */
bool hd_init()
{
	natl id;
	natb bus = 0, dev = 0, fun = 0;
	des_ata* d;

	d = &hard_disk;

	if ( (d->mutex = sem_ini(1)) == 0xFFFFFFFF) {
		flog(LOG_ERR, "hd: impossibile creare mutex");
		return false;
	}
	if ( (d->sincr = sem_ini(0)) == 0xFFFFFFFF) {
		flog(LOG_ERR, "hd: impossibile creare sincr");
		return false;
	}

	if (!bm::find(bus, dev, fun)) {
		flog(LOG_WARN, "hd: bus master non trovato");
		return false;
	}

	if ( (d->prd = new (std::align_val_t{65536}) natl[2 * MAX_PRD]) == nullptr) {
		flog(LOG_WARN, "hd: impossibile allocare vettore di PRD");
		return false;
	}

	flog(LOG_INFO, "bm: %02x:%02x.%1d", bus, dev, fun);
	bm::init(bus, dev, fun);

	id = activate_pe(estern_hd, 0, MIN_EXT_PRIO + INTR_TIPO_HD, LIV_SISTEMA, HD_IRQ);
	if (id == 0xFFFFFFFF) {
		flog(LOG_ERR, "hd: impossibile creare proc. esterno");
		return false;
	}

	hd::enable_intr();

// [ ESAME 2023-02-15
/// @ingroup esame
/// @note conviene inserire anche i buffer vuoti nella coda LRU (in un ordine
/// qualsiasi), in modo da non dover considerare a parte il caso di buffer
/// vuoto.
	d->lru = d->mru = -1;
	for (int i = 0; i < MAX_BUF_DES; i++) {
		buf_des *b = &d->bufcache[i];
		b->full = false;
		b->next = b->prev = -1;
		bufcache_promote(b);
		b->dirty = false;
	}
//   ESAME 2023-02-15 ]

	return true;
}
/// @}

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ioinit		Inizializzazione
/// @{
////////////////////////////////////////////////////////////////////////////////

/// Ultimo indirizzo utilizzato dal modulo I/O (fornito dal collegatore)
extern "C" char _end[];

/*! @brief Riempie i gate della IDT relativi alle primitive fornite dal modulo I/O
 *  @return		true in caso di successo, false altrimenti
 */
extern "C" bool fill_io_gates();

/*! @brief Corpo del processo main I/O.
 *
 *  Il modulo sistema crea il processo main I/O all'avvio e gli cede
 *  il controllo, passandogli l'indirizzo di una variabile intera.
 *  Il modulo I/O deve scrivere 1 in questa variabile quando ha
 *  ha terminato la fase di inizializzazione.
 *
 *  @param p		indirizzo della variabile di sincronizzazione
 */
extern "C" void main_io(natq p)
{
	int *p_io_init_done = ptr_cast<int>(p);

	fill_io_gates();
	ioheap_mutex = sem_ini(1);
	if (ioheap_mutex == 0xFFFFFFFF) {
		flog(LOG_ERR, "impossible creare semaforo ioheap_mutex");
		abort_p();
	}
	char* end_ = allinea_ptr(_end, DIM_PAGINA);
	heap_init(end_, DIM_IO_HEAP);
	flog(LOG_INFO, "Heap del modulo I/O: %llxB [%p, %p)", DIM_IO_HEAP,
			end_, end_ + DIM_IO_HEAP);
	flog(LOG_INFO, "Inizializzo la console (kbd + vid)");
	if (!console_init()) {
		flog(LOG_ERR, "inizializzazione console fallita");
		abort_p();
	}
	flog(LOG_INFO, "Inizializzo la gestione dell'hard disk");
	if (!hd_init()) {
		flog(LOG_ERR, "inizializzazione hard disk fallita");
		abort_p();
	}
	*p_io_init_done = 1;
	terminate_p();
}
/// @}

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup iodbg		Supporto per il debugging
/// @brief Funzioni che forniscono informazioni sullo stato del sistema
/// @{
////////////////////////////////////////////////////////////////////////////////

/*! @brief Parte C++ della primitiva getiomeminfo()
 *  @return		byte liberi nello heap I/O
 */
extern "C" natq c_getiomeminfo()
{
	natq rv;
	sem_wait(ioheap_mutex);
	rv = disponibile();
	sem_signal(ioheap_mutex);
	return rv;
}
/// @}
/// @}
