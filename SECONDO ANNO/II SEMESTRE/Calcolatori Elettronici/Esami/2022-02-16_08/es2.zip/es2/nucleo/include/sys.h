/// @file sys.h
/// @brief Primitive comuni definite dal modulo sistema
///
/// Queste primitive possono essere usate sia dal modulo utente che
/// dal modulo I/O.

/// @name Primitive per la gestione dei processi
/// @{

/**
 * @brief Crea un nuovo processo
 *
 * Il nuovo processo eseguirà _f(a)_ con priorità _prio_ e a livello _liv_.
 *
 * Un processo non può usare questa primitiva per creare un processo a priorità
 * o livello maggiori dei propri.
 *
 * @param f		corpo del processo
 * @param a		parametro per il corpo del processo 
 * @param prio		priorità del processo 
 * @param liv		livello del processo (LIV_UTENTE o LIV_SISTEMA)
 *
 * @return 		id del nuovo processo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl activate_p(void f(natq), natq a, natl prio, natl liv);

/**
 * @brief Termina il processo corrente.
 *
 * I processi devono invocare questa primitiva per poter terminare.
 */
extern "C" void terminate_p();

/**
 * @brief Abortisce il processo corrente.
 *
 * Come terminate_p(), ma mostra lo stato del processo sul log.
 */
extern "C" void abort_p();

/// @}

/// @name Primitive per l'utilizzo dei semafori
/// @{

/**
 * @brief Crea un nuovo semaforo.
 *
 * @param val		numero di gettoni iniziali
 *
 * @return 		id del nuovo semaforo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl sem_ini(int val);

/**
 * @brief Estrae un gettone da un semaforo.
 *
 * @param sem		id del semaforo.
 */
extern "C" void sem_wait(natl sem);

/**
 * @brief Inserisce un gettone in un semaforo.
 *
 * @param sem		id del semaforo
 */
extern "C" void sem_signal(natl sem);

/// @}

/// @name Primitive per l'utilizzo del timer
/// @{

/**
 * @brief Sospende il processo corrente.
 *
 * @param n		numero di intervalli di tempo
 */
extern "C" void delay(natl n);

/// @}

/// @name Primitive di supporto al debugging
/// @{

/**
 * @brief Informazioni di debug
 *
 * Questa struttura contiene delle informazioni che sono usate nei testi d'esame
 * per eseguire alcuni controlli.
 */
struct meminfo {
	/// numero di byte liberi nello heap di sistema
	natl heap_libero;
	/// numero di frame liberi in M2
	natl num_frame_liberi;
	/// id del processo corrente
	natl pid;
};

/**
 * @brief Estrae informazioni di debug.
 *
 * @return		struttura contenente le informazioni
 */
extern "C" meminfo getmeminfo();

/**
 * @brief Invia un messaggio al log.
 *
 * Questa primitiva è usata dai moduli I/O e utente per inviare i propri
 * messaggi al log di sistema. 
 *
 * @note Il modulo sistema usa direttamente la do_log() definita in libce.
 *
 * @param sev		severità del messaggio
 * @param buf		buffer contenente il messaggio
 * @param quanti	lunghezza del messaggio
 */
extern "C" void do_log(log_sev sev, const char* buf, natl quanti);
/// @}

// ( ESAME 2022-02-16


/**
 * @brief 	Monitora la memory-area di un processo.
 * @pre		_pid_ deve essere un identificatore valido.
 * @pre		Il processo invocante non deve cercare di monitorare sé stesso.
 * @pre		La dimensione della memory-area non può essere né zero, né superiore
 * 		a MAX_MA_PAGES
 * @pre		Il processo invocante non deve essere già monitor.
 *
 * @param pid	id del processo da monitorare
 * @param npag	dimensione della memory-area (in pagine)
 *
 * @return 	false se il processo da monitorare non esiste,
 * 		o è già monitorato; false anche se il processo
 * 		invocante è a sua volta monitorato; true altrimenti
 */
extern "C" bool ma_attach(natw pid, natq npag);

/// Descrittore di page fault
struct ma_fault {
	/// Indirizzo che ha causato il fault
	vaddr v;
	/// True se l'accesso era in scrittura
	bool  is_write;
};

/**
 * @brief 	Attende che il processo monitorato generi un page fault nella memory-area o termini.
 * @pre		Il processo invocante deve essere monitor.
 *
 * @return 	descrittore del page fault (con v == 0 in caso di processo terminato)
 */
extern "C" ma_fault ma_wait();

/**
 * @brief 	Modifica una traduzione nella memory-area del processo monitorato.
 *
 * Il processo monitor può invocare questa primitiva in qualsiasi momento.
 * La primitiva può essere usata sia per creare una nuova traduzione, sia per modificare
 * il permesso di scrittura o eliminare una traduzione esistente.
 *
 * Nel caso di creazione di una nuova traduzione, il frame corrispondente deve
 * contere una pagina dello spazio utente/condiviso ed è specificato tramite
 * il suo indirizzo virtuale (_src_).
 *
 * @param src	indirizzo virtuale del frame da mappare (se si crea una nuova traduzione)
 * @param dst	indirizzo virtuale di cui modificare la traduzione
 * @param P	true se la traduzione di _dst_ deve essere valida, false se deve essere non valida
 * @param W	true se _dst_ deve essere accessibile in scrittura, false se solo in lettura
 *
 * @pre Il processo invocante deve essere monitor.
 * @pre se _src_ è utilizzato (creazione di una nuova traduzione), deve cadere all'interno
 * 	della zona utente/condivisa
 * @pre _dst_ deve essere un indirizzo all'interno della memory-area del processo monitorato.
 * @pre _src_ e _dst_ devono essere allineati alla pagina.
 *
 * @return 	contenuto precedente del descrittore di livello 1 di _dst_,
 * 		o 0xFFFFFFFFFFFFFFFF in caso di fallimento.
 */
extern "C" natq ma_map(vaddr src, vaddr dst, bool P, bool W);

/**
 * @brief 	Risveglia il processo monitorato.
 * @pre		Il processo invocante deve essere monitor.
 * @pre		Il processo monitorato doveva essere in attesa di essere risvegliato.
 */
extern "C" void ma_cont();
//   ESAME 2022-02-16 )
