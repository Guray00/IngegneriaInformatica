/// @file sys.h
/// @brief Primitive comuni definite dal modulo sistema
///
/// Queste primitive possono essere usate sia dal modulo utente che
/// dal modulo I/O.

/// @name Primitive per la gestione dei processi
/// @{

/**
 * @brief Crea un nuovo processo
 *
 * Il nuovo processo eseguirà _f(a)_ con priorità _prio_ e a livello _liv_.
 *
 * Un processo non può usare questa primitiva per creare un processo a priorità
 * o livello maggiori dei propri.
 *
 * @param f		corpo del processo
 * @param a		parametro per il corpo del processo 
 * @param prio		priorità del processo 
 * @param liv		livello del processo (LIV_UTENTE o LIV_SISTEMA)
 *
 * @return 		id del nuovo processo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl activate_p(void f(natq), natq a, natl prio, natl liv);

/**
 * @brief Termina il processo corrente.
 *
 * I processi devono invocare questa primitiva per poter terminare.
 */
extern "C" void terminate_p();

/**
 * @brief Abortisce il processo corrente.
 *
 * Come terminate_p(), ma mostra lo stato del processo sul log.
 */
extern "C" void abort_p();

/// @}

/// @name Primitive per l'utilizzo dei semafori
/// @{

/**
 * @brief Crea un nuovo semaforo.
 *
 * @param val		numero di gettoni iniziali
 *
 * @return 		id del nuovo semaforo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl sem_ini(int val);

/**
 * @brief Estrae un gettone da un semaforo.
 *
 * @param sem		id del semaforo.
 */
extern "C" void sem_wait(natl sem);

/**
 * @brief Inserisce un gettone in un semaforo.
 *
 * @param sem		id del semaforo
 */
extern "C" void sem_signal(natl sem);

/// @}

/// @name Primitive per l'utilizzo del timer
/// @{

/**
 * @brief Sospende il processo corrente.
 *
 * @param n		numero di intervalli di tempo
 */
extern "C" void delay(natl n);

/// @}

/// @name Primitive di supporto al debugging
/// @{

/**
 * @brief Informazioni di debug
 *
 * Questa struttura contiene delle informazioni che sono usate nei testi d'esame
 * per eseguire alcuni controlli.
 */
struct meminfo {
	/// numero di byte liberi nello heap di sistema
	natl heap_libero;
	/// numero di frame liberi in M2
	natl num_frame_liberi;
	/// id del processo corrente
	natl pid;
};

/**
 * @brief Estrae informazioni di debug.
 *
 * @return		struttura contenente le informazioni
 */
extern "C" meminfo getmeminfo();

/**
 * @brief Invia un messaggio al log.
 *
 * Questa primitiva è usata dai moduli I/O e utente per inviare i propri
 * messaggi al log di sistema. 
 *
 * @note Il modulo sistema usa direttamente la do_log() definita in libce.
 *
 * @param sev		severità del messaggio
 * @param buf		buffer contenente il messaggio
 * @param quanti	lunghezza del messaggio
 */
extern "C" void do_log(log_sev sev, const char* buf, natl quanti);
/// @}

// ( ESAME 2012-01-12

/// Tipo dei gestori di segnale
typedef void (*gestore)();

/**
 * @brief Associa un gestore ad un tipo di segnale.
 *
 * Azzera anche eventuali segnali pendenti di quel tipo.
 *
 * La primitiva ignora i tentativi di associare un gestore al tipo 0.
 *
 * @param signo	tipo del segnale
 * @param g	gestore (se nullptr, disassocia un eventuale gestore già presente)
 */
extern "C" void gestisci(natl signo, gestore g);

/**
 * @brief Invia un segnale ad un processo.
 *
 * Se il processo non ha associato un gestore per quel tipo di segnale,
 * non fa niente.
 *
 * @pre Il processo deve essere di livello utente.
 * @pre _signo_ deve essere un tipo valido (minore di @ref MAX_SEGNALI)
 *
 * @param signo tipo del segnale
 * @param id	id del processo
 * @return true se il processo esiste, false altrimenti
 */
extern "C" bool segnala(natl signo, natl id);

/**
 * @brief Primitiva che i gestori devono invocare per poter terminare.
 *
 * @param signo tipo del segnale gestito dal gestore
 */
extern "C" void termina_gestore(natl signo);

/**
 * @brief Maschera un segnale.
 *
 * La primitiva ignora i tentativi di mascherare il tipo 0.
 *
 * @param signo tipo del segnale da mascherare
 */
extern "C" void maschera(natl signo);

/**
 * @brief Smaschera un segnale.
 *
 * @warning Se il segnale appena smascherato era pendente,
 * deve essere gestito.
 *
 * @param signo tipo del segnale da smascherare
 */
extern "C" void smaschera(natl signo);
//   ESAME 2012-01-12 )
