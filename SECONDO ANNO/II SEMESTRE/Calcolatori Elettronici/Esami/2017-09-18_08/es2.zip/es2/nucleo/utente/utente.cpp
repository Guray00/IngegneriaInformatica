#include <all.h>


extern natl hello;

extern natl Pause;
extern natl sync;
void p1(int a, int b)
{
	printf("a=%d b=%d", a, b);
	if (a % 2)
		sem_wait(sync);
	else
		sem_signal(sync);
	terminate_p();
}

void p2(int a, int b)
{
	printf("a=%d b=%d", a, b);
	*(natl *)0 = 0;
	terminate_p();
}

void pause_body(natq a)
{
	pause();

	terminate_p();
}
void hello_body(natq a)
{
	newproc((void *)p1, 15, 19);
	newproc((void *)p2, 300, 17);
	newproc((void *)p1, 26, 18);
	newproc((void *)p2, 18, 17);

	terminate_p();
}
natl hello;
natl Pause;
natl sync;

extern "C" void main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	Pause = activate_p(pause_body, 0, 10, LIV_UTENTE);
	sync = sem_ini(0);

	terminate_p();
}
