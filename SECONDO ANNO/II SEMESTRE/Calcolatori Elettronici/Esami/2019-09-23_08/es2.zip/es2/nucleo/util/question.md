Vogliamo fornire ai processi la possibilità di bloccare l'esecuzione di
un processo a scelta, ogni volta che questo passa da una certa
istruzione. Per far questo forniamo alcune primitive. Con la primitiva
`bpattach(natl id, vaddr rip)` un processo *master* installa un
breakpoint (istruzione `int3`, codice operativo `0xCC`) all'indirizzo
`rip` nella memoria virtuale del processo `id`, che diventa *slave*. Da
quel momento in poi il processo slave si blocca se passa da `rip`. Nel
frattempo, usando la primitiva `bpwait()`, il processo master può
sospendersi in attesa che lo slave passi dal breakpoint. A quel punto il
processo master può invocare la primitiva `bpcontinue()` per permettere
al processo slave di continuare la propria esecuzione come se non fosse
mai stato intercettato. Se lo slave ripassa dal breakpoint viene
intercettato nuovamente e il meccanismo di ripete. Infine, con la
primitiva `bpdetach()`, il processo master rimuove il breakpoint e, se
necessario, risveglia un'ultima volta lo slave.

Si noti che processi che non sono slave non devono essere intercettati.
Inoltre, se un processo esegue `int3` senza che ciò sia stato richiesto
da un master, il processo deve essere abortito.

Aggiungiamo i seguenti campi ai descrittori di processo:

        des_proc *bp_master;
        des_proc *bp_slave;
        vaddr   bp_addr;
        natb    bp_orig;
        natl    bp_slave_id;
        bool    bp_waiting;

dove: `bp_master` punta al processo master di questo processo (nullo se
il processo non ha un master); `bp_slave` punta al processo slave di
questo processo (nullo se il processo non ha uno slave); `bp_addr` e
`bp_orig` sono sinificativi solo per i processi slave e contengono,
rispettivamente, l'indirizzo a cui è installato il breakpoint e il byte
originariamente contenuto a quell'indirizzo; il campo `bp_slave_id` è
significativo solo per il processo master e contiene l'id dello slave;
`bp_waiting` vale `true` nel descrittore di uno slave se il master è
bloccato, e viceversa.

Si modifichino i file `sistema/sistema.s` e `sistema/sistema.cpp` per
implementare le seguenti primitive (abortiscono il processo in caso di
errore):

-   `bool bpattach(natl id, vaddr rip)`: (tipo 0x59, già realizzata): se
    il processo che invoca la primitiva non è uno slave e il processo
    `id` esiste e non è già uno slave o un master, installa il
    breakpoint all'indirizzo `rip` e restituisce `true`, altrimenti
    restituisce `false`; è un errore se `rip` non appartiene
    all'intervallo $[\mathtt{ini\_utn\_c}, \mathtt{fin\_utn\_c})$ (zona
    utente/condivisa) o se il processo è già master o cerca di diventare
    master di se stesso.

-   `void bpwait()`: (tipo 0x5a, già realizzata): attende che il
    processo slave passi dal breakpoint; è un errore invocare questa
    primitiva se il processo non è master;

-   `void bpcontinue()`: (tipo 0x5c, da realizzare): permette allo slave
    di proseguire l'esecuzione, facendo in modo che venga intercettato
    nuovamente se ripassa dal breakpoint; è un errore invocare questa
    primitiva se il processo non è master o se lo slave non è bloccato
    sul breakpoint;

-   `void bpdetach()` (tipo 0x5b, già realizzata): disfa tutto ciò che
    ha fatto la `bpattach()` e risveglia eventualmente il processo
    slave; se il processo non è master non compie alcuna azione.

**Suggerimento**: per realizzare la `bpcontinue()` si deve
temporaneamente rimuovere il breakpoint, quindi reinserirlo non appena
lo slave ha eseguito una istruzione. Per intercettare questo evento si
può abilitare temporaneamente il single-step trap nel processo slave.
