#include <all.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %lu: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %lu PROC %d: " s "\n", test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)
#define die(s, ...) do { err(s, ## __VA_ARGS__); goto error; } while (0)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_subtest() do {\
	(void)&&error;\
error:\
	terminate_p();\
} while (0)

#define end_test() do {\
	(void)&&error;\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

#define TCNT(n)	natl t##n##m0; natl t##n##n0;
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

static inline const char* bool2str(bool v)
{
	return v ? "true" : "false";
}

#define cksem(sem_, to_, r_) do {\
	bool rr_ = sem_wait_to(sem_, to_);\
	if (rr_ != (r_)) {\
		err("ottenuto %s (%x) invece di %s (%x)",\
			bool2str(rr_), rr_, bool2str(r_), r_);\
	}\
} while (0)
natq test_num;

///**********************************************************************
// *             test 00: errori vari                                   *
// **********************************************************************/

natl t00p0;

void t00p0b(natq test_num)
{
	sem_wait_to(1000, 10);
	err("accesso a semaforo non valido non ha causato abort");
	terminate_p();
}

///**********************************************************************
// *             test 01: nessun time out                               *
// **********************************************************************/

natl t01p0;
natl t01p1;
natl t01s0;
TCNT(01);

void t01p0b(natq test_num)
{
	for (int i = 0; i < 10; i++)
		sem_wait(t01s0);
	testok(01);
	end_test();
}

void t01p1b(natq test_num)
{
	for (int i = 0; i < 10; i++)
		sem_signal(t01s0);
	testok(01);
	end_test();
}

///**********************************************************************
// *             test 02: time out zero                                 *
// **********************************************************************/

natl t02p0;
natl t02p1;
natl t02s0;
natl t02s1;
TCNT(02);

void t02p0b(natq test_num)
{
	cksem(t02s0, 0, false);
	sem_wait(t02s1);
	cksem(t02s0, 0, true);
	testok(02);
	end_test();
}

void t02p1b(natq test_num)
{
	sem_signal(t02s0);
	sem_signal(t02s1);
	testok(02);
	end_test();
}

///**********************************************************************
// *             test 03: scatto del time out                           *
// **********************************************************************/

natl t03p0;
natl t03s0;
TCNT(03);

void t03p0b(natq test_num)
{
	cksem(t03s0, 2, false);
	sem_signal(t03s0);
	cksem(t03s0, 2, true);
	testok(03);
	end_test();
}

///**********************************************************************
// *             test 04: sem_signal in tempo                           */
// **********************************************************************/

natl t04p0;
natl t04p1;
natl t04s0;
TCNT(04);

void t04p0b(natq test_num)
{
	cksem(t04s0, 100, true);
	testok(04);
	end_test();
}

void t04p1b(natq test_num)
{
	delay(10);
	sem_signal(t04s0);
	testok(04);
	end_test();
}

///**********************************************************************
// *             test 05: sem_signal fuori tempo                        *
// **********************************************************************/

natl t05p0;
natl t05p1;
natl t05s0;
TCNT(05);

void t05p0b(natq test_num)
{
	cksem(t05s0, 1, false);
	testok(05);
	end_test();
}

void t05p1b(natq test_num)
{
	delay(10);
	sem_signal(t05s0);
	testok(05);
	end_test();
}

///**********************************************************************
// *             test 06: coda semafori mista                           *
// **********************************************************************/

natl t06p0;
natl t06p1;
natl t06p2;
natl t06s0;
TCNT(06);

void t06p0b(natq test_num)
{
	cksem(t06s0, 1, false);
	testok(06);
	end_test();
}

void t06p1b(natq test_num)
{
	sem_wait(t06s0);
	testok(06);
	end_test();
}

void t06p2b(natq test_num)
{
	delay(10);
	sem_signal(t06s0);
	testok(06);
	end_test();
}

/**********************************************************************/


extern natl mainp;
void main_body(natq id)
{
	natl prio = 600;
	natl membefore = getmeminfo().heap_libero;

	end_test = sem_ini(0);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	delay(1);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: nessun time out");
	t01s0 = sem_ini(0);
	new_proc(01, 0);
	new_proc(01, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t01n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: time out zero");
	t02m0 = sem_ini(1);
	t02s0 = sem_ini(0);
	t02s1 = sem_ini(0);
	new_proc(02, 0);
	new_proc(02, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t02n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 3;
	dbg(">>>INIZIO<<< scatto del time out");
	t03m0 = sem_ini(1);
	t03s0 = sem_ini(0);
	new_proc(03, 0);
	sem_wait(end_test);
	if (t03n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: sem_signal in tempo");
	t04m0 = sem_ini(1);
	t04s0 = sem_ini(0);
	new_proc(04, 0);
	new_proc(04, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t04n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: sem_signal fuori tempo");
	t05m0 = sem_ini(1);
	t05s0 = sem_ini(0);
	new_proc(05, 0);
	new_proc(05, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t05n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 6;
	dbg(">>>INIZIO<<<: coda semafori mista");
	t06m0 = sem_ini(1);
	t06s0 = sem_ini(0);
	new_proc(06, 0);
	new_proc(06, 1);
	new_proc(06, 2);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t06n0 == 3) msg("OK");
	dbg("=== FINE ===");

	delay(10);
	test_num = 6;
	natl memafter = getmeminfo().heap_libero;
	if (memafter != membefore)
		err("memoria non liberata: %d byte", membefore - memafter);
	pause();

	terminate_p();
}
natl mainp;

extern "C" void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();
}
