#include <all.h>

static const int MAX_PAYLOAD = 2048;
static const int HDR_SZ = 2*sizeof(natl);
static const int MAX_MSGSZ = MAX_PAYLOAD + HDR_SZ;

struct msg {
	natl s;
	const char *p;
};

#define MSG(src, dst, payload) { src, payload },

msg toreceive[] = {
#include "messages"
};


extern natl hello;

extern natl bad2;

extern natl bad5;
void bad2_body(natq a)
{
	natq len = waitnet();
	receive((char *)0x200000, len);
	printf("processo errato 2\n");

	terminate_p();
}
void bad5_body(natq a)
{
	receive((char *)(0UL-4), 8);
	printf("processo errato 5\n");

	terminate_p();
}
void hello_body(natq a)
{
	char magic[] = { 'A', 'B', 'C', 'D' };
	char* buf = new char[MAX_MSGSZ + sizeof(magic)];
	memset(buf, 0, MAX_MSGSZ + sizeof(magic));
	natq len;
	int errors = 0;
	for (unsigned i = 0; i < sizeof(toreceive)/sizeof(msg); i++) {
		unsigned int j;
		memcpy(buf + MAX_MSGSZ, magic, sizeof(magic));
		natq explen = strlen(toreceive[i].p);
		len = waitnet();
		receive(buf, len < MAX_MSGSZ ? len : MAX_MSGSZ);
		if (len < HDR_SZ) {
			printf("message %d too short (len %lu)\n", i, len);
			errors++;
			continue;
		}
		//printf("message %d len %d\n", i, len);
		for (j = 0; j < sizeof(magic); j++) {
			if (buf[MAX_MSGSZ + j] != magic[j]) {
				printf("message %d: write after the end of the buffer\n", i);
				errors++;
				break;
			}
		}
		buf += HDR_SZ;
		len -= HDR_SZ;
		if (len != explen) {
			printf("message %d: len is %lu instead of the expected %lu\n", i, len, explen);
			errors++;
			continue;
		}
		buf[len <= MAX_PAYLOAD ? len : MAX_PAYLOAD] = '\0';
		for (j = 0; buf[j] && toreceive[i].p[j] && buf[j] == toreceive[i].p[j]; j++)
			;
		if (buf[j]) {
			if (toreceive[i].p[j]) {
				printf("message %d: payload error at byte %d\n", i, j);
				printf("   received '%d', expected '%d'\n", buf[j], toreceive[i].p[j]);
				errors++;
				continue;
			} else {
				printf("message %d: payload error at byte %d\n", i, j);
				printf("   received '%s' beyond expected end of message\n", buf + j);
				errors++;
				continue;
			}
		} else if (toreceive[i].p[j] && explen <= MAX_PAYLOAD) {
			printf("message %d: unexpected null byte at %d\n", i, j);
			errors++;
			continue;
		}
	}
	if (errors == 0)
		printf("receiver: no errors\n");
	pause();

	terminate_p();
}
natl hello;
natl bad2;
natl bad5;

extern "C" void main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	bad2 = activate_p(bad2_body, 0, 49, LIV_UTENTE);
	bad5 = activate_p(bad5_body, 0, 46, LIV_UTENTE);

	terminate_p();
}
