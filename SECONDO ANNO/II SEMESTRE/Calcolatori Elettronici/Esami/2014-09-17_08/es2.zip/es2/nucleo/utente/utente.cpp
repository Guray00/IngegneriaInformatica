#include <all.h>


extern natl pbarrier;
extern natl sync1;
extern natl sync2;
extern natl sync3;
extern natl sync5;
natl pid1, pid2, pid3, pid5;

void check_reg(const char *me, const char *pname, natl pid, natl bid)
{
	printf("proc %s: reg(%s, %d)\n", me, pname, bid);
	if (!reg(pid, bid))
		printf("proc %s: reg returned false\n", me);
}

void do_barrier(const char *me)
{
	printf("proc %s: barrier()\n", me);
	barrier();
	printf("proc %s: barrier opened\n", me);
}

void b1(natq a)
{
	sem_wait(sync1);
	check_reg("b1", "b1", pid1, 0);
	sem_wait(sync1);
	do_barrier("b1");
	sem_wait(sync1);
	do_barrier("b1");
	sem_wait(sync1);
	do_barrier("b1");
	terminate_p();
}

void b2(natq a)
{
	sem_wait(sync2);
	check_reg("b2", "b2", pid2, 0);
	sem_wait(sync2);
	do_barrier("b2");
	sem_wait(sync2);
	do_barrier("b2");
	sem_wait(sync2);
	do_barrier("b2");
	sem_wait(sync2);
	terminate_p();
}

void b3(natq a)
{
	sem_wait(sync3);
	check_reg("b3", "b3", pid3, 1);
	sem_wait(sync3);
	do_barrier("b3");
	sem_wait(sync3);
	do_barrier("b3");
	sem_wait(sync3);
	terminate_p();
}

void b5(natq a)
{
	sem_wait(sync5);
	check_reg("b5", "b1", pid1, 1);
	sem_wait(sync5);
	check_reg("b5", "b3", pid3, 0);
	sem_wait(sync5);
	check_reg("b5", "b1", pid1, 0xFFFFFFFF);
	terminate_p();
}

void conductor(natq a)
{
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync5);
	sem_signal(sync3);
	sem_signal(sync1);
	sem_signal(sync3);
	sem_signal(sync5);
	sem_signal(sync2);
	sem_signal(sync5);

	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync5);
	sem_signal(sync2);
	pause();
	terminate_p();
}

void main_body(natq a)
{
	pid1 = activate_p(b1, 1, 30, LIV_UTENTE);
	pid2 = activate_p(b2, 2, 29, LIV_UTENTE);
	pid3 = activate_p(b3, 3, 28, LIV_UTENTE);
	pid5 = activate_p(b5, 5, 26, LIV_UTENTE);
	activate_p(conductor, 6, 10, LIV_UTENTE);

	terminate_p();
}
natl pbarrier;
natl sync1;
natl sync2;
natl sync3;
natl sync5;

extern "C" void main()
{
	pbarrier = activate_p(main_body, 0, 100, LIV_UTENTE);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);
	sync5 = sem_ini(0);

	terminate_p();
}
