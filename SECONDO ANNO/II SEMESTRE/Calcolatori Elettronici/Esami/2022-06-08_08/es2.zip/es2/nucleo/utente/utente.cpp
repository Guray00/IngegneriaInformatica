/*
 * Programma di test 2022-06-08
 */

#include <all.h>

const int MSG_SIZE1 = 4;
const int MSG_SIZE2 = 16;
const int MSG_SIZE3 = 8;
const int MSG_SIZE4 = 12;
const int MSG_SIZE5 = 16;
const int MAX_SIZE  = 16;
const int NMESG = 1;

extern natl mailbox_piena;
extern natl mailbox_vuota;

extern natl scrittore1;

extern natl scrittore2;

extern natl scrittore3;

extern natl scrittore4;

extern natl scrittore5;

extern natl lettore;
struct mess {
	int mittente;
	char corpo[MAX_SIZE + 1];
};

mess mailbox;

char buf1[MSG_SIZE1] __attribute__((aligned(sizeof(natl)))) = { 'a' };
natl canary1 = 0x0a0b0c0d;
char buf2[MSG_SIZE2] __attribute__((aligned(sizeof(natl)))) = { 'b' };
natl canary2 = 0x0e0f0102;
char buf3[MSG_SIZE3] __attribute__((aligned(sizeof(natl)))) = { 'c' };
natl canary3 = 0x03040506;
char buf4[MSG_SIZE4] __attribute__((aligned(sizeof(natl)))) = { 'd' };
natl canary4 = 0x07080910;
char buf5[MSG_SIZE5] __attribute__((aligned(sizeof(natl)))) = { 'e' };
natl canary5 = 0x11121314;

char *bufs[] = { buf1, buf2, buf3, buf4, buf5 };
int sizes[] = { MSG_SIZE1, MSG_SIZE2, MSG_SIZE3, MSG_SIZE4, MSG_SIZE5 };

void pms(natq a)
{
	natl quanti = sizes[a];
	for (natl i = 0; i < quanti; i++) {
		bufs[a][i] = 'a' + a;
	}
	for (int i = 0; i < NMESG; i++) {
		ceread(0, bufs[a], quanti);
		sem_wait(mailbox_vuota);
		for (natl i = 0; i < quanti; i++) {
			mailbox.corpo[i] = bufs[a][i];
		}
		mailbox.corpo[quanti] = '\0';
		mailbox.mittente = a;
		sem_signal(mailbox_piena);
	}
	printf("fine scrittore %lu\n", a);

	terminate_p();
}
void pml(natq a)
{
	char corpo[MAX_SIZE + 1];
	int mittente;
	for (int i = 0; i < 5 * NMESG; i++) {
		sem_wait(mailbox_piena);
		mittente = mailbox.mittente;
		memcpy(corpo, mailbox.corpo, sizeof(corpo));
		sem_signal(mailbox_vuota);
		printf("mittente=%d corpo=%s\n", mittente, corpo);
	}
	printf("fine lettore\n");
	printf("controllo1=%08x\n", canary1);
	printf("controllo2=%08x\n", canary2);
	printf("controllo3=%08x\n", canary3);
	printf("controllo4=%08x\n", canary4);
	printf("controllo5=%08x\n", canary5);
	pause();

	terminate_p();
}
natl mailbox_piena;
natl mailbox_vuota;
natl scrittore1;
natl scrittore2;
natl scrittore3;
natl scrittore4;
natl scrittore5;
natl lettore;

extern "C" void main()
{
	mailbox_piena = sem_ini(0);
	mailbox_vuota = sem_ini(1);
	scrittore1 = activate_p(pms, 0, 6, LIV_UTENTE);
	scrittore2 = activate_p(pms, 1, 7, LIV_UTENTE);
	scrittore3 = activate_p(pms, 2, 8, LIV_UTENTE);
	scrittore4 = activate_p(pms, 3, 9, LIV_UTENTE);
	scrittore5 = activate_p(pms, 4, 10, LIV_UTENTE);
	lettore = activate_p(pml, 0, 5, LIV_UTENTE);

	terminate_p();
}
