#include <all.h>


extern natl pbarrier;
extern natl sync1;
extern natl sync2;
extern natl sync3;
void notreg(natq a)
{
	barrier();
	printf("processo errato %lu\n", a);
	terminate_p();
}

void b1(natq a)
{
	sem_wait(sync1);
	printf("processo %lu: reg\n", a);
	reg();
	sem_wait(sync1);
	printf("processo %lu: dereg\n", a);
	dereg();
	printf("processo %lu: after dereg\n", a);
	sem_wait(sync1);
	printf("processo %lu: reg\n", a);
	reg();
	sem_wait(sync1);
	printf("processo %lu: barrier approach\n", a);
	barrier();
	printf("processo %lu: barrier leave\n", a);
	sem_wait(sync1);
	printf("processo %lu: terminate\n", a);
	terminate_p();
}

void b2(natq a)
{
	sem_wait(sync2);
	printf("processo %lu: reg\n", a);
	reg();
	sem_wait(sync2);
	printf("processo %lu: barrier approach\n", a);
	barrier();
	printf("processo %lu: barrier leave\n", a);
	sem_wait(sync2);
	printf("processo %lu: dereg\n", a);
	dereg();
	printf("processo %lu: after dereg\n", a);
	sem_wait(sync2);
	printf("processo %lu: reg\n", a);
	reg();
	sem_wait(sync2);
	printf("processo %lu: dereg\n", a);
	dereg();
	printf("processo %lu: after dereg\n", a);
	sem_wait(sync2);
	printf("processo %lu: terminate\n", a);
	terminate_p();
}

void b3(natq a)
{
	sem_wait(sync3);
	printf("processo %lu: reg\n", a);
	reg();
	sem_wait(sync3);
	printf("processo %lu: barrier approach\n", a);
	barrier();
	printf("processo %lu: barrier leave\n", a);
	sem_wait(sync3);
	printf("processo %lu: barrier approach\n", a);
	barrier();
	printf("processo %lu: barrier leave\n", a);
	sem_wait(sync3);
	printf("processo %lu: barrier approach\n", a);
	barrier();
	printf("processo %lu: barrier leave\n", a);
	sem_wait(sync3);
	printf("processo %lu: terminate\n", a);
	terminate_p();
}

void conductor(natq a)
{
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync2);
	sem_signal(sync1);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	pause();
	terminate_p();
}

void main_body(natq a)
{
	activate_p(notreg, 1, 50, LIV_UTENTE);
	activate_p(b1, 1, 29, LIV_UTENTE);
	activate_p(b2, 2, 30, LIV_UTENTE);
	activate_p(b3, 3, 28, LIV_UTENTE);
	activate_p(conductor, 4, 10, LIV_UTENTE);

	terminate_p();
}
natl pbarrier;
natl sync1;
natl sync2;
natl sync3;

extern "C" void main()
{
	pbarrier = activate_p(main_body, 0, 100, LIV_UTENTE);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);

	terminate_p();
}
