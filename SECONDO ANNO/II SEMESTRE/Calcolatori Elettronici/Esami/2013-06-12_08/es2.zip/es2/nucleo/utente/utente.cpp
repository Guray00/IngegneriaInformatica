#include <all.h>


extern natl m1;
extern natl s1;
extern natl s2;
natl pim;

void p1(natq a)
{
	sem_wait(s1);
	sem_signal(s2);
	pim_wait(pim);
	printf("sezione critica %lu\n", a);
	pim_signal(pim);
	printf("fine processo %lu\n", a);
	terminate_p();
}

void p2(natq a)
{
	sem_wait(s2);
	printf("fine processo %lu\n", a);
	terminate_p();
}

void p3(natq a)
{
	pim_wait(pim);
	printf("inizio sezione critica %lu\n", a);
	sem_signal(s1);
	printf("fine sezione critica %lu\n", a);
	pim_signal(pim);
	printf("fine processo %lu\n", a);
	pause();
	terminate_p();
}

void mio_main(natq a)
{
	pim = pim_init();
	(void) activate_p(p1, 1, 90, LIV_UTENTE);
	(void) activate_p(p2, 2, 89, LIV_UTENTE);
	(void) activate_p(p3, 3, 88, LIV_UTENTE);

	terminate_p();
}
natl m1;
natl s1;
natl s2;

extern "C" void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);
	s1 = sem_ini(0);
	s2 = sem_ini(0);

	terminate_p();
}
