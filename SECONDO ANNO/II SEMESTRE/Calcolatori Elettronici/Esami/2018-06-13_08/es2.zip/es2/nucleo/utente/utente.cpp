#include <all.h>

struct msg {
	natl d;
	char p[1000];
};

#define MSG(src, dst, payload)	{ dst, payload },

msg tosend[] = {
#include "messages"
};


extern natl hello;

extern natl error;
void error_body(natq a)
{
	send(0x11223344, (char *)0x200000, 100);
	printf("processo errato\n");

	terminate_p();
}
void hello_body(natq a)
{
	natl mem0 = getiomeminfo();
	for (unsigned i = 0; i < sizeof(tosend)/sizeof(msg); i++) {
		msg *m = &tosend[i];
		send(m->d, m->p, strlen(m->p));
	}
	natl e = waitnet();
	natl mem1 = getiomeminfo();
	printf("errori di trassmissione: %d\n", e);
	printf("memoria non liberata: %d\n", mem0 - mem1);
	pause();

	terminate_p();
}
natl hello;
natl error;

extern "C" void main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	error = activate_p(error_body, 0, 30, LIV_UTENTE);

	terminate_p();
}
