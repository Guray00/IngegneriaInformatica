#include <all.h>

#define MAX_PAYLOAD 1024

struct msg {
	natl s;
	const char *p;
};

#define MSG(src, dst, payload) { src, payload },

msg toreceive[] = {
#include "messages"
};


extern natl hello;

extern natl bad1;

extern natl bad2;

extern natl bad3;

extern natl bad4;

extern natl bad5;
void bad1_body(natq a)
{
	char buf[MAX_PAYLOAD + 1];
	natq len = MAX_PAYLOAD;
	receive(*(natl *)0x200000, buf, len);
	printf("processo errato 1\n");

	terminate_p();
}
void bad2_body(natq a)
{
	natl src;
	natq len = MAX_PAYLOAD;
	receive(src, (char *)0x200000, len);
	printf("processo errato 2\n");

	terminate_p();
}
void bad3_body(natq a)
{
	natl src;
	char buf[MAX_PAYLOAD + 1];
	receive(src, buf, *(natq *)0x200000);
	printf("processo errato 3\n");

	terminate_p();
}
void bad4_body(natq a)
{
	natl src;
	char buf[MAX_PAYLOAD + 1];
	receive(src, buf, *(natq *)(0UL-4));
	printf("processo errato 4\n");

	terminate_p();
}
void bad5_body(natq a)
{
	natl src;
	natq len = 8;
	receive(src, (char *)(0UL-4), len);
	printf("processo errato 5\n");

	terminate_p();
}
void hello_body(natq a)
{
	char magic[] = { 'A', 'B', 'C', 'D' };
	char* buf = new char[MAX_PAYLOAD + sizeof(magic)];
	natl src;
	natq len;
	int errors = 0;
	for (unsigned i = 0; i < sizeof(toreceive)/sizeof(msg); i++) {
		unsigned int j;
		len = MAX_PAYLOAD;
		src = 0;
		memcpy(buf + MAX_PAYLOAD, magic, sizeof(magic));
		natq explen = strlen(toreceive[i].p);
		bool rv = receive(src, buf, len);
		for (j = 0; j < sizeof(magic); j++) {
			if (buf[MAX_PAYLOAD + j] != magic[j]) {
				printf("message %d: write after the end of the buffer\n", i);
				errors++;
				continue;
			}
		}
		if ((explen <= MAX_PAYLOAD) != rv) {
			printf("message %d: receive() returned %s instead of the expected %s\n", i,
				(rv ? "true" : "false"), (rv ? "false" : "true"));
			errors++;
			continue;
		}
		if (len != explen) {
			printf("message %d: len is %lu instead of the expected %lu\n", i, len, explen);
			errors++;
			continue;
		}
		if (src != toreceive[i].s) {
			printf("message %d: src is %8x instead of the expected %8x\n", i, src, toreceive[i].s);
			errors++;
			continue;
		}
		buf[len <= MAX_PAYLOAD ? len : MAX_PAYLOAD] = '\0';
		for (j = 0; buf[j] && toreceive[i].p[j] && buf[j] == toreceive[i].p[j]; j++)
			;
		if (buf[j]) {
			if (toreceive[i].p[j]) {
				printf("message %d: payload error at byte %d\n", i, j);
				printf("   received '%d', expected '%d'\n", buf[j], toreceive[i].p[j]);
				errors++;
				continue;
			} else {
				printf("message %d: payload error at byte %d\n", i, j);
				printf("   received '%s' beyond expected end of message\n", buf + j);
				errors++;
				continue;
			}
		} else if (toreceive[i].p[j] && explen <= MAX_PAYLOAD) {
			printf("message %d: unexpected null byte at %d\n", i, j);
			errors++;
			continue;
		}
	}
	if (errors == 0)
		printf("receiver: no errors\n");
	pause();

	terminate_p();
}
natl hello;
natl bad1;
natl bad2;
natl bad3;
natl bad4;
natl bad5;

extern "C" void main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	bad1 = activate_p(bad1_body, 0, 50, LIV_UTENTE);
	bad2 = activate_p(bad2_body, 0, 49, LIV_UTENTE);
	bad3 = activate_p(bad3_body, 0, 48, LIV_UTENTE);
	bad4 = activate_p(bad4_body, 0, 47, LIV_UTENTE);
	bad5 = activate_p(bad5_body, 0, 46, LIV_UTENTE);

	terminate_p();
}
