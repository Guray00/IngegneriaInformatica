/// @file sys.h
/// @brief Primitive comuni definite dal modulo sistema
///
/// Queste primitive possono essere usate sia dal modulo utente che
/// dal modulo I/O.

/// @name Primitive per la gestione dei processi
/// @{

/**
 * @brief Crea un nuovo processo
 *
 * Il nuovo processo eseguirà _f(a)_ con priorità _prio_ e a livello _liv_.
 *
 * Un processo non può usare questa primitiva per creare un processo a priorità
 * o livello maggiori dei propri.
 *
 * @param f		corpo del processo
 * @param a		parametro per il corpo del processo 
 * @param prio		priorità del processo 
 * @param liv		livello del processo (LIV_UTENTE o LIV_SISTEMA)
 *
 * @return 		id del nuovo processo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl activate_p(void f(natq), natq a, natl prio, natl liv);

/**
 * @brief Termina il processo corrente.
 *
 * I processi devono invocare questa primitiva per poter terminare.
 */
extern "C" void terminate_p();

/**
 * @brief Abortisce il processo corrente.
 *
 * Come terminate_p(), ma mostra lo stato del processo sul log.
 */
extern "C" void abort_p();

/// @}

/// @name Primitive per l'utilizzo dei semafori
/// @{

/**
 * @brief Crea un nuovo semaforo.
 *
 * @param val		numero di gettoni iniziali
 *
 * @return 		id del nuovo semaforo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl sem_ini(int val);

/**
 * @brief Estrae un gettone da un semaforo.
 *
 * @param sem		id del semaforo.
 */
extern "C" void sem_wait(natl sem);

/**
 * @brief Inserisce un gettone in un semaforo.
 *
 * @param sem		id del semaforo
 */
extern "C" void sem_signal(natl sem);

/// @}

/// @name Primitive per l'utilizzo del timer
/// @{

/**
 * @brief Sospende il processo corrente.
 *
 * @param n		numero di intervalli di tempo
 */
extern "C" void delay(natl n);

/// @}

/// @name Primitive di supporto al debugging
/// @{

/**
 * @brief Informazioni di debug
 *
 * Questa struttura contiene delle informazioni che sono usate nei testi d'esame
 * per eseguire alcuni controlli.
 */
struct meminfo {
	/// numero di byte liberi nello heap di sistema
	natl heap_libero;
	/// numero di frame liberi in M2
	natl num_frame_liberi;
	/// id del processo corrente
	natl pid;
};

/**
 * @brief Estrae informazioni di debug.
 *
 * @return		struttura contenente le informazioni
 */
extern "C" meminfo getmeminfo();

/**
 * @brief Invia un messaggio al log.
 *
 * Questa primitiva è usata dai moduli I/O e utente per inviare i propri
 * messaggi al log di sistema. 
 *
 * @note Il modulo sistema usa direttamente la do_log() definita in libce.
 *
 * @param sev		severità del messaggio
 * @param buf		buffer contenente il messaggio
 * @param quanti	lunghezza del messaggio
 */
extern "C" void do_log(log_sev sev, const char* buf, natl quanti);
/// @}

// ( ESAME 2021-07-21


/// Descrittore di msg-area.
struct des_ma {
	/// base della msg-area. Se nullptr, il descrittore non è valido.
	void* base;
	/// Dimensione in numero di pagine.
	natq  npag;
};

/**
 * @brief Crea una nuova msg-area di una data dimensione.
 *
 * @pre La dimensione richiesta non può essere zero.
 *
 * @param size	dimensione della msg-area da creare (numero di pagine)
 *
 * @return 	puntatore alla base della msg-area, o nullptr in caso di errore
 */
extern "C" void*   macreate(natq size);

/**
 * @brief 	Trasferisce una msg-area ad un altro processo.
 *
 * @pre _v_ deve essere l'indirizzo base di una delle msg-area del processo invocante.
 * @pre Il processo destinatario non può essere lo stesso del processo invocante.
 * @pre Il processo destinatario non può essere un processo di livello sistema.
 *
 * La primitiva è sincrona con la marecv().
 * Nei casi un cui la primitiva restituisce false, lascia tutto inalterato
 * (in particolare, non risveglia il destinatario).
 *
 * @param v	indirizzo base della msg-area da trasferire
 * @param pid	id del processo destinatario
 *
 * @return 	false se il destinatario non esiste o se non è stato
 * 		possibile completare il trasferimento; true altrimenti
 */
extern "C" bool    masend(void *v, natl pid);

/**
 * @brief Attende il trasferimento di una msg-area.
 *
 * La primitiva è sincrona con la masend().
 *
 * @return 	il descrittore della msg-area ricevuta; il descrittore
 * 		sarà non valido se non è possibile ricevere nuove
 * 		msg-area.	
 */
extern "C" des_ma  marecv();
//   ESAME 2021-07-21 )
