QEMU_EXTRA_OPTIONS="-chardev pipe,id=ce1a,path=ce1a -device ce,id=ce1,async=ce1a"
QEMU_PRE_CMD="perl ce.pl 1 4 &"
QEMU_FIFOS="ce1 ce1a"

