/// @file sys.h
/// @brief Primitive comuni definite dal modulo sistema
///
/// Queste primitive possono essere usate sia dal modulo utente che
/// dal modulo I/O.

/// @name Primitive per la gestione dei processi
/// @{

/**
 * @brief Crea un nuovo processo
 *
 * Il nuovo processo eseguirà _f(a)_ con priorità _prio_ e a livello _liv_.
 *
 * Un processo non può usare questa primitiva per creare un processo a priorità
 * o livello maggiori dei propri.
 *
 * @param f		corpo del processo
 * @param a		parametro per il corpo del processo 
 * @param prio		priorità del processo 
 * @param liv		livello del processo (LIV_UTENTE o LIV_SISTEMA)
 *
 * @return 		id del nuovo processo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl activate_p(void f(natq), natq a, natl prio, natl liv);

/**
 * @brief Termina il processo corrente.
 *
 * I processi devono invocare questa primitiva per poter terminare.
 */
extern "C" void terminate_p();

/**
 * @brief Abortisce il processo corrente.
 *
 * Come terminate_p(), ma mostra lo stato del processo sul log.
 */
extern "C" void abort_p();

/// @}

/// @name Primitive per l'utilizzo dei semafori
/// @{

/**
 * @brief Crea un nuovo semaforo.
 *
 * @param val		numero di gettoni iniziali
 *
 * @return 		id del nuovo semaforo, o 0xFFFFFFFF in caso di errore
 */
extern "C" natl sem_ini(int val);

/**
 * @brief Estrae un gettone da un semaforo.
 *
 * @param sem		id del semaforo.
 */
extern "C" void sem_wait(natl sem);

/**
 * @brief Inserisce un gettone in un semaforo.
 *
 * @param sem		id del semaforo
 */
extern "C" void sem_signal(natl sem);

/// @}

/// @name Primitive per l'utilizzo del timer
/// @{

/**
 * @brief Sospende il processo corrente.
 *
 * @param n		numero di intervalli di tempo
 */
extern "C" void delay(natl n);

/// @}

/// @name Primitive di supporto al debugging
/// @{

/**
 * @brief Informazioni di debug
 *
 * Questa struttura contiene delle informazioni che sono usate nei testi d'esame
 * per eseguire alcuni controlli.
 */
struct meminfo {
	/// numero di byte liberi nello heap di sistema
	natl heap_libero;
	/// numero di frame liberi in M2
	natl num_frame_liberi;
	/// id del processo corrente
	natl pid;
};

/**
 * @brief Estrae informazioni di debug.
 *
 * @return		struttura contenente le informazioni
 */
extern "C" meminfo getmeminfo();

/**
 * @brief Invia un messaggio al log.
 *
 * Questa primitiva è usata dai moduli I/O e utente per inviare i propri
 * messaggi al log di sistema. 
 *
 * @note Il modulo sistema usa direttamente la do_log() definita in libce.
 *
 * @param sev		severità del messaggio
 * @param buf		buffer contenente il messaggio
 * @param quanti	lunghezza del messaggio
 */
extern "C" void do_log(log_sev sev, const char* buf, natl quanti);
/// @}

// ( ESAME 2011-06-22

/**
 * @brief Tenta di estrarre un gettone da un semaforo, con attesa interrompibile.
 *
 * La primitiva opera su normali semafori e si comporta come una normale
 * sem_wait(), ma se il processo si deve bloccare ed è stato interrotto
 * (flag @ref interrupted settato), resetta il flag, restituisce `false`
 * e termina.
 *
 * Aggiorna opportunamente in campi del descrittore di processo.
 *
 * @param sem id del semaforo
 *
 * @return  true se termina normalmente (gettone estratto), false
 *          altrimenti
 */
extern "C" bool sem_wait2(natl sem);

/**
 * @brief  Inserisce un gettone in un semaforo e gestisce eventuali interruzioni.
 *
 * La primitiva opera su normali semafori e si comporta come una normale
 * sem_signal(), ma aggiorna opportunamente i campi del descrittore di
 * processo e completa il funzionamento della sem_wait2().
 *
 * @param sem id del semaforo
 */
extern "C" void sem_signal2(natl sem);

/**
 * @brief Interrompe un processo.
 *
 * Se il processo era già stato interrotto non fa altro.
 * Se il processo non era stato interrotto e non è bloccato
 * (tramite sem_wait2()) su un semaforo, si limita a settare
 * l'opportuno flag. Infine, se il processo non era stato interrotto
 * ed è bloccato su un semaforo (tramite sem_wait2()) lo sblocca.
 * Aggiorna opportunamente i campi del descrittore di processo e del
 * semaforo e gestisce eventuali preemption.
 *
 * @param id id del processo da interrompere
 *
 * @return false se il processo non esiste, true altrimenti
 */
extern "C" bool interrupt(natl id);

/**
 * @brief Leggi e resetta il flag di interruzione.
 *
 * @return true se il flag era settato, false altrimenti
 */
extern "C" bool interrupted();
//   ESAME 2011-06 22 )
