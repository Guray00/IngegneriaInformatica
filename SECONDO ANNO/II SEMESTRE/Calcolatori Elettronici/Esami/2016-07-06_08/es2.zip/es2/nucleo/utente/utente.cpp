/*
 * Programma di test 2016-07-06
 */

#include <all.h>

const int MSG_SIZE = 16;
const int NMESG = 1;

extern natl mailbox_piena;
extern natl mailbox_vuota;

extern natl scrittore1;

extern natl scrittore2;

extern natl lettore;
struct mess {
	int mittente;
	char corpo[MSG_SIZE + 1];
};

mess mailbox;

char buf1[MSG_SIZE] __attribute__((aligned(sizeof(natl)))) = { 'a' };
natl canary1 = 0x0a0b0c0d;
char buf2[MSG_SIZE] __attribute__((aligned(sizeof(natl)))) = { 'b' };
natl canary2 = 0x0e0f0102;

char *bufs[] = { buf1, buf2 };

void pms(natq a)
{
	for (int i = 0; i < MSG_SIZE; i++) {
		bufs[a][i] = 'a' + a;
	}
	for (int i = 0; i < NMESG; i++) {
		natl quanti = MSG_SIZE;
		ceread(0, bufs[a], quanti, 'H' + a);
		sem_wait(mailbox_vuota);
		for (natl i = 0; i < quanti; i++) {
			mailbox.corpo[i] = bufs[a][i];
		}
		mailbox.corpo[quanti] = '\0';
		mailbox.mittente = a;
		sem_signal(mailbox_piena);
	}
	printf("fine scrittore %lu\n", a);

	terminate_p();
}
void pml(natq a)
{
	char corpo[MSG_SIZE];
	int mittente;
	for (int i = 0; i < 2 * NMESG; i++) {
		sem_wait(mailbox_piena);
		mittente = mailbox.mittente;
		memcpy(corpo, mailbox.corpo, sizeof(corpo));
		sem_signal(mailbox_vuota);
		printf("mittente=%d corpo=%s\n", mittente, corpo);
	}
	printf("fine lettore\n");
	printf("controllo1=%x\n", canary1);
	printf("controllo2=%x\n", canary2);
	pause();

	terminate_p();
}
natl mailbox_piena;
natl mailbox_vuota;
natl scrittore1;
natl scrittore2;
natl lettore;

extern "C" void main()
{
	mailbox_piena = sem_ini(0);
	mailbox_vuota = sem_ini(1);
	scrittore1 = activate_p(pms, 0, 6, LIV_UTENTE);
	scrittore2 = activate_p(pms, 1, 7, LIV_UTENTE);
	lettore = activate_p(pml, 0, 5, LIV_UTENTE);

	terminate_p();
}
