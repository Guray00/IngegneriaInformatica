#include <all.h>
#include <vm.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %lu: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %lu PROC %u: " s "\n", test_num, getpid(), ## __VA_ARGS__)

#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__);
#define die(s, ...) do { err(s, ## __VA_ARGS__); goto error; } while (0)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_test() do {\
	(void)&&error;\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

#define TPH(n) t##n##f0
#define TCNT(n) natl t##n##m0; natl t##n##n0; volatile natl TPH(n);
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

#define waitphase(n, f) do {\
	natq cnt_ = 0;\
	while (TPH(n) < (f)) {\
		if (++cnt_ % 32 == 0)\
			dbg("waitphase: %u != %u", TPH(n), f);\
		delay(1);\
	}\
} while (0)

#define chkphase(n, s, f) do {\
	natl f_ = TPH(n);\
	if (f_ != (f))\
		die("%s: fase %u invece di %u", s, f_, f);\
} while (0);

#define minphase(n, s, f) do {\
	natl f_ = TPH(n);\
	if (f_ < (f))\
		die("%s: troppo presto: fase %u invece di %u", s, f_, f);\
} while (0);

natq test_num;

////////////////////////////////////////////////////////////////////////////////
// TEST 01: errori vari (devono abortire)
//  - reg con gruppo non valido (4)
//  - listen senza reg
//  - doppia reg (anche su gruppo diverso)
////////////////////////////////////////////////////////////////////////////////

natl t01p0, t01p1, t01p2;
TCNT(01);

void t01p0b(natq)
{
	reg(4); // MAX_MCGROUPS = 4 => valido 0..3
	err("reg(4) non ha causato abort");
	testok(01);
	end_test();
}

void t01p1b(natq)
{
	(void)listen();
	err("listen() senza reg non ha causato abort");
	testok(01);
	end_test();
}

void t01p2b(natq)
{
	bool ok;

	ok = reg(0);
	if (!ok)
		die("reg(0) ha restituito false");

	reg(1); // seconda registrazione => abort
	err("seconda reg non ha causato abort");
	testok(01);
	end_test();
}

////////////////////////////////////////////////////////////////////////////////
// TEST 02: multicast base: 2 receiver sullo stesso gruppo ricevono lo stesso msg
//
// Fasi:
// 0: start
// 1: R0 registrato
// 2: R1 registrato
// 3: sender ha inviato
////////////////////////////////////////////////////////////////////////////////

natl t02p0, t02p1, t02p2;
TCNT(02);

void t02p0b(natq)
{
	bool ok;
	natq v;

	ok = reg(1);
	if (!ok)
		die("R0 reg(1) fallita");

	chkphase(02, "R0 reg", 0);
	TPH(02) = 1;

	v = listen();
	if (v != 0x1111)
		die("R0: msg inatteso %lx", v);

	testok(02);
	end_test();
}

void t02p1b(natq)
{
	bool ok;
	natq v;

	waitphase(02, 1);

	ok = reg(1);
	if (!ok)
		die("R1 reg(1) fallita");

	chkphase(02, "R1 reg", 1);
	TPH(02) = 2;

	v = listen();
	if (v != 0x1111)
		die("R1: msg inatteso %lx", v);

	testok(02);
	end_test();
}

void t02p2b(natq)
{
	waitphase(02, 2);

	mcast(1, 0x1111);

	chkphase(02, "sender invio", 2);
	TPH(02) = 3;

	testok(02);
	end_test();
}

////////////////////////////////////////////////////////////////////////////////
// TEST 03: wake-up: listen su coda vuota blocca e viene risvegliato da mcast
//
// Fasi:
// 0: start
// 1: receiver registrato e sta per listen (si blocca)
// 2: sender ha inviato
////////////////////////////////////////////////////////////////////////////////

natl t03p0, t03p1;
TCNT(03);

void t03p0b(natq)
{
	bool ok;
	natq v;

	ok = reg(2);
	if (!ok)
		die("reg(2) fallita");

	chkphase(03, "R reg", 0);
	TPH(03) = 1;

	v = listen(); // deve bloccare finché non arriva msg

	chkphase(03, "R sbloccato", 2);
	if (v != 0x2222)
		die("msg inatteso %lx", v);

	testok(03);
	end_test();
}

void t03p1b(natq)
{
	waitphase(03, 1);

	delay(10);

	chkphase(03, "S invio", 1);
	TPH(03) = 2;
	mcast(2, 0x2222);
	TPH(03) = 3;

	testok(03);
	end_test();
}

////////////////////////////////////////////////////////////////////////////////
// TEST 04: coda piena: un receiver non riceve l'ultimo msg se la sua coda è piena
//
// Fasi:
// 0: start
// 1: Rfull registrato
// 2: Rok registrato
// 3: sender ha finito invii (MCAST_SIZE + extra)
// 4: Rfull ha svuotato MCAST_SIZE msg (pronto al kick)
////////////////////////////////////////////////////////////////////////////////

natl t04p0, t04p1, t04p2;
TCNT(04);

void t04p0b(natq)
{
	bool ok;
	natl i;
	natq v;
	natq k;

	ok = reg(3);
	if (!ok)
		die("Rfull reg(3) fallita");

	chkphase(04, "Rfull reg", 0);
	TPH(04) = 1;

	waitphase(04, 3);

	// svuota: deve trovare 0..MCAST_SIZE-1
	for (i = 0; i < MCAST_SIZE; i++) {
		v = listen();
		if (v != i)
			die("Rfull: atteso %u, trovato %lu", i, v);
	}

	TPH(04) = 4;

	// kick per terminare senza deadlock
	k = listen();
	if (k != 0xF00D)
		die("Rfull: kick inatteso %lx", k);

	testok(04);
	end_test();
}

void t04p1b(natq)
{
	bool ok;
	natl i;
	natq v;
	natq last;

	waitphase(04, 1);

	ok = reg(3);
	if (!ok)
		die("Rok reg(3) fallita");

	chkphase(04, "Rok reg", 1);
	TPH(04) = 2;

	for (i = 0; i < MCAST_SIZE; i++) {
		v = listen();
		if (v != i)
			die("Rok: atteso %u, trovato %lu", i, v);
	}

	last = listen();
	if (last != 0xBEEF)
		die("Rok: atteso 0xBEEF, trovato %lx", last);

	testok(04);
	end_test();
}

void t04p2b(natq)
{
	natl i;

	waitphase(04, 2);

	for (i = 0; i < MCAST_SIZE; i++)
		mcast(3, i);

	mcast(3, 0xBEEF);

	TPH(04) = 3;

	waitphase(04, 4);

	mcast(3, 0xF00D);

	testok(04);
	end_test();
}

////////////////////////////////////////////////////////////////////////////////
// TEST 05: più gruppi (0..3) aggressivo: 2 msg per gruppo, FIFO
//
// Fasi:
// 0: start
// 1: R0 reg(0)
// 2: R1 reg(1)
// 3: R2 reg(2)
// 4: R3 reg(3)
// 5: sender ha inviato tutto
////////////////////////////////////////////////////////////////////////////////

natl t05p0, t05p1, t05p2, t05p3, t05p4;
TCNT(05);

static const natq G0M1 = 0xA0A00001, G0M2 = 0xA0A00002;
static const natq G1M1 = 0xB1B10001, G1M2 = 0xB1B10002;
static const natq G2M1 = 0xC2C20001, G2M2 = 0xC2C20002;
static const natq G3M1 = 0xD3D30001, G3M2 = 0xD3D30002;

void t05p0b(natq) // R0
{
	bool ok;
	natq v1, v2;

	ok = reg(0);
	if (!ok)
		die("R0 reg(0) fallita");

	chkphase(05, "R0 reg", 0);
	TPH(05) = 1;

	v1 = listen();
	if (v1 != G0M1)
		die("R0: primo msg %lx invece di %lx", v1, G0M1);

	v2 = listen();
	if (v2 != G0M2)
		die("R0: secondo msg %lx invece di %lx", v2, G0M2);

	testok(05);
	end_test();
}

void t05p1b(natq) // R1
{
	bool ok;
	natq v1, v2;

	waitphase(05, 1);

	ok = reg(1);
	if (!ok)
		die("R1 reg(1) fallita");

	chkphase(05, "R1 reg", 1);
	TPH(05) = 2;

	v1 = listen();
	if (v1 != G1M1)
		die("R1: primo msg %lx invece di %lx", v1, G1M1);

	v2 = listen();
	if (v2 != G1M2)
		die("R1: secondo msg %lx invece di %lx", v2, G1M2);

	testok(05);
	end_test();
}

void t05p2b(natq) // R2
{
	bool ok;
	natq v1, v2;

	waitphase(05, 2);

	ok = reg(2);
	if (!ok)
		die("R2 reg(2) fallita");

	chkphase(05, "R2 reg", 2);
	TPH(05) = 3;

	v1 = listen();
	if (v1 != G2M1)
		die("R2: primo msg %lx invece di %lx", v1, G2M1);

	v2 = listen();
	if (v2 != G2M2)
		die("R2: secondo msg %lx invece di %lx", v2, G2M2);

	testok(05);
	end_test();
}

void t05p3b(natq) // R3
{
	bool ok;
	natq v1, v2;

	waitphase(05, 3);

	ok = reg(3);
	if (!ok)
		die("R3 reg(3) fallita");

	chkphase(05, "R3 reg", 3);
	TPH(05) = 4;

	v1 = listen();
	if (v1 != G3M1)
		die("R3: primo msg %lx invece di %lx", v1, G3M1);

	v2 = listen();
	if (v2 != G3M2)
		die("R3: secondo msg %lx invece di %lx", v2, G3M2);

	testok(05);
	end_test();
}

void t05p4b(natq) // sender
{
	waitphase(05, 4);

	mcast(0, G0M1);
	mcast(1, G1M1);
	mcast(2, G2M1);
	mcast(3, G3M1);

	mcast(3, G3M2);
	mcast(2, G2M2);
	mcast(1, G1M2);
	mcast(0, G0M2);

	TPH(05) = 5;

	testok(05);
	end_test();
}

////////////////////////////////////////////////////////////////////////////////
// TEST 06: priorità nel wake-up di listen (stesso gruppo, multicast)
//
// Idea:
//  - Rhi e Rlo sono registrati sullo stesso gruppo e bloccati su listen().
//  - Sender fa mcast(MSG1): entrambi ricevono MSG1 e diventano pronti.
//  - Deve eseguire prima Rhi, poi Rlo (precedenza).
//  - Ripetiamo con MSG2.
//
// Fasi:
// 0: start
// 1: Rhi pronto a bloccare su listen
// 2: Rlo pronto a bloccare su listen
// 3: sender sta per inviare MSG1
// 4: Rhi ha consumato MSG1 (DEVE essere il primo)
// 5: Rlo ha consumato MSG1
// 6: sender sta per inviare MSG2
// 7: Rhi ha consumato MSG2 (DEVE essere il primo)
// 8: Rlo ha consumato MSG2
////////////////////////////////////////////////////////////////////////////////

natl t06p0, t06p1, t06p2;
TCNT(06);

static const natq T06M1 = 0x60600001;
static const natq T06M2 = 0x60600002;

void t06p0b(natq) // Rhi
{
	bool ok;
	natq v;

	ok = reg(0);
	if (!ok)
		die("Rhi reg(0) fallita");

	chkphase(06, "Rhi reg", 0);
	TPH(06) = 1;

	// --- prima ondata (MSG1) ---
	v = listen(); // blocca finché arriva MSG1
	minphase(06, "Rhi riprende MSG1", 3);
	chkphase(06, "Rhi primo MSG1", 3);
	if (v != T06M1)
		die("Rhi: MSG1 %lx invece di %lx", v, T06M1);
	TPH(06) = 4;

	// --- seconda ondata (MSG2) ---
	v = listen(); // blocca finché arriva MSG2
	minphase(06, "Rhi riprende MSG2", 6);
	chkphase(06, "Rhi primo MSG2", 6);
	if (v != T06M2)
		die("Rhi: MSG2 %lx invece di %lx", v, T06M2);
	TPH(06) = 7;

	testok(06);
	end_test();
}

void t06p1b(natq) // Rlo
{
	bool ok;
	natq v;

	waitphase(06, 1);

	ok = reg(0);
	if (!ok)
		die("Rlo reg(0) fallita");

	chkphase(06, "Rlo reg", 1);
	TPH(06) = 2;

	// --- prima ondata (MSG1) ---
	v = listen(); // blocca finché arriva MSG1
	// Rlo deve riprendere DOPO Rhi: quindi phase deve essere già 4
	chkphase(06, "Rlo dopo Rhi MSG1", 4);
	if (v != T06M1)
		die("Rlo: MSG1 %lx invece di %lx", v, T06M1);
	TPH(06) = 5;

	// --- seconda ondata (MSG2) ---
	v = listen(); // blocca finché arriva MSG2
	// Rlo deve riprendere DOPO Rhi: quindi phase deve essere già 7
	chkphase(06, "Rlo dopo Rhi MSG2", 7);
	if (v != T06M2)
		die("Rlo: MSG2 %lx invece di %lx", v, T06M2);
	TPH(06) = 8;

	testok(06);
	end_test();
}

void t06p2b(natq) // sender (prio più bassa)
{
	waitphase(06, 2);

	// annuncia PRIMA (dopo mcast può essere preemptato)
	chkphase(06, "sender annuncio MSG1", 2);
	TPH(06) = 3;
	mcast(0, T06M1);

	// aspetta che entrambi abbiano consumato MSG1 (phase==5)
	waitphase(06, 5);

	chkphase(06, "sender annuncio MSG2", 5);
	TPH(06) = 6;
	mcast(0, T06M2);

	// aspetta che entrambi abbiano consumato MSG2 (phase==8)
	waitphase(06, 8);

	testok(06);
	end_test();
}

////////////////////////////////////////////////////////////////////////////////
// MAIN
////////////////////////////////////////////////////////////////////////////////

extern natl mainp;

void main_body(natq)
{
	natl prio;

	prio = 600;
	end_test = sem_ini(0);

	// init contatori + phase
	t01m0 = sem_ini(1); t01n0 = 0; TPH(01) = 0;
	t02m0 = sem_ini(1); t02n0 = 0; TPH(02) = 0;
	t03m0 = sem_ini(1); t03n0 = 0; TPH(03) = 0;
	t04m0 = sem_ini(1); t04n0 = 0; TPH(04) = 0;
	t05m0 = sem_ini(1); t05n0 = 0; TPH(05) = 0;
	t06m0 = sem_ini(1); t06n0 = 0; TPH(06) = 0;

	// ---------------- test 01 ----------------
	test_num = 1;
	dbg(">>>INIZIO<<<: errori vari (abort atteso)");

	new_proc(01, 0);
	new_proc(01, 1);
	new_proc(01, 2);

	// devono abortire: lasciamo tempo e andiamo avanti
	delay(30);
	dbg("=== FINE ===");

	// ---------------- test 02 ----------------
	test_num = 2;
	dbg(">>>INIZIO<<<: multicast base (2 receiver stesso gruppo)");
	TPH(02) = 0;

	prio = 600;
	new_proc(02, 0);
	new_proc(02, 1);
	new_proc(02, 2);

	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);

	if (t02n0 == 3) msg("OK");
	dbg("=== FINE ===");

	// ---------------- test 03 ----------------
	test_num = 3;
	dbg(">>>INIZIO<<<: wake-up listen su coda vuota");
	TPH(03) = 0;

	prio = 600;
	new_proc(03, 0);
	new_proc(03, 1);

	sem_wait(end_test);
	sem_wait(end_test);

	if (t03n0 == 2) msg("OK");
	dbg("=== FINE ===");

	// ---------------- test 04 ----------------
	test_num = 4;
	dbg(">>>INIZIO<<<: coda piena (drop per un receiver)");
	TPH(04) = 0;

	prio = 600;
	new_proc(04, 0);
	new_proc(04, 1);
	new_proc(04, 2);

	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);

	if (t04n0 == 3) msg("OK");
	dbg("=== FINE ===");

	// ---------------- test 05 ----------------
	test_num = 5;
	dbg(">>>INIZIO<<<: più gruppi (0..3) aggressivo FIFO");
	TPH(05) = 0;

	prio = 600;
	new_proc(05, 0);
	new_proc(05, 1);
	new_proc(05, 2);
	new_proc(05, 3);
	new_proc(05, 4);

	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);

	if (t05n0 == 5) msg("OK");
	dbg("=== FINE ===");

	// ---------------- test 06 ----------------
	test_num = 6;
	dbg(">>>INIZIO<<<: priorità nel wake-up listen (stesso gruppo)");
	TPH(06) = 0;

	prio = 600;
	// ordine di creazione + prio--: t06p0 avrà prio più alta di t06p1
	new_proc(06, 0); // Rhi
	new_proc(06, 1); // Rlo
	new_proc(06, 2); // sender

	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);

	if (t06n0 == 3) msg("OK");
	dbg("=== FINE ===");


	pause();
	terminate_p();
}

natl mainp;

extern "C" void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);
	terminate_p();
}
