Introduciamo un meccanismo di *multicast* tramite il quale un processo
può inviare un messagio ad un insieme di processi. I messaggi consistono
in valori di tipo `natq`. Per ricevere i messaggi multicast, i processi
si devono preventivamente registrare per uno dei gruppi multicast
previsti dal sistema. I gruppi multicast sono identificati da un numero
compreso tra 0 e $\mathtt{MAX\_MCGROUPS}-1$.

Quando un processo si registra su un gruppo multicast, riceve una coda
privata di messaggi (realizzata come una coda circolare) da cui può
estrarre i messaggi ricevuti uno alla volta, o bloccarsi se la coda è
vuota. Quando un processo invia un messaggio multicast ad un certo
gruppo, il messaggio viene inviato a tutti i processi registrati per
quel gruppo. Se uno dei processi ha la coda piena, quel processo non
riceverà il messaggio.

Per realizzare il sistema aggiungiamo le seguenti strutture dati:

    struct mcgroup_elem {
        natw id;
        natw head;
        natw tail;
        natw nmsg;
        natq msg[MCAST_SIZE];
        mcgroup_elem *next;
        bool waiting;
    };
    mcgroup_elem* mcgroups[MAX_MCGROUPS];

Ogni `mcgroup\_elem` descrive la coda privata di un particolare
processo. Tutti gli `mcgrop\_elem` dello stesso gruppo multicast sono
organizzati in una lista semplice, tramite i puntatori `next`. La testa
della lista del gruppo $g$ è puntata da `mcgroups[`$g$`]`. Il campo `id`
è l'identificatore del processo a cui appartiene l'elemento. I campi
`head`, `tail`, `nmsg` e `msg` servono a realizzare la coda circolare di
messaggi. Il campo `waiting` è `true` se il processo è bloccato in
attesa di ricevere un messaggio.

Aggiungiamo inoltre il seguente campo ai descrittori di processo:

        mcgroup_elem* mcgroup;

Il campo contiene inizialmente `nullptr` e viene inizializzato con un
nuovo elemento `mcgroup\_elem` se il processo si registra per un gruppo
multicast.

Aggiungiamo infine le seguenti primitive:

- `bool reg(natw mcg)` (tipo 0x3a): registra il processo per il gruppo
  multicast con identificatore `mcg`. È un errore se l'identificatore
  non è valido, o se il processo è già registrato (non importa se per lo
  stesso o per un altro gruppo).

- `natq listen()` (tipo 0x3b): estrare e restituisce un messaggio dalla
  coda privata del processo; se la coda è vuota, il processo si blocca
  in attesa del prossimo messaggio; è un errore se il processo non è
  registrato per un gruppo multicast.

- `void mcast(natw mcg, natq msg)` (tipo 0x3c): invia il messaggio `msg`
  sul gruppo multicast con identificatore `mcg`; è un errore se `mcg`
  non è un identificatore valido.

Le primitive abortiscono il processo chiamante in caso di errore e
tengono conto della priorità tra i processi.

Modificare il file `sistema.cpp` in modo da realizzare le parti
mancanti.
