Definiamo un *rw* come un oggetto su cui i processi possono leggere o
scrivere rispettando le seguenti condizioni:

1.  più processi possono leggere contemporaneamente, purchè nessun
    processo stia scrivendo;

2.  un solo processo alla volta può scrivere.

Per leggere o scrivere su un rw, i processi devono prima acquisire il
diritto di lettura o scrittura, quindi devono rilasciare tale diritto
quando hanno terminato.

Per realizzare i rw definiamo la seguente struttura (file
` sistema.cpp`):

        struct des_rw {
            int  status;
            natl n_writers;
            natl n_readers;
            natl sem_writers;
            natl sem_readers;
        };

Il campo `status` contiene: $$\begin{cases}
 -1  & \text{se un processo ha acquisito il diritto di scrittura e non lo ha ancora rilasciato;}\\
 n>0 & \text{se $n$ processi hanno acquisito il diritto di lettura e non lo hanno ancora rilasciato;}\\
 0   & \text{altrimenti.}
\end{cases}$$ Il campo `n_readers` memorizza il numero di lettori in
attesa di acquisire il diritto di lettura. Il campo `n_writers`
memorizza il numero di scrittori in attesa di acquisire il diritto di
scrittura. Il campo `sem_readers` è l'indice di un semaforo su cui si
sospendono i processi in attesa di acquisire il diritto di lettura. Il
campo `sem_writers` è l'indice di un semaforo su cui si sospendono i
processi in attesa di acquisire il diritto di scrittura.

Le seguenti primitive, accessibili dal livello utente, operano sui rw
(nei casi di errore, abortiscono il processo chiamante):

-   `natl rw_init()` (tipo `0x3e`, già realizzata): inizializza un nuovo
    rw e ne restituisce l'identificatore. Se non è possibile creare un
    nuovo rw restituisce `0xFFFFFFFF`.

-   `void rw_acq_write(natl rw)` (tipo `0x3a`) : tenta di acquisire il
    diritto di scrittura sul rw di identificatore `rw`. Se ci sono già
    processi che hanno acquisito un diritto e non lo hanno ancora
    rilasciato, sospende il processo in attesa che le condizioni
    permettano l'acquisizione del diritto di scrittura.

-   `void rw_acq_read(natl rw)` (tipo `0x3b`): tenta di acquisire il
    diritto di lettura sul rw di identificatore `rw`. Se c'è un processo
    che ha acquisito il diritto di scrittura e non lo ha ancora
    rilasciato sospende il processo in attesa che le condizioni
    permettano l'acquisizione del diritto di lettura.

-   `void rw_rel_write(natl rw)` (tipo `0x3c`, già realizzata): Rilascia
    il diritto di scrittura sul rw di identificatore `rw`. Se vi sono
    processi in attesa di acquisire un diritto di lettura o scrittura,
    lo concede dando precedenza ai lettori e cercando di concedere il
    diritto a più processi possibile, nel rispetto delle condizioni.

-   `void rw_rel_read(natl rw)` (tipo `0x3d`, già realizzata): Rilascia
    il diritto di scrittura sul rw di identificatore `rw`. Se vi sono
    processi in attesa di acquisire un diritto di lettura o scrittura,
    lo concede dando precedenza agli scrittori e cercando di concedere
    il diritto a più processi possibile, nel rispetto delle condizioni.

La funzione `rw_rel_write` ha bisogno della seguente primitiva (tipo
`0x3f`, da realizzare):

-   `void sem_signal_all(natl sem)`: risveglia tutti i processi in
    attesa sul semaforo di indice `sem`.

Modificare i file `sistema.cpp` e `sistema.s` in modo da realizzare le
primitive mancanti.
