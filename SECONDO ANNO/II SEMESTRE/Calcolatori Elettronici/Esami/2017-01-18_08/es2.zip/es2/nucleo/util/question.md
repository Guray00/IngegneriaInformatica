Introduciamo un meccanismo di *broadcast* tramite il quale un processo
può inviare un messagio ad un insieme di processi. Per ricevere o
inviare un broadcast i processi si devono preventivamente registrare
come *listener* o *broadcaster*, rispettivamente. Un solo processo alla
volta può essere registrato come broadcaster (un nuovo processo può
diventare broadcaster solo quando il precedente termina).

Il sistema ricorda tutti i messaggi di broadcast inviati (fino ad un
massimo dato dalla costante `MAX_BROADCAST`) e ciascun processo listener
li riceve tutti, in ordine. I messaggi sono di tipo `natl`.

Per realizzare il sistema aggiungiamo il seguente tipo enumerato:

       enum broadcast_role { B_NONE, B_BROADCASTER, B_LISTENER };

e il seguente campo ai descrittori di processo:

      broadcast_role b_reg;

Il campo è posto a `B_NONE` alla creazione del processo.

Aggiungiamo infine le seguenti primitive:

-   `void reg(broadcast_role role)` (tipo 0x3a, da realizzare): registra
    il processo per il ruolo dato da `role`; è un errore se role non
    specifica né un broadcaster, né un listener, se il processo era già
    registrato (per lo stesso o un altro ruolo), o se cè già un
    broadcaster e si tenta di registrarne un altro;

-   `natl listen()` (tipo 0x3b, da realizzare): restituisce il prossimo
    messagio di broadcast non ancora letto dal processo; se il processo
    li ha già letti tutti, si blocca in attesa del prossimo; è un errore
    se il processo non è registrato come listener;

-   `void broadcast(natl msg)` (tipo 0x3c, da realizzare): invia in
    broadcast il messaggio `msg`; è un errore se il processo non è
    registrato come broadcaster o se il limite di messaggi di broadcast
    è stato superato.

Le primitive abortiscono il processo chiamante in caso di errore e
tengono conto della priorità tra i processi.

Modificare i file `sistema.cpp` e `sistema.S` in modo da realizzare le
primitive mancanti. Attenzione: il candidato deve definire anche le
necessarie strutture dati.
