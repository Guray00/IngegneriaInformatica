#include <all.h>


extern natl m1;
extern natl chain1;
extern natl chain2;
extern natl chain3;
extern natl middle;
natl pim1, pim2, pim3;

void p_max(natq a)
{
	sem_wait(chain3);
	sem_signal(middle);
	pim_wait(pim1);
	printf("%lu: sezione critica pim1\n", a);
	pim_signal(pim1);
	printf("%lu: termino\n", a);
	terminate_p();
}

void p_middle(natq a)
{
	sem_wait(middle);
	printf("%lu: termino\n", a);
	terminate_p();
}

void p_chain1(natq a)
{
	pim_wait(pim1);
	printf("%lu: inizio sezione critica pim1\n", a);
	sem_wait(chain1);
	pim_wait(pim2);
	printf("%lu: sezione critica pim2\n", a);
	pim_signal(pim2);
	printf("%lu: termino sezione critica pim1\n", a);
	pim_signal(pim1);
	printf("%lu: termino\n", a);
	terminate_p();
}

void p_chain2(natq a)
{
	pim_wait(pim2);
	printf("%lu: inizio sezione critica pim2\n", a);
	sem_signal(chain1);
	sem_wait(chain2);
	pim_wait(pim3);
	printf("%lu: sezione critica pim3\n", a);
	pim_signal(pim3);
	printf("%lu: termino sezione critica pim2\n", a);
	pim_signal(pim2);
	printf("%lu: termino\n", a);
	terminate_p();
}

void p_chain3(natq a)
{
	pim_wait(pim3);
	printf("%lu: inizio sezione critica pim3\n", a);
	sem_signal(chain2);
	sem_signal(chain3);
	printf("%lu: termino sezione critica pim3\n", a);
	pim_signal(pim3);
	printf("%lu: termino\n", a);
	pause();
	terminate_p();
}


void mio_main(natq a)
{
	pim1 = pim_init();
	pim2 = pim_init();
	pim3 = pim_init();
	(void) activate_p(p_max, 50, 50, LIV_UTENTE);
	(void) activate_p(p_chain1, 30, 30, LIV_UTENTE);
	(void) activate_p(p_chain2, 20, 20, LIV_UTENTE);
	(void) activate_p(p_chain3, 10, 10, LIV_UTENTE);
	(void) activate_p(p_middle, 40, 40, LIV_UTENTE);

	terminate_p();
}
natl m1;
natl chain1;
natl chain2;
natl chain3;
natl middle;

extern "C" void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);
	chain1 = sem_ini(0);
	chain2 = sem_ini(0);
	chain3 = sem_ini(0);
	middle = sem_ini(0);

	terminate_p();
}
