#include <all.h>


extern natl init;
const natl MAXMSG = 100;

struct test_des {
	natl p;  // pipe
	natl wb; // writer batch
	natl rb; // reader batch
	natl wp; // writer prio
	natl rp; // reader prio
	natl  n;  // chars to transfer
	const char src[MAXMSG];
	char dst[MAXMSG];
};

test_des tests[] = {
	{
		0xFFFFFFFF,
		2,
		3,
		20,
		30,
		6,
		"a-b-c-d-e-f-",
	},
	{
		0xFFFFFFFF,
		3,
		3,
		50,
		40,
		9,
		"1-2-3-4-5-",
	},
	{
		0xFFFFFFFF,
		4,
		6,
		25,
		45,
		7,
		"A-B-C-D-E-F-",
	}
};
		
	

void writer(natq i)
{
	test_des *d = &tests[i];
	natl j = d->n;
	const char *src = d->src;
	while (j) {
		natl n = d->wb < j ? d->wb : j;
		printf("writer %lu: invio %d byte\n", i, n);
		writepipe(d->p, src, n);
		src += n;
		j -= n;
	}
	printf("writer %lu: termino\n", i);
	terminate_p();
}

void reader(natq i)
{
	test_des *d = &tests[i];
	natl j = d->n;
	char *dst = d->dst;
	while (j) {
		natl n = d->rb < j ? d->rb : j;
		printf("reader %lu: ricevo %d byte\n", i, n);
		readpipe(d->p, dst, n);
		dst += n;
		j -= n;
	}
	printf("reader %lu: %s\n", i, d->dst);
	terminate_p();

}

void last(natq a)
{
	pause();
	terminate_p();
}

void init_body(natq a)
{
	for (size_t i = 0; i < sizeof(tests)/sizeof(test_des); i++) {
		test_des *d = &tests[i];
		d->p = inipipe();
		activate_p(writer, i, d->wp, LIV_UTENTE);
		activate_p(reader, i, d->rp, LIV_UTENTE);
	}
	activate_p(last, 3, 10, LIV_UTENTE);

	terminate_p();
}
natl init;

extern "C" void main()
{
	init = activate_p(init_body, 0, 60, LIV_UTENTE);

	terminate_p();
}
