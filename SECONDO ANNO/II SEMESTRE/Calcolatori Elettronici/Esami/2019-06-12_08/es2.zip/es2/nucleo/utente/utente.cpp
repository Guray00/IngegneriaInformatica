#include <all.h>


extern natl bad1;

extern natl bad2;

extern natl bad4;

extern natl bad5;

extern natl usr1;

extern natl usr2;

extern natl usr3;

extern natl dbg1;

extern natl dbg2;

extern natl dbg3;

extern natl last;
extern natl sync;
void bad(natq a)
{
	asm("int3");
	printf("processo errato %lu\n", a);

	terminate_p();
}
void catch_me(natq a)
{
	printf("proc%lu: eseguo funzione\n", a);
}

vaddr bad_addr[] = { 1000, 0xffffc00000000000 };

void badb(natq a)
{
	breakpoint(bad_addr[a - 3]);
	printf("processo errato %lu\n", a);

	terminate_p();
}
void usr(natq a)
{
	if (a % 2 == 0) {
		sem_wait(sync);
	}
	printf("proc%lu: prima della funzione\n", a);
	catch_me(a);
	printf("proc%lu: dopo la funzione\n", a);

	terminate_p();
}
void debugger(natq a)
{
	printf("debugger %lu: chiamo breakpoint\n", a);
	natl proc = breakpoint(reinterpret_cast<natq>(catch_me));
	if (proc == 0xFFFFFFFF) {
		printf("debugger %lu: occupato\n", a);
	} else {
		sem_signal(sync);
		printf("debugger %lu: breapoint intercettato, processo: %d\n", a, proc);
	}

	terminate_p();
}
void last_body(natq a)
{
	pause();

	terminate_p();
}
natl bad1;
natl bad2;
natl bad4;
natl bad5;
natl usr1;
natl usr2;
natl usr3;
natl dbg1;
natl dbg2;
natl dbg3;
natl last;
natl sync;

extern "C" void main()
{
	bad1 = activate_p(bad, 1, 20, LIV_UTENTE);
	bad2 = activate_p(bad, 2, 8, LIV_UTENTE);
	bad4 = activate_p(badb, 3, 21, LIV_UTENTE);
	bad5 = activate_p(badb, 4, 22, LIV_UTENTE);
	usr1 = activate_p(usr, 1, 5, LIV_UTENTE);
	usr2 = activate_p(usr, 2, 15, LIV_UTENTE);
	usr3 = activate_p(usr, 3, 3, LIV_UTENTE);
	dbg1 = activate_p(debugger, 0, 10, LIV_UTENTE);
	dbg2 = activate_p(debugger, 1, 11, LIV_UTENTE);
	dbg3 = activate_p(debugger, 2, 4, LIV_UTENTE);
	last = activate_p(last_body, 0, 1, LIV_UTENTE);
	sync = sem_ini(0);

	terminate_p();
}
