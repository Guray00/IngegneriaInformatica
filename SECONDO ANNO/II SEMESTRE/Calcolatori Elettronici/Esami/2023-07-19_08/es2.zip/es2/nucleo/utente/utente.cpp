#include <all.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %lu: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %lu PROC %d: " s "\n", test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)
#define die(s, ...) do { err(s, ## __VA_ARGS__); goto error; } while (0)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_subtest() do {\
	(void)&&error;\
error:\
	terminate_p();\
} while (0)

#define end_test() do {\
	(void)&&error;\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

#define TCNT(n)	natl t##n##m0; natl t##n##n0;
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

static inline const char* bool2str(bool v)
{
	return v ? "true" : "false";
}

#define ckrd(vn_, dst_, n_, exp_) do {\
	vceread_n(vn_, dst_, n_);\
	for (natq i = 0; i < (n_); i++) {\
		if ((dst_)[i] != (exp_)[i]) {\
			die("carattere %lu: letto %c (0x%02x) invece di %c (0x%02x)",\
				i, (dst_)[i], (dst_)[i], (exp_)[i], (exp_)[i]);\
		}\
	}\
} while (0)
natq test_num;

///**********************************************************************
// *             test 00: errori vari                                   *
// **********************************************************************/

natl t00p0;
natl t00p1;
natl t00p2;
char t00b0;

void t00p0b(natq test_num)
{
	vceread_n(VCE_NUM + 1, &t00b0, 1);
	err("accesso a vce non esistente non ha causato abort");
	terminate_p();
}

void t00p1b(natq test_num)
{
	vceread_n(VCE_NUM, &t00b0, 1);
	err("accesso a vce non esistente non ha causato abort");
	terminate_p();
}

void t00p2b(natq test_num)
{
	vceread_n(0, nullptr, 1000);
	err("buffer non valido non ha causato abort");
	terminate_p();
}

///**********************************************************************
// *             test 01: lettura di un byte gia' pronto                *
// **********************************************************************/

natl t01p0;
char t01b0;
TCNT(01);

void t01p0b(natq test_num)
{
	ckrd(0, &t01b0, 1, "?");
	testok(01);
	end_test();
}

///**********************************************************************
// *             test 02: lettura di un byte non ancora pronto          *
// **********************************************************************/

natl t02p0;
natl t02p1;
char t02b0;
TCNT(02);

void t02p0b(natq test_num)
{
	ckrd(0, &t02b0, 1, "B");
	testok(02);
	end_test();
}

void t02p1b(natq test_num)
{
	cedbg('B');
	cedbg(0);
	end_test();
}

///**********************************************************************
// *             test 03: lettura di piu' byte                          *
// **********************************************************************/

natl t03p0;
natl t03p1;
char t03b0[16];
char t03t0[] = "1234567887654321";
TCNT(03);

void t03p0b(natq test_num)
{
	ckrd(0, t03b0, 16, t03t0);
	testok(03);
	end_test();
}

void t03p1b(natq test_num)
{
	for (int i = 0; i < 8; i++)
		cedbg(t03t0[i]);
	cedbg(0);
	delay(1);
	for (int i = 0; i < 8; i++)
		cedbg(t03t0[8+i]);
	cedbg(0);
	end_test();
}

///**********************************************************************
// *             test 04: lettura da una vce non attiva ma pronta       *
// **********************************************************************/

natl t04p0;
natl t04p1;
char t04b0[8];
char t04t0[] = "abcdefgh";
TCNT(04);

void t04p0b(natq test_num)
{
	vceswitch(1);
	for (int i = 0; i < 8; i++) {
		cedbg(t04t0[i]);
		cedbg(0);
	}
	vceswitch(0);
	end_test();
}

void t04p1b(natq test_num)
{
	ckrd(1, t04b0, 8, t04t0);
	testok(04);
	end_test();
}

///**********************************************************************
// *             test 05: lettura da una vce non attiva e non pronta    *
// **********************************************************************/

natl t05p0;
natl t05p1;
char t05b0[8];
char t05t0[] = "ilmnopqr";
TCNT(05);

void t05p0b(natq test_num)
{
	vceswitch(0);
	ckrd(1, t05b0, 8, t05t0);
	testok(05);
	end_test();
}

void t05p1b(natq test_num)
{
	vceswitch(1);
	for (int i = 0; i < 8; i++)
		cedbg(t05t0[i]);
	cedbg(0);
	end_test();
}

///**********************************************************************
// *             test 06: piu' processi su vce diverse                  *
// **********************************************************************/

natl t06p0;
natl t06p1;
natl t06p2;
char t06t0[] = "ABCDDCBA";
char t06t1[] = "EFGGFE";
TCNT(06);

void t06p0b(natq test_num)
{
	char buf[8];
	ckrd(2, buf, 8, t06t0);
	testok(06);
	end_test();
}

void t06p1b(natq test_num)
{
	char buf[6];
	ckrd(3, buf, 6, t06t1);
	testok(06);
	end_test();
}

void t06p2b(natq test_num)
{
	int i, j;

	vceswitch(2);
	for (i = 0; i < 3; i++) {
		cedbg(t06t0[i]);
		cedbg(0);
	}
	while (cedbg(0xFF) & 1)
		delay(1);
	vceswitch(3);
	for (j = 0; j < 3; j++) {
		cedbg(t06t1[j]);
		cedbg(0);
	}
	while (cedbg(0xFF) & 1)
		delay(1);
	vceswitch(2);
	for (; i < 8; i++) {
		cedbg(t06t0[i]);
		cedbg(0);
	}
	while (cedbg(0xFF) & 1)
		delay(1);
	vceswitch(3);
	for (; j < 6; j++) {
		cedbg(t06t1[j]);
		cedbg(0);
	}
	end_test();
}

///**********************************************************************
// *             test 07: piu' processi sulla stesa vce                 *
// **********************************************************************/

natl t07p0;
natl t07p1;
natl t07p2;
char t07t0[] = "QWERTY";
char t07t1[] = "ASDF";
TCNT(07);

void t07p0b(natq test_num)
{
	char buf[6];
	ckrd(1, buf, 6, t07t0);
	testok(07);
	end_test();
}

void t07p1b(natq test_num)
{
	char buf[4];
	ckrd(1, buf, 4, t07t1);
	testok(07);
	end_test();
}

void t07p2b(natq test_num)
{
	int i;

	vceswitch(1);
	for (i = 0; i < 4; i++) {
		cedbg(t07t0[i]);
	}
	cedbg(0);
	while (cedbg(0xFF) & 1)
		delay(1);
	for (; i < 6; i++) {
		cedbg(t07t0[i]);
	}
	for (i = 0; i < 4; i++) {
		cedbg(t07t1[i]);
	}
	cedbg(0);
	end_test();
}

/**********************************************************************/

///**********************************************************************
// *             test 08: perdita di dati                               *
// **********************************************************************/

natl t08p0;
natl t08p1;
natl t08s0;
char t08b0[16];
char t08b1[8];
char t08t0[] = "ILMNOPQRRQPONMLIXXXXXXXXMNBVCXZL";
TCNT(08);

void t08p0b(natq test_num)
{
	sem_wait(t08s0);
	ckrd(1, t08b0, 16, t08t0);
	ckrd(1, t08b1, 8, t08t0+24);
	testok(08);
	end_test();
}

void t08p1b(natq test_num)
{
	vceswitch(1);
	for (int i = 0; i < 24; i++)
		cedbg(t08t0[i]);
	cedbg(0);
	while (cedbg(0xFF) & 1)
		delay(1);
	sem_signal(t08s0);
	for (int i = 24; i < 32; i++)
		cedbg(t08t0[i]);
	cedbg(0);
	end_test();
}


extern natl mainp;
void main_body(natq id)
{
	natl prio = 600;

	end_test = sem_ini(0);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	new_proc(00, 1);
	new_proc(00, 2);
	delay(1);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: lettura di un byte gia' pronto");
	new_proc(01, 0);
	sem_wait(end_test);
	if (t01n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: lettura di un byte non ancora pronto");
	new_proc(02, 0);
	new_proc(02, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t02n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 3;
	dbg(">>>INIZIO<<<: lettura di piu' byte");
	new_proc(03, 0);
	new_proc(03, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t03n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: lettura da una vce non attiva ma pronta");
	new_proc(04, 0);
	new_proc(04, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t04n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: lettura da una vce non attiva e non pronta");
	new_proc(05, 0);
	new_proc(05, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t05n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 6;
	dbg(">>>INIZIO<<<: piu' processi su vce diverse");
	new_proc(06, 0);
	new_proc(06, 1);
	new_proc(06, 2);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t06n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 7;
	dbg(">>>INIZIO<<<: piu' processi sulla stessa vce");
	new_proc(07, 0);
	new_proc(07, 1);
	new_proc(07, 2);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t07n0 == 2) msg("OK");

	test_num = 8;
	dbg(">>>INIZIO<<<: perdita di dati");
	t08s0 = sem_ini(0);
	new_proc(08, 0);
	new_proc(08, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t08n0 == 1) msg("OK");

	dbg("=== FINE ===");
	pause();

	terminate_p();
}
natl mainp;

extern "C" void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();
}
