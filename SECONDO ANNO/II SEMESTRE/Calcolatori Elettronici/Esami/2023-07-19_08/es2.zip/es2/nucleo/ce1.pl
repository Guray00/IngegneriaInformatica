use JSON::XS;
use Data::Dumper;
use IO::Handle;

#$debug = 1;

($dev = $0) =~ s/\.pl$//;

open $in, "<", "$dev.out";
open $out, ">", "$dev.in";
open $async, ">", "${dev}a.in";

$out->autoflush(1);
$async->autoflush(1);

$json = JSON::XS->new;

$config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 16,
			}
		],
		'interrupt-pin' => 2
	};


my $CTL;
my $STS = 0;
my $RBR;
my $pend_intr;
my @values;

sub dbg {
	my $msg = shift;
	print "$0: $msg" if $debug;
}

sub send {
	my ($ch, $msg) = @_;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on $ch\n");
	if ($ch eq "sync") {
		print $out "$r\n";
	} else {
		print $async "$r\n";
	}
}

sub receive {
	while (<$in>) {
	       	if ($obj = $json->incr_parse($_)) {
			&dbg(Dumper($obj));
			return $obj;
		}
	}
	&dbg("Bye");
	exit;
}

sub send_ret {
	my $arg = shift || 0;
	&send("sync", { return => $arg});
}

sub send_intr {
	return unless ($CTL & 1);

	if (($STS & 1) && !$pend_intr) {
		&send("async", { "raise-irq" => 1 });
		$pend_intr = 1;
	}
}

sub send_sync_intr {
	return unless ($CTL & 1);

	if (($STS & 1) && !$pend_intr) {
		&send("sync", { "raise-irq" => 1 });
		$pend_intr = 1;
	}
}

sub clear_intr {
	if ($pend_intr) {
		&send("async", { "lower-irq" => 1 });
		$pend_intr = 0;
	}
}

while (1) {
	$obj = &receive;
	if ($$obj{'get-config'}) {
		&send("sync", $config);
		&send_ret;
	} elsif ($i = $$obj{'write'}) {
		$a = $i->{'addr'};
		&send_ret if  ($a != 4 && $a != 8);
		$s = $i->{'size'};
		$v = $i->{'val'};
		if ($a == 4) {
			&send_ret if  ($s != 1);
			&dbg("### $0: writing $v at $a\n");
			($old, $CTL) = ($CTL, $v & 1);
			&dbg("### CTL $old -> $CTL\n");
			if ($old ^ $v) {
				# we are changing the interrupt enabled bit
				if ($old) {
					# was enabled, clear any pending intr
					&clear_intr
				} else {
					$RBR = 0x3f; # '?'
					$STS |= 1;
					# was disabled, send intr if necessary
					&send_sync_intr;
				}
			}
			&send_ret;
		} else {
			if ($v) {
				push @values, $v;
				if (!($STS & 1)) {
					$RBR = shift @values;
					$STS |= 1;
				}
			} elsif ($STS & 1) {
				&send_intr;
			}
			&send_ret;
		}
	} elsif ($i = $$obj{'read'}) {
		$a = $i->{'addr'};
		&send_ret if  ($a % 4 || $a > 8);
		$s = $i->{'size'};
		&send_ret if  ($s != 1);
		&dbg("### $0: reading from $a\n");
		if ($a == 0) {
			&clear_intr;
			$STS &= ~1;
			&send_ret($RBR);
			if (@values) {
				$RBR = shift @values;
				$STS |= 1;
				&send_intr;
			}
		} elsif ($a == 4) {
			&send_ret($CTL);
		} elsif ($a == 8) {
			&send_ret($STS);
		}
	}
}
