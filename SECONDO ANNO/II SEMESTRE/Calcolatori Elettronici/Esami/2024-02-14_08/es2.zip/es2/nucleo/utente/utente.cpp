#include <all.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %lu: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %lu PROC %u: " s "\n", test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)
#define die(s, ...) do { err(s, ## __VA_ARGS__); goto error; } while (0)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_subtest() do {\
	(void)&&error;\
error:\
	terminate_p();\
} while (0)

#define end_test() do {\
	(void)&&error;\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

#define TCNT(n)	natl t##n##m0; natl t##n##n0;
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

#define ckrecv(er_) do {\
	natq r_ = mq_recv();\
	if ((er_) != r_) {\
		err("ottenuto %lx invece di %lx", r_, er_);\
		goto error;\
	}\
} while (0)
natq test_num;

///**********************************************************************
// *             test 00: errori vari                                   *
// **********************************************************************/

natl t00p0;

void t00p0b(natq test_num)
{
	mq_recv();
	err("mq_recv() da processo non registrato non ha causato abort");
	terminate_p();
}

///**********************************************************************
// *             test 01: singolo messaggio, lettore bloccato           *
// **********************************************************************/

natl t01p0;
natl t01p1;
TCNT(01);

void t01p0b(natq test_num)
{
	mq_reg();
	ckrecv(0x12345678abcdabcd);
	testok(01);
	end_test();
}

void t01p1b(natq test_num)
{
	mq_send(0x12345678abcdabcd);
	testok(01);
	end_test();
}

///**********************************************************************
// *             test 02: sequenza di messaggi, lettore bloccato        *
// **********************************************************************/

natl t02p0;
natl t02p1;
TCNT(02);

void t02p0b(natq test_num)
{
	mq_reg();
	for (unsigned i = 0; i < 10U; i++)
		ckrecv(0x0102030405060708 * (i+1));
	testok(02);
	end_test();
}

void t02p1b(natq test_num)
{
	for (unsigned i = 0; i < 10U; i++)
		mq_send(0x0102030405060708 * (i+1));
	testok(02);
	end_test();
}

///**********************************************************************
// *             test 03: sequenza di messaggi, scrittore bloccato      *
// **********************************************************************/

natl t03p0;
natl t03p1;
natl t03s0;
TCNT(03);

void t03p0b(natq test_num)
{
	sem_wait(t03s0);
	for (unsigned i = 0; i < 10U; i++)
		mq_send(0x0a0b0c0d0e0f0001 * (i+1));
	testok(03);
	end_test();
}

void t03p1b(natq test_num)
{
	mq_reg();
	sem_signal(t03s0);
	for (unsigned i = 0; i < 10U; i++)
		ckrecv(0x0a0b0c0d0e0f0001 * (i+1));
	testok(03);
	end_test();
}

///**********************************************************************
// *             test 04: più lettori                                   *
// **********************************************************************/

natl t04p0;
natl t04p1;
natl t04p2;
natl t04s0;
TCNT(04);

void t04p0b(natq test_num)
{
	mq_reg();
	for (unsigned i = 0; i < 10U; i++)
		ckrecv(0x0a010b020c030d04 * (i+1));
	testok(04);
	end_test();
}

void t04p1b(natq test_num)
{
	sem_wait(t04s0);
	for (unsigned i = 0; i < 10U; i++)
		mq_send(0x0a010b020c030d04 * (i+1));
	testok(04);
	end_test();
}

void t04p2b(natq test_num)
{
	mq_reg();
	sem_signal(t04s0);
	for (unsigned i = 0; i < 10U; i++)
		ckrecv(0x0a010b020c030d04 * (i+1));
	testok(04);
	end_test();
}

///**********************************************************************
// *             test 05: processo sia lettore che scrittore            *
// **********************************************************************/

natl t05p0;
natl t05p1;
natl t05s0;
TCNT(05);

void t05p0b(natq test_num)
{
	mq_reg();
	sem_wait(t05s0);
	for (unsigned i = 0; i < 10U; i++)
		mq_send(0x0a0b0c0d0e0f0001 * (i+1));
	testok(05);
	end_test();
}

void t05p1b(natq test_num)
{
	mq_reg();
	sem_signal(t05s0);
	for (unsigned i = 0; i < 10U; i++)
		ckrecv(0x0a0b0c0d0e0f0001 * (i+1));
	testok(05);
	end_test();
}

/**********************************************************************/


extern natl mainp;
void main_body(natq id)
{
	natl prio = 600;

	end_test = sem_ini(0);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	delay(1);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: singolo messaggio, lettore bloccato");
	new_proc(01, 0);
	new_proc(01, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t01n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: sequenza di messaggi, lettore bloccato");
	new_proc(02, 0);
	new_proc(02, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t02n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 3;
	dbg(">>>INIZIO<<<: sequenza di messaggi, scrittore bloccato");
	t03s0 = sem_ini(0);
	new_proc(03, 0);
	new_proc(03, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t03n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: piu' lettori");
	t04s0 = sem_ini(0);
	new_proc(04, 0);
	new_proc(04, 1);
	new_proc(04, 2);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t04n0 == 3) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: processo sia lettore che scrittore");
	t05s0 = sem_ini(0);
	new_proc(05, 0);
	new_proc(05, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t05n0 == 2) msg("OK");
	dbg("=== FINE ===");
	pause();

	terminate_p();
}
natl mainp;

extern "C" void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();
}
