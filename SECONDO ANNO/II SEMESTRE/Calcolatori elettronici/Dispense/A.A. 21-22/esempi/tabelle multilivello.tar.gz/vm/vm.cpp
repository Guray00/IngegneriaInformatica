#include <libce.h>

extern "C" void init_vm();
extern natq* tab_4;
natq var = 3;
void main()
{
	natq *dummy = reinterpret_cast<natq*>(0x7ff000);
	init_vm();
	*dummy = 50;
	pause();
}
