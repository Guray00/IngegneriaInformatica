#include <libce.h>
void foo()
{
	natb c;
	printf("Provo a leggere RBR\n");
	c = inputb(0x60);
	printf("Ho letto RBR: %2x\n", c);
}

void foo2()
{
	printf("provo ad eseguire hlt\n");
	asm("hlt");
}

void foo3()
{
	printf("disabilito le interruzioni\n");
	asm("cli");
	printf("riabilito le interruzioni\n");
	asm("sti");
}

extern "C" void liv_utente();
extern "C" void liv_sistema();
int main()
{
	gate_init(0x70, liv_sistema);

	// proviamo ad eseguire foo() prima a livello sistema e poi a livello
	// utente
	foo();
	// portiamo il processore a livello utente
	liv_utente();
	// ora siamo a livello utente
	foo();
	// [provare anche con foo2() e foo3()]

	// nel caso in cui riusciamo ad arrivare fin qui (per esempio con foo()
	// o foo3() se IOPL=utente) dobbiamo poi ritornare alla funzione start
	// della libce. Questa vorrà eseguire alcune operazioni privilegiate e,
	// se torniamo mentre siamo ancora a livello utente, si genererà
	// un'eccezione di protezione.  Per tornare a livello sistema abbiamo
	// predisposto un gate della IDT (numero 0x70) ed eseguiamo una INT per
	// attraversarlo
	asm("int $0x70");
	pause();
}

// printf() chiama ripetutamente char_write() che, oltre a scrivere un
// carattere sul video, aggiorna il cursore hardware usando delle istruzioni
// out sui registri dell'interfaccia della scheda grafica. Per permettere
// la scrittura sul video anche da livello utente ridefiniamo cursore()
// in modo che non faccia niente.
void cursore()
{
}
