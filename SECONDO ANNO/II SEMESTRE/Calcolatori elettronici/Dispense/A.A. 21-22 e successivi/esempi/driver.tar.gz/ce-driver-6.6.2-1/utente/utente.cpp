#include <all.h>

static const natq BUFSZ = 8;
char buf[BUFSZ];
char sentinel;
void p1(natq id)
{
	sentinel = 'S';
	printf("sentinella: %c\n", sentinel);
	ceread_n(id, buf, BUFSZ);
	printf("letti da %d: ", id);
	for (natq i = 0; i < BUFSZ; i++)
		printf("%c", buf[i]);
	printf("\n");
	printf("sentinella: %c\n", sentinel);
	terminate_p();
}

void p2(natq id)
{
	for (;;);
}

void main()
{
	activate_p(p1, 0, 10, LIV_UTENTE);
	activate_p(p2, 0, 5, LIV_UTENTE);
	terminate_p();
}
