#include <libce.h>

extern "C" void init_vm();
extern "C" void flush_tlb();
extern "C" void disable_w();
int dummy;
// assumendo che &dummy = 0x20f240, forgiamo un puntatore che la raggiunge
// tramite la pagina alias (si veda vm.s)
// (nota: 240 in base 16 è 1100 in base 8)
//              444333222111oooo
int *p = (int*)00000000037771100;
void main()
{
	init_vm();
	dummy = 1;
	*p = 2;
	// disable_w();
	// flush_tlb();
	// *p = 3;
	printf("%d\n", dummy);
	pause();
}

// prova n.1
//
// compilare e avviare. Il programma dovrebbe stampare il valore 2, mostrando
// che dummy è stata modificata tramite p.  Altre cose da notare: avviare con
// il debugger e usare il comando 'vm path &dummy' oppure 'vm path p' per
// osservare il percorso si traduzione di &dummy e di p. In particolare,
// prestare attenzione a come cambiano i bit A e D nei due percorsi dopo che vengono eseguiti
// gli assegnamenti 'dummy = 1' e '*p = 2'.
//
// prova n.2
//
// commentare la riga '*p = 2' e scommentare le righe 'disable_w()' e '*p = 3',
// quindi compilare e avviare. Questa volta il programma non dovrebbe stampare
// niente.  Avviando con il debugger, si dovrebbe vedere che l'istruzione che
// traduce *p = 3 genera un'eccezione di page fault (n. 14). Visto che
// l'eccezione può essere sollevata per diversi motivi (bit P a zero,
// violazione dei bit U/S o R/W), questa eccezione lascia in pila una ulteriore
// parola quadrupla i cui 3 bit meno significativi danno indicazioni che
// permettono di risalire alla causa dell'eccezione.
//
// prova n.3 
//
// scommentare di nuovo la riga '*p = 2', quindi compilare e avviare. Questa volta
// la riga '*p = 3' non causa una eccezione. Il motivo è che la precedente scrittura
// (*p = 2) ha caricato la traduzione di p nel TLB, quando ancora W era settato a 1.
// Durante la seconda scrittura (*p = 3) la MMU ha trovato la traduzione nel TLB e,
// dunque, non ha consultato il TRIE, ignorando così la nostra modifica del bit W.
//
// prova n.4
//
// scommentare la riga 'flush_tlb()', quindi compilare e avviare. Ora la scrittura
// '*p = 3' viene correttamente fermata, perché abbiamo svuotato il TLB, costringendo
// la MMU a visitare il TRIE aggiornato.
// Nota: in questo caso non conviene svuotare completamente il TLB, ma solo l'eventuale
// riga contenente la traduzione di p. Per far questo si può usare l'istruzione invlpg
// (la funzione invalida_entrata_TLB() in libce usa questa istruzione).
