#line 1 "utente/prog/pbarrier.in"
#include <all.h>


#line 4 "utente/prog/pbarrier.in"
extern natl pbarrier;
#line 4 "utente/prog/pbarrier.in"
extern natl sync1;
#line 5 "utente/prog/pbarrier.in"
extern natl sync2;
#line 6 "utente/prog/pbarrier.in"
extern natl sync3;
#line 7 "utente/prog/pbarrier.in"
extern natl sync4;
#line 8 "utente/prog/pbarrier.in"
extern natl sync5;
#line 10 "utente/prog/pbarrier.in"
natl bar1;
natl bar2;

natl getmem()
{
	return getmeminfo().heap_libero;
}

void b1(natq a)
{
	sem_wait(sync1);
	bar1 = barrier_create(2);
	printf("processo %d: barrier_create(2) = %d\n", a, bar1);
	sem_wait(sync1);
	printf("processo %d: barrier(%d)\n", a, bar1);
	bool ret = barrier(bar1);
	printf("processo %d: barrier returned %s\n", a, ret ? "true" : "false");
	sem_wait(sync1);
	printf("processo %d: barrier(%d)\n", a, bar1);
	ret = barrier(bar1);
	printf("processo %d: barrier returned %s\n", a, ret ? "true" : "false");
	sem_wait(sync1);
	printf("processo %d: barrier_destroy(%d)\n", a, bar1);
	barrier_destroy(bar1);
	sem_wait(sync1);
	printf("processo %d: terminate\n", a);
	terminate_p();
}

void b2(natq a)
{
	sem_wait(sync2);
	printf("processo %d: barrier(%d)\n", a, bar1);
	bool ret = barrier(bar1);
	printf("processo %d: barrier returned %s\n", a, ret ? "true" : "false");
	sem_wait(sync2);
	printf("processo %d: barrier(%d)\n", a, bar1);
	ret = barrier(bar1);
	printf("processo %d: barrier returned %s\n", a, ret ? "true" : "false");
	sem_wait(sync2);
	printf("processo %d: terminate\n", a);
	terminate_p();
}

void b3(natq a)
{
	sem_wait(sync3);
	bar2 = barrier_create(3);
	printf("processo %d: barrier_create(3) = %d\n", a, bar2);
	sem_wait(sync3);
	printf("processo %d: barrier(%d)\n", a, bar2);
	bool ret = barrier(bar2);
	printf("processo %d: barrier returned %s\n", a, ret ? "true" : "false");
	sem_wait(sync3);
	ret = barrier(bar2);
	printf("processo %d: terminate\n", a);
	terminate_p();
}

void b4(natq a)
{
	sem_wait(sync4);
	printf("processo %d: barrier(%d)\n", a, bar2);
	bool ret = barrier(bar2);
	printf("processo %d: barrier returned %s\n", a, ret ? "true" : "false");
	sem_wait(sync4);
	printf("processo %d: terminate\n", a);
	terminate_p();
}

void b5(natq a)
{
	sem_wait(sync5);
	printf("processo %d: barrier_destroy(%d)\n", a, bar2);
	barrier_destroy(bar2);
	sem_wait(sync5);
	printf("processo %d: terminate\n", a);
	terminate_p();
}

natl mem;
void conductor(natq a)
{
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	sem_signal(sync4);
	sem_signal(sync4);
	sem_signal(sync5);
	sem_signal(sync3);
	sem_signal(sync4);
	sem_signal(sync5);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	natl mem2 = getmem();
	if (mem2 != mem)
		printf("memory leak: %d bytes missing\n", mem - mem2);
	pause();
	terminate_p();
}

void main_body(natq a)
#line 120 "utente/prog/pbarrier.in"
{
	activate_p(conductor, 6, 10, LIV_UTENTE);
	mem = getmem() + 152;
	activate_p(b1, 1, 30, LIV_UTENTE);
	activate_p(b2, 2, 29, LIV_UTENTE);
	activate_p(b3, 3, 28, LIV_UTENTE);
	activate_p(b4, 4, 27, LIV_UTENTE);
	activate_p(b5, 5, 26, LIV_UTENTE);

	terminate_p();
}
natl pbarrier;
natl sync1;
natl sync2;
natl sync3;
natl sync4;
natl sync5;
#line 147 "utente/utente.cpp"

void main()
{
	pbarrier = activate_p(main_body, 0, 100, LIV_UTENTE);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);
	sync4 = sem_ini(0);
	sync5 = sem_ini(0);

	terminate_p();}
