extern "C" natl activate_pe(void f(int), int a, natl prio, natl liv, natb type);
extern "C" void wfi();
extern "C" void abort_p();
extern "C" void io_panic();
extern "C" paddr trasforma(void* ff);
extern "C" bool access(const void* start, natq dim, bool writeable, bool shared = true);
extern "C" void fill_gate(natl tipo, vaddr f);

extern "C" bool kill(natl id);
