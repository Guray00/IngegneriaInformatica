#line 1 "utente/prog/pgrp.in"
#include <all.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %d: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %d PROC %d: " s "\n", test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)

#define check_newgrp(r) ({\
	dbg("chiamo newgrp()");\
	natl g__ = newgrp();\
	dbg("newgrp() restituisce %d", g__);\
	if ((r) == 0xFFFFFFFF && g__ != (r)) {\
		err("newgrp() doveva restituire 0xFFFFFFFF");\
		goto error;\
	}\
	g__;\
})

#define check_joingrp(g, r) ({\
	dbg("chiamo joingrp(%d)", g);\
	bool r__ = joingrp(g);\
	dbg("joingrp(%d) restituisce %s", (g), r__ ? "true" : "false");\
	if (r != r__) {\
		err("joingrp(%d) doveva restituire %s", (g), (r) ? "true" : "false");\
		goto error;\
	}\
	r__;\
})

#define check_waitgrp(g, r) ({\
	dbg("chiamo waitgrp(%d)", g);\
	natl p__ = waitgrp(g);\
	dbg("waitgrp(%d) restituisce %d", (g), p__);\
	if (p__ != r) {\
		err("waitgrp(%d) doveva restituire %d", (g), (r));\
		goto error;\
	}\
	p__;\
})

#define check_leavegrp() do {\
	dbg("chiamo leavegrp()");\
	leavegrp();\
	dbg("leavegrp() terminata");\
} while (0)

natl end_test; // sync

#define end_test() do {\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

/*************************************************************
 *                test 01: funzionalita' minima              *
 *************************************************************/

natl t01s1;	// sync
natl t01s2;	// sync
natl t01g1;	// gid
natl t01p0;
natl t01p1;
natl t01p2;

void t01p0b(natq test_num)
{
	sem_wait(t01s2);
	check_waitgrp(t01g1, t01p1);
	check_waitgrp(t01g1, t01p2);
	msg("OK");
	end_test();
}

void t01p1b(natq test_num)
{
	t01g1 = check_newgrp(0);
	sem_wait(t01s1);
	sem_signal(t01s2);
	end_test();
}

void t01p2b(natq test_num)
{
	check_joingrp(t01g1, true);
	sem_signal(t01s1);
	end_test();
}

/*************************************************************
 *                test 02: lasciare un gruppo                *
 *************************************************************/

natl t02s1;	// sync
natl t02g1;
natl t02p0;
natl t02p1;

void t02p0b(natq test_num)
{
	sem_wait(t02s1);
	check_waitgrp(t02g1, 0xFFFFFFFF);
	msg("OK");
	end_test();
}

void t02p1b(natq test_num)
{
	t02g1 = check_newgrp(0);
	sem_signal(t02s1);
	check_leavegrp();
	msg("OK");
	end_test();
}

/*************************************************************
 *                test 03: attesa multipla                   *
 *************************************************************/

natl t03s1;	// sync
natl t03g1;
natl t03p0;
natl t03p1;
natl t03p2;

void t03p0b(natq test_num)	// == t03p1b
{
	sem_wait(t03s1);
	check_waitgrp(t03g1, t03p2);
	msg("OK");
	end_test();
}

void t03p2b(natq test_num)
{
	t03g1 = check_newgrp(0);
	sem_signal(t03s1);
	sem_signal(t03s1);
	end_test();
}

/*************************************************************
 *                test 04: piu' gruppi                       *
 *************************************************************/

natl t04s1;	// sync
natl t04s2;	// sync
natl t04s3;	// sync
natl t04s4;	// sync
natl t04g1;
natl t04g2;
natl t04g3;
natl t04p0;
natl t04p1;
natl t04p4;
natl t04p5;
natl t04p6;

void t04p0b(natq test_num)
{
	sem_wait(t04s1);
	check_waitgrp(t04g1, t04p4);
	msg("OK");
	end_test();
}

void t04p1b(natq test_num)
{
	sem_wait(t04s2);
	check_waitgrp(t04g2, t04p5);
	msg("OK");
	end_test();
}

void t04p4b(natq test_num)
{
	t04g1 = check_newgrp(0);
	sem_signal(t04s1);
	sem_wait(t04s4);
	end_test();
}

void t04p5b(natq test_num)
{
	t04g2 = check_newgrp(0);
	sem_signal(t04s2);
	sem_wait(t04s3);
	sem_signal(t04s4);
	end_test();
}

void t04p6b(natq test_num)
{
	check_newgrp(0xFFFFFFFF);
	msg("OK");
	sem_signal(t04s3);
	end_test();
}

/*************************************************************
 *                test 05: lasciare un gruppo con newgrp     *
 *************************************************************/

natl t05s1;	// sync
natl t05s2;	// sync
natl t05s3;	// sync
natl t05s4;	// sync
natl t05s5;	// sync
natl t05g1;
natl t05g2;
natl t05p0;
natl t05p1;
natl t05p2;
natl t05p3;

void t05p0b(natq test_num)
{
	sem_wait(t05s3);
	check_waitgrp(t05g1, t05p2);
	check_waitgrp(t05g1, 0xFFFFFFFF);
	msg("OK");
	end_test();
}

void t05p1b(natq test_num)
{
	sem_wait(t05s5);
	check_waitgrp(t05g2, t05p3);
	msg("OK");
	end_test();
}

void t05p2b(natq test_num)
{
	sem_wait(t05s2);
	check_joingrp(t05g1, true);
	sem_signal(t05s3);
	sem_wait(t05s4);
	end_test();
}

void t05p3b(natq test_num)
{
	t05g1 = check_newgrp(0);
	sem_signal(t05s2);
	t05g2 = check_newgrp(0);
	sem_signal(t05s4);
	sem_signal(t05s5);
	end_test();
}

/*************************************************************
 *                test 06: attesa multipla con svuotamento   *
 *************************************************************/

natl t06s1;	// sync
natl t06g1;
natl t06p0;
natl t06p1;
natl t06p2;

void t06p0b(natq test_num)	// == t06p1b
{
	sem_wait(t06s1);
	check_waitgrp(t06g1, 0xFFFFFFFF);
	msg("OK");
	end_test();
}

void t06p2b(natq test_num)
{
	t06g1 = check_newgrp(0);
	sem_signal(t06s1);
	sem_signal(t06s1);
	check_leavegrp();
	end_test();
}

/*************************************************************
 *                test 07: newgrp fallita non ha effetti     *
 *************************************************************/

natl t07s1;	// sync
natl t07g1;
natl t07p0;
natl t07p1;

void t07p0b(natq test_num)
{
	check_newgrp(0);
	sem_wait(t07s1);
	check_waitgrp(t07g1, t07p1);
	msg("OK");
	end_test();
}

void t07p1b(natq test_num)
{
	t07g1 = check_newgrp(0);
	check_newgrp(0xFFFFFFFF);
	sem_signal(t07s1);
	end_test();
}

/*************************************************************
 *                test 08: joingrp su gruppo vuoto           *
 *************************************************************/

natl t08s1;	// sync
natl t08g1;
natl t08p0;
natl t08p1;

void t08p0b(natq test_num)
{
	sem_wait(t08s1);
	check_joingrp(t08g1, false);
	msg("OK");
	end_test();
}

void t08p1b(natq test_num)
{
	t08g1 = check_newgrp(0);
	check_leavegrp();
	sem_signal(t08s1);
	end_test();
}

/************************************************************
 *                test 00: errori vari                      *
 ************************************************************
 */

void t00p1b(natq test_num)
{
	waitgrp(0xFFFFFFFF);
	err("waitgrp su gruppo con id non valido non ha causato abort");
	terminate_p();
}

void t00p2b(natq test_num)
{
	natl g = newgrp();
	joingrp(g);
	err("joingrp da processo appartenente a un gruppo non ha causato abort");
	terminate_p();
}

void t00p3b(natq test_num)
{
	leavegrp();
	err("leavegrp da processo non appartenente a un gruppo non ha causato abort");
	terminate_p();
}

void t00p4b(natq test_num)
{
	joingrp(0xFFFFFFFF);
	err("joingrp su gruppo con id non valido non ha causato abort");
	terminate_p();
}

/**********************************************************************/


#line 366 "utente/prog/pgrp.in"
extern natl mainp;
#line 366 "utente/prog/pgrp.in"

#line 368 "utente/prog/pgrp.in"
extern natl last;
#line 368 "utente/prog/pgrp.in"
void last_body(natq a)
#line 369 "utente/prog/pgrp.in"
{
	pause();

	terminate_p();
}
void main_body(natq id)
#line 374 "utente/prog/pgrp.in"
{
	natl test_num;

	end_test = sem_ini(0);

	test_num = 0;
	activate_p(t00p1b, test_num, 603, LIV_UTENTE);
	activate_p(t00p2b, test_num, 602, LIV_UTENTE);
	activate_p(t00p3b, test_num, 601, LIV_UTENTE);
	activate_p(t00p4b, test_num, 600, LIV_UTENTE);

	test_num = 1;
	dbg(">>>INIZIO<<<: funzionalita' minima");
	t01s1 = sem_ini(0);
	t01s2 = sem_ini(0);
	t01p0 = activate_p(t01p0b, test_num, 552, LIV_UTENTE);
	t01p1 = activate_p(t01p1b, test_num, 551, LIV_UTENTE);
	t01p2 = activate_p(t01p2b, test_num, 550, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	test_num = 2;
	dbg(">>>INIZIO<<<: lasciare un gruppo");
	t02s1 = sem_ini(0);
	t02p0 = activate_p(t02p0b, test_num, 501, LIV_UTENTE);
	t02p1 = activate_p(t02p1b, test_num, 500, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	test_num = 3;
	dbg(">>>INIZIO<<<: attesa multipla");
	t03s1 = sem_ini(0);
	t03p0 = activate_p(t03p0b, test_num, 452, LIV_UTENTE);
	t03p1 = activate_p(t03p0b, test_num, 451, LIV_UTENTE);
	t03p2 = activate_p(t03p2b, test_num, 450, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	test_num = 4;
	dbg(">>>INIZIO<<<: piu' gruppi");
	t04s1 = sem_ini(0);
	t04s2 = sem_ini(0);
	t04s3 = sem_ini(0);
	t04s4 = sem_ini(0);
	t04p0 = activate_p(t04p0b, test_num, 404, LIV_UTENTE);
	t04p1 = activate_p(t04p1b, test_num, 403, LIV_UTENTE);
	t04p4 = activate_p(t04p4b, test_num, 402, LIV_UTENTE);
	t04p5 = activate_p(t04p5b, test_num, 401, LIV_UTENTE);
	t04p6 = activate_p(t04p6b, test_num, 400, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	test_num = 5;
	dbg(">>>INIZIO<<<: lasciare un gruppo con newgrp");
	t05s1 = sem_ini(0);
	t05s2 = sem_ini(0);
	t05s3 = sem_ini(0);
	t05s4 = sem_ini(0);
	t05s5 = sem_ini(0);
	t05p0 = activate_p(t05p0b, test_num, 353, LIV_UTENTE);
	t05p1 = activate_p(t05p1b, test_num, 352, LIV_UTENTE);
	t05p2 = activate_p(t05p2b, test_num, 351, LIV_UTENTE);
	t05p3 = activate_p(t05p3b, test_num, 350, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	test_num = 6;
	dbg(">>>INIZIO<<<: attesa multipla con svuotamento");
	t06s1 = sem_ini(0);
	t06p0 = activate_p(t06p0b, test_num, 302, LIV_UTENTE);
	t06p1 = activate_p(t06p0b, test_num, 301, LIV_UTENTE);
	t06p2 = activate_p(t06p2b, test_num, 300, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	test_num = 7;
	dbg(">>>INIZIO<<<: newgrp fallita non ha effetti");
	t07s1 = sem_ini(0);
	t07p0 = activate_p(t07p0b, test_num, 252, LIV_UTENTE);
	t07p1 = activate_p(t07p1b, test_num, 251, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	test_num = 8;
	dbg(">>>INIZIO<<<: joingrp su gruppo vuoto");
	t08s1 = sem_ini(0);
	t08p0 = activate_p(t08p0b, test_num, 202, LIV_UTENTE);
	t08p1 = activate_p(t08p1b, test_num, 201, LIV_UTENTE);
	sem_wait(end_test);
	sem_wait(end_test);
	dbg("===FINE===");

	terminate_p();
}
natl mainp;
natl last;
#line 495 "utente/utente.cpp"

void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);
	last = activate_p(last_body, 0, 100, LIV_UTENTE);

	terminate_p();}
