#line 1 "utente/prog/hello.in"
#include <sys.h>
#include <lib.h>


#line 5 "utente/prog/hello.in"

#line 6 "utente/prog/hello.in"
extern int sync;
#line 8 "utente/prog/hello.in"
void p1(int a, int b)
{
	printf("a=%d b=%d", a, b);
	if (a % 2)
		sem_wait(sync);
	else
		sem_signal(sync);
	terminate_p();
}

void p2(int a, int b)
{
	printf("a=%d b=%d", a, b);
	*(natl *)0 = 0;
	terminate_p();
}

void pause_body(int a)
#line 26 "utente/prog/hello.in"
{
	pause();

	terminate_p();
}
void hello_body(int a)
#line 31 "utente/prog/hello.in"
{
	newproc((void *)p1, 15, 19);
	newproc((void *)p2, 300, 17);
	newproc((void *)p1, 26, 18);
	newproc((void *)p2, 18, 17);

	terminate_p();
}
short hello;
short Pause;
int sync;
#line 49 "utente/utente.cpp"

int main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	Pause = activate_p(pause_body, 0, 10, LIV_UTENTE);
	sync = sem_ini(0);

	terminate_p();
}
