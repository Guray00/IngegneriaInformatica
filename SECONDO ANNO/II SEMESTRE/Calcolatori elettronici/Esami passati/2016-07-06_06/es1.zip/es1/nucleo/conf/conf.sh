QEMU_EXTRA_OPTIONS="-device ce,id=ce1"
QEMU_PRE_CMD="perl ce1.pl &"
QEMU_FIFOS="ce1"

