CEHDPATH=hd.img
