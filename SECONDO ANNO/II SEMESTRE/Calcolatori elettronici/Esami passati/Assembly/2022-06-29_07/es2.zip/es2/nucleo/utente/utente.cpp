#line 1 "utente/prog/pce.in"
/*
 * Programma di test 2022-06-29
 */

#include <all.h>

const int MSG_SIZE1 = DIM_PAGINA;
const int MSG_SIZE2 = 2 * DIM_PAGINA;
const int MSG_SIZE3 = DIM_PAGINA / 2;
const int MSG_SIZE4 = 3 * DIM_PAGINA;
const int MSG_SIZE5 = DIM_PAGINA - 1;
const int MAX_SIZE  = 1024;
const int NMESG = 1;

extern natl mailbox_piena;
#line 16 "utente/prog/pce.in"
extern natl mailbox_vuota;
#line 18 "utente/prog/pce.in"

#line 19 "utente/prog/pce.in"
extern natl scrittore1;
#line 19 "utente/prog/pce.in"

#line 20 "utente/prog/pce.in"
extern natl scrittore2;
#line 20 "utente/prog/pce.in"

#line 21 "utente/prog/pce.in"
extern natl scrittore3;
#line 21 "utente/prog/pce.in"

#line 22 "utente/prog/pce.in"
extern natl scrittore4;
#line 22 "utente/prog/pce.in"

#line 23 "utente/prog/pce.in"
extern natl scrittore5;
#line 23 "utente/prog/pce.in"

#line 25 "utente/prog/pce.in"
extern natl lettore;
#line 25 "utente/prog/pce.in"
struct mess {
	int mittente;
	char corpo[MAX_SIZE + 1];
};

mess mailbox;

char buf1[MSG_SIZE1] __attribute__((aligned(sizeof(natl)))) = { 'a' };
natl canary1 = 0x0a0b0c0d;
char buf2[MSG_SIZE2] __attribute__((aligned(sizeof(natl)))) = { 'b' };
natl canary2 = 0x0e0f0102;
char buf3[MSG_SIZE3] __attribute__((aligned(sizeof(natl)))) = { 'c' };
natl canary3 = 0x03040506;
char buf4[MSG_SIZE4] __attribute__((aligned(sizeof(natl)))) = { 'd' };
natl canary4 = 0x07080910;
char buf5[MSG_SIZE5] __attribute__((aligned(sizeof(natl)))) = { 'e' };
natl canary5 = 0x11121314;

char *bufs[] = { buf1, buf2, buf3, buf4, buf5 };
int sizes[] = { MSG_SIZE1, MSG_SIZE2, MSG_SIZE3, MSG_SIZE4, MSG_SIZE5 };

void pms(natq a)
#line 47 "utente/prog/pce.in"
{
	natl quanti = sizes[a];
	for (natl i = 0; i < quanti; i++) {
		bufs[a][i] = 'a' + a;
	}
	for (int k = 0; k < NMESG; k++) {
		ceread(0, bufs[a], quanti);
		sem_wait(mailbox_vuota);
		natl i, j;
		for (i = 0, j = 0; i < quanti && j < MAX_SIZE - 1; i += 500, j++) {
			mailbox.corpo[j] = bufs[a][i];
		}
		mailbox.corpo[j] = '\0';
		mailbox.mittente = a;
		sem_signal(mailbox_piena);
	}
	printf("fine scrittore %d\n", a);

	terminate_p();
}
void pml(natq a)
#line 67 "utente/prog/pce.in"
{
	char corpo[MAX_SIZE + 1];
	int mittente;
	for (int i = 0; i < 5 * NMESG; i++) {
		sem_wait(mailbox_piena);
		mittente = mailbox.mittente;
		copy(mailbox.corpo, corpo);
		sem_signal(mailbox_vuota);
		printf("mittente=%d corpo=%s\n", mittente, corpo);
	}
	printf("fine lettore\n");
	printf("controllo1=%x\n", canary1);
	printf("controllo2=%x\n", canary2);
	printf("controllo3=%x\n", canary3);
	printf("controllo4=%x\n", canary4);
	printf("controllo5=%x\n", canary5);
	pause();

	terminate_p();
}
natl mailbox_piena;
natl mailbox_vuota;
natl scrittore1;
natl scrittore2;
natl scrittore3;
natl scrittore4;
natl scrittore5;
natl lettore;
#line 118 "utente/utente.cpp"

void main()
{
	mailbox_piena = sem_ini(0);
	mailbox_vuota = sem_ini(1);
	scrittore1 = activate_p(pms, 0, 6, LIV_UTENTE);
	scrittore2 = activate_p(pms, 1, 7, LIV_UTENTE);
	scrittore3 = activate_p(pms, 2, 8, LIV_UTENTE);
	scrittore4 = activate_p(pms, 3, 9, LIV_UTENTE);
	scrittore5 = activate_p(pms, 4, 10, LIV_UTENTE);
	lettore = activate_p(pml, 0, 5, LIV_UTENTE);

	terminate_p();}
