QEMU_EXTRA_OPTIONS="-device ce,id=ce1"
QEMU_PRE_CMD="perl ce1.pl &"
QEMU_FIFOS="ce1"
QEMU=/usr/local/CE/bin/qemu-system-x86_64
QEMU_BOOT=/usr/local/CE/lib/ce/boot.bin
MEM=8
