use threads;
use threads::shared;
use strict;
use JSON::XS;
use Data::Dumper;
use IO::Handle;
use Time::HiRes qw(usleep);
use Thread::Queue;

my $debug = 0;

my $ID = $ARGV[0];
my $NCHAN = $ARGV[1];
my $DEV = "ce$ID";

my ($in, $out, $ain, $aout);

open $in, "<", "$DEV.out";
open $out, ">", "$DEV.in";
open $ain, "<", "${DEV}a.out";
open $aout, ">", "${DEV}a.in";

$out->autoflush(1);
$aout->autoflush(1);

my $json = JSON::XS->new->allow_nonref;

my $config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 32,
			}
		],
		'interrupt-pin' => 2
	};


my $CHN = int(0);
my $iCHN = 0;
my $STS :shared = int(0);
my $iSTS = 4;
my $BMCR3 = int(0);
my $iBMCR3 = 8;
my $BMPTR_HIGH = int(0);
my $iBMPTR_HIGH = 12;
my $BMPTR_LOW = int(0);
my $iBMPTR_LOW = 16;
my $BMLEN = int(0);
my $iBMLEN = 20;
my $pend_intr :shared = 0;

my $dout;
if ($debug) {
	open $dout, ">", "debug.$ID";
	$dout->autoflush(1);
}

sub dbg {
	my $msg = shift;
	$| = 1;
	if ($debug) {
		printf $dout "$DEV: $msg", @_;
	}
}

sub send {
	my ($ch, $msg) = @_;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on $ch\n");
	if ($ch eq "sync") {
		print $out "$r\n";
	} else {
		print $aout "$r\n";
	}
	&dbg("### $0: done sending\n");
}

my $thr;
my $queue = Thread::Queue->new();

sub send_cmd {
	my ($c, $t, $b, $l) = @_;
	&dbg("### $0: enqueing $c, $t, $b, $l\n");
	$queue->enqueue("$c,$t,$b,$l");
}

sub receive {
	my $ch = shift || "sync";
	my $i = \*$in;
	my $obj;
	if ($ch eq "async") {
		$i = \*$ain;
	}
	&dbg("### $0: receiving from $ch\n");
	while (<$i>) {
	       	if ($obj = $json->incr_parse($_)) {
			&dbg("[$ch]<-" . Dumper($obj));
			return $obj;
		}
	}
	&dbg("### $0: exiting...\n");
	&stop_running;
	$thr->join();
	exit;
}

sub send_ret {
	my $arg = shift || 0;
	&send('sync', { return => int($arg)});
}

sub send_intr {
	lock($pend_intr);
	if (!$pend_intr) {
		&send('async', { "raise-irq" => 1 });
		&receive('async');
		$pend_intr = 1;
	}
}

sub clear_intr {
	lock($pend_intr);
	if ($pend_intr) {
		&send('sync', { "lower-irq" => 1 });
		&receive('sync');
		$pend_intr = 0;
	}
}

sub stop_running
{
	$queue->enqueue('-1');
}

sub get_des
{
	my $p = shift;
	&send("async", { "dma-read" => { addr => $p, len => 8 } });
	my $obj = &receive("async");
	my @a = ();
	if (!(@a = @{$obj->{'bytes'}})) {
		&dbg("no bytes?\n");
		return 0;
	}
	my $addr = 0;
	$a[6] &= 0x0f;
	$a[1] &= 0xf0;
	for (my $i = 6; $i >= 1; $i--) {
		$addr <<= 8;
		$addr |= $a[$i];
	}
	return (int($a[0]), $addr << 8);	
}

sub translate {
	my $b = int(shift);
	my $v = int(shift);
	my $sh = 36;
	my $d;
	for (my $i = 4; $i >= 1; $i--) {
		($d, $b) = &get_des($b | (($v >> $sh) & 07770));
		&dbg("translate(%x) lev $i -> access %x, next %x\n", $v, $d, $b);
		if (!($d & 1)) {
			return 0;
		}
		$sh -= 9;
	}
	return $b | ($v & 0xfff);
}

sub start_dma {
	my ($cr3, $v, $tosend, $off) = @_;
	#push @log, $v, $tosend;
	&dbg("### DMA %x+%x CR3=%x\n", $v, $tosend, $cr3);
	my $beg = int($off);
	my $end = $beg;
	while ($tosend) {
		my $p = &translate($cr3, $v);
		if (!$p) {
			last;
		}
		my $next_pag = ($p + 4096) & ~0xfff;
		my $len = $next_pag - $p;
		my $trans = ($len, $tosend)[$tosend < $len];
		my $end = $beg + $trans - 1;
		$tosend -= $trans;
		#dbg("### addr %x - %x len $len trans $trans remain $CNT\n", $v, $p);
		my $reply = {
			"dma-write" => {
				addr => int($p),
				len  => int($trans),
				bytes => [map { ($_ % 26) + 65 } $beg..$end],
			}
		};
		&send("async", $reply);
		&receive("async");
		$v += $trans;
		$beg = $end + 1;
	}
	return $end + 1;
}

sub process_cmd {
	my (@chans, @bmcr3, @bmptr, @bmlen, @choff);

	for my $c (0 .. $NCHAN) {
		$choff[$c] = int($c);
	}

	while (1) {
		my $m = $queue->dequeue_nb();
		if (defined($m)) {
			&dbg("### $0: dequeued $m\n");
			# exit or start new channel
			my ($c, $t, $b, $l) = split /,/, $m;
			if ($c < 0) {
				last;
			}
			if ($c < $NCHAN && $l > 0) {
				$bmcr3[$c] = int($t);
				$bmptr[$c] = int($b);
				$bmlen[$c] = int($l);
				push @chans, $c;
			}
		}
		# process all active channels
		my @nextchans = ();
		while (@chans) {
			my $c = shift @chans;
			my $tosend = $bmlen[$c];
			if ($tosend > 1024) {
				$tosend = 1024;
			}
			$choff[$c] = &start_dma($bmcr3[$c], $bmptr[$c], $tosend, $choff[$c]);
			$bmptr[$c] += $tosend;
			$bmlen[$c] -= $tosend;
			if (!$bmlen[$c]) {
				lock($STS);
				$STS &= ~(1 << $c);
				&send_intr;
			} else {
				push @nextchans, $c;
			}
		}
		@chans = @nextchans;
		usleep(10000);
	}
}

$thr = threads->create(\&process_cmd);

while (1) {
	my $obj = &receive;
	if ($$obj{'get-config'}) {
		&send('sync', $config);
		&send_ret;
	} elsif (my $i = $$obj{'write'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		my $v = $i->{'val'};
		&dbg("### writing $v at $a\n");
		if      ($a == $iCHN) {
			$CHN = $v;
			# activate channel if not already active
			lock($STS);
			if ($STS & (1 << $v)) {
				next;
			}
			$STS |= (1 << $v);
			my $a = $BMPTR_HIGH << 32 | $BMPTR_LOW;
			&send_cmd($v, $BMCR3, $a, $BMLEN);
		} elsif ($a == $iSTS) {
			# readonly
		} elsif ($a == $iBMCR3) {
			$BMCR3 = $v;
		} elsif ($a == $iBMPTR_HIGH) {
			$BMPTR_HIGH = $v;
		} elsif ($a == $iBMPTR_LOW) {
			$BMPTR_LOW = $v;
		} elsif ($a == $iBMLEN) {
			$BMLEN = $v;
		}
		&send_ret;
	} elsif (my $i = $$obj{'read'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		&dbg("### reading from $a\n");
		my $ret;
		if      ($a == $iCHN) {
			$ret = $CHN;
		} elsif ($a == $iSTS) {
			lock($STS);
			$ret = $STS;
			&clear_intr;
		} elsif ($a == $iBMCR3) {
			$ret = $BMCR3;
		} elsif ($a == $iBMPTR_HIGH) {
			$ret = $BMPTR_HIGH;
		} elsif ($a == $iBMPTR_LOW) {
			$ret = $BMPTR_LOW;
		} elsif ($a == $iBMLEN) {
			$ret = $BMLEN;
		}
		&send_ret($ret);
	}
}
