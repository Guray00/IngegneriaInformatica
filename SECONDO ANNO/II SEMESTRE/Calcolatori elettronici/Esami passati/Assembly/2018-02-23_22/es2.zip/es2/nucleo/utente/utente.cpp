#line 1 "utente/prog/hello.in"
#include <sys.h>
#include <lib.h>


#line 6 "utente/prog/hello.in"
void loop(int a)
{
	while (true)
		;
}

void good(int a)
{
	printf("proc%d: termino", a);
	terminate_p();
}

void last(int a)
{
	pause();
	terminate_p();
}


void hello_body(int a)
#line 26 "utente/prog/hello.in"
{
	newproc(loop, 0, 40, 1);
	newproc(good, 1, 35, 1);
	newproc(good, 2, 30, 1);
	newproc(good, 3, 25, 1);
	newproc(loop, 4, 20, 1);
	activate_p(last, 6, 5, LIV_UTENTE);

	terminate_p();
}
short hello;
#line 40 "utente/utente.cpp"

int main()
{
	hello = activate_p(hello_body, 0, 50, LIV_UTENTE);

	terminate_p();
}
