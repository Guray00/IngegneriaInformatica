#line 1 "utente/prog/pbufcache.in"
#include <all.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %d: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %d PROC %d: " s "\n", test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)
#define die(s, ...) do { err(s, ## __VA_ARGS__); goto error; } while (0)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_subtest() do {\
	(void)&&error;\
error:\
	terminate_p();\
} while (0)

#define end_test() do {\
	(void)&&error;\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

#define TCNT(n)	natl t##n##m0; natl t##n##n0;
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

static const natl START_BLOCK = 32;
static const natl NUM_BLOCKS = 64;

int test_num;

///**********************************************************************
// *             test 00: errori vari                                   *
// **********************************************************************/

natl t00p0;
natl t00p1;
natl t00p2;
natl t00p3;
natl t00p4;

void t00p0b(natq test_num)
{
	bufread_n(nullptr, 0, 1);
	err("bufread_n su nullptr non ha causato abort");
	terminate_p();
}

void t00p1b(natq test_num)
{
	bufread_n((natb*)t00p1b, 0, 1);
	err("bufread_n su memoria non scrivibile non ha causato abort");
	terminate_p();
}

void t00p2b(natq test_num)
{
	bufwrite_n(nullptr, 0, 1);
	err("bufwrite_n su nullptr non ha causato abort");
	terminate_p();
}


///**********************************************************************
// *             test 01: lettura di un byte                            *
// **********************************************************************/

static const natl t01o0 = 236;
static const natl t01w0 = START_BLOCK * DIM_BLOCK + t01o0;

natl t01p0;
TCNT(01);

natb t01b0[2*DIM_BLOCK];

void t01p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl brd, rd, bwr, wr;

	bufcache_status(nullptr, &brd, &bwr);
	for (natl i = 0; i < 2*DIM_BLOCK; i++)
		t01b0[i] = 0xFF;
	bufread_n(&t01b0[DIM_BLOCK], t01w0, 1);
	for (natl i = 0; i < 2*DIM_BLOCK; i++) {
		if (i != DIM_BLOCK && t01b0[i] != 0xFF)
			die("bufread_n() ha scritto in vetti piu' byte di quanto richiesto");
		if (i == DIM_BLOCK && t01b0[i] != t01o0)
			die("letto %2x invece di %2x", t01b0[i], t01o0);
	}
	if ( (n = bufcache_status(blocks, &rd, &wr)) != 1)
		die("la bufcache contiene %d blocchi invece di 1");
	if (blocks[0] != t01w0 / DIM_BLOCK)
		die("la bufcache contiene il blocco %d invece di %d",
			blocks[0], t01w0 / DIM_BLOCK);
	if (rd - brd != 1)
		die("eseguite %d letture invece di una", rd - brd);
	if (wr - bwr != 0)
		die("eseguite %d scritture invece di zero", wr - bwr);
	testok(01);
	end_test();
}

///**********************************************************************
// *             test 02: lettura di da più blocchi                     *
// **********************************************************************/

static const natl t02o0 = 300;
static const natl t02w0 = START_BLOCK * DIM_BLOCK + t02o0;
static const natl t02s0 = 2 * DIM_BLOCK - 24;

natl t02p0;
TCNT(02);

natb t02b0[t02s0];

void t02p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl brd, rd, bwr, wr;

	bufcache_status(nullptr, &brd, &bwr);
	for (natl i = 0; i < t02s0; i++)
		t02b0[i] = 0xFF;
	bufread_n(t02b0, t02w0, t02s0);
	for (natl i = 0; i < t02s0; i++) {
		natb e = t02w0 + i;
		if (t02b0[i] != e)
			die("letto %2x invece di %2x", t02b0[i], e);
	}
	if ( (n = bufcache_status(blocks, &rd, &wr)) != 3)
		die("la bufcache contiene %d blocchi invece di 3");
	if (rd - brd != 2)
		die("eseguite %d letture invece di due", rd - brd);
	if (wr - bwr != 0)
		die("eseguite %d scritture invece di zero", wr - bwr);
	testok(02);
	end_test();
}

///**********************************************************************
// *             test 03: scrittura in cache                            *
// **********************************************************************/

static const natl t03o0 = 17;
static const natl t03w0 = (START_BLOCK + 1) * DIM_BLOCK + t03o0;
static const natl t03s0 = 3;

natb t03b0[t03s0];
natb t03b1[t03s0];
natl t03p0;
TCNT(03);

void t03p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl r1, r2, r3, w1, w2, w3;

	bufcache_status(nullptr, &r1, &w1);
	for (natq j = 0; j < t03s0; j++)
		t03b0[j] = 0xFF;
	bufwrite_n(t03b0, t03w0, t03s0);
	if ( (n = bufcache_status(blocks, &r2, &w2)) != 3)
		die("la bufcache contiene %d blocchi invece di 3", n);
	if (r2 - r1 != 0)
		die("eseguite %d letture invece di zero", r2 - r1);
	if (w2 - w1 != 0)
		die("eseguite %d scritture invece di zero", w2 - w1);
	bufread_n(t03b1, t03w0, t03s0);
	for (natq j = 0; j < t03s0; j++)
		if (t03b1[j] != t03b0[j])
			die("byte %d: letto %2x invece di %2x",
				t03w0+j, t03b1[j], t03b0[j]);
	if ( (n = bufcache_status(blocks, &r3, &w3)) != 3)
		die("la bufcache contiene %d blocchi invece di 3", n);
	if (r3 - r2 != 0)
		die("eseguite %d letture invece di zero", r3 - r2);
	if (w3 - w2 != 0)
		die("eseguite %d scritture invece di zero", w3 - w2);
	testok(03);
	end_test();
}

///**********************************************************************
// *             test 04: scrittura non in cache                        *
// **********************************************************************/

static const natl t04o0 = 42;
static const natl t04w0 = (START_BLOCK + 2) * DIM_BLOCK + t04o0;
static const natl t04s0 = 512;

natb t04b0[t04s0];
natb t04b1[t04s0];
natl t04p0;
TCNT(04);

void t04p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl r1, r2, r3, w1, w2, w3;

	bufcache_status(nullptr, &r1, &w1);
	for (natq j = 0; j < t04s0; j++)
		t04b0[j] = 0x11;
	bufwrite_n(t04b0, t04w0, t04s0);
	if ( (n = bufcache_status(blocks, &r2, &w2)) != 4)
		die("la bufcache contiene %d blocchi invece di 4", n);
	if (r2 - r1 != 1)
		die("eseguite %d letture invece di zero", r2 - r1);
	if (w2 - w1 != 0)
		die("eseguite %d scritture invece di zero", w2 - w1);
	bufread_n(t04b1, t04w0, t04s0);
	for (natq j = 0; j < t04s0; j++)
		if (t04b1[j] != t04b0[j])
			die("byte %d: letto %2x invece di %2x",
				t04w0+j, t04b1[j], t04b0[j]);
	if ( (n = bufcache_status(blocks, &r3, &w3)) != 4)
		die("la bufcache contiene %d blocchi invece di 4", n);
	if (r3 - r2 != 0)
		die("eseguite %d letture invece di zero", r3 - r2);
	if (w3 - w2 != 0)
		die("eseguite %d scritture invece di zero", w3 - w2);
	testok(04);
	end_test();
}

///**********************************************************************
// *             test 05: rimpiazzamento                                *
// **********************************************************************/

static const natl t05o0 = 0;
static const natl t05w0 = (START_BLOCK + 8) * DIM_BLOCK + t05o0;
static const natl t05s0 = 4 * DIM_BLOCK;

natl t05p0;
TCNT(05);

natb t05b0[t05s0];
natb t05b1[2*DIM_BLOCK];

void t05p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl brd, rd, bwr, wr;

	bufcache_status(nullptr, &brd, &bwr);
	for (natl i = 0; i < t05s0; i++)
		t05b0[i] = 0xFF;
	bufread_n(t05b0, t05w0, t05s0);
	for (natl i = 0; i < t05s0; i++) {
		natb e = t05w0 + i;
		if (t05b0[i] != e)
			die("letto %2x invece di %2x", t05b0[i], e);
	}
	if ( (n = bufcache_status(blocks, &rd, &wr)) != 4)
		die("la bufcache contiene %d blocchi invece di 4");
	if (rd - brd != 4)
		die("eseguite %d letture invece di quattro", rd - brd);
	if (wr - bwr != 3)
		die("eseguite %d scritture invece di tre", wr - bwr);
	dmareadhd_n(t05b1, t04w0/DIM_BLOCK, 2);
	for (natq j = 0; j < t04s0; j++)
		if (t05b1[j + t04o0] != t04b1[j])
			die("byte %d: letto %2x invece di %2x",
				t04w0+j, t05b1[j], t04b1[j]);
	testok(05);
	end_test();
}

///**********************************************************************
// *             test 06: scrittura non in cache ottimizzata            *
// **********************************************************************/

static const natl t06o0 = 100;
static const natl t06w0 = START_BLOCK * DIM_BLOCK + t06o0;
static const natl t06s0 = 3 * DIM_BLOCK;

natb t06b0[t06s0];
natb t06b1[t06s0];
natl t06p0;
TCNT(06);

void t06p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl r1, r2, r3, w1, w2, w3;

	bufcache_status(nullptr, &r1, &w1);
	for (natq j = 0; j < t06s0; j++)
		t06b0[j] = 0x55;
	bufwrite_n(t06b0, t06w0, t06s0);
	if ( (n = bufcache_status(blocks, &r2, &w2)) != 4)
		die("la bufcache contiene %d blocchi invece di 4", n);
	if (r2 - r1 != 2)
		die("eseguite %d letture invece di due", r2 - r1);
	if (w2 - w1 != 0)
		die("eseguite %d scritture invece di zero", w2 - w1);
	bufread_n(t06b1, t06w0, t06s0);
	for (natq j = 0; j < t06s0; j++)
		if (t06b1[j] != t06b0[j])
			die("byte %d: letto %2x invece di %2x",
				t06w0+j, t06b1[j], t06b0[j]);
	if ( (n = bufcache_status(blocks, &r3, &w3)) != 4)
		die("la bufcache contiene %d blocchi invece di 4", n);
	if (r3 - r2 != 0)
		die("eseguite %d letture invece di zero", r3 - r2);
	if (w3 - w2 != 0)
		die("eseguite %d scritture invece di zero", w3 - w2);
	testok(06);
	end_test();
}


#if 0
///**********************************************************************
// *             test 03: sync                                          *
// **********************************************************************/

natl t03p0;
TCNT(03);

natb t03b0[DIM_BLOCK];
natb t03b1[DIM_BLOCK];

void t03p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl r1, r2, r3, w1, w2, w3;
	natl b = first_block + 3;

	bufcache_status(nullptr, &r1, &w1);
	readhd_n(t03b0, b, 1);
	if ( (n = bufcache_status(blocks, &r2, &w2)) != 2)
		die("la bufcache contiene %d blocchi invece di 2");
	if (r2 - r1 != 1)
		die("eseguite %d letture invece di una", r2 - r1);
	if (w2 - w1 != 0)
		die("eseguite %d scritture invece di zero", w2 - w1);
	synchd();
	if ( (n = bufcache_status(blocks, &r3, &w3)) != 2)
		die("la bufcache contiene %d blocchi invece di 2");
	if (r3 - r2 != 0)
		die("eseguite %d letture invece di zero", r3 - r2);
	if (w3 - w2 != 1)
		die("eseguite %d scritture invece di una", w3 - w2);
	dmareadhd_n(t03b1, first_block, 1);
	for (natq j = 0; j < DIM_BLOCK; j++)
		if (t03b1[j] != 'a')
			die("blocco %d, byte %d: letto %c invece di %c",
				first_block, j, t03b1[j], 'a');
	testok(03);
	end_test();
}

///**********************************************************************
// *             test 04: scrittura di un blocco non cache              *
// **********************************************************************/

natb t04b0[DIM_BLOCK];
natb t04b1[DIM_BLOCK];
natl t04p0;
TCNT(04);

void t04p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl r1, r2, r3, w1, w2, w3;
	natl b = first_block + 4;

	bufcache_status(nullptr, &r1, &w1);
	for (natq j = 0; j < DIM_BLOCK; j++)
		t04b0[j] = 'c';
	writehd_n(t04b0, b, 1);
	if ( (n = bufcache_status(blocks, &r2, &w2)) != 3)
		die("la bufcache contiene %d blocchi invece di 3", n);
	for (int i = 0; i < n; i++) {
		if (blocks[i] == b)
			goto found;
	}
	die("la bufcache non contiene il blocco %d", b);
found:
	if (r2 - r1 != 0)
		die("eseguite %d letture invece di zero", r2 - r1);
	if (w2 - w1 != 0)
		die("eseguite %d scritture invece di zero", w2 - w1);
	readhd_n(t04b1, b, 1);
	for (natq j = 0; j < DIM_BLOCK; j++)
		if (t04b1[j] != 'c')
			die("blocco %d, byte %d: letto %c invece di %c",
				b, j, t04b1[j], 'c');
	if ( (n = bufcache_status(blocks, &r3, &w3)) != 3)
		die("la bufcache contiene %d blocchi invece di 3", n);
	if (r3 - r2 != 0)
		die("eseguite %d letture invece di zero", r3 - r2);
	if (w3 - w2 != 0)
		die("eseguite %d scritture invece di zero", w3 - w2);
	testok(04);
	end_test();
}


///**********************************************************************
// *             test 05: rimpiazzamento                                *
// **********************************************************************/

natb t05b0[DIM_BLOCK * MAX_BUF_DES];
natb t05b1[DIM_BLOCK];
natb t05b2[DIM_BLOCK];
natl t05p0;
TCNT(05);

void t05p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl r1, r2, w1, w2;
	natl b = first_block + 5;
	natl wb = first_block + 4;
	natl m1, m2;

	bufcache_status(nullptr, &r1, &w1);
	readhd_n(t05b0, b, MAX_BUF_DES);
	if ( (n = bufcache_status(blocks, &r2, &w2)) != MAX_BUF_DES)
		die("la bufcache contiene %d blocchi invece di %d", n, MAX_BUF_DES);
	if (r2 - r1 != MAX_BUF_DES)
		die("eseguite %d letture invece di %d", r2 - r1, MAX_BUF_DES);
	if (w2 - w1 != 1)
		die("eseguite %d scritture invece di 1", w2 - w1);
	m1 = 0;
	for (int i = 0; i < MAX_BUF_DES; i++)
		m1 |= 1U << (5 + i);
	m2 = 0;
	for (int i = 0; i < MAX_BUF_DES; i++)
		m2 |= 1U << (blocks[i] - first_block);
	if (m1 != m2)
		die("la bufcache non contiene tutti e soli i blocchi attesi");
	dmareadhd_n(t05b2, wb, 1);
	for (natq j = 0; j < DIM_BLOCK; j++)
		if (t05b2[j] != 'c')
			die("blocco %d, byte %d: letto %c invece di %c",
				wb, j, t05b2[j], 'c');
	testok(05);
	end_test();
}

///**********************************************************************
// *             test 06: sync 2                                        *
// **********************************************************************/

natl t06p0;
TCNT(06);

natb t06b0[DIM_BLOCK * 2];
natb t06b1[DIM_BLOCK * 2];

void t06p0b(natq test_num)
{
	natl blocks[MAX_BUF_DES];
	int n;
	natl r1, r2, r3, r4, w1, w2, w3, w4;
	natl b = first_block + 6;

	bufcache_status(nullptr, &r1, &w1);
	for (natq j = 0; j < DIM_BLOCK * 2; j++)
		t06b0[j] = 'd';
	writehd_n(t06b0, b, 2);
	if ( (n = bufcache_status(blocks, &r2, &w2)) != MAX_BUF_DES)
		die("la bufcache contiene %d blocchi invece di %d", MAX_BUF_DES);
	if (r2 - r1 != 0)
		die("eseguite %d letture invece di zero", r2 - r1);
	if (w2 - w1 != 0)
		die("eseguite %d scritture invece di zero", w2 - w1);
	synchd();
	if ( (n = bufcache_status(blocks, &r3, &w3)) != MAX_BUF_DES)
		die("la bufcache contiene %d blocchi invece di %d", MAX_BUF_DES);
	if (r3 - r2 != 0)
		die("eseguite %d letture invece di zero", r3 - r2);
	if (w3 - w2 != 2)
		die("eseguite %d scritture invece di 2", w3 - w2);
	dmareadhd_n(t06b1, b, 2);
	for (natq j = 0; j < DIM_BLOCK; j++)
		if (t06b1[j] != 'd')
			die("blocco %d, byte %d: letto %c invece di %c",
				b, j, t06b1[j], 'd');
	synchd();
	if ( (n = bufcache_status(blocks, &r4, &w4)) != MAX_BUF_DES)
		die("la bufcache contiene %d blocchi invece di %d", n, MAX_BUF_DES);
	if (r4 - r3 != 0)
		die("eseguite %d letture invece di zero", r4 - r3);
	if (w4 - w3 != 0)
		die("eseguite %d scritture invece di zero", w4 - w3);
	testok(06);
	end_test();
}
#endif
/**********************************************************************/



#line 515 "utente/prog/pbufcache.in"
extern natl mainp;
#line 515 "utente/prog/pbufcache.in"
static const natl TOT = NUM_BLOCKS * DIM_BLOCK;
natb inib[TOT];
void main_body(natq id)
#line 518 "utente/prog/pbufcache.in"
{
	natl prio = 600;

	for (natl i = 0; i < TOT; i++)
		inib[i] = i;
	dmawritehd_n(inib, START_BLOCK, NUM_BLOCKS);

	end_test = sem_ini(0);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	delay(1);
	new_proc(00, 1);
	delay(1);
	new_proc(00, 2);
	delay(1);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: lettura di un byte");
	t01m0 = sem_ini(1);
	new_proc(01, 0);
	sem_wait(end_test);
	if (t01n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: lettura da piu' blocchi");
	t02m0 = sem_ini(1);
	new_proc(02, 0);
	sem_wait(end_test);
	if (t02n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 3;
	dbg(">>>INIZIO<<<: scrittura in cache");
	t03m0 = sem_ini(1);
	new_proc(03, 0);
	sem_wait(end_test);
	if (t03n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: scrittura non in cache");
	t04m0 = sem_ini(1);
	new_proc(04, 0);
	sem_wait(end_test);
	if (t04n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: rimpiazzamento");
	t05m0 = sem_ini(1);
	new_proc(05, 0);
	sem_wait(end_test);
	if (t05n0 == 1) msg("OK");
	dbg("=== FINE ===");


	test_num = 6;
	dbg(">>>INIZIO<<<: scrittura non in cache ottimizzata");
	t06m0 = sem_ini(1);
	new_proc(06, 0);
	sem_wait(end_test);
	if (t06n0 == 1) msg("OK");
	dbg("=== FINE ===");

	pause();

	terminate_p();
}
natl mainp;
#line 596 "utente/utente.cpp"

void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();}
