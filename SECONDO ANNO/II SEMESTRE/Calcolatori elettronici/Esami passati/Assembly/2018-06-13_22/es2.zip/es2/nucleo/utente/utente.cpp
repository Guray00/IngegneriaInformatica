#line 1 "utente/prog/psend.in"
#include <sys.h>
#include <lib.h>

struct msg {
	natl d;
	char p[1000];
};

#define MSG(src, dst, payload)	{ dst, payload },

msg tosend[] = {
#include "messages"
};


#line 16 "utente/prog/psend.in"

#line 18 "utente/prog/psend.in"
void error_body(int a)
#line 19 "utente/prog/psend.in"
{
	send(0x11223344, (char *)0x200000, 100);
	printf("processo errato");

	terminate_p();
}
void hello_body(int a)
#line 25 "utente/prog/psend.in"
{
	natl mem0 = iomemlibera();
	for (unsigned i = 0; i < sizeof(tosend)/sizeof(msg); i++) {
		msg *m = &tosend[i];
		send(m->d, m->p, strlen(m->p));
	}
	natl e = waitnet();
	natl mem1 = iomemlibera();
	printf("errori di trassmissione: %d", e);
	printf("memoria non liberata: %d", mem0 - mem1);
	pause();

	terminate_p();
}
short hello;
short error;
#line 47 "utente/utente.cpp"

int main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	error = activate_p(error_body, 0, 30, LIV_UTENTE);

	terminate_p();
}
