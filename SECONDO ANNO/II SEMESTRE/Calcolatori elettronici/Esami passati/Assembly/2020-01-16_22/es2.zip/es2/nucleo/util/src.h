/*
 * src.h
 */


static const char *intest_utente[] = {
//	"short dummy;",
//	"void dd(int i)",
//	"{",
//	"\twhile(give_num() != 1);",
//	"\tend_program();",
//	"}",
//	"",
	0
};

