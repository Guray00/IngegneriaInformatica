use JSON::XS;
use Data::Dumper;
use IO::Handle;
use strict;

my $dev = "ce1";
my $in;
my $out;

open $in, "<", "$dev.out";
open $out, ">", "$dev.in";

$out->autoflush(1);

my $json = JSON::XS->new->allow_nonref;

my $debug = 0;

my $config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 32,
			}
		],
		'interrupt-pin' => 1,
	};

my $HEAD = int(0);
my $TAIL = int(0);
my $RING = int(0);
my $ERROR = int(0);
my $pend_intr;
my @messages = ();
my $recvd = 0;

open M, "<utente/messages" or die $!;
while (<M>) {
	if (/^\s*MSG\((.*?)\s*,\s*(.*?)\s*,\s*"(.*?)"\s*\)/) {
		my ($src, $dst, $payload) = ($1, $2, $3);
		&dbg("src $src dst $dst payload $payload\n");
		push @messages, { src => hex($src), dst => hex($dst), payload => $payload };
	}
}
close M;

sub dbg {
	my $msg = shift;
	if ($debug) {
		printf "$dev: $msg", @_;
	}
}

sub send {
	my $msg = shift;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on sync\n");
	print $out "$r\n";
	&dbg("### $0: done sending\n");
}

sub receive {
	&dbg("### $0: receiving from sync\n");
	while (<$in>) {
	       	if (my $obj = $json->incr_parse($_)) {
			&dbg("<-" . Dumper($obj));
			return $obj;
		}
	}
	exit;
}


sub send_ret {
	my $arg = shift || 0;
	&send({ return => int($arg)});
}

sub send_intr {
	if (!$pend_intr) {
		&send({ "raise-irq" => 1 });
		&receive;
		$pend_intr = 1;
	}
}

sub clear_intr {
	if ($pend_intr) {
		&send({ "lower-irq" => 1 });
		&receive;
		$pend_intr = 0;
	}
}

my @begproc = ( 1, 5, 3 );
my @endproc = ( 1, 4, 3 );
my $curproc = 0;

sub get_natl {
	my $rv = int(0);
	for (my $i = 3; $i >= 0; $i--) {
		$rv <<= 8;
		$rv |= @_[$i];
	}
	return $rv;
}

sub get_des {
	my $i = shift;
	my $a = $RING + $i * 8;
	&send({ 'dma-read' => { addr => $a, len => 8 } });
	my $obj = &receive;
	my @b = @{$obj->{'bytes'}};
	my ($pa, $pl) = (&get_natl(@b[0..3]), &get_natl(@b[4..7]));
	return ($pa, $pl);
}

my $cur_payload;
my $cur_len;
my $cur_src;
my $cur_dst;
my $cur_seq = -1;

sub check_last_pkt {
	if ($cur_seq != -1) {
		if ($cur_src != $messages[$recvd]->{'src'} ||
		    $cur_dst != $messages[$recvd]->{'dst'} ||
		    !($cur_payload eq $messages[$recvd]->{'payload'}) ||
		    $cur_len != length($messages[$recvd]->{'payload'})) {
		    $ERROR++;
		    &dbg("!!! ERROR: $ERROR\n");
		} else {
		    &dbg("### pkt $recvd OK\n");
		}
		$recvd++;
	}
}

sub get_packet {
	my ($pa, $pl) = @_;
	&send({ 'dma-read' => { addr => $pa, len => $pl } });
	my $obj = &receive;
	my @b = @{$obj->{'bytes'}};
	my ($src, $dst, $len, $seq) = (&get_natl(@b[0..3]), &get_natl(@b[4..7]), &get_natl(@b[8..11]), &get_natl(@b[12..15]));
	my $msg = join '', map { chr($_) } @b[16..$#b];
	&dbg(sprintf("packet: src %08x dst %08x seq %3d payload '%s'\n", $src, $dst, $seq, $msg));
	if ($cur_seq != -1 && $seq == $cur_seq + 1) {
		if ($src != $cur_src || $dst != $cur_dst) {
			$ERROR++;
			&dbg("!!! src/dst mismatch ERROR: $ERROR\n");
		}
	} elsif ($seq == 0) {
		&check_last_pkt;
		$cur_len = 0;
		$cur_payload = '';
		$cur_src = $src;
		$cur_dst = $dst;
	}
	$cur_len += $len;
	$cur_payload .= $msg;
	$cur_seq = $seq;
}

sub ring_next {
	my $i = shift;
	return ($i + 1) % 8;
}

sub proc_packets {
	my $end = $endproc[$curproc] || $TAIL;
	&dbg("processing packets from $HEAD to $end\n");
	for ( ; $HEAD != $end; $HEAD = &ring_next($HEAD)) {
		my ($pa, $pl) = &get_des($HEAD);
		&dbg(sprintf("desc %d: %x %d\n", $HEAD, $pa, $pl));
		if ($pl > 0) {
			&get_packet($pa, $pl);
		} else {
			$ERROR++;
		}
	}
	&send_intr;
}

while (1) {
	my $obj = &receive;
	my ($i, $a, $s, $v);
	if ($$obj{'get-config'}) {
		&send($config);
		&send_ret;
	} elsif ($i = $$obj{'write'}) {
		$a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		$s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		$v = $i->{'val'};
		&dbg("### writing $v at $a\n");
		if ($a == 0) {
			# read only
		} elsif ($a == 4) {
			$TAIL = $v;
			&dbg("TAIL $v begproc $begproc[$curproc]\n");
			if (!$begproc[$curproc] || $TAIL == $begproc[$curproc]) {
				&proc_packets;
				$curproc++;
			}
		} elsif ($a == 8) {
			$RING = $v;
		} 
		&send_ret;
	} elsif ($i = $$obj{'read'}) {
		$a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		$s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		&dbg("### reading from $a\n");
		if ($a == 0) {
			&clear_intr;
			&send_ret($HEAD);
		} elsif ($a == 4) {
			&send_ret($TAIL);
		} elsif ($a == 8) {
			&send_ret($RING);
		} elsif ($a == 12) {
			&check_last_pkt;
			&send_ret($ERROR + (@messages - $recvd));
		}
	}			
}
