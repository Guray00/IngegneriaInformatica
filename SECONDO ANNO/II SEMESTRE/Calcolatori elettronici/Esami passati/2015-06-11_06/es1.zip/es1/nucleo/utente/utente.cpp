#line 1 "utente/prog/psp.in"
#include <all.h>

#line 4 "utente/prog/psp.in"
extern natl psp;
#line 4 "utente/prog/psp.in"
extern natl sem1;
#line 5 "utente/prog/psp.in"
extern natl sem2;
#line 7 "utente/prog/psp.in"
const int NPROC = 9;
natl proc[NPROC];

void p0(natq a)
{
	printf("proc 0: 1\n");
	set_prio(proc[4], 27);
	printf("proc 0: 2\n");
	sem_signal(sem1);
	terminate_p();
}

void p1(natq a)
{
	printf("proc 1: 1\n");
	sem_signal(sem1);
	printf("proc 1: 2\n");
	terminate_p();
}

void p2(natq a)
{
	printf("proc 2: 1\n");
	set_prio(proc[0], 55);
	printf("proc 2: 2\n");
	set_prio(proc[2], 53);
	printf("proc 2: 3\n");
	terminate_p();
}

void p3(natq a)
{
	printf("proc 3: 1\n");
	sem_wait(sem1);
	printf("proc 3: 2\n");
	terminate_p();
}

void p4(natq a)
{
	printf("proc 4: 1\n");
	sem_wait(sem1);
	printf("proc 4: 2\n");
	terminate_p();
}

void p5(natq a)
{
	printf("proc 5: 1\n");
	set_prio(proc[5], 100);
	printf("proc 5: 2\n");
	terminate_p();
}

void p6(natq a)
{
	sem_wait(sem2);
	set_prio(proc[8], 23);
	set_prio(proc[7], 24);
	terminate_p();
}

int flag = 0;
void p7(natq a)
{
	delay(20);
	printf("proc 7\n");
	flag = 1;
	terminate_p();
}

void p8(natq a)
{
	sem_signal(sem2);
	printf("proc 8: 1\n");
	while (!flag)
		;
	printf("proc 8: 2\n");
	terminate_p();
}

void last(natq a)
{
	pause();
	terminate_p();
}


void psp_body(natq a)
#line 96 "utente/prog/psp.in"
{
	proc[0] = activate_p(p0, 0, 30, LIV_UTENTE);
	proc[1] = activate_p(p1, 0, 50, LIV_UTENTE);
	proc[2] = activate_p(p2, 0, 70, LIV_UTENTE);
	proc[3] = activate_p(p3, 0, 80, LIV_UTENTE);
	proc[4] = activate_p(p4, 0, 85, LIV_UTENTE);
	proc[5] = activate_p(p5, 0, 20, LIV_UTENTE);
	proc[6] = activate_p(p6, 0, 25, LIV_UTENTE);
	proc[7] = activate_p(p7, 0, 22, LIV_UTENTE);
	proc[8] = activate_p(p8, 0, 21, LIV_UTENTE);
	activate_p(last, 0, 10, LIV_UTENTE);

	terminate_p();
}
natl psp;
natl sem1;
natl sem2;
#line 119 "utente/utente.cpp"

void main()
{
	psp = activate_p(psp_body, 0, 100, LIV_UTENTE);
	sem1 = sem_ini(0);
	sem2 = sem_ini(0);

	terminate_p();}
