#line 1 "utente/prog/psend.in"
#include <all.h>

const int N_SENDERS = 4;
const int N_RECEIVERS = 1;
const int NPROC = N_SENDERS + N_RECEIVERS;


#line 8 "utente/prog/psend.in"
extern natl m1;
#line 8 "utente/prog/psend.in"
natl finish[NPROC];

struct conf {
	natl dest;
	natl msg;
	natl n_msg;
};

conf config[N_SENDERS];

void sender(natq a)
{
	for (unsigned i = 0; i < config[a].n_msg; i++) {
		natl r = 0;
		printf("%d: invio %d a %d\n", a, config[a].msg+i, config[a].dest);
		if ( (r = send(config[a].dest, config[a].msg+i)) == 0) {
			// printf("%d: invio riuscito\n", a);
		} else {
			printf("%d: invio fallito (causa: %d)\n", a, r);
		}
	}
	sem_signal(finish[a]);
	terminate_p();
}

void receiver(natq a)
{
	for (int i = 0; i < 8; i++) {
		natl m = receive();
		printf("%d: ricevuto %d\n", getpid(), m);
	}
	sem_signal(finish[a]);
	terminate_p();
}

void mio_main(natq a)
#line 44 "utente/prog/psend.in"
{
	for (int i = 0; i < NPROC; i++)
		finish[i] = sem_ini(0);

	natl r1 = activate_p(receiver, 4, 35, LIV_UTENTE);
	config[0].dest = r1;
	config[0].msg  = 1234;
	config[0].n_msg  = 5;
	config[1].dest = r1;
	config[1].msg  = 4321;
	config[1].n_msg = 2;
	config[2].dest = r1;
	config[2].msg  = 555;
	config[2].n_msg = 2;
	(void) activate_p(sender, 0, 45, LIV_UTENTE);
	(void) activate_p(sender, 1, 30, LIV_UTENTE);
	(void) activate_p(sender, 2, 20, LIV_UTENTE);

	config[3].dest = 100;
	config[3].msg  = 333;
	config[3].n_msg = 1;
	(void) activate_p(sender, 3, 42, LIV_UTENTE);

	for (int i = 0; i < NPROC; i++)
		sem_wait(finish[i]);
	pause();

	terminate_p();
}
natl m1;
#line 80 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
