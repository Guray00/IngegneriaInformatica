#line 1 "utente/prog/pchan.in"
#include <all.h>

const int N_SENDERS = 6;
const int N_RECEIVERS = 1;
const int NPROC = N_SENDERS + N_RECEIVERS;


#line 8 "utente/prog/pchan.in"
extern natl m1;
#line 8 "utente/prog/pchan.in"
natl finish[NPROC];


natl chan1, chan2;

struct conf {
	natl cid;
	natl msg;
};

conf config[NPROC];

void sender(natq a)
{
	natl chan = config[a].cid;
	natl msg  = config[a].msg;
	printf("%d: invio %d sul canale %d\n", a, msg, chan);
	channel_send(chan, msg);
	sem_signal(finish[a]);
	terminate_p();
}

void receiver2(natq a)
{
	natl msg;
	for (int i = 0; i < 3; i++) {
		msg = channel_receive2(chan1, chan2);
		printf("%d: ricevuto %d\n", a, msg);
		natl chan = (msg % 2) ? chan1 : chan2;
		msg = channel_receive(chan);
		printf("%d: ricevuto %d dal canale %d\n", a, msg, chan);
	}
	sem_signal(finish[a]);
	terminate_p();
}

void mio_main(natq a)
#line 45 "utente/prog/pchan.in"
{
	for (int i = 0; i < NPROC; i++)
		finish[i] = sem_ini(0);

	chan1 = channel_init(1);
	if (chan1 == 0xFFFFFFFF) {
		flog(LOG_WARN, "allocazione channel fallita");
		terminate_p();
	}
	chan2 = channel_init(1);
	if (chan2 == 0xFFFFFFFF) {
		printf("allocazione secondo channel fallita\n");
	}
	config[0].cid = chan1;
	config[0].msg  = 2222;
	config[1].cid = chan1;
	config[1].msg  = 3333; 
	config[2].cid = chan2;
	config[2].msg  = 5555;
	config[3].cid = chan1;
	config[3].msg  = 4444;
	config[4].cid = chan2;
	config[4].msg  = 7777;
	config[5].cid = chan1;
	config[5].msg  = 9999;
	(void) activate_p(sender, 0, 45, LIV_UTENTE);
	(void) activate_p(sender, 1, 30, LIV_UTENTE);
	(void) activate_p(sender, 2, 20, LIV_UTENTE);
	(void) activate_p(sender, 3, 15, LIV_UTENTE);
	(void) activate_p(sender, 4, 10, LIV_UTENTE);
	(void) activate_p(sender, 5, 5, LIV_UTENTE);
	(void) activate_p(receiver2, 3, 50, LIV_UTENTE);

	for (int i = 0; i < NPROC - 1; i++)
		sem_wait(finish[i]);
	pause();

	terminate_p();
}
natl m1;
#line 91 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
