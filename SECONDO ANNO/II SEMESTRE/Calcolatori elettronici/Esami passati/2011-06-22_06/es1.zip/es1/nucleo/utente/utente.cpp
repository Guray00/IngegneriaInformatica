#line 1 "utente/prog/pintr.in"
/*
 * Prova interrupt/interrupted
 */

#include <all.h>

const int NPROC = 6;


#line 10 "utente/prog/pintr.in"
extern natl m1;
#line 10 "utente/prog/pintr.in"
extern natl sem1;
#line 11 "utente/prog/pintr.in"
extern natl sem2;
#line 12 "utente/prog/pintr.in"
extern natl sem3;
#line 14 "utente/prog/pintr.in"
natl p1, p2, p3, p4, p5, p6;
natl finish[NPROC];


void pm1(natq a)
{
	if (sem_wait2(sem1)) printf("1: sem_wait2 OK\n");
	else 		     printf("1: sem_wait2 failed\n");
	sem_signal(finish[a]);
	terminate_p();
}

void pm2(natq a)
{
	sem_signal2(sem1);
	printf("2: sem_signal2 OK\n");
	sem_signal(finish[a]);
	terminate_p();
}

void pm3(natq a)
{
	if (sem_wait2(sem2)) printf("3: sem_wait2 failed\n");
	else 		     printf("3: sem_wait2 OK\n");
	sem_signal(finish[a]);
	terminate_p();
}

void pm4(natq a)
{
	if (interrupt(p3)) printf("4: interrupt OK\n");
	else 		   printf("4: interrupt failed\n");
	sem_signal(finish[a]);
	terminate_p();
}

void pm5(natq a)
{
	while (!interrupted())
		delay(1);
	printf("5: interrupted OK\n");
	sem_signal(finish[a]);
	terminate_p();
}

void pm6(natq a)
{
	if (interrupt(p5)) printf("6: interrupt OK\n");
	else 		   printf("6: interrupt failed\n");
	sem_signal(finish[a]);
	terminate_p();
}

void mio_main(natq a)
#line 68 "utente/prog/pintr.in"
{
	for (int i = 0; i < NPROC; i++)
		finish[i] = sem_ini(0);
	p1 = activate_p(pm1, 0, 40, LIV_UTENTE);
	p2 = activate_p(pm2, 1, 35, LIV_UTENTE);
	p3 = activate_p(pm3, 2, 30, LIV_UTENTE);
	p4 = activate_p(pm4, 3, 25, LIV_UTENTE);
	p5 = activate_p(pm5, 4, 20, LIV_UTENTE);
	p6 = activate_p(pm6, 5, 15, LIV_UTENTE);
	for (int i = 0; i < NPROC; i++)
		sem_wait(finish[i]);
	pause();

	terminate_p();
}
natl m1;
natl sem1;
natl sem2;
natl sem3;
#line 95 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);
	sem1 = sem_ini(0);
	sem2 = sem_ini(0);
	sem3 = sem_ini(0);

	terminate_p();}
