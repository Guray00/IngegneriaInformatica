#line 1 "utente/prog/pbreak.in"
#include <all.h>


#line 4 "utente/prog/pbreak.in"
extern natl usr1;
#line 4 "utente/prog/pbreak.in"

#line 5 "utente/prog/pbreak.in"
extern natl usr2;
#line 5 "utente/prog/pbreak.in"

#line 6 "utente/prog/pbreak.in"
extern natl usr3;
#line 6 "utente/prog/pbreak.in"

#line 7 "utente/prog/pbreak.in"
extern natl usr4;
#line 7 "utente/prog/pbreak.in"

#line 8 "utente/prog/pbreak.in"
extern natl usr5;
#line 8 "utente/prog/pbreak.in"

#line 9 "utente/prog/pbreak.in"
extern natl dbg1;
#line 9 "utente/prog/pbreak.in"

#line 10 "utente/prog/pbreak.in"
extern natl dbg2;
#line 10 "utente/prog/pbreak.in"

#line 11 "utente/prog/pbreak.in"
extern natl dbg3;
#line 11 "utente/prog/pbreak.in"

#line 12 "utente/prog/pbreak.in"
extern natl dbg4;
#line 12 "utente/prog/pbreak.in"

#line 13 "utente/prog/pbreak.in"
extern natl dbg5;
#line 13 "utente/prog/pbreak.in"

#line 14 "utente/prog/pbreak.in"
extern natl dbg6;
#line 14 "utente/prog/pbreak.in"

#line 15 "utente/prog/pbreak.in"
extern natl dbg7;
#line 15 "utente/prog/pbreak.in"

#line 16 "utente/prog/pbreak.in"
extern natl dbg9;
#line 16 "utente/prog/pbreak.in"

#line 17 "utente/prog/pbreak.in"
extern natl dbga;
#line 17 "utente/prog/pbreak.in"

#line 19 "utente/prog/pbreak.in"
extern natl last;
#line 19 "utente/prog/pbreak.in"
extern natl sync;
#line 21 "utente/prog/pbreak.in"
#define MSG(fmt, ...)	do { printf("proc %d: " fmt "\n", getpid(), ## __VA_ARGS__); } while (0)

void usr_div(natq a)
#line 24 "utente/prog/pbreak.in"
{
	int b = 42 / a;

	MSG("b vale %d", b);

	terminate_p();
}
void usr_pf(natq a)
#line 31 "utente/prog/pbreak.in"
{
	*(int *)0 = 0;

	terminate_p();
}
void usr_bp(natq a)
#line 36 "utente/prog/pbreak.in"
{
	MSG("eseguo int3");
	asm("int3");

	terminate_p();
}
void usr_prot(natq a)
#line 42 "utente/prog/pbreak.in"
{
	sem_wait(sync);
	MSG("eseguo mov %%rax, %%cr3");
	asm("mov %rax, %cr3");

	terminate_p();
}
void bad1(natq a)
#line 49 "utente/prog/pbreak.in"
{
	if (proc_attach(getpid())) {
		MSG("errore: proc_attach ricorsiva riuscita");
	}

	terminate_p();
}
void bad2(natq a)
#line 56 "utente/prog/pbreak.in"
{
	if (proc_attach(100)) {
		MSG("errore: proc_attach su processo non esistente riuscita");
	}

	terminate_p();
}
void bad3(natq a)
#line 63 "utente/prog/pbreak.in"
{
	proc_wait();
	MSG("errore: proc_wait() da non-master riuscita");

	terminate_p();
}
void bad5(natq a)
#line 69 "utente/prog/pbreak.in"
{
	if (proc_attach(a)) {
		MSG("errore: proc_attach() duplicata su slave riuscita");
	}

	terminate_p();
}
static const char *eccezioni[] = {
	"errore di divisione", 		// 0
	"debug",			// 1
	"interrupt non mascherabile",	// 2
	"breakpoint",			// 3
	"overflow",			// 4
	"bound check",			// 5
	"codice operativo non valido",	// 6
	"dispositivo non disponibile",	// 7
	"doppio fault",			// 8
	"coprocessor segment overrun",	// 9
	"TSS non valido",		// 10
	"segmento non presente",	// 11
	"errore sul segmento stack",	// 12
	"errore di protezione",		// 13
	"page fault",			// 14
	"riservato",			// 15
	"errore su virgola mobile",	// 16
	"errore di allineamento",	// 17
	"errore interno",		// 18
	"errore SIMD",			// 19
	"20??",
	"21??",
	"22??",
	"23??",
	"24??",
	"25??",
	"26??",
	"27??",
	"28??",
	"29??",
	"30??",
	"31??",
	"normale"
};

void debugger(natq a)
#line 112 "utente/prog/pbreak.in"
{
	MSG("master di %d: chiamo proc_attach", a);
	if (!proc_attach(a)) {
		MSG("debugger di %d: proc_attach() fallita", a);
		terminate_p();
	}
	natl v = proc_wait();
	if (v > 32) {
		MSG("master di %d: codice terminazione non riconosciuto: %d", v);
	} else  {
		MSG("master di %d: motivo terminazione: %s", a, eccezioni[v]);
	}

	terminate_p();
}
void debugger2(natq a)
#line 127 "utente/prog/pbreak.in"
{
	MSG("master di %d: chiamo proc_attach", a);
	if (!proc_attach(a)) {
		MSG("debugger di %d: proc_attach() fallita", a);
		terminate_p();
	}
	sem_signal(sync);
	natl v = proc_wait();
	if (v > 32) {
		MSG("master di %d: codice terminazione non riconosciuto: %d", v);
	} else  {
		MSG("master di %d: motivo terminazione: %s", a, eccezioni[v]);
	}

	terminate_p();
}
void last_body(natq a)
#line 143 "utente/prog/pbreak.in"
{
	pause();

	terminate_p();
}
natl usr1;
natl usr2;
natl usr3;
natl usr4;
natl usr5;
natl dbg1;
natl dbg2;
natl dbg3;
natl dbg4;
natl dbg5;
natl dbg6;
natl dbg7;
natl dbg9;
natl dbga;
natl last;
natl sync;
#line 231 "utente/utente.cpp"

void main()
{
	usr1 = activate_p(usr_div, 1, 10, LIV_UTENTE);
	usr2 = activate_p(usr_div, 0, 23, LIV_UTENTE);
	usr3 = activate_p(usr_pf, 2, 22, LIV_UTENTE);
	usr4 = activate_p(usr_bp, 2, 15, LIV_UTENTE);
	usr5 = activate_p(usr_prot, 0, 9, LIV_UTENTE);
	dbg1 = activate_p(debugger, usr1, 20, LIV_UTENTE);
	dbg2 = activate_p(debugger, usr2, 30, LIV_UTENTE);
	dbg3 = activate_p(debugger, usr3, 24, LIV_UTENTE);
	dbg4 = activate_p(debugger, usr4, 16, LIV_UTENTE);
	dbg5 = activate_p(bad1, 20, 51, LIV_UTENTE);
	dbg6 = activate_p(bad2, 21, 52, LIV_UTENTE);
	dbg7 = activate_p(bad3, 22, 53, LIV_UTENTE);
	dbg9 = activate_p(bad5, usr1, 11, LIV_UTENTE);
	dbga = activate_p(debugger2, usr5, 8, LIV_UTENTE);
	last = activate_p(last_body, 0, 1, LIV_UTENTE);
	sync = sem_ini(0);

	terminate_p();}
