#line 1 "utente/prog/pmprotect.in"
#include <sys.h>
#include <lib.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %d: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %d PROC %d: " s, test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)
#define die(s, ...) do { err(s, ## __VA_ARGS__); goto error; } while (0)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_subtest() do {\
	(void)&&error;\
error:\
	terminate_p();\
} while (0)

#define end_test() do {\
	(void)&&error;\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

#define TCNT(n)	natl t##n##m0; natl t##n##n0;
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

int test_num;

const char *b2s(bool b)
{
	return b ? "true" : "false";
}

#define ckmp(v_, n_, w_, er_) do {\
	bool r_;\
	if ((r_ = mprotect((void *)(v_), (n_), (w_))) != (er_)) {\
		die("mprotect(%p, %d, %s) ha restituito %s invece di %s",\
			(v_), (n_), b2s(w_), b2s(r_), b2s(er_));\
	}\
} while (0)



///**********************************************************************
// *             test 00: errori vari                                   *
// *                                                                    *
// * Il processo 0 tenta di cambiare i permessi su indirizzi di sistema.*
// * Il processo 1 fa lo stesso, ma con wrap-around. Il processo 2      *
// * tenta di cambiare i permessi su degli indirizzi della sua pila,    *
// * che sono al di fuori della regione specificata nel testo.          *
// * Ci si aspetta che tutti e tre i processi vengano abortiti.         *
// **********************************************************************/

natl t00p0;
natl t00p1;

void t00p0b(int test)
{
	mprotect((void *)0x200000, 8, true);
	err("mprotect su memoria di sistema non ha causato abort");
	terminate_p();
}

void t00p1b(int test_num)
{
	mprotect((void *)(-(1UL << 39) - 0x1000), (1UL << 39) + 0x201000 + 8, true);
	err("mprotect con wrap-around su memoria di sistema non ha causato abort");
	terminate_p();
}

void t00p2b(int test_num)
{
	int useless;
	mprotect(&useless, sizeof(useless), false);
	err("mprotect su indirizzi della pila utente non ha causato abort");
	terminate_p();
}

///**********************************************************************
// *             test 01: funzionalità minima                           *
// *                                                                    *
// * L'array di const char, t01p0b, verrà allocato in una sezione       *
// * .rodata (read-only data) del file ELF, marcata come non-scrivibile.*
// * Il programma che inizializza lo swap a partire dal file ELF        *
// * (creatimg) creerà i relativi percorsi di traduzione con i bit R/W  *
// * a 0 (più precisamente, solo quelli nelle tabelle di livello 1).    *
// *                                                                    *
// * ckmk() chiama mprotect() con i primi tre parametri, poi controlla  *
// * che il valore restituito sia uguale al quarto parametro.           *
// *                                                                    *
// * Il processo, dunque, abilita la scrittura sull'array e poi prova   *
// * a scriverci. Ci aspettiamo che ci riesca.                          *
// *                                                                    *
// * [Il cast a (char*) è necessario, altrimenti sarebbe il compilatore *
// * a impedirci di scrivere, ma questo non ci interessa.]              *
// *                                                                    *
// **********************************************************************/

natl t01p0;
TCNT(01);

const unsigned long t01b0d = DIM_PAGINA;
const char t01b0[t01b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t01p0b(int test_num)
{
	ckmp(t01b0, t01b0d, true, true);
	((char*)t01b0)[10] = 1;
	testok(01);
	end_test();
}

///**********************************************************************
// *             test 02: parte di un buffer                            *
// *                                                                    *
// * Simile al test 01, ma l'intervallo passato a mprotect() non è      *
// * allineato alla pagina. Secondo quanto richiesto dal testo, ci      *
// * aspettiamo che l'effetto sia però lo stesso. In particolare,       *
// * controlliamo che il diritto di scrittura non sia stato erronamente *
// * esteso alle pagine intorno a quella richiesta.                     *
// *                                                                    *
// * Il secondo processo serve solo a far terminare il test.            *
// **********************************************************************/

natl t02p0;
natl t02p1;
natl t02s0;
TCNT(02);

const unsigned long t02b0d = 3 * DIM_PAGINA;
const char t02b0[t02b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t02p0b(int test_num)
{
	char *b = (char*)t02b0;

	sem_wait(t02s0);
	// abilitiamo un intervallo all'interno della seconda pagina
	ckmp(t02b0 + DIM_PAGINA +  27, 4069, true, true);
	// scriviamo dentro la seconda pagina: deve funzionare
	b[DIM_PAGINA + 10] = 1;
	// le scritture nella prima e seconda pagina devono invece fallire
	b[2 * DIM_PAGINA + 10] = 1;
	err("scrittura possibile su pagina successiva a quella richiesta");
	b[10] = 1;
	err("scrittura possibile su pagina precedente a quella richiesta");
	end_subtest();
}

void t02p1b(int test_num)
{
	char *b = (char*)t02b0;
	sem_signal(t02s0);
	if (!b[DIM_PAGINA + 10] || b[10] || b[2 * DIM_PAGINA + 10]) {
		die("mprotect() ha agito su un insieme di pagine scorretto");
	}
	testok(02);
	end_test();
}


///**********************************************************************
// *             test 03: a cavallo di due pagine                       *
// *                                                                    *
// *  In questo caso l'intervallo attraversa due pagine. Ci aspettiamo  *
// *  che la mprotect() abbia successo e che il processo possa poi      *
// *  scrivere in entambe le pagine.                                    *
// **********************************************************************/

natl t03p0;
TCNT(03);

const unsigned long t03b0d = 2 * DIM_PAGINA;
const char t03b0[t03b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t03p0b(int test_num)
{
	ckmp(t03b0 + 27, DIM_PAGINA + 42, true, true);
	((char*)t03b0)[10] = 1;
	((char*)t03b0)[DIM_PAGINA + 10] = 1;
	testok(03);
	end_test();
}

///**********************************************************************
// *             test 04: due processi (1)                              *
// *                                                                    *
// * Il processo 1 abilita la scrittura sul buffer e vi scrive. Il      *
// * processo 0 verifica di essere in grado di vedere la scrittura del  *
// * processo 1.                                                        *
// *                                                                    *
// * Il test serve a controllare che le pagine del buffer continuino a  *
// * essere condivise anche dopo la mprotect().                         *
// **********************************************************************/

natl t04p0;
natl t04p1;
natl t04s0;
TCNT(04);

const unsigned long t04b0d = DIM_PAGINA;
const char t04b0[t04b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t04p0b(int test_num)
{
	sem_wait(t04s0);
	// il cast è necessario anche qui, altrimenti il compilatore
	// ometterebbe il test assumendo che il buffer sia costante
	if (((char *)t04b0)[100] != 1) {
		die("buffer non più condiviso");
	}
	testok(04);
	end_test();
}

void t04p1b(int test_num)
{
	ckmp(t04b0, t04b0d, true, true);
	((char *)t04b0)[100] = 1;
	sem_signal(t04s0);
	testok(04);
	end_test();
}

///**********************************************************************
// *             test 05: due processi (2)                              *
// *                                                                    *
// * Il processo 1 abilita la scrittura sul buffer e, successivamente,  *
// * Il processo 0 prova a scrivervi. Ci aspettiamo che non ci riesca.  *
// *                                                                    *
// * Il test serve a controllare che l'effetto di mprotect() sia        *
// * confinato al solo processo che la invoca e che il percorso di      *
// * traduzione sia stato correttamente duplicato.                      *
// **********************************************************************/

natl t05p0;
natl t05p1;
natl t05s0;
TCNT(05);

const unsigned long t05b0d = DIM_PAGINA;
const char t05b0[t05b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t05p0b(int test_num)
{
	sem_wait(t05s0);
	((char *)t05b0)[100] = 1;
	err("scrittura su buffer read-only non ha terminato il processo");
	end_subtest();
}

void t05p1b(int test_num)
{
	ckmp(t05b0, t05b0d, true, true);
	sem_signal(t05s0);
	if (((char *)t05b0)[100]) {
		die("mprotect() ha avuto effetti su un altro processo");
	}
	testok(05);
	end_test();
}

///**********************************************************************
// *             test 06: solo lettura                                  *
// *                                                                    *
// * Questa volta il buffer non è const e dunque sarà normalmente       *
// * scrivibile.                                                        *
// *                                                                    *
// * Il processo 0 disabilita le scritture sul buffer, quindi prova     *
// * a scrivervi. Ci aspettiamo che la scrittura fallisca.              *
// *                                                                    *
// * Il processo 1 serve solo a terminare il test.                      *
// **********************************************************************/

natl t06p0;
natl t06p1;
natl t06s0;
TCNT(06);

const unsigned long t06b0d = DIM_PAGINA;
char t06b0[t06b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t06p0b(int test_num)
{
	sem_wait(t06s0);
	ckmp(t06b0, t06b0d, false, true);
	t06b0[100] = 1;
	err("scrittura su buffer read-only non ha terminato il processo");
	end_subtest();
}

void t06p1b(int test_num)
{
	sem_signal(t06s0);
	if (t06b0[100]) {
		die("scrittura possibile nonostante mprotect()");
	}
	testok(06);
	end_test();
}

///**********************************************************************
// *             test 07: solo lettura su meta' buffer                  *
// *                                                                    *
// * Il buffer è scrivibile e si estende su due pagine. Il processo 0   *
// * disabilita le scritture solo sulla prima pagina, quindi prova a    *
// * scrivere su entrambe. Ci aspettiamo che la scrittura sulla         *
// * prima pagina fallisca, ma quella sulla seconda abbia successo.     *
// *                                                                    *
// * Il test serve a controllare che il bit R/W non sia stato messo a   *
// * zero troppo in alto nel percorso di traduzione.                    *
// * (Il programma è sufficientemente piccolo e tutti i buffer sono     *
// * contenuti nella stessa regione di 2MiB.)                           *
// **********************************************************************/

natl t07p0;
natl t07p1;
natl t07s0;
TCNT(07);

const unsigned long t07b0d = 2 * DIM_PAGINA;
char t07b0[t07b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t07p0b(int test_num)
{
	sem_wait(t07s0);
	ckmp(t07b0, DIM_PAGINA, false, true);
	t07b0[DIM_PAGINA + 100] = 1;
	t07b0[100] = 1;
	err("scrittura su buffer read-only non ha terminato il processo");
	end_subtest();
}

void t07p1b(int test_num)
{
	sem_signal(t07s0);
	if (t07b0[DIM_PAGINA + 100] != 1) {
		die("protezione da lettura su pagine non richieste");
	}
	if (t07b0[100]) {
		die("scrittura possibile nonostante mprotect()");
	}
	testok(07);
	end_test();
}

///**********************************************************************
// *             test 08: mprotect() ripetute                           *
// *                                                                    *
// * Il processo si limita a ripetere la stessa mprotect() 50 volte.    *
// * Ci aspettiamo che ci riesca.                                       *
// *                                                                    *
// * Il test serve a controllare che la duplicazione del percorso di    *
// * traduzione venga fatta solo se necessario, altrimenti vengono      *
// * esauriti inutilmente tutti i frame liberi.                         *
// **********************************************************************/

natl t08p0;
TCNT(08);

const unsigned long t08b0d = DIM_PAGINA;
const char t08b0[t08b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t08p0b(int test_num)
{
	for (int i = 0; i < 50; i++) {
		ckmp(t08b0, t08b0d, true, true);
		((char *)t08b0)[2000] = i;
	}
	testok(08);
	end_test();
}

///**********************************************************************
// *             test 09: mprotect() dopo aver gia' acceduto            *
// *                                                                    *
// * Il buffer parte scrivibile, quindi il processo disabilita le       *
// * scritture e poi prova a scrivervi. Ci aspettiamo che non ci riesca.*
// *                                                                    *
// * Il test è simile allo 06, con l'unica differenza che questa volta  *
// * il processo ha già eseguito una scrittura sul buffer appena prima  *
// * di eseguire la mprotect(). Perché questo dovrebbe fare differenza? *
// **********************************************************************/

natl t09p0;
natl t09p1;
natl t09s0;
TCNT(09);

const unsigned long t09b0d = DIM_PAGINA;
char t09b0[t09b0d] __attribute__((aligned(DIM_PAGINA))) = { 0 };

void t09p0b(int test_num)
{
	sem_wait(t09s0);
	// prima scrittura, sicuramente permessa
	t09b0[3000] = 1;
	// disabilita le scritture
	ckmp(t09b0, t09b0d, false, true);
	// seconda scrittura, dovrebbe non essere permessa
	t09b0[3000] = 2;
	die("mprotect() dopo un accesso non ha terminato il processo");
	end_subtest();
}

void t09p1b(int test_num)
{
	sem_signal(t09s0);
	if (t09b0[3000] == 2) {
		die("mprotect() dopo un accesso non ha avuto effetto");
	}
	testok(09);
	end_test();
}

/**********************************************************************/



#line 428 "utente/prog/pmprotect.in"
void main_body(int id)
#line 429 "utente/prog/pmprotect.in"
{
	natl prio = 600;

	end_test = sem_ini(0);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	delay(10);
	new_proc(00, 1);
	delay(10);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: funzionalita' minima");
	t01m0 = sem_ini(1);
	new_proc(01, 0);
	sem_wait(end_test);
	if (t01n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: parte di un buffer");
	t02m0 = sem_ini(1);
	new_proc(02, 0);
	new_proc(02, 1);
	sem_wait(end_test);
	if (t02n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 3;
	dbg(">>>INIZIO<<<: a cavallo di due pagine");
	t03m0 = sem_ini(1);
	new_proc(03, 0);
	sem_wait(end_test);
	if (t03n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: due processi (1)");
	t04m0 = sem_ini(1);
	t04s0 = sem_ini(0);
	new_proc(04, 0);
	new_proc(04, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t04n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: due processi (2)");
	t05m0 = sem_ini(1);
	t05s0 = sem_ini(0);
	new_proc(05, 0);
	new_proc(05, 1);
	sem_wait(end_test);
	if (t05n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 6;
	dbg(">>>INIZIO<<<: solo lettura");
	t06m0 = sem_ini(1);
	t06s0 = sem_ini(0);
	new_proc(06, 0);
	new_proc(06, 1);
	sem_wait(end_test);
	if (t06n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 7;
	dbg(">>>INIZIO<<<: solo lettura su meta' buffer");
	t07m0 = sem_ini(1);
	t07s0 = sem_ini(0);
	new_proc(07, 0);
	new_proc(07, 1);
	sem_wait(end_test);
	if (t07n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 8;
	dbg(">>>INIZIO<<<: mprotect() ripetute");
	t08m0 = sem_ini(1);
	new_proc(08, 0);
	sem_wait(end_test);
	if (t08n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 9;
	dbg(">>>INIZIO<<<: mprotect() dopo un accesso");
	t09m0 = sem_ini(1);
	t09s0 = sem_ini(0);
	new_proc(09, 0);
	new_proc(09, 1);
	sem_wait(end_test);
	if (t09n0 == 1) msg("OK");
	dbg("=== FINE ===");

	pause();

	terminate_p();
}
short mainp;
#line 534 "utente/utente.cpp"

int main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();
}
