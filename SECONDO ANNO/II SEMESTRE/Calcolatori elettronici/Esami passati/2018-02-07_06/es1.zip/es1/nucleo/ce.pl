use threads;
use threads::shared;
use JSON::XS;
use Data::Dumper;
use IO::Handle;

$dev = "ce$ARGV[0]";

open $in, "<", "$dev.out";
open $out, ">", "$dev.in";
open $ain, "<", "${dev}a.out";
open $aout, ">", "${dev}a.in";

$out->autoflush(1);
$aout->autoflush(1);

$json = JSON::XS->new->allow_nonref;

#$debug = 1;

$config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 32,
			}
		],
		'interrupt-pin' => 1 + ($ARGV[0] % 4)
	};

my $CFG = int($ARGV[1]);	# 0
my $SWD = int(-1);		# 4
my $CNT = int(0);		# 8
my $EWD = int(0);		# 12
my @pend_intr :shared;
my @counters :shared;
my $running :shared = 1;

sub timerthread {
	while ($running) {
		my @expired = ();
		{
			lock (@counters);
			for (my $i = 0; $i < $CFG; $i++) {
				&dbg("=== counter $i: $counters[$i]\n");
				if ($counters[$i] > 0) {
					$counters[$i]--;
					if ($counters[$i] == 0) {
						push @expired, $i
					}
				}
			}
		}
		if (@expired) {
			my $int = 0;
			lock(@pend_intr);
			if (!@pend_intr) {
				$int = 1;
			}
			push @pend_intr, @expired;
			if ($int) {
				&send_intr;
			}
		}
		sleep(1);
	}
}

my $thr = threads->create(\&timerthread);

sub dbg {
	my $msg = shift;
	if ($debug) {
		printf "$dev: $msg", @_;
	}
}

sub send {
	my ($ch, $msg) = @_;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on $ch\n");
	if ($ch eq "sync") {
		print $out "$r\n";
	} else {
		print $aout "$r\n";
	}
	&dbg("### $0: done sending\n");
}

sub receive {
	my $ch = shift || "sync";
	my $i = \*$in;
	if ($ch eq "async") {
		$i = \*$ain;
	}
	&dbg("### $0: receiving from $ch\n");
	while (<$i>) {
	       	if ($obj = $json->incr_parse($_)) {
			&dbg("<-" . Dumper($obj));
			return $obj;
		}
	}
	$running = 0;
	$thr->join();
	exit;
}


sub send_ret {
	my $arg = shift || 0;
	&send("sync", { return => $arg});
}

sub send_intr {
	&send("async", { "raise-irq" => 1 });
	&receive("async");
	$pend_intr = 1;
}

sub clear_intr {
	&send("async", { "lower-irq" => 1 });
	&receive("async");
	$pend_intr = 0;
}

while (1) {
	$obj = &receive;
	if ($$obj{'get-config'}) {
		&send("sync", $config);
		&send_ret;
	} elsif ($i = $$obj{'write'}) {
		$a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		$s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		$v = $i->{'val'};
		&dbg("### writing $v at $a\n");
		if ($a == 0) {
			# read only
		} elsif ($a == 4) {
			if ($v < $CFG) {
				$SWD = $v;
				lock(@counters);
				$counters[$v] = $CNT;
			}
		} elsif ($a == 8) {
			$CNT = $v;
		} elsif ($a == 12) {
			# read only
		}
		&send_ret;
	} elsif ($i = $$obj{'read'}) {
		$a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		$s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		&dbg("### reading from $a\n");
		if ($a == 0) {
			&send_ret($CFG);
		} elsif ($a == 4) {
			&send_ret($SWD);
		} elsif ($a == 8) {
			&send_ret($CNT);
		} elsif ($a == 12) {
			lock(@pend_intr);
			if (@pend_intr) {
				$EWD = pop @pend_intr;
				&dbg("### intr $EWD, pending:@pend_intr\n");
				if (!@pend_intr) {
					&clear_intr;
				}
			}
			&send_ret($EWD);
		}
	}			
}
