#line 1 "utente/prog/pwd.in"
#include <all.h>


#line 5 "utente/prog/pwd.in"
extern natl psp;
#line 5 "utente/prog/pwd.in"
extern natl sem1;
#line 7 "utente/prog/pwd.in"
natl getwd(int a, natl id, natl secs)
{
	natl wd = startwatchdog(id, secs);
	if (wd == 0xffffffff) {
		printf("proc%d: allocazione watchdog su %d fallita\n", a, id);
		terminate_p();
	}
	printf("proc%d: nuovo watchdog su %d\n", a, id);
	return wd;
}

void bad(natq a)
{
	getwd(a, 3, 10);
}

void loop(natq a)
{
	getwd(a, 1, 1);
	while (true)
		;
}

void good(natq a)
{
	natl wd = getwd(a, 0, 10);
	stopwatchdog(0, wd);
	printf("proc%d: reset watchdog su 0\n", a);
	terminate_p();
}

void last(natq a)
{
	pause();
	terminate_p();
}

void psp_body(natq a)
#line 45 "utente/prog/pwd.in"
{
	activate_p(loop, 0, 40, LIV_UTENTE);
	activate_p(good, 1, 35, LIV_UTENTE);
	activate_p(good, 2, 30, LIV_UTENTE);
	activate_p(good, 3, 25, LIV_UTENTE);
	activate_p(loop, 4, 20, LIV_UTENTE);
	activate_p(bad, 5, 10, LIV_UTENTE);
	activate_p(last, 6, 5, LIV_UTENTE);

	terminate_p();
}
natl psp;
natl sem1;
#line 63 "utente/utente.cpp"

void main()
{
	psp = activate_p(psp_body, 0, 100, LIV_UTENTE);
	sem1 = sem_ini(0);

	terminate_p();}
