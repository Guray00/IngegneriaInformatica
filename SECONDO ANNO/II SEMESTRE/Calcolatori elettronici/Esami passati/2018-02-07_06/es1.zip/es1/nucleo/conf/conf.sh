QEMU_EXTRA_OPTIONS="-chardev pipe,id=ce1a,path=ce1a -device ce,id=ce1,async=ce1a -chardev pipe,id=ce2a,path=ce2a -device ce,id=ce2,async=ce2a"
QEMU_PRE_CMD="perl ce.pl 1 2 & perl ce.pl 2 1 &"
QEMU_FIFOS="ce1a ce1 ce2a ce2"
