#line 1 "utente/prog/pbreak.in"
#include <all.h>


#line 4 "utente/prog/pbreak.in"
extern natl bad1;
#line 4 "utente/prog/pbreak.in"

#line 5 "utente/prog/pbreak.in"
extern natl bad2;
#line 5 "utente/prog/pbreak.in"

#line 6 "utente/prog/pbreak.in"
extern natl bad4;
#line 6 "utente/prog/pbreak.in"

#line 7 "utente/prog/pbreak.in"
extern natl bad5;
#line 7 "utente/prog/pbreak.in"

#line 8 "utente/prog/pbreak.in"
extern natl usr1;
#line 8 "utente/prog/pbreak.in"

#line 9 "utente/prog/pbreak.in"
extern natl usr2;
#line 9 "utente/prog/pbreak.in"

#line 10 "utente/prog/pbreak.in"
extern natl usr3;
#line 10 "utente/prog/pbreak.in"

#line 11 "utente/prog/pbreak.in"
extern natl dbg1;
#line 11 "utente/prog/pbreak.in"

#line 12 "utente/prog/pbreak.in"
extern natl dbg2;
#line 12 "utente/prog/pbreak.in"

#line 13 "utente/prog/pbreak.in"
extern natl dbg3;
#line 13 "utente/prog/pbreak.in"

#line 15 "utente/prog/pbreak.in"
extern natl last;
#line 15 "utente/prog/pbreak.in"
extern natl sync;
#line 17 "utente/prog/pbreak.in"
void bad(natq a)
#line 18 "utente/prog/pbreak.in"
{
	asm("int3");
	printf("processo errato %d\n", a);

	terminate_p();
}
void catch_me(int a)
{
	printf("proc%d: eseguo funzione\n", a);
}

vaddr bad_addr[] = { 1000, 0xffffc00000000000 };

void badb(natq a)
#line 31 "utente/prog/pbreak.in"
{
	breakpoint(bad_addr[a - 3]);
	printf("processo errato %d\n", a);

	terminate_p();
}
void usr(natq a)
#line 37 "utente/prog/pbreak.in"
{
	if (a % 2 == 0) {
		sem_wait(sync);
	}
	printf("proc%d: prima della funzione\n", a);
	catch_me(a);
	printf("proc%d: dopo la funzione\n", a);

	terminate_p();
}
void debugger(natq a)
#line 47 "utente/prog/pbreak.in"
{
	printf("debugger %d: chiamo breakpoint\n", a);
	natl proc = breakpoint(reinterpret_cast<natq>(catch_me));
	if (proc == 0xFFFFFFFF) {
		printf("debugger %d: occupato\n", a);
	} else {
		sem_signal(sync);
		printf("debugger %d: breapoint intercettato, processo: %d\n", a, proc);
	}

	terminate_p();
}
void last_body(natq a)
#line 59 "utente/prog/pbreak.in"
{
	pause();

	terminate_p();
}
natl bad1;
natl bad2;
natl bad4;
natl bad5;
natl usr1;
natl usr2;
natl usr3;
natl dbg1;
natl dbg2;
natl dbg3;
natl last;
natl sync;
#line 119 "utente/utente.cpp"

void main()
{
	bad1 = activate_p(bad, 1, 20, LIV_UTENTE);
	bad2 = activate_p(bad, 2, 8, LIV_UTENTE);
	bad4 = activate_p(badb, 3, 21, LIV_UTENTE);
	bad5 = activate_p(badb, 4, 22, LIV_UTENTE);
	usr1 = activate_p(usr, 1, 5, LIV_UTENTE);
	usr2 = activate_p(usr, 2, 15, LIV_UTENTE);
	usr3 = activate_p(usr, 3, 3, LIV_UTENTE);
	dbg1 = activate_p(debugger, 0, 10, LIV_UTENTE);
	dbg2 = activate_p(debugger, 1, 11, LIV_UTENTE);
	dbg3 = activate_p(debugger, 2, 4, LIV_UTENTE);
	last = activate_p(last_body, 0, 1, LIV_UTENTE);
	sync = sem_ini(0);

	terminate_p();}
