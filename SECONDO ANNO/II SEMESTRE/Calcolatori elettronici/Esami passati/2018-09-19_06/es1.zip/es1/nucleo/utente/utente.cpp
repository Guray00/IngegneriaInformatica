#line 1 "utente/prog/psend.in"
#include <all.h>

struct msg {
	natl d;
	char p[1000];
};

#define MSG(src, dst, payload)	{ dst, payload },

msg tosend[] = {
#include "messages"
};


#line 15 "utente/prog/psend.in"
extern natl hello;
#line 15 "utente/prog/psend.in"

#line 16 "utente/prog/psend.in"
extern natl error;
#line 16 "utente/prog/psend.in"

#line 18 "utente/prog/psend.in"
extern natl error2;
#line 18 "utente/prog/psend.in"
void error_body(natq a)
#line 19 "utente/prog/psend.in"
{
	send(0x11223344, (char *)0x200000, 100);
	printf("processo errato 1\n");

	terminate_p();
}
void error2_body(natq a)
#line 25 "utente/prog/psend.in"
{
	send(0x11223344, (char *)tosend, 6000);
	printf("processo errato 2\n");

	terminate_p();
}
void hello_body(natq a)
#line 31 "utente/prog/psend.in"
{
	natl mem0 = getiomeminfo();
	for (unsigned i = 0; i < sizeof(tosend)/sizeof(msg); i++) {
		msg *m = &tosend[i];
		//flog(LOG_DEBUG, "sending %d", i);
		while (!send(m->d, m->p, strlen(m->p))) {
			//flog(LOG_DEBUG, "retrying...");
		}
	}
	natl e = waitnet();
	natl mem1 = getiomeminfo();
	printf("errori di trassmissione: %d\n", e);
	printf("memoria non liberata: %d\n", mem0 - mem1);
	pause();

	terminate_p();
}
natl hello;
natl error;
natl error2;
#line 66 "utente/utente.cpp"

void main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	error = activate_p(error_body, 0, 30, LIV_UTENTE);
	error2 = activate_p(error2_body, 0, 25, LIV_UTENTE);

	terminate_p();}
