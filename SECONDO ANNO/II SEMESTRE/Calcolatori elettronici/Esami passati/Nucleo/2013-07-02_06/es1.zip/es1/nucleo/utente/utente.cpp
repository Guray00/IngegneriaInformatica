#line 1 "utente/prog/phm.in"
#include <all.h>


#line 5 "utente/prog/phm.in"
extern natl m1;
#line 5 "utente/prog/phm.in"
extern natl chain1;
#line 6 "utente/prog/phm.in"
extern natl chain2;
#line 7 "utente/prog/phm.in"
extern natl chain3;
#line 8 "utente/prog/phm.in"
extern natl middle;
#line 10 "utente/prog/phm.in"
natl pim1, pim2, pim3;

void p_max(natq a)
{
	sem_wait(chain3);
	sem_signal(middle);
	pim_wait(pim1);
	printf("%d: sezione critica pim1\n", a);
	pim_signal(pim1);
	printf("%d: termino\n", a);
	terminate_p();
}

void p_middle(natq a)
{
	sem_wait(middle);
	printf("%d: termino\n", a);
	terminate_p();
}

void p_chain1(natq a)
{
	pim_wait(pim1);
	printf("%d: inizio sezione critica pim1\n", a);
	sem_wait(chain1);
	pim_wait(pim2);
	printf("%d: sezione critica pim2\n", a);
	pim_signal(pim2);
	printf("%d: termino sezione critica pim1\n", a);
	pim_signal(pim1);
	printf("%d: termino\n", a);
	terminate_p();
}

void p_chain2(natq a)
{
	pim_wait(pim2);
	printf("%d: inizio sezione critica pim2\n", a);
	sem_signal(chain1);
	sem_wait(chain2);
	pim_wait(pim3);
	printf("%d: sezione critica pim3\n", a);
	pim_signal(pim3);
	printf("%d: termino sezione critica pim2\n", a);
	pim_signal(pim2);
	printf("%d: termino\n", a);
	terminate_p();
}

void p_chain3(natq a)
{
	pim_wait(pim3);
	printf("%d: inizio sezione critica pim3\n", a);
	sem_signal(chain2);
	sem_signal(chain3);
	printf("%d: termino sezione critica pim3\n", a);
	pim_signal(pim3);
	printf("%d: termino\n", a);
	pause();
	terminate_p();
}


void mio_main(natq a)
#line 74 "utente/prog/phm.in"
{
	pim1 = pim_init();
	pim2 = pim_init();
	pim3 = pim_init();
	(void) activate_p(p_max, 50, 50, LIV_UTENTE);
	(void) activate_p(p_chain1, 30, 30, LIV_UTENTE);
	(void) activate_p(p_chain2, 20, 20, LIV_UTENTE);
	(void) activate_p(p_chain3, 10, 10, LIV_UTENTE);
	(void) activate_p(p_middle, 40, 40, LIV_UTENTE);

	terminate_p();
}
natl m1;
natl chain1;
natl chain2;
natl chain3;
natl middle;
#line 99 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);
	chain1 = sem_ini(0);
	chain2 = sem_ini(0);
	chain3 = sem_ini(0);
	middle = sem_ini(0);

	terminate_p();}
