#line 1 "utente/prog/pce.in"
#include <all.h>
#include "ce0_data.h"
#include "ce1_data.h"

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %d: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %d PROC %d: " s "\n", test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_test() do {\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

bool cmp(int test_num, char *tocheck, char *good, int quanti)
{
	for (int i = 0; i < quanti; i++) {
		if (tocheck[i] != good[i]) {
			err("il byte %d vale %2x invece di %2x", i, tocheck[i], good[i]);
			return false;
		}
	}
	return true;
}

#define check_ceread(id, off, buf, n) do {\
	(buf)[-1] = (buf)[n] = 0;\
	if (!ceread(id, off, buf, n)) {\
		err("ceread(%d, %d, %x, %d) ha restituto false invece di true", id, off, buf, n);\
		goto error;\
	}\
	if (!cmp(test_num, buf, (char *)utente_ce##id##_data + (off), n))\
		goto error;\
	if ((buf)[-1] || (buf)[n]) {\
		err("ceread(%d, %d, %x, %d) ha scritto al di fuori del buffer", id, off, buf, n);\
	}\
} while (0)

#define check_cewrite(id, off, buf, n) do {\
	memcpy(utente_ce##id##_data + (off), buf, n);\
	if (!cewrite(id, off, buf, n)) {\
		err("cewrite(%d, %d, %x, %d) ha restituto false invece di true", id, off, buf, n);\
		goto error;\
	}\
} while (0)

#define TCNT(n)	natl t##n##m0; natl t##n##n0;
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

/************************************************************
 *            test 00: errori vari                          *
 ************************************************************/

natl t00p0;
natl t00p1;
natl t00p2;
natl t00p3;
natl t00p4;
natl t00p5;

void t00p0b(natq test_num)
{
	char sect[1];
	ceread(2, 0, sect, 1);
	err("ceread su dispositivo inesistente non ha causato abort");
	terminate_p();
}

void t00p1b(natq test_num)
{
	char sect[10*DIM_SECT];

	if (ceread(0, 11*DIM_SECT, sect, DIM_SECT)) {
		err("ceread su settore inesistente di ce0 ha restituito true");
		goto error;
	}
	if (ceread(0, 5*DIM_SECT, sect, 10*DIM_SECT)) {
		err("ceread terminante oltre la fine di ce0 ha restituito true");
		goto error;
	}
	if (ceread(1, 5*DIM_SECT, sect, DIM_SECT)) {
		err("ceread su settore inesistente di ce1 ha restituito true");
		goto error;
	}
	if (ceread(1, 2*DIM_SECT, sect, 5*DIM_SECT)) {
		err("ceread terminante oltre la fine di ce1 ha restituito true");
		goto error;
	}
	if (ceread(0, 10*DIM_SECT, sect, 1)) {
		err("ceread terminante oltre la fine di ce0 ha restituito true");
		goto error;
	}
	if (ceread(0, 10*DIM_SECT+1, sect, 1)) {
		err("ceread su settore inesistente di ce0 ha restituito true");
		goto error;
	}
	if (ceread(0, 10*DIM_SECT-1, sect, 2)) {
		err("ceread terminante oltre la fine di ce0 ha restituito true");
		goto error;
	}
	end_test();
}

void t00p2b(natq test_num)
{
	ceread(0, 0, 0, 1);
	err("ceread con buf non accessibile all'utente non ha causato abort");
	terminate_p();
}

void t00p3b(natq test_num)
{
	ceread(0, 0, (char *)-10, 20);
	err("ceread con buf non interamente accessibile all'utente non ha causato abort");
	terminate_p();
}

void t00p4b(natq test_num)
{
	cewrite(0, 0, 0, 1);
	err("cewrite con buf non accessibile all'utente non ha causato abort");
	terminate_p();
}

void t00p5b(natq test_num)
{
	cewrite(0, 0, (char *)-10, 20);
	err("cewrite con buf non interamente accessibile all'utente non ha causato abort");
	terminate_p();
}

/*************************************************************
 *                test 01: lettura di un intero settore      *
 *************************************************************/

natl t01p0;
natl t01p1;
TCNT(01);

void t01p0b(natq test_num)
{
	char sect[DIM_SECT+2];

	check_ceread(0, 3*DIM_SECT, sect+1, DIM_SECT);
	testok(01);
	end_test();
}

void t01p1b(natq test_num)
{
	char sect[DIM_SECT+2];

	check_ceread(1, 2*DIM_SECT, sect+1, DIM_SECT);
	testok(01);
	end_test();
}

///**************************************************************
// *           test 02: scrittura e rilettura di un setore      *
// **************************************************************/

natl t02s0;
natl t02p0;
natl t02p1;
TCNT(02);

void t02p0b(natq test_num)
{
	char sect[DIM_SECT+2];

	sem_wait(t02s0);
	check_ceread(0, 9*DIM_SECT, sect+1, DIM_SECT);
	testok(02);
	end_test();
}

void t02p1b(natq test_num)
{
	char sect[DIM_SECT+2] = "\0TEST 02;TEST 02;TEST 02;TEST 02;";

	check_ceread(0, 9*DIM_SECT, sect+1, DIM_SECT);
	sem_signal(t02s0);
	testok(02);
	end_test();
}

///**************************************************************
// *           test 03: lettura di piu' settori                 *
// **************************************************************/

natl t03p0;
natl t03p1;
TCNT(03);

void t03p0b(natq test_num)
{
	char sect[9*DIM_SECT+2];

	check_ceread(0, DIM_SECT, sect+1, 9*DIM_SECT);
	testok(03);
	end_test();
}

void t03p1b(natq test_num)
{
	char sect[3*DIM_SECT+2];

	check_ceread(0, 0, sect+1, 3*DIM_SECT);
	testok(03);
	end_test();
}

///**************************************************************
// *    test 04: scrittura e rilettura di piu' settori (interi) *
// **************************************************************/

natl t04s0;
natl t04p0;
natl t04p1;
TCNT(04);

void t04p0b(natq test_num)
{
	char sect[6*DIM_SECT+2];

	sem_wait(t04s0);
	check_ceread(0, 0, sect+1, 6*DIM_SECT);
	testok(04);
	end_test();
}

void t04p1b(natq test_num)
{
	char sect[4*DIM_SECT+2];

	for (int i = 1; i <= 4*DIM_SECT; i++)
		sect[i] = 'A' + (i % 26);

	check_cewrite(0, DIM_SECT, sect+1, 4*DIM_SECT);
	sem_signal(t04s0);
	testok(04);
	end_test();
}

///**************************************************************
// *           test 05: lettura di parte di un settore          *
// **************************************************************/

natl t05p0;
bool t05b0;

void t05p0b(natq test_num)
{
	char sect1[10+2];
	char sect2[6+2];

	check_ceread(0, 15, sect1+1, 10);
	check_ceread(1, 2*DIM_SECT+3, sect2+1, 6);
	t05b0 = true;
	end_test();
}

///**************************************************************
// *           test 06: lettura di parti di piu' settori        *
// **************************************************************/

natl t06p0;
bool t06b0;

void t06p0b(natq test_num)
{
	char sect[1+2*DIM_SECT+4+2];

	check_ceread(0, DIM_SECT-1, sect+1, 1+2*DIM_SECT+4);
	t06b0 = true;
	end_test();
}

///**************************************************************
// *     test 07: lettura fino alla fine dell'ultimo settore    *
// **************************************************************/

natl t07p0;
bool t07b0;

void t07p0b(natq test_num)
{
	char sect[5+2*DIM_SECT+2];

	check_ceread(1, 3*DIM_SECT-5, sect+1, 5+2*DIM_SECT);
	t07b0 = true;
	end_test();
}

///**************************************************************
// *  test 08: scrittura e rilettura di parte di un settore     *
// **************************************************************/

natl t08p0;
bool t08b0;

void t08p0b(natq test_num)
{
	char sect1[1], sect2[DIM_SECT+2];

	sect1[0] = '@';

	check_cewrite(0, 3*DIM_SECT+10, sect1, 1);
	check_ceread(0, 3*DIM_SECT, sect2+1, DIM_SECT);
	t08b0 = true;
	end_test();
}

///**************************************************************
// *  test 09: scrittura e rilettura di parti di piu' settori   *
// **************************************************************/

natl t09p0;
bool t09b0;

void t09p0b(natq test_num)
{
	char sect1[10+2*DIM_SECT+19], sect2[4*DIM_SECT+2];

	for (int i = 0; i < 10+2*DIM_SECT+19; i++)
		sect1[i] = '0' + (i % 10);

	check_cewrite(1, DIM_SECT-10, sect1, 10+2*DIM_SECT+19);
	check_ceread(1, 0, sect2+1, 4*DIM_SECT);
	t09b0 = true;
	end_test();
}

///**************************************************************
// *           test 10: operazioni concorrenti                  *
// **************************************************************/

natl t10p0;
natl t10p1;
natl t10p2;
natl t10p3;
TCNT(10);

void t10p0b(natq test_num)
{
	char sect[DIM_SECT+2];

	check_ceread(0, 3, sect, DIM_SECT);
	testok(10);;
	end_test();
}
void t10p1b(natq test_num)
{
	char sect[DIM_SECT+2];

	check_ceread(0, DIM_SECT+30, sect, DIM_SECT);
	testok(10);
	end_test();
}
void t10p2b(natq test_num)
{
	char sect[DIM_SECT+2];

	check_ceread(0, 2*DIM_SECT+10, sect, DIM_SECT);
	testok(10);
	end_test();
}
void t10p3b(natq test_num)
{
	char sect[DIM_SECT+2];

	check_ceread(0, 3*DIM_SECT+9, sect, DIM_SECT);
	testok(10);
	end_test();
}

/**********************************************************************/


#line 390 "utente/prog/pce.in"
extern natl mainp;
#line 390 "utente/prog/pce.in"
void main_body(natq id)
#line 391 "utente/prog/pce.in"
{
	natl test_num;
	natl prio = 600;

	end_test = sem_ini(0);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	new_proc(00, 1);
	new_proc(00, 2);
	new_proc(00, 3);
	new_proc(00, 4);
	new_proc(00, 5);
	sem_wait(end_test);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: lettura di un settore");
	t01m0 = sem_ini(1);
	new_proc(01, 0);
	new_proc(01, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t01n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: scrittura e rilettura di un settore");
	t02s0 = sem_ini(0);
	t02m0 = sem_ini(1);
	new_proc(02, 0);
	new_proc(02, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t02n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 3;
	dbg(">>>INIZIO<<<: lettura di piu' settori (interi)");
	t03m0 = sem_ini(1);
	new_proc(03, 0);
	new_proc(03, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t03n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: scrittura e rilettura di piu' settori (interi)");
	t04s0 = sem_ini(0);
	t04m0 = sem_ini(1);
	new_proc(04, 0);
	new_proc(04, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t04n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: lettura di parte di un settore");
	new_proc(05, 0);
	sem_wait(end_test);
	if (t05b0) msg("OK");
	dbg("=== FINE ===");

	test_num = 6;
	dbg(">>>INIZIO<<<: lettura di parti di piu' settori");
	new_proc(06, 0);
	sem_wait(end_test);
	if (t06b0) msg("OK");
	dbg("=== FINE ===");

	test_num = 7;
	dbg(">>>INIZIO<<<: lettura fino alla fine dell'ultimo settore");
	new_proc(07, 0);
	sem_wait(end_test);
	if (t07b0) msg("OK");
	dbg("=== FINE ===");

	test_num = 8;
	dbg(">>>INIZIO<<<: scrittura e rilettura di parte di un settore");
	new_proc(08, 0);
	sem_wait(end_test);
	if (t08b0) msg("OK");
	dbg("=== FINE ===");

	test_num = 9;
	dbg(">>>INIZIO<<<: scrittura e rilettura di parti di piu' settori");
	new_proc(09, 0);
	sem_wait(end_test);
	if (t09b0) msg("OK");
	dbg("=== FINE ===");

	test_num = 10;
	dbg(">>>INIZIO<<<: accessi concorrenti");
	t10m0 = sem_ini(1);
	new_proc(10, 0);
	new_proc(10, 1);
	new_proc(10, 2);
	new_proc(10, 3);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t10n0 == 4) msg("OK");
	dbg("=== FINE ===");

	pause();

	terminate_p();
}
natl mainp;
#line 509 "utente/utente.cpp"

void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();}
