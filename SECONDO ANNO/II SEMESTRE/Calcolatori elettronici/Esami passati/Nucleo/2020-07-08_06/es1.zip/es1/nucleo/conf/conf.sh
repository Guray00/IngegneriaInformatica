QEMU_EXTRA_OPTIONS="-chardev pipe,id=ce0a,path=ce0a -device ce,id=ce0,async=ce0a -chardev pipe,id=ce1a,path=ce1a -device ce,id=ce1,async=ce1a"
QEMU_PRE_CMD="perl ce.pl 0 10 & perl ce.pl 1 5 &"
QEMU_FIFOS="ce0a ce0 ce1a ce1"
