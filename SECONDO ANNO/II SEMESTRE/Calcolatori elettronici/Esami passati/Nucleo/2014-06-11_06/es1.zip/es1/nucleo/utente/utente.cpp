#line 1 "utente/prog/pbarrier.in"
#include <all.h>


#line 4 "utente/prog/pbarrier.in"
extern natl pbarrier;
#line 4 "utente/prog/pbarrier.in"
extern natl sync1;
#line 5 "utente/prog/pbarrier.in"
extern natl sync2;
#line 6 "utente/prog/pbarrier.in"
extern natl sync3;
#line 8 "utente/prog/pbarrier.in"
void notreg(natq a)
{
	barrier();
	printf("processo errato %d\n", a);
	terminate_p();
}

void b1(natq a)
{
	reg();
	sem_wait(sync1);
	barrier();
	printf("processo %d\n", a);
	terminate_p();
}

void b2(natq a)
{
	reg();
	sem_wait(sync2);
	barrier();
	printf("processo %d\n", a);
	terminate_p();
}

void b3(natq a)
{
	reg();
	sem_signal(sync1);
	sem_signal(sync2);
	sem_signal(sync3);
	barrier();
	printf("processo %d\n", a);
	pause();
	terminate_p();
}

void late(natq a)
{
	reg();
	printf("processo errato %d\n", a);
	terminate_p();
}

void main_body(natq a)
#line 53 "utente/prog/pbarrier.in"
{
	reg();

	activate_p(notreg, 1, 50, LIV_UTENTE);
	activate_p(b1, 1, 30, LIV_UTENTE);
	activate_p(b2, 2, 29, LIV_UTENTE);
	activate_p(b3, 3, 28, LIV_UTENTE);
	activate_p(late, 2, 10, LIV_UTENTE);
	sem_wait(sync3);
	barrier();

	terminate_p();
}
natl pbarrier;
natl sync1;
natl sync2;
natl sync3;
#line 78 "utente/utente.cpp"

void main()
{
	pbarrier = activate_p(main_body, 0, 100, LIV_UTENTE);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);

	terminate_p();}
