#line 1 "utente/prog/pbreak.in"
#include <all.h>

const int NSLAVES = 6;
const int NPROCS = 9;


#line 7 "utente/prog/pbreak.in"
extern natl first;
#line 7 "utente/prog/pbreak.in"

#line 8 "utente/prog/pbreak.in"
extern natl usr0;
#line 8 "utente/prog/pbreak.in"

#line 9 "utente/prog/pbreak.in"
extern natl usr1;
#line 9 "utente/prog/pbreak.in"

#line 10 "utente/prog/pbreak.in"
extern natl usr2;
#line 10 "utente/prog/pbreak.in"

#line 11 "utente/prog/pbreak.in"
extern natl usr3;
#line 11 "utente/prog/pbreak.in"

#line 12 "utente/prog/pbreak.in"
extern natl usr4;
#line 12 "utente/prog/pbreak.in"

#line 13 "utente/prog/pbreak.in"
extern natl usr5;
#line 13 "utente/prog/pbreak.in"

#line 14 "utente/prog/pbreak.in"
extern natl dbg0;
#line 14 "utente/prog/pbreak.in"

#line 15 "utente/prog/pbreak.in"
extern natl dbg1;
#line 15 "utente/prog/pbreak.in"

#line 16 "utente/prog/pbreak.in"
extern natl dbg2;
#line 16 "utente/prog/pbreak.in"

#line 17 "utente/prog/pbreak.in"
extern natl dbg5;
#line 17 "utente/prog/pbreak.in"

#line 18 "utente/prog/pbreak.in"
extern natl dbg6;
#line 18 "utente/prog/pbreak.in"

#line 19 "utente/prog/pbreak.in"
extern natl dbg7;
#line 19 "utente/prog/pbreak.in"

#line 20 "utente/prog/pbreak.in"
extern natl dbg9;
#line 20 "utente/prog/pbreak.in"

#line 22 "utente/prog/pbreak.in"
extern natl last;
#line 22 "utente/prog/pbreak.in"
extern natl sync0;
#line 23 "utente/prog/pbreak.in"
extern natl sync1;
#line 24 "utente/prog/pbreak.in"
extern natl sync2;
#line 25 "utente/prog/pbreak.in"
extern natl sync3;
#line 26 "utente/prog/pbreak.in"
extern natl sync4;
#line 27 "utente/prog/pbreak.in"
extern natl sync5;
#line 28 "utente/prog/pbreak.in"
extern natl sync6;
#line 29 "utente/prog/pbreak.in"
extern natl sync7;
#line 30 "utente/prog/pbreak.in"
extern natl sync8;
#line 32 "utente/prog/pbreak.in"
natl sems[NPROCS];
natl slaves[NSLAVES];
natq masters[NSLAVES];

int getallocdiff()
{
	return getmeminfo().heap_libero;
}

void first_body(natq a)
#line 42 "utente/prog/pbreak.in"
{
	sems[0] = sync0;
	sems[1] = sync1;
	sems[2] = sync2;
	sems[3] = sync3;
	sems[4] = sync4;
	sems[5] = sync5;
	sems[6] = sync6;
	sems[7] = sync7;
	sems[8] = sync8;
	slaves[0] = usr0;
	slaves[1] = usr1;
	slaves[2] = usr2;
	slaves[3] = usr3;
	slaves[4] = usr4;
	slaves[5] = usr5;
	masters[0] = 10;
	masters[1] = 10;
	masters[2] = 11;
	masters[3] = 11;
	masters[4] = 12;
	masters[5] = 12;

	terminate_p();
}
#define MSG(fmt, ...)	do { printf("proc %d: " fmt "\n", getpid(), ## __VA_ARGS__); } while (0)

int zero = 0;

void usr_div(natq a)
#line 71 "utente/prog/pbreak.in"
{
	int b;

	sem_wait(sems[a]);
	MSG("eseguo 42/0");
	b = 42 / zero;
	MSG("sopravvissuto a divisione per zero", b);

	terminate_p();
}
void usr_pf(natq a)
#line 81 "utente/prog/pbreak.in"
{
	sem_wait(sems[a]);
	*(int *)0 = 0;

	terminate_p();
}
void usr_term(natq a)
#line 87 "utente/prog/pbreak.in"
{
	sem_wait(sems[a]);
	MSG("termino normalmente");

	terminate_p();
}
void usr_break(natq a)
#line 93 "utente/prog/pbreak.in"
{
	sem_wait(sems[a]);
	MSG("eseguo mov int3");
	asm("int3");
	MSG("sopravvissuto a int3");

	terminate_p();
}
void usr_prot(natq a)
#line 101 "utente/prog/pbreak.in"
{
	sem_wait(sems[a]);
	MSG("eseguo mov %%rax, %%cr3");
	asm("movq %rax, %cr3");
	MSG("sopravvissuto a mov %%rax, %%cr3");

	terminate_p();
}
void bad1(natq a)
#line 109 "utente/prog/pbreak.in"
{
	if (proc_attach(getpid())) {
		MSG("errore: proc_attach ricorsiva riuscita");
	}

	terminate_p();
}
void bad2(natq a)
#line 116 "utente/prog/pbreak.in"
{
	if (proc_attach(100)) {
		MSG("errore: proc_attach su processo non esistente riuscita");
	}

	terminate_p();
}
void bad3(natq a)
#line 123 "utente/prog/pbreak.in"
{
	if (natl v = proc_wait() != 0xFFFFFFFF)
		MSG("errore: proc_wait() senza slave ha restituito %d invece di 0xFFFFFFFF", v);

	terminate_p();
}
void bad5(natq a)
#line 129 "utente/prog/pbreak.in"
{
	if (proc_attach(a)) {
		MSG("errore: proc_attach() duplicata su slave riuscita");
	}

	terminate_p();
}
static const char *eccezioni[] = {
	"errore di divisione", 		// 0
	"debug",			// 1
	"interrupt non mascherabile",	// 2
	"breakpoint",			// 3
	"overflow",			// 4
	"bound check",			// 5
	"codice operativo non valido",	// 6
	"dispositivo non disponibile",	// 7
	"doppio fault",			// 8
	"coprocessor segment overrun",	// 9
	"TSS non valido",		// 10
	"segmento non presente",	// 11
	"errore sul segmento stack",	// 12
	"errore di protezione",		// 13
	"page fault",			// 14
	"riservato",			// 15
	"errore su virgola mobile",	// 16
	"errore di allineamento",	// 17
	"errore interno",		// 18
	"errore SIMD",			// 19
	"20??",
	"21??",
	"22??",
	"23??",
	"24??",
	"25??",
	"26??",
	"27??",
	"28??",
	"29??",
	"30??",
	"31??",
	"normale"
};

void debugger(natq a)
#line 172 "utente/prog/pbreak.in"
{
	int nslaves = 0;

	for (int i = 0; i < NSLAVES; i++) {
		if (masters[i] == a) {
			nslaves++;
			MSG("chiamo proc_attach(%d)", slaves[i]);
			if (!proc_attach(slaves[i])) {
				MSG("proc_attach(%d) fallita", slaves[i]);
				terminate_p();
			}
		}
	}
	for (int i = 0; i < nslaves; i++) {
		sem_wait(sems[a - 10 + NSLAVES]);
		natl v = proc_wait();
		if (v == 0xFFFFFFFF) {
			MSG("tutti gli slave sono terminati");
			break;
		}
		natl c = proc_exception(v);
		if (c == 0xFFFFFFFF) {
			MSG("proc_exception(%d) fallita", v);
			continue;
		}
		if (c > 32) {
			MSG("codice terminazione non riconosciuto: %d", c);
		} else  {
			MSG("motivo terminazione di %d: %s", v, eccezioni[c]);
		}
		proc_cont(v, c != 3);
	}

	terminate_p();
}
void last_body(natq a)
#line 207 "utente/prog/pbreak.in"
{
	// proc_wait prima di entrambi
	sem_signal(sync6);
	sem_signal(sync0);
	sem_signal(sync6);
	sem_signal(sync1);
	// proc_wait alternata
	sem_signal(sync2);
	sem_signal(sync7);
	sem_signal(sync7);
	sem_signal(sync3);
	// proc_wait dopo entrambi
	sem_signal(sync4);
	sem_signal(sync5);
	sem_signal(sync8);
	sem_signal(sync8);

	printf("heap di sistema disponibile: %d\n", getallocdiff());
	pause();

	terminate_p();
}
natl first;
natl usr0;
natl usr1;
natl usr2;
natl usr3;
natl usr4;
natl usr5;
natl dbg0;
natl dbg1;
natl dbg2;
natl dbg5;
natl dbg6;
natl dbg7;
natl dbg9;
natl last;
natl sync0;
natl sync1;
natl sync2;
natl sync3;
natl sync4;
natl sync5;
natl sync6;
natl sync7;
natl sync8;
#line 330 "utente/utente.cpp"

void main()
{
	first = activate_p(first_body, 0, 100, LIV_UTENTE);
	usr0 = activate_p(usr_div, 0, 20, LIV_UTENTE);
	usr1 = activate_p(usr_prot, 1, 21, LIV_UTENTE);
	usr2 = activate_p(usr_term, 2, 22, LIV_UTENTE);
	usr3 = activate_p(usr_term, 3, 23, LIV_UTENTE);
	usr4 = activate_p(usr_div, 4, 24, LIV_UTENTE);
	usr5 = activate_p(usr_break, 5, 25, LIV_UTENTE);
	dbg0 = activate_p(debugger, 10, 40, LIV_UTENTE);
	dbg1 = activate_p(debugger, 11, 41, LIV_UTENTE);
	dbg2 = activate_p(debugger, 12, 42, LIV_UTENTE);
	dbg5 = activate_p(bad1, 20, 51, LIV_UTENTE);
	dbg6 = activate_p(bad2, 21, 52, LIV_UTENTE);
	dbg7 = activate_p(bad3, 22, 53, LIV_UTENTE);
	dbg9 = activate_p(bad5, usr1, 11, LIV_UTENTE);
	last = activate_p(last_body, 0, 1, LIV_UTENTE);
	sync0 = sem_ini(0);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);
	sync4 = sem_ini(0);
	sync5 = sem_ini(0);
	sync6 = sem_ini(0);
	sync7 = sem_ini(0);
	sync8 = sem_ini(0);

	terminate_p();}
