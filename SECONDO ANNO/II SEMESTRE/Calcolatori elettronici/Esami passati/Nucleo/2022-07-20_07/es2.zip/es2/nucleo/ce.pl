use JSON::XS;
use Data::Dumper;
use IO::Handle;
use Time::HiRes qw(alarm);

$dev = "ce$ARGV[0]";
$CHANS = int($ARGV[1]) || 2;

open $in, "<", "$dev.out";
open $out, ">", "$dev.in";
open $ain, "<", "${dev}a.out";
open $aout, ">", "${dev}a.in";

$out->autoflush(1);
$aout->autoflush(1);

$json = JSON::XS->new;

#$debug = 1;

$config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 8,
			}
		],
		'interrupt-pin' => int($ARGV[0]),
	};


my $CTL = int(0);
my $CHN = int(0);
my $RBR = int(0);
my @queue = ();
my $pend_intr = 0;

my @chan = ();
for my $i (0 .. $CHANS - 1) {
	push @chan, '65'+$i;
}

sub dbg {
	my $msg = shift;
	print "$0: $msg" if $debug;
}

sub send {
	my $msg = shift;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r'\n");
	print $out "$r\n";
	&dbg("### $0: done sending\n");
}

sub send_async {
	my $msg = shift;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on async\n");
	print $aout "$r\n";
	&dbg("### $0: done sending on async\n");
}

sub receive {
	&dbg("### $0: receiving\n");
	while (<$in>) {
	       	if ($obj = $json->incr_parse($_)) {
			&dbg("<-" . Dumper($obj));
			return $obj;
		}
	}
	exit;
}

sub receive_async {
	&dbg("### $0: receiving from async\n");
	while (<$ain>) {
	       	if ($obj = $json->incr_parse($_)) {
			&dbg("<-" . Dumper($obj));
			return $obj;
		}
	}
	exit;
}

sub send_ret {
	my $arg = shift || 0;
	&send({ return => int($arg) });
}

my $done_sending = 0;
$SIG{ALRM} = sub { &send_async({ "raise-irq" => 1 }); $done_sending = 1; };

sub send_intr {
	&dbg("### $0: sending interrupt (pending: $pend_intr CTL: $CTL)\n");
	if (!$pend_intr && $CTL) {
		$pend_intr = 1;
		$done_sending = 0;
		alarm(0.02);
	}
}

sub clear_intr {
	&dbg("### $0: clearing interrupt (pending: $pend_intr)\n");
	if ($pend_intr) {
		&dbg("### $0: done_sending: $done_sending\n");
		while (!$done_sending) {
		}
		&receive_async;
		&send({ "lower-irq" => 1 });
		&receive;
		$pend_intr = 0;
	}
}

sub new_value {
	if (!@queue) {
		return;
	}
	$CHN = shift @queue;
	$RBR = $chan[$CHN];
	$chan[$CHN]++;
	if ($chan[$CHN] == 90) {
		$chan[$CHN] = 65;
	}
	push @queue, $CHN;
}


while (1) {
	$obj = &receive;
	if ($$obj{'get-config'}) {
		&send($config);
		&send_ret;
	} elsif ($i = $$obj{'write'}) {
		$a = $i->{'addr'};
		$s = $i->{'size'};
		$v = $i->{'val'};
		if  ($a != 0 || $s != 1) {
			&dbg("scrittura di $v ($s byte) su $a ignorata\n");
			&send_ret;
		} else {
			&dbg("### $0: writing $v into CTL\n");
			($old, $CTL) = ($CTL, $v & ((1<<$CHANS)-1));
			&dbg("### CTL $old -> $CTL\n");
			for my $i (0 .. $CHANS-1) {
				my $ch = 1 << $i;
				if (($old & $ch) ^ ($CTL & $ch)) {
					if ($old & $ch) {
						@queue = grep { $_ != $i } @queue;
						if (!$CTL) {
							&clear_intr;
						}
					} else {
						push @queue, $i;
						if (!$pend_intr) {
							&new_value;
							&send_intr;	
						}
					}
				}
			}
			&send_ret;
		}
	} elsif ($i = $$obj{'read'}) {
		$a = $i->{'addr'};
		&send_ret if  ($a % 1 || $a >= 8);
		$s = $i->{'size'};
		&send_ret if  ($s != 1);
		&dbg("### $0: reading from $a\n");
		if ($a == 0) {
			&send_ret($CTL);
		} elsif ($a == 2) {
			if ($CTL == 0) {
				&send_ret($CHANS);
			} else {
				&send_ret($CHN);
			}
		} elsif ($a == 4) {
			&clear_intr;
			$cur = $RBR;
			&new_value;
			&send_intr;
			&send_ret($cur);
		} else {
			&send_ret;
		}
	}
}
