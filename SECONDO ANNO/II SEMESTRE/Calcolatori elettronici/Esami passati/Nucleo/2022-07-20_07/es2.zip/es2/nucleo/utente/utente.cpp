#line 1 "utente/prog/pce.in"
/*
 * Programma di test 2022-07-20
 */

#include <all.h>

const int MSG_SIZE1 = 4;
const int MSG_SIZE2 = 16;
const int MSG_SIZE3 = 8;
const int MSG_SIZE4 = 12;
const int MSG_SIZE5 = 16;
const int MSG_SIZE6 = 2;
const int MSG_SIZE7 = 5;
const int MSG_SIZE8 = 11;
const int MSG_SIZE9 = 10;
const int MAX_SIZE  = 16;
const int NMESG = 1;

extern natl mailbox_piena;
#line 20 "utente/prog/pce.in"
extern natl mailbox_vuota;
#line 22 "utente/prog/pce.in"

#line 23 "utente/prog/pce.in"
extern natl errore1;
#line 23 "utente/prog/pce.in"

#line 24 "utente/prog/pce.in"
extern natl errore2;
#line 24 "utente/prog/pce.in"

#line 25 "utente/prog/pce.in"
extern natl errore3;
#line 25 "utente/prog/pce.in"

#line 26 "utente/prog/pce.in"
extern natl errore4;
#line 26 "utente/prog/pce.in"

#line 27 "utente/prog/pce.in"
extern natl scrittore1;
#line 27 "utente/prog/pce.in"

#line 28 "utente/prog/pce.in"
extern natl scrittore2;
#line 28 "utente/prog/pce.in"

#line 29 "utente/prog/pce.in"
extern natl scrittore3;
#line 29 "utente/prog/pce.in"

#line 30 "utente/prog/pce.in"
extern natl scrittore4;
#line 30 "utente/prog/pce.in"

#line 31 "utente/prog/pce.in"
extern natl scrittore5;
#line 31 "utente/prog/pce.in"

#line 32 "utente/prog/pce.in"
extern natl scrittore6;
#line 32 "utente/prog/pce.in"

#line 33 "utente/prog/pce.in"
extern natl scrittore7;
#line 33 "utente/prog/pce.in"

#line 34 "utente/prog/pce.in"
extern natl scrittore8;
#line 34 "utente/prog/pce.in"

#line 35 "utente/prog/pce.in"
extern natl scrittore9;
#line 35 "utente/prog/pce.in"

#line 37 "utente/prog/pce.in"
extern natl lettore;
#line 37 "utente/prog/pce.in"
char dummybuf[10];
void e1(natq a)
#line 39 "utente/prog/pce.in"
{
	ceread(a, 0, dummybuf, 1);
	printf("ERRORE: accesso a dispositivo %d non esistente\n", a);

	terminate_p();
}
void e2(natq a)
#line 45 "utente/prog/pce.in"
{
	natq d = a >> 3;
	natq c = a & 07;
	ceread(d, c, dummybuf, 1);
	printf("ERRORE: accesso a canale %d non esistente nel dispositivo %d\n", c, d);

	terminate_p();
}
struct mess {
	int mittente;
	char corpo[MAX_SIZE + 1];
};

mess mailbox;

struct {
char buf1[MSG_SIZE1];
natb canary1 = 0x01;
char buf2[MSG_SIZE2];
natb canary2 = 0x02;
char buf3[MSG_SIZE3];
natb canary3 = 0x03;
char buf4[MSG_SIZE4];
natb canary4 = 0x04;
char buf5[MSG_SIZE5];
natb canary5 = 0x05;
char buf6[MSG_SIZE6];
natb canary6 = 0x06;
char buf7[MSG_SIZE7];
natb canary7 = 0x07;
char buf8[MSG_SIZE8];
natb canary8 = 0x08;
char buf9[MSG_SIZE9];
natb canary9 = 0x09;
} __attribute__((packed)) b;

char *bufs[] = { b.buf1, b.buf2, b.buf3, b.buf4, b.buf5, b.buf6, b.buf7, b.buf8, b.buf9 };
natb *canaries[] = { &b.canary1, &b.canary2, &b.canary3, &b.canary4, &b.canary5, &b.canary6, &b.canary7, &b.canary8, &b.canary9 };
int sizes[]  = { MSG_SIZE1, MSG_SIZE2, MSG_SIZE3, MSG_SIZE4, MSG_SIZE5, MSG_SIZE6, MSG_SIZE7, MSG_SIZE8, MSG_SIZE9 };
natl devs[]  = { 0, 1, 1, 1, 0, 0, 1, 0, 1 };
natl chans[] = { 0, 2, 1, 2, 1, 1, 2, 0, 0 };

void pms(natq a)
#line 87 "utente/prog/pce.in"
{
	natl quanti = sizes[a];
	for (natl i = 0; i < quanti; i++) {
		bufs[a][i] = 'a' + a;
	}
	for (int i = 0; i < NMESG; i++) {
		ceread(devs[a], chans[a], bufs[a], quanti);
		sem_wait(mailbox_vuota);
		for (natl i = 0; i < quanti; i++) {
			mailbox.corpo[i] = bufs[a][i];
		}
		mailbox.corpo[quanti] = '\0';
		mailbox.mittente = a;
		sem_signal(mailbox_piena);
	}

	terminate_p();
}
void pml(natq a)
#line 105 "utente/prog/pce.in"
{
	char corpo[MAX_SIZE + 1];
	int mittente;
	for (int i = 0; i < 9 * NMESG; i++) {
		sem_wait(mailbox_piena);
		mittente = mailbox.mittente;
		copy(mailbox.corpo, corpo);
		sem_signal(mailbox_vuota);
		printf("mittente=%d corpo=%s\n", mittente, corpo);
	}
	for (int i = 0; i < 9; i++) {
		if (*canaries[i] != i + 1) {
			printf("overflow nel buffer %d", i + 1);
		}
	}
	pause();

	terminate_p();
}
natl mailbox_piena;
natl mailbox_vuota;
natl errore1;
natl errore2;
natl errore3;
natl errore4;
natl scrittore1;
natl scrittore2;
natl scrittore3;
natl scrittore4;
natl scrittore5;
natl scrittore6;
natl scrittore7;
natl scrittore8;
natl scrittore9;
natl lettore;
#line 191 "utente/utente.cpp"

void main()
{
	mailbox_piena = sem_ini(0);
	mailbox_vuota = sem_ini(1);
	errore1 = activate_p(e1, 3, 60, LIV_UTENTE);
	errore2 = activate_p(e1, 2, 59, LIV_UTENTE);
	errore3 = activate_p(e2, 015, 58, LIV_UTENTE);
	errore4 = activate_p(e2, 002, 57, LIV_UTENTE);
	scrittore1 = activate_p(pms, 0, 6, LIV_UTENTE);
	scrittore2 = activate_p(pms, 1, 7, LIV_UTENTE);
	scrittore3 = activate_p(pms, 2, 8, LIV_UTENTE);
	scrittore4 = activate_p(pms, 3, 9, LIV_UTENTE);
	scrittore5 = activate_p(pms, 4, 10, LIV_UTENTE);
	scrittore6 = activate_p(pms, 5, 11, LIV_UTENTE);
	scrittore7 = activate_p(pms, 6, 12, LIV_UTENTE);
	scrittore8 = activate_p(pms, 7, 13, LIV_UTENTE);
	scrittore9 = activate_p(pms, 8, 14, LIV_UTENTE);
	lettore = activate_p(pml, 0, 5, LIV_UTENTE);

	terminate_p();}
