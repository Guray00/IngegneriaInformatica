#line 1 "utente/prog/pmutex.in"
#include <all.h>


#line 5 "utente/prog/pmutex.in"
extern natl m1;
#line 5 "utente/prog/pmutex.in"
natl mux1, mux2, mux3;
int counter = 0;

void errore1(natq a) {
	printf("Processo errore 1\n");
	mutex_wait(mux1);
	mutex_wait(mux1);
	printf("Questo non deve apparire (1)\n");
	terminate_p();
}

void errore2(natq a) {
	printf("Processo errore 2\n");
	mutex_signal(mux2);
	printf("Questo non deve apparire (2)\n");
	terminate_p();
}

void corretto(natq a) {
	for (int i = 0; i < 5; i++) {
		mutex_wait(mux3);
		printf("Processo corretto %d\n", a);
		counter++;
		delay(2);
		mutex_signal(mux3);
	}
	terminate_p();
}

void mio_main(natq a)
#line 35 "utente/prog/pmutex.in"
{
	mux1 = mutex_ini();
	mux2 = mutex_ini();
	mux3 = mutex_ini();
	activate_p(errore1, 0, 60, LIV_UTENTE);
	activate_p(errore2, 0, 50, LIV_UTENTE);
	activate_p(corretto, 1, 20, LIV_UTENTE);
	activate_p(corretto, 2, 40, LIV_UTENTE);
	for (;;) {
		int b;
		mutex_wait(mux3);
		b = counter;
		mutex_signal(mux3);
		if (b == 10)
			break;
		delay(20);
	}
	pause();

	terminate_p();
}
natl m1;
#line 62 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
