#line 1 "utente/prog/psegnali.in"
/*
 * Prova interrupt/interrupted
 */

#include <all.h>

const int NPROC = 3;
const unsigned int ITER = 6;


#line 11 "utente/prog/psegnali.in"
extern natl m1;
#line 11 "utente/prog/psegnali.in"
natl p0, p1, p2;
natl finish[NPROC];

volatile natl cont = 0;

void gest()
{
	cont++;
	printf("gestore: %d\n", cont);
	termina_gestore();
}

void pm0(natq a)
{
	gestisci(gest);	
	while (cont < ITER) {
		delay(1);
	}
	printf("processo %d: terminato\n", a);
	sem_signal(finish[a]);
	terminate_p();
}

void pm(natq a)
{
	while (cont < ITER) {
		segnala(p0);
		delay(1);
	}
	printf("processo %d: terminato\n", a);
	sem_signal(finish[a]);
	terminate_p();
}


void mio_main(natq a)
#line 47 "utente/prog/psegnali.in"
{
	for (int i = 0; i < NPROC; i++)
		finish[i] = sem_ini(0);
	p0 = activate_p(pm0, 0, 40, LIV_UTENTE);
	p1 = activate_p(pm, 1, 35, LIV_UTENTE);
	p2 = activate_p(pm, 2, 35, LIV_UTENTE);
	for (int i = 0; i < NPROC; i++)
		sem_wait(finish[i]);
	pause();

	terminate_p();
}
natl m1;
#line 66 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
