#line 1 "utente/prog/psegnali.in"
#include <all.h>

const int NPROC = 17;
const unsigned int ITER = 15;


#line 7 "utente/prog/psegnali.in"
extern natl m1;
#line 7 "utente/prog/psegnali.in"
natl p0, p1, p2;
natl finish[NPROC];

natl cont = 0;

#define decl_gest(n)\
	void gest##n()					\
	{						\
		cont++;					\
		printf("gestore %d\n", n);		\
		termina_gestore(n);			\
	}

decl_gest(0)
decl_gest(1)
decl_gest(2)
decl_gest(3)
decl_gest(4)
decl_gest(5)
decl_gest(6)
decl_gest(7)
decl_gest(8)
decl_gest(9)
decl_gest(10)
decl_gest(11)
decl_gest(12)
decl_gest(13)
decl_gest(14)
decl_gest(15)

void pm0(natq a)
{
	gestisci(0, gest0);	
	gestisci(1, gest1);	
	//gestisci(2, gest2);	
	gestisci(3, gest3);	
	gestisci(4, gest4);	
	gestisci(5, gest5);	
	gestisci(6, gest6);	
	gestisci(7, gest7);	
	gestisci(8, gest8);	
	gestisci(9, gest9);	
	gestisci(10, gest10);	
	gestisci(11, gest11);	
	gestisci(12, gest12);	
	gestisci(13, gest13);	
	gestisci(14, gest14);	
	gestisci(15, gest15);	
	while (cont < ITER) {
		delay(1);
	}
	printf("processo 0: terminato\n");
	sem_signal(finish[0]);
	terminate_p();
}

void pm(natq a)
{
	segnala(a, p0);
	sem_signal(finish[a + 1]);
	terminate_p();
}


void mio_main(natq a)
#line 72 "utente/prog/psegnali.in"
{
	for (int i = 0; i < NPROC; i++)
		finish[i] = sem_ini(0);
	p0 = activate_p(pm0, 0, 40, LIV_UTENTE);
	int prio[16] = { 20, 30, 22, 31, 34, 32, 19, 18, 21, 35, 36, 17, 37, 16, 15, 37 };
	for (int i = 0; i < 16; i++)
		activate_p(pm, i, prio[i], LIV_UTENTE);
	for (int i = 0; i < NPROC; i++)
		sem_wait(finish[i]);
	pause();

	terminate_p();
}
natl m1;
#line 92 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
