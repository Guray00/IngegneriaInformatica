use strict;
use JSON::XS;
use Data::Dumper;
use IO::Handle;

my $dev = "ce1";

my ($in, $out);

open $in, "<", "$dev.out";
open $out, ">", "$dev.in";

$out->autoflush(1);

my $json = JSON::XS->new->allow_nonref;

my $debug = 0;

my $config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 32,
			}
		],
		'interrupt-pin' => 1,
	};

my $HEAD = int(0);
my $TAIL = int(0);
my $RING = int(0);
my $ERROR = int(0);
my $pend_intr;
my @messages = ();
my $sent = 0;

open M, "<utente/messages" or die $!;
while (<M>) {
	if (/^\s*MSG\((.*?)\s*,\s*(.*?)\s*,\s*"(.*?)"\s*\)/) {
		my ($src, $dst, $payload) = ($1, $2, $3);
		&dbg("src $src dst $dst payload $payload\n");
		push @messages, pack('L2 A*', hex($src), hex($dst), $payload);
	}
}
close M;

sub dbg {
	my $msg = shift;
	if ($debug) {
		printf "$dev: $msg", @_;
	}
}

sub send {
	my $msg = shift;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on sync\n");
	print $out "$r\n";
	&dbg("### $0: done sending\n");
}

sub receive {
	&dbg("### $0: receiving from sync\n");
	while (<$in>) {
	       	if (my $obj = $json->incr_parse($_)) {
			&dbg("<-" . Dumper($obj));
			return $obj;
		}
	}
	exit;
}


sub send_ret {
	my $arg = shift || 0;
	&send({ return => int($arg)});
}

sub send_intr {
	if (!$pend_intr) {
		&send({ "raise-irq" => 1 });
		&receive;
		$pend_intr = 1;
	}
}

sub clear_intr {
	if ($pend_intr) {
		&send({ "lower-irq" => 1 });
		&receive;
		$pend_intr = 0;
	}
}

sub get_natl {
	my $rv = int(0);
	for (my $i = 3; $i >= 0; $i--) {
		$rv <<= 8;
		$rv |= $_[$i];
	}
	return $rv;
}

sub get_natw {
	my $rv = int(0);
	return ($_[1] << 8) | $_[0];
}

sub get_des {
	my $i = shift;
	my $a = $RING + $i * 8;
	&send({ 'dma-read' => { addr => $a, len => 8 } });
	my $obj = &receive;
	my @b = @{$obj->{'bytes'}};
	my ($pa, $pl) = (&get_natl(@b[0..3]), &get_natl(@b[4..7]));
	return ($pa, $pl);
}

sub put_des {
	my ($i, $sl) = @_;
	my $a = $RING + $i * 8;
	my @upd = unpack('C4', pack('L', $sl));
	&send({ 'dma-write' => { addr => $a + 4, len => 4, bytes => \@upd } });
	&receive;
}

sub ring_next {
	my $i = shift;
	return ($i + 1) % 4;
}

my @toprocess = ( 2, 0, 3, 1, 0, 0, 3, 0, 2, 1, 0, 0);
my $curproc = 0;
sub proc_slot {
	my $i = shift;
	my ($ba, $bl) = &get_des($i);
	&dbg(sprintf("desc %d: %x %d\n", $i, $ba, $bl));
	if ($bl < 8) {
		$ERROR++;
		return;
	}
	my @bytes = unpack('(C)*', $messages[$sent % @messages]);
	my $sl = @bytes;
	if ($sl > $bl) {
		$sl = $bl;
	}
	my @segment;
	@segment[0..$sl-1] = @bytes[0..$sl-1];
	&send({ 'dma-write' => { addr => int($ba), len => int($sl), bytes => \@segment } });
	&receive;
	&put_des($i, $sl);
	&dbg("===> moving on to next packet\n");
	$sent++;
}
sub proc_slots {
	my $n = $toprocess[$curproc % @toprocess];
	&dbg("processing $n slots\n");
	for (my $i = 0 ; $i < $n; $i++) {
		if ($HEAD != $TAIL) {
			&proc_slot($HEAD);
			$HEAD = &ring_next($HEAD);
		}
	}
	if ($n > 0) {
		&send_intr;
	}
	$curproc++;
}

while (1) {
	my $obj = &receive;
	if ($$obj{'get-config'}) {
		&send($config);
		&send_ret;
	} elsif (my $i = $$obj{'write'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		my $v = $i->{'val'};
		&dbg("### writing $v at $a\n");
		if ($a == 0) {
			# read only
		} elsif ($a == 4) {
			$TAIL = $v;
			&dbg("TAIL $v curproc $curproc\n");
			&proc_slots;
		} elsif ($a == 8) {
			$RING = $v;
		} 
		&send_ret;
	} elsif (my $i = $$obj{'read'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		&dbg("### reading from $a\n");
		if ($a == 0) {
			&clear_intr;
			&send_ret($HEAD);
		} elsif ($a == 4) {
			&send_ret($TAIL);
		} elsif ($a == 8) {
			&send_ret($RING);
		} elsif ($a == 12) {
			&send_ret($ERROR);
		}
	}			
}
