int printf(const char *fmt, ...);
void pause();

natl getpid();
