#line 1 "utente/prog/ppipe.in"
#include <all.h>


#line 5 "utente/prog/ppipe.in"
extern natl init;
#line 5 "utente/prog/ppipe.in"
char src[] = "a b c d e f g h i";
char dst[sizeof(src) + 1];

void writer(natq p)
{
	for (unsigned i = 0; i < sizeof(src) + 1; i += 5) {
		printf("writer: invio %d byte\n", 5);
		writepipe(p, src + i, 5);
	}
	printf("writer: termino\n");
	terminate_p();
}

void reader(natq p)
{
	for (unsigned i = 0; i < sizeof(dst) + 1; i += 2) {
		printf("reader: ricevo %d byte\n", 2);
		readpipe(p, dst + i, 2);
	}
	printf("reader: %s\n", dst);
	terminate_p();

}

void last(natq a)
{
	pause();
	terminate_p();
}

void init_body(natq a)
#line 36 "utente/prog/ppipe.in"
{
	natl p = inipipe();
	activate_p(writer, p, 50, LIV_UTENTE);
	activate_p(reader, p, 20, LIV_UTENTE);
	activate_p(last, 3, 10, LIV_UTENTE);

	terminate_p();
}
natl init;
#line 50 "utente/utente.cpp"

void main()
{
	init = activate_p(init_body, 0, 60, LIV_UTENTE);

	terminate_p();}
