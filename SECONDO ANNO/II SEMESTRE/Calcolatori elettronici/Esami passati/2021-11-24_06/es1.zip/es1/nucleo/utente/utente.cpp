#line 1 "utente/prog/psbrk.in"
#include <all.h>
#include <vm.h>
#pragma GCC diagnostic ignored "-Wuninitialized"
#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %d: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %d PROC %d: " s "\n", test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)
#define die(s, ...) do { err(s, ## __VA_ARGS__); goto error; } while (0)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_subtest() do {\
	(void)&&error;\
error:\
	terminate_p();\
} while (0)

#define end_test() do {\
	(void)&&error;\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

natl tokmux;
#define TCNT(n)	natl t##n##n0;
#define testok(n) do {\
	sem_wait(tokmux);\
	t##n##n0++;\
	sem_signal(tokmux);\
} while (0)

int test_num;

const char *b2s(bool b)
{
	return b ? "true" : "false";
}

template<typename T>
const char *p2s(T b)
{
	return b ? "un puntatore" : "nullptr";
}

#define check_incr_break(dim_, exp_) ({ \
	vaddr b_ = incr_break(dim_); \
	if (b_ != (exp_)) { \
		err("incr_break(%x) ha restituito %x invece di %x", dim_, b_, exp_); \
	} \
	b_; \
})

#define check_decr_break(dim_, exp_) ({ \
	vaddr b_ = decr_break(dim_); \
	if (b_ != (exp_)) { \
		err("decr_break(%x) ha restituito %x invece di %x", dim_, b_, exp_); \
	} \
	b_; \
})

#define check_io_heap(incr_, delta_, testlevel_) do { \
	if (!test_heap(incr_, delta_, testlevel_)) { \
		err("errore su heap IO (dettagli nel log)"); \
		goto error; \
	} \
} while (0)

///**********************************************************************
// *             test 00: errori vari                                   *
// **********************************************************************/

natl t00p0;
natl t00p1;
natl t00p2;
natl t00p3;
natl t00p4;
natl t00p5;
natl t00p6;
natl t00p7;
natl t00p8;
natl t00p9;
natl t00pA;

void t00p0b(natq test_num)
{
	incr_break(1);
	err("incr_break con delta non multiplo di DIM_PAGINA non ha causato abort");
	terminate_p();
}

void t00p1b(natq test_num)
{
	incr_break(0xfffffffffffff000L);
	err("incr_break con delta che causa overflow non ha causato abort");
	terminate_p();
}

void t00p2b(natq test_num)
{
	decr_break(0xfffffffffffff000L);
	err("decr_break con delta che causa underflow non ha causato abort");
	terminate_p();
}

void t00p3b(natq test_num)
{
	decr_break(0x101000);
	err("decr_break con delta troppo piccolo non ha causato abort");
	terminate_p();
}

void t00p4b(natq test_num)
{
	incr_break(0x7ffffff000L);
	err("decr_break con delta troppo grande non ha causato abort");
	terminate_p();
}

void t00p5b(natq test_num)
{
	vaddr a = incr_break(0);
	*reinterpret_cast<natq*>(a) = 1;
	err("accesso oltre la fine dello heap non ha causato page fault");
	terminate_p();
}

void t00p6b(natq test_num)
{
	test_heap(true, 1);
	err("incr_break IO con delta non multiplo di DIM_PAGINA non ha causato abort");
	terminate_p();
}

void t00p7b(natq test_num)
{
	test_heap(true, 0xfffffffffffff000L);
	err("incr_break IO con delta che causa overflow non ha causato abort");
	terminate_p();
}

void t00p8b(natq test_num)
{
	test_heap(false, 0xfffffffffffff000L);
	err("decr_break IO con delta che causa underflow non ha causato abort");
	terminate_p();
}

void t00p9b(natq test_num)
{
	test_heap(false, 0x101000);
	err("decr_break IO con delta troppo piccolo non ha causato abort");
	terminate_p();
}

void t00pAb(natq test_num)
{
	test_heap(true, 0x7ffffff000L);
	err("decr_break IO con delta troppo grande non ha causato abort");
	terminate_p();
}

// **********************************************************************
// *             test 01: funzionalità minima                           *
// **********************************************************************

natl t01p0;
TCNT(01);

void t01p0b(natq test_num)
{
	vaddr a = incr_break(0);
	check_incr_break(DIM_PAGINA, a + DIM_PAGINA);
	*reinterpret_cast<natq*>(a) = 1;
	testok(01);
	end_test();
}

// **********************************************************************
// *             test 02: funzionalità minima                           *
// **********************************************************************

natl t02p0;
natl t02p1;
natl t02w0;
TCNT(02);

void t02p0b(natq test_num)
{
	vaddr a = incr_break(0);
	vaddr b = check_decr_break(DIM_PAGINA, a - DIM_PAGINA);
	*reinterpret_cast<natq*>(b) = 1;
	t02w0 = 1;
	err("accesso dopo decr_break non ha causato page fault");
	terminate_p();
}

void t02p1b(natq test_num)
{
	if (!t02w0)
		testok(02);
	end_test();
}

// **********************************************************************
// *             test 03: azzeramento pagine                            *
// **********************************************************************

natl t03p0;
TCNT(03);

void t03p0b(natq test_num)
{
	vaddr a = incr_break(0);
	vaddr b = check_incr_break(2*DIM_PAGINA, a + 2*DIM_PAGINA);
	natq *q = reinterpret_cast<natq*>(b - DIM_PAGINA);
	for (unsigned i = 0; i < DIM_PAGINA/sizeof(*q); i++) {
		if (q[i]) {
			err("la memoria allocata da incr_break() non e' stata azzerata");
			goto error;
		}
	}
	testok(03);
	end_test();
}

// **********************************************************************
// *             test 04: heap globale                                  *
// **********************************************************************

natl t04p0;
natl t04p1;
natq *t05w0;
TCNT(04);

void t04p0b(natq test_num)
{
	vaddr a = incr_break(0);
	check_incr_break(DIM_PAGINA, a + DIM_PAGINA);
	t05w0 = reinterpret_cast<natq*>(a);
	testok(04);
	end_test();
}

void t04p1b(natq test_num)
{
	*t05w0 = 1;
	testok(04);
	end_test();
}

// **********************************************************************
// *             test 05: heap IO (1)					*
// **********************************************************************

natl t05p0;
TCNT(05);

void t05p0b(natq test_num)
{
	check_io_heap(true, DIM_PAGINA, 1);
	check_io_heap(false, DIM_PAGINA, 1);
	testok(05);
	end_test();
}

// **********************************************************************
// *             test 06: heap IO (2)					*
// **********************************************************************

natl t06s0;
natl t06w0;
natl t06p0;
natl t06p1;
TCNT(06);

void t06p0b(natq test_num)
{
	sem_wait(t06s0);
	check_io_heap(false, DIM_PAGINA, 2);
	t06w0 = 1;
	end_subtest();
}

void t06p1b(natq test_num)
{
	check_io_heap(true, DIM_PAGINA, 2);
	sem_signal(t06s0);
	if (t06w0) {
		err("accesso oltre la fine dello heap IO non ha causato page fault");
		goto error;
	}
	testok(06);
	end_test();
}


/**********************************************************************/



#line 307 "utente/prog/psbrk.in"
extern natl mainp;
#line 307 "utente/prog/psbrk.in"
void main_body(natq id)
#line 308 "utente/prog/psbrk.in"
{
	natl prio = 600;
	natl membefore = getmeminfo().num_frame_liberi;
	vaddr heap_before = incr_break(0);

	end_test = sem_ini(0);
	tokmux = sem_ini(1);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	new_proc(00, 1);
	new_proc(00, 2);
	new_proc(00, 3);
	new_proc(00, 4);
	new_proc(00, 5);
	new_proc(00, 6);
	new_proc(00, 7);
	new_proc(00, 8);
	new_proc(00, 9);
	new_proc(00, A);
	delay(10);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: funzionalita' minima");
	new_proc(01, 0);
	sem_wait(end_test);
	if (t01n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: funzionalita' minima (2)");
	new_proc(02, 0);
	new_proc(02, 1);
	sem_wait(end_test);
	if (t02n0 == 1) msg("OK");
	dbg("=== FINE ===");


	test_num = 3;
	dbg(">>>INIZIO<<<: azzeramento memoria");
	new_proc(03, 0);
	sem_wait(end_test);
	if (t03n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: heap globale");
	new_proc(04, 0);
	new_proc(04, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t04n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: IO heap (1)");
	new_proc(05, 0);
	sem_wait(end_test);
	if (t05n0 == 1) msg("OK");
	dbg("=== FINE ===");

	test_num = 6;
	dbg(">>>INIZIO<<<: IO heap (2)");
	t06s0 = sem_ini(0);
	new_proc(06, 0);
	new_proc(06, 1);
	sem_wait(end_test);
	if (t06n0 == 1) msg("OK");
	dbg("=== FINE ===");

	delay(10);
	test_num = 7;
	// controlliamo che tutta la memoria sia stata correttamente rilasciata
	natl memafter = getmeminfo().num_frame_liberi;
	vaddr heap_after = incr_break(0);
	if (memafter != membefore - (heap_after - heap_before)/DIM_PAGINA)
		err("memoria non liberata: %d frame", membefore - memafter);

	pause();

	terminate_p();
}
natl mainp;
#line 398 "utente/utente.cpp"

void main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();}
