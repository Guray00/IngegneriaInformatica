#line 1 "utente/prog/pbroadcast.in"
#include <all.h>


#line 4 "utente/prog/pbroadcast.in"
extern natl pbarrier;
#line 4 "utente/prog/pbroadcast.in"
extern natl sync1;
#line 5 "utente/prog/pbroadcast.in"
extern natl sync2;
#line 6 "utente/prog/pbroadcast.in"
extern natl sync3;
#line 8 "utente/prog/pbroadcast.in"
void notreg(natq a)
{
	listen();
	printf("processo errato %d\n", a);
	terminate_p();
}

void breg(natq a)
{
	reg();
	broadcast(1);
	printf("processo errato %d\n", a);
	terminate_p();
}

void l1(natq a)
{
	reg();
	sem_signal(sync1);
	natl m = listen();
	printf("processo %d mess %d\n", a, m);
	sem_signal(sync3);
	terminate_p();
}

void l2(natq a)
{
	reg();
	sem_signal(sync2);
	natl m = listen();
	printf("processo %d mess %d\n", a, m);
	sem_signal(sync3);
	terminate_p();
}

void b3(natq a)
{
	sem_wait(sync1);
	sem_wait(sync2);
	broadcast(a + 100);
	printf("processo %d\n", a);
	sem_signal(sync3);
	terminate_p();
}

void main_body(natq a)
#line 54 "utente/prog/pbroadcast.in"
{
	activate_p(notreg, 1, 50, LIV_UTENTE);
	activate_p(breg, 1, 51, LIV_UTENTE);
	activate_p(l1, 1, 30, LIV_UTENTE);
	activate_p(l2, 2, 29, LIV_UTENTE);
	activate_p(b3, 3, 28, LIV_UTENTE);
	activate_p(l1, 4, 27, LIV_UTENTE);
	activate_p(b3, 5, 26, LIV_UTENTE);
	activate_p(l2, 6, 25, LIV_UTENTE);
	activate_p(b3, 7, 24, LIV_UTENTE);
	activate_p(l1, 8, 23, LIV_UTENTE);
	activate_p(l2, 9, 22, LIV_UTENTE);
	for (int i = 0; i < 9; i++)
		sem_wait(sync3);
	pause();

	terminate_p();
}
natl pbarrier;
natl sync1;
natl sync2;
natl sync3;
#line 84 "utente/utente.cpp"

void main()
{
	pbarrier = activate_p(main_body, 0, 100, LIV_UTENTE);
	sync1 = sem_ini(0);
	sync2 = sem_ini(0);
	sync3 = sem_ini(0);

	terminate_p();}
