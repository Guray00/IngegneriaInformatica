use threads;
use threads::shared;
use strict;
use JSON::XS;
use Data::Dumper;
use IO::Handle;
use Time::HiRes qw(usleep);

my $debug = 1;

my $ID = $ARGV[0];
my $MAXSNR = int($ARGV[1]);
my $DEV = "ce$ID";

my ($in, $out, $ain, $aout);

open $in, "<", "$DEV.out";
open $out, ">", "$DEV.in";
open $ain, "<", "${DEV}a.out";
open $aout, ">", "${DEV}a.in";

$out->autoflush(1);
$aout->autoflush(1);

my $json = JSON::XS->new->allow_nonref;

my $config = {
		bars => [
			{
				name => 'ce-io',
				type => 'io',
				size => 32,
			}
		],
		'interrupt-pin' => $ID % 4 + 1,
	};

my $SNR :shared = int(0);
my $iSNR = 0;
my $CMD :shared = int(0);
my $iCMD = 4;
my $STS :shared = $MAXSNR;
my $iSTS = 8;
my $ADR :shared = int(0);
my $iADR = 12;
my $pend_intr :shared;
my $running :shared = 1;

my $dout;
if ($debug) {
	open $dout, ">", "debug.$ID";
	$dout->autoflush(1);
}

sub dbg {
	my $msg = shift;
	if ($debug) {
		printf $dout "$DEV: $msg", @_;
	}
}

sub send {
	my ($ch, $msg) = @_;
	my $r = $json->encode($msg);
	&dbg("### $0: sending '$r' on $ch\n");
	if ($ch eq "sync") {
		print $out "$r\n";
	} else {
		print $aout "$r\n";
	}
	&dbg("### $0: done sending\n");
}

my $thr;

sub receive {
	my $ch = shift || "sync";
	my $i = \*$in;
	my $obj;
	if ($ch eq "async") {
		$i = \*$ain;
	}
	&dbg("### $0: receiving from $ch\n");
	while (<$i>) {
	       	if ($obj = $json->incr_parse($_)) {
			&dbg("<-" . Dumper($obj));
			return $obj;
		}
	}
	&dbg("### $0: exiting...\n");
	&stop_running;
	$thr->join();
	exit;
}

sub send_ret {
	my $arg = shift || 0;
	&send('sync', { return => int($arg)});
}

sub send_intr {
	lock($pend_intr);
	if (!$pend_intr) {
		&send('async', { "raise-irq" => 1 });
		&receive('async');
		$pend_intr = 1;
	}
}

sub clear_intr {
	lock($pend_intr);
	if ($pend_intr) {
		&send('async', { "lower-irq" => 1 });
		&receive('async');
		$pend_intr = 0;
	}
}

sub get_cmd {
	lock($CMD);
	cond_wait($CMD);
	return $CMD;
}

sub stop_running
{
	lock($running);
	$running = 0;
	lock($CMD);
	cond_signal($CMD);
}

sub is_running
{
	return lock($running);
}

sub process_cmd {
	my ($a, $c, $s);
	my @hd;
	my $df;
	local $,=",";

	open $df, "<utente/${DEV}_data";
	my $data = <$df>;
	close($df);
	my @a = unpack("(A32)*", $data);
	for my $b (@a) {
		my @c = map(ord, split(//, $b));
		push @hd, \@c;
	}


	while (&is_running) {
		$c = &get_cmd;
		{
			lock($ADR);
			$a = int($ADR);
		}
		{
			lock($SNR);
			$s = int($SNR);
		}
		if ($s >= $MAXSNR) {
			lock($STS);
			$STS |= 0x20000;
			next;
		}
		if ($c == 1) {
			# write
			&send('async', { 'dma-read' => { addr => $a, len => 32 } });
			my $obj = &receive("async");
			$hd[$s] = \@{$obj->{'bytes'}};
			&send_intr;
		} else {
			# read
			usleep(int(rand(10))*1000);
			&send('async', { 'dma-write' => { addr => $a, len => 32, bytes => $hd[$s] } });
			&receive('async');
			&send_intr;
		}
	}
}

$thr = threads->create(\&process_cmd);

while (1) {
	my $obj = &receive;
	if ($$obj{'get-config'}) {
		&send('sync', $config);
		&send_ret;
	} elsif (my $i = $$obj{'write'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		my $v = $i->{'val'};
		&dbg("### writing $v at $a\n");
		if      ($a == $iSNR) {
			lock($SNR);
			$SNR = $v;
		} elsif ($a == $iADR) {
			lock($ADR);
			$ADR = $v;
		} elsif ($a == $iCMD) {
			if ($v != 1 && $v != 2) {
				lock($STS);
				$STS |= 0x10000;
			} else {
				lock($CMD);
				$CMD = $v;
				cond_signal($CMD);
			}
		} elsif ($a == $iSTS) {
			# read only
		}
		&send_ret;
	} elsif (my $i = $$obj{'read'}) {
		my $a = $i->{'addr'};
		if  ($a % 4) {
			&send_ret;
			next;
		}
		my $s = $i->{'size'};
		if  ($s != 4) {
			&send_ret;
			next;
		}
		&dbg("### reading from $a\n");
		my $ret;
		if      ($a == $iSNR) {
			lock($SNR); $ret = $SNR;
		} elsif ($a == $iADR) {
			lock($ADR); $ret = $ADR;
		} elsif ($a == $iCMD) {
			lock($CMD); $ret = $CMD;
		} elsif ($a == $iSTS) {
			lock($STS); $ret = $STS;
			&clear_intr;
		}
		&send_ret($ret);
	}			
}

