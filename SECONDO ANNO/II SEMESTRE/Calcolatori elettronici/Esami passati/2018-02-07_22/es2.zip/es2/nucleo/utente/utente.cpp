#line 1 "utente/prog/pwd.in"
#include <sys.h>
#include <lib.h>


#line 6 "utente/prog/pwd.in"
extern int sem1;
#line 8 "utente/prog/pwd.in"
natl getwd(int a, natl id, natl secs)
{
	natl wd = startwatchdog(id, secs);
	if (wd == 0xffffffff) {
		printf("proc%d: allocazione watchdog su %d fallita", a, id);
		terminate_p();
	}
	printf("proc%d: nuovo watchdog su %d", a, id);
	return wd;
}

void bad(int a)
{
	getwd(a, 3, 10);
}

void loop(int a)
{
	getwd(a, 1, 1);
	while (true)
		;
}

void good(int a)
{
	natl wd = getwd(a, 0, 10);
	stopwatchdog(0, wd);
	printf("proc%d: reset watchdog su 0", a);
	terminate_p();
}

void last(int a)
{
	pause();
	terminate_p();
}

void psp_body(int a)
#line 46 "utente/prog/pwd.in"
{
	activate_p(loop, 0, 40, LIV_UTENTE);
	activate_p(good, 1, 35, LIV_UTENTE);
	activate_p(good, 2, 30, LIV_UTENTE);
	activate_p(good, 3, 25, LIV_UTENTE);
	activate_p(loop, 4, 20, LIV_UTENTE);
	activate_p(bad, 5, 10, LIV_UTENTE);
	activate_p(last, 6, 5, LIV_UTENTE);

	terminate_p();
}
short psp;
int sem1;
#line 62 "utente/utente.cpp"

int main()
{
	psp = activate_p(psp_body, 0, 100, LIV_UTENTE);
	sem1 = sem_ini(0);

	terminate_p();
}
