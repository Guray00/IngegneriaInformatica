#line 1 "utente/prog/preceive.in"
#include <all.h>

static const int MAX_PAYLOAD = 500;
static const int HDR_SZ = 2*sizeof(natl);
static const int MAX_MSGSZ = MAX_PAYLOAD + HDR_SZ;

struct msg {
	natl s;
	const char *p;
};

#define MSG(src, dst, payload) { src, payload },

msg toreceive[] = {
#include "messages"
};


#line 19 "utente/prog/preceive.in"
extern natl rec0;
#line 19 "utente/prog/preceive.in"

#line 20 "utente/prog/preceive.in"
extern natl rec1;
#line 20 "utente/prog/preceive.in"

#line 21 "utente/prog/preceive.in"
extern natl bad2;
#line 21 "utente/prog/preceive.in"

#line 22 "utente/prog/preceive.in"
extern natl bad3;
#line 22 "utente/prog/preceive.in"

#line 23 "utente/prog/preceive.in"
extern natl bad5;
#line 23 "utente/prog/preceive.in"

#line 24 "utente/prog/preceive.in"
extern natl cyc;
#line 24 "utente/prog/preceive.in"

#line 25 "utente/prog/preceive.in"
extern natl coordinatror;
#line 25 "utente/prog/preceive.in"
extern natl sync0;
#line 26 "utente/prog/preceive.in"
extern natl sync1;
#line 27 "utente/prog/preceive.in"
extern natl syncc;
#line 30 "utente/prog/preceive.in"
void bad2_body(natq a)
#line 31 "utente/prog/preceive.in"
{
	natq len = waitnet();
	receive((char *)0x200000, len);
	printf("processo errato 2\n");

	terminate_p();
}
void bad3_body(natq a)
#line 38 "utente/prog/preceive.in"
{
	char buf[10];
	receive(buf, 10);
	printf("processo errato 3\n");

	terminate_p();
}
void bad5_body(natq a)
#line 45 "utente/prog/preceive.in"
{
	receive((char *)(0UL-4), 8);
	printf("processo errato 5\n");

	terminate_p();
}
char magic[] = { 'A', 'B', 'C', 'D' };
char *new_buf() {
	char* buf = new char[MAX_MSGSZ + sizeof(magic)];
	memset(buf, 0, MAX_MSGSZ + sizeof(magic));
	memcpy(buf + MAX_MSGSZ, magic, sizeof(magic));
	return buf;
}

void free_buf(char *buf)
{
	delete buf;
}

bool check_buf(char *buf, natl len, int i)
{
	unsigned int j;
	if (len < HDR_SZ) {
		printf("message %d too short (len %d)\n", i, len);
		return false;
	}
	for (j = 0; j < sizeof(magic); j++) {
		if (buf[MAX_MSGSZ + j] != magic[j]) {
			printf("message %d: write after the end of the buffer\n", i);
			return false;
		}
	}
	buf += HDR_SZ;
	len -= HDR_SZ;
	natq explen = strlen(toreceive[i].p);
	if (len != explen) {
		printf("message %d: len is %d instead of the expected %d\n", i, len, explen);
		return false;
	}
	buf[len <= MAX_PAYLOAD ? len : MAX_PAYLOAD] = '\0';
	for (j = 0; buf[j] && toreceive[i].p[j] && buf[j] == toreceive[i].p[j]; j++)
		;
	if (buf[j]) {
		if (toreceive[i].p[j]) {
			printf("message %d: payload error at byte %d\n", i, j);
			printf("   received '%d', expected '%d'\n", buf[j], toreceive[i].p[j]);
			return false;
		} else {
			printf("message %d: payload error at byte %d\n", i, j);
			printf("   received '%s' beyond expected end of message\n", buf + j);
			return false;
		}
	} else if (toreceive[i].p[j] && explen <= MAX_PAYLOAD) {
		printf("message %d: unexpected null byte at %d\n", i, j);
		return false;
	}
	return true;
}

void cyc_body(natq a)
#line 104 "utente/prog/preceive.in"
{
	natq len = waitnet();
	natq len1 = waitnet();
	if (len != len1) {
		printf("message 0: waitnet() returned %d and then %d\n", len, len1);
	} else {
		char *buf = new_buf();
		receive(buf, len < MAX_MSGSZ ? len : MAX_MSGSZ);
		check_buf(buf, len, 0);
		free_buf(buf);
	}

	terminate_p();
}
int nextp[2];
int next = 1;

int wait(natq a)
{
	sem_wait(a ? sync1 : sync0);
	int i = nextp[a];
	sem_signal(syncc);
	return i;
}


void advance(natq a, bool update = false)
{
	sem_wait(syncc);
	if (update) {
		nextp[a] = next++;
	}
	sem_signal(a ? sync1 : sync0);
}

void stop(natq a, bool update = false)
{
	sem_wait(syncc);
	nextp[a] = -1;
	sem_signal(a ? sync1 : sync0);
}

void coordinator_body(natq a)
#line 146 "utente/prog/preceive.in"
{
	// rec0 legge un messaggio
	advance(0, true);
	advance(0);

	// rec0 e rec1 prenotano un messaggio ciascuno...
	advance(1, true);
	advance(0, true);
	// ... quindi copiano LIFO
	advance(0);
	advance(1);

	// rec0 e rec1 prenotano un messaggio ciascuno...
	advance(1, true);
	advance(0, true);
	// ... quindi copiano FIFO
	advance(1);
	advance(0);

	stop(0);
	stop(1);

	pause();

	terminate_p();
}
void receiver_body(natq a)
#line 172 "utente/prog/preceive.in"
{
	natq len;
	int errors = 0;
	for (;;) {
		int i = wait(a);
		if (i < 0)
			break;
		len = waitnet();
		wait(a);
		char *buf = new_buf();
		receive(buf, len < MAX_MSGSZ ? len : MAX_MSGSZ);
		//printf("message %d len %d\n", i, len);
		if (!check_buf(buf, len, i))
			errors++;
		free_buf(buf);
	}
	if (errors == 0)
		printf("receiver %d: no errors\n", a);

	terminate_p();
}
natl rec0;
natl rec1;
natl bad2;
natl bad3;
natl bad5;
natl cyc;
natl coordinatror;
natl sync0;
natl sync1;
natl syncc;
#line 238 "utente/utente.cpp"

void main()
{
	rec0 = activate_p(receiver_body, 0, 20, LIV_UTENTE);
	rec1 = activate_p(receiver_body, 1, 22, LIV_UTENTE);
	bad2 = activate_p(bad2_body, 0, 49, LIV_UTENTE);
	bad3 = activate_p(bad3_body, 0, 48, LIV_UTENTE);
	bad5 = activate_p(bad5_body, 0, 46, LIV_UTENTE);
	cyc = activate_p(cyc_body, 0, 45, LIV_UTENTE);
	coordinatror = activate_p(coordinator_body, 0, 10, LIV_UTENTE);
	sync0 = sem_ini(0);
	sync1 = sem_ini(0);
	syncc = sem_ini(1);

	terminate_p();}
