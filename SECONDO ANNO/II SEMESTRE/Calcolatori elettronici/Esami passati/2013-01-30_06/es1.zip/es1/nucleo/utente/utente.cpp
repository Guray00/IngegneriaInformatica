#line 1 "utente/prog/pjoin.in"
#include <all.h>


#line 5 "utente/prog/pjoin.in"
extern natl m1;
#line 5 "utente/prog/pjoin.in"
void child(natq a)
{
	printf("figlio %d: termino\n", a);
	terminate_p(10 + a);
}

void father(natq a)
{
	(void) activate_p(child, 3, 30, LIV_UTENTE);
	printf("padre %d: termino\n", a);
	terminate_p(20 + a);
}

void errato(natq a)
{
	join();
	printf("errato %d: termino\n", a);
	terminate_p(30 + a);
}

void mio_main(natq a)
#line 26 "utente/prog/pjoin.in"
{
	natl r;
	(void) activate_p(child, 1, 90, LIV_UTENTE);
	(void) activate_p(child, 2, 91, LIV_UTENTE);
	printf("attendo terminazione figlio\n");
	r = join();
	printf("figlio terminato con valore %d\n", r);
	delay(10);
	printf("attendo terminazione figlio\n");
	r = join();
	printf("figlio terminato con valore %d\n", r);
	(void) activate_p(father, 1, 50, LIV_UTENTE);
	printf("attendo terminazione padre\n");
	r = join();
	printf("padre terminato con valore %d\n", r);
	(void) activate_p(errato, 1, 50, LIV_UTENTE);
	printf("attendo terminazione processo errato\n");
	r = join();
	printf("processo errato terminato con valore %d\n", r);
	delay(1);
	pause();

	terminate_p();
}
natl m1;
#line 56 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
