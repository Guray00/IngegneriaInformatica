#line 1 "utente/prog/pce.in"
/*
 * Programma di test 2016-06-15
 */

#include <all.h>

const int MSG_SIZE = 60;
const int NMESG = 2;

extern natl mailbox_piena;
#line 11 "utente/prog/pce.in"
extern natl mailbox_vuota;
#line 13 "utente/prog/pce.in"

#line 14 "utente/prog/pce.in"
extern natl errato1;
#line 14 "utente/prog/pce.in"

#line 15 "utente/prog/pce.in"
extern natl errato2;
#line 15 "utente/prog/pce.in"

#line 16 "utente/prog/pce.in"
extern natl errato3;
#line 16 "utente/prog/pce.in"

#line 17 "utente/prog/pce.in"
extern natl errato4;
#line 17 "utente/prog/pce.in"

#line 18 "utente/prog/pce.in"
extern natl scrittore1;
#line 18 "utente/prog/pce.in"

#line 19 "utente/prog/pce.in"
extern natl scrittore2;
#line 19 "utente/prog/pce.in"

#line 21 "utente/prog/pce.in"
extern natl lettore;
#line 21 "utente/prog/pce.in"
struct mess {
	int mittente;
	char corpo[MSG_SIZE];
};

mess mailbox;

struct mybuf {
	char b[MSG_SIZE * 100];
} __attribute__((aligned(4096)));

mybuf buf[2];

void err1(natq a)
#line 35 "utente/prog/pce.in"
{
	natl quanti = 256;
	cedmaread(0, quanti, (char *)0x20000);
	printf("processo errato 1\n");

	terminate_p();
}
void err2(natq a)
#line 42 "utente/prog/pce.in"
{
	natl quanti = 100;
	cedmaread(0, quanti, buf[0].b + 30);
	printf("processo errato 2\n");

	terminate_p();
}
void err3(natq a)
#line 49 "utente/prog/pce.in"
{
	cedmaread2(0, (natl*)0x20100, buf[0].b);
	printf("processo errato 3\n");

	terminate_p();
}
void err4(natq a)
#line 55 "utente/prog/pce.in"
{
	natl quanti = 4096 * 10;
	cedmaread(0, quanti, (char *)-4096);
	printf("processo errato 4\n");

	terminate_p();
}
void pms(natq a)
#line 62 "utente/prog/pce.in"
{
	natl quanti;
	for (int i = 0; i < MSG_SIZE * 100; i++) {
		buf[a].b[i] = 'a' + a;
	}
	for (int i = 0; i < NMESG; i++) {
		quanti = MSG_SIZE * 100;
		if (!cedmaread(0, quanti, buf[a].b)) {
			printf("scrittore %d DMA incompleto\n", a);
		}
		flog(LOG_DEBUG, "%d: letti %d byte", a, quanti);
		sem_wait(mailbox_vuota);
		natl j, k;
		for (j = 0, k = 0; k < quanti; k += 100, j++) {
			mailbox.corpo[j] = buf[a].b[k];
		}
		mailbox.corpo[j] = '\0';
		mailbox.mittente = a;
		sem_signal(mailbox_piena);
	}
	printf("fine scrittore %d\n", a);

	terminate_p();
}
void pml(natq a)
#line 86 "utente/prog/pce.in"
{
	char corpo[MSG_SIZE];
	int mittente;
	for (int i = 0; i < 2 * NMESG; i++) {
		sem_wait(mailbox_piena);
		mittente = mailbox.mittente;
		copy(mailbox.corpo, corpo);
		sem_signal(mailbox_vuota);
		printf("mittente=%d corpo=%s\n", mittente, corpo);
	}
	printf("fine lettore\n");
	pause();

	terminate_p();
}
natl mailbox_piena;
natl mailbox_vuota;
natl errato1;
natl errato2;
natl errato3;
natl errato4;
natl scrittore1;
natl scrittore2;
natl lettore;
#line 144 "utente/utente.cpp"

void main()
{
	mailbox_piena = sem_ini(0);
	mailbox_vuota = sem_ini(1);
	errato1 = activate_p(err1, 1, 22, LIV_UTENTE);
	errato2 = activate_p(err2, 2, 21, LIV_UTENTE);
	errato3 = activate_p(err3, 3, 20, LIV_UTENTE);
	errato4 = activate_p(err4, 4, 20, LIV_UTENTE);
	scrittore1 = activate_p(pms, 0, 6, LIV_UTENTE);
	scrittore2 = activate_p(pms, 1, 7, LIV_UTENTE);
	lettore = activate_p(pml, 0, 5, LIV_UTENTE);

	terminate_p();}
