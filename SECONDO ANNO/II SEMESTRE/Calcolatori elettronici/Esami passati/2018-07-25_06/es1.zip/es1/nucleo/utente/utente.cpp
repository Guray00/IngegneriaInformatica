#line 1 "utente/prog/preceive.in"
#include <all.h>

struct msg {
	natl s;
	natl port;
	char p[MAX_PAYLOAD + 1];
};

#define MSG(src, dst, port, payload) { src, port, payload },

msg toreceive[] = {
#include "messages"
};


#line 16 "utente/prog/preceive.in"
extern natl bad1;
#line 16 "utente/prog/preceive.in"

#line 17 "utente/prog/preceive.in"
extern natl bad2;
#line 17 "utente/prog/preceive.in"

#line 18 "utente/prog/preceive.in"
extern natl bad3;
#line 18 "utente/prog/preceive.in"

#line 19 "utente/prog/preceive.in"
extern natl bad4;
#line 19 "utente/prog/preceive.in"

#line 20 "utente/prog/preceive.in"
extern natl rx1;
#line 20 "utente/prog/preceive.in"

#line 21 "utente/prog/preceive.in"
extern natl rx2;
#line 21 "utente/prog/preceive.in"

#line 22 "utente/prog/preceive.in"
extern natl rx3;
#line 22 "utente/prog/preceive.in"

#line 23 "utente/prog/preceive.in"
extern natl rx4;
#line 23 "utente/prog/preceive.in"

#line 25 "utente/prog/preceive.in"
extern natl last;
#line 25 "utente/prog/preceive.in"
void bad1_body(natq a)
#line 26 "utente/prog/preceive.in"
{
	natq len = 8;
	receive(8, (char *)(0UL-4), len);
	printf("processo errato 1\n");

	terminate_p();
}
void bad2_body(natq a)
#line 34 "utente/prog/preceive.in"
{
	natq len = MAX_PAYLOAD;
	receive(8, (char *)0x200000, len);
	printf("processo errato 2\n");

	terminate_p();
}
void bad3_body(natq a)
#line 41 "utente/prog/preceive.in"
{
	char buf[MAX_PAYLOAD + 1];
	receive(8, buf, *(natq *)0x200000);
	printf("processo errato 3\n");

	terminate_p();
}
void bad4_body(natq a)
#line 48 "utente/prog/preceive.in"
{
	char buf[MAX_PAYLOAD + 1];
	receive(8, buf, *(natq *)(0UL-4));
	printf("processo errato 4\n");

	terminate_p();
}
void last_body(natq a)
#line 55 "utente/prog/preceive.in"
{
	pause();

	terminate_p();
}
void rx_body(natq a)
#line 60 "utente/prog/preceive.in"
{
	char buf[MAX_PAYLOAD + 1];
	natq len;
	int errors = 0;
	for (unsigned i = 0; i < sizeof(toreceive)/sizeof(msg); i++) {
		msg *m = &toreceive[i];
		if (m->port != (natl)a)
			continue;
		len = MAX_PAYLOAD;
		if (!receive(a, buf, len)) {
			printf("message %d: receive error\n", i);
			errors++;
			continue;
		}
		buf[len] = '\0';
		//printf("port %d received %d bytes: %s\n", a, len, buf);
		unsigned int j;
		for (j = 0; buf[j] && toreceive[i].p[j] && buf[j] == toreceive[i].p[j]; j++)
			;
		if (buf[j] || toreceive[i].p[j]) {
			printf("message %d: payload error at byte %d\n", i, j);
			printf("   received '%d', expected '%d'\n", buf[j], toreceive[i].p[j]);
			errors++;
			continue;
		}
	}
	if (errors == 0)
		printf("receiver from port %d: no errors\n", a);

	terminate_p();
}
natl bad1;
natl bad2;
natl bad3;
natl bad4;
natl rx1;
natl rx2;
natl rx3;
natl rx4;
natl last;
#line 138 "utente/utente.cpp"

void main()
{
	bad1 = activate_p(bad1_body, 0, 50, LIV_UTENTE);
	bad2 = activate_p(bad2_body, 0, 49, LIV_UTENTE);
	bad3 = activate_p(bad3_body, 0, 48, LIV_UTENTE);
	bad4 = activate_p(bad4_body, 0, 47, LIV_UTENTE);
	rx1 = activate_p(rx_body, 0, 35, LIV_UTENTE);
	rx2 = activate_p(rx_body, 1, 30, LIV_UTENTE);
	rx3 = activate_p(rx_body, 10, 25, LIV_UTENTE);
	rx4 = activate_p(rx_body, 8, 20, LIV_UTENTE);
	last = activate_p(last_body, 0, 10, LIV_UTENTE);

	terminate_p();}
