#line 1 "utente/prog/pce.in"
/*
 * Programma di test 2016-06-15
 */

#include <all.h>

const int MSG_SIZE = 60;
const int NMESG = 1;

extern natl mailbox_piena;
#line 11 "utente/prog/pce.in"
extern natl mailbox_vuota;
#line 13 "utente/prog/pce.in"

#line 14 "utente/prog/pce.in"
extern natl scrittore1;
#line 14 "utente/prog/pce.in"

#line 15 "utente/prog/pce.in"
extern natl scrittore2;
#line 15 "utente/prog/pce.in"

#line 17 "utente/prog/pce.in"
extern natl lettore;
#line 17 "utente/prog/pce.in"
struct mess {
	int mittente;
	char corpo[MSG_SIZE];
};

mess mailbox;

char buf[2][MSG_SIZE * 100];

void pms(natq a)
#line 27 "utente/prog/pce.in"
{
	for (int i = 0; i < MSG_SIZE * 100; i++) {
		buf[a][i] = 'a' + a;
	}
	for (int i = 0; i < NMESG; i++) {
		cedmaread(0, buf[a], MSG_SIZE * 100);
		sem_wait(mailbox_vuota);
		for (int i = 0; i < MSG_SIZE - 1; i++) {
			mailbox.corpo[i] = buf[a][i * 100];
		}
		mailbox.corpo[MSG_SIZE - 1] = '\0';
		mailbox.mittente = a;
		sem_signal(mailbox_piena);
	}
	printf("fine scrittore %d\n", a);

	terminate_p();
}
void pml(natq a)
#line 45 "utente/prog/pce.in"
{
	char corpo[MSG_SIZE];
	int mittente;
	for (int i = 0; i < 2 * NMESG; i++) {
		sem_wait(mailbox_piena);
		mittente = mailbox.mittente;
		copy(mailbox.corpo, corpo);
		sem_signal(mailbox_vuota);
		printf("mittente=%d corpo=%s\n", mittente, corpo);
	}
	printf("fine lettore\n");
	pause();

	terminate_p();
}
natl mailbox_piena;
natl mailbox_vuota;
natl scrittore1;
natl scrittore2;
natl lettore;
#line 79 "utente/utente.cpp"

void main()
{
	mailbox_piena = sem_ini(0);
	mailbox_vuota = sem_ini(1);
	scrittore1 = activate_p(pms, 0, 6, LIV_UTENTE);
	scrittore2 = activate_p(pms, 1, 7, LIV_UTENTE);
	lettore = activate_p(pml, 0, 5, LIV_UTENTE);

	terminate_p();}
