#line 1 "utente/prog/psignal.in"
#include <sys.h>
#include <lib.h>

#define dbg(s, ...) flog(LOG_DEBUG, "TEST %d: " s, test_num, ## __VA_ARGS__)
#define msg(s, ...) printf("TEST %d PROC %d: " s, test_num, getpid(), ## __VA_ARGS__)
#define err(s, ...) msg("ERRORE: " s, ## __VA_ARGS__)
#define errh(s, ...) msg("SIGHND  %d: ERRORE: " s, t, ## __VA_ARGS__)
#define msgh(s, ...) printf("SIGHND %d: TEST %d PROC %d: " s, t, test_num, getpid(), ## __VA_ARGS__)

#define new_proc(tn, pn)\
	t##tn##p##pn = activate_p(t##tn##p##pn##b, test_num, prio--, LIV_UTENTE);

natl end_test; // sync

#define end_test() do {\
error:\
	sem_signal(end_test);\
	terminate_p();\
} while (0)

#define end_handler(rip_) do {\
error:\
	signal_return(rip_);\
} while(0)

#define TCNT(n)	natl t##n##m0; natl t##n##n0;
#define testok(n) do {\
	sem_wait(t##n##m0);\
	t##n##n0++;\
	sem_signal(t##n##m0);\
} while (0)

int test_num;

#define SH(n, m)	t##n##g##m
#define SHRI(n, m)	t##n##g##m##i0
#define SHRF(n, m)	t##n##g##m##i1
#define SHCK(n, m, t, et, e, ee, r, er) do {\
	int ne = 0;\
	if (t != et) {\
		errh("tipo vale %d invece di %d", t, et);\
		ne++;\
	}\
	if (e != ee) {\
		errh("parametro vale %d invece di %d", e, ee);\
		ne++;\
	}\
	if (r != SHRI(n, m)) {\
		errh("rip vale %p invece di %p", r, SHRI(n, m));\
		ne++;\
	}\
	if (ne)\
		goto error;\
} while (0)
#define declsh(n, m, et, ee)\
void SH(n, m)(int t, natq e, natq r) {\
	SHCK(n, m, t, et, e, ee, r, SHRI(n, m));\
	testok(n);\
	end_handler(SHRF(n, m));\
}

///**********************************************************************
// *             test 00: errori vari                                   *
// **********************************************************************/

natl t00p0;
natl t00p1;
natl t00p2;
natl t00p3;
natl t00p4;

void t00g0(int t, natq e, natq r)
{
	static int i = 0;

	if (i) {
		int test_num = 0;
		err("eccezione annidata non ha causato abort");
		terminate_p();
	}
	i++;
	asm volatile("int3" ::: "memory");
	signal_return(r);
}

void t00p0b(int test_num)
{
	signal(40, t00g0);
	err("signal su eccezione non esistente non ha causato abort");
	terminate_p();
}

void t00p1b(int test_num)
{
	signal(-10, t00g0);
	err("signal su eccezione negativa non ha causato abort");
	terminate_p();
}

void t00p2b(int test_num)
{
	signal(2, t00g0);
	err("signal su nmi non ha causato abort");
	terminate_p();
}

void t00p3b(int test_num)
{
	signal_return((natq)t00g0);
	err("signal_return spuria non ha causato abort");
	terminate_p();
}

void t00p4b(int test_num)
{
	signal(3, t00g0);
	asm volatile("int3" ::: "memory");
	terminate_p();
}

///**********************************************************************
// *             test 01: funzionalità minima                           *
// **********************************************************************/

natl t01p0;
natq SHRI(01, 0);
natq SHRF(01, 0);
TCNT(01);

declsh(01, 0, 0, 0);

void t01p0b(int test_num)
{
	(void)&&error;

	int x = 0;
	signal(0, SH(01, 0));

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	movabsq $2f, %%rax\n"
	"	movq %%rax, %1\n"
	"1:	idivl %2\n"
	"2:\n"
	: "=m" (SHRI(01, 0)), "=m" (SHRF(01, 0))
	: "r" (x)
	: "rax", "memory");

	testok(01);
	end_test();
}

/**********************************************************************/

///**********************************************************************
// *             test 02: eccezione senza handler                       *
// **********************************************************************/

natl t02p0;
void t02p0b(int test_num)
{
	int x = 0;

	asm volatile (
	"	idivl %0\n"
	:
	: "r" (x)
	: "memory");

	err("handler non installato, ma processo non abortito");
	terminate_p();
}

///**********************************************************************
// *             test 03: piu' di un handler                            *
// **********************************************************************/

natl t03p0;
natq SHRI(03, 0);
natq SHRF(03, 0);
natq SHRI(03, 1);
natq SHRF(03, 1);
TCNT(03);

declsh(03, 0, 3, 0);
declsh(03, 1, 13, 34);

void t03p0b(int test_num)
{
	(void)&&error;

	signal(3, SH(03, 0));
	signal(13, SH(03, 1));

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	movq %%rax, %1\n"
	"	int3\n"
	"1:\n"
	: "=m" (SHRI(03, 0)), "=m" (SHRF(03, 0))
	:
	: "rax", "memory");

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	movabsq $2f, %%rax\n"
	"	movq %%rax, %1\n"
	"1:	int $2\n"
	"2:\n"
	: "=m" (SHRI(03, 1)), "=m" (SHRF(03, 1))
	:
	: "rax", "memory");

	testok(03);
	end_test();
}

///**********************************************************************
// *             test 04: salvataggio del contesto                      *
// **********************************************************************/

natl t04p0;
natq SHRI(04, 0);
natq SHRF(04, 0);
TCNT(04);

declsh(04, 0, 0, 0);

void t04p0b(int test_num)
{
	int x = 0;
	signal(0, SH(04, 0));

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	movabsq $2f, %%rax\n"
	"	movq %%rax, %1\n"
	: "=m" (SHRI(04, 0)), "=m" (SHRF(04, 0))
	: 
	: "rax");

	asm goto (
	"	movl $0xdeadbeef, %%edi\n"
	"1:	idivl %0\n"
	"2:	cmpl $0xdeadbeef, %%edi\n"
	"	jne %l1\n"
	:
	: "r" (x)
	: "rdi", "memory"
	: error2);

	testok(04);
	end_test();

error2:
	err("il contenuto di rdi e' cambiato dopo l'eccezione");
	goto error;
}

///**********************************************************************
// *             test 05: riesecuzione dopo il fault                    *
// **********************************************************************/

natl t05p0;
natq SHRI(05, 0);
TCNT(05);

natl t05v0 = 0;

void t05g0(int t, natq e, natq r)
{
	SHCK(05, 0, t, 0, e, 0, r, SHRI(05, 0));

	t05v0 = 1;

	testok(05);
	end_handler(r);
}

void t05p0b(int test_num)
{
	(void)&&error;

	signal(0, t05g0);

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	xorl %%edx, %%edx\n"
	"	movq $1, %%rax\n"
	"1:	divl %1\n"
	: "=m" (SHRI(05, 0))
	: "m" (t05v0)
	: "rax", "rdx", "memory");

	testok(05);
	end_test();
}

///**********************************************************************
// *             test 06: page fault                                    *
// **********************************************************************/

natl t06p0;
natq SHRI(06, 0);
natq SHRF(06, 0);
TCNT(06);

declsh(06, 0, 14, 1023);

void t06p0b(int test_num)
{
	(void)&&error;

	signal(14, SH(06, 0));

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	movabsq $2f, %%rax\n"
	"	movq %%rax, %1\n"
	"1:	movl $0, 1023\n"
	"2:\n"
	: "=m" (SHRI(06, 0)), "=m" (SHRF(06, 0))
	:
	: "rax", "memory");

	testok(06);
	end_test();
}

///**********************************************************************
// *             test 07: page fault senza handler                      *
// **********************************************************************/

natl t07p0;
void t07p0b(int test_num)
{
	asm volatile ("movl $0, 1023" ::: "memory");
	err("handler del page fault non installato, ma processo non abortito");
	terminate_p();
}

///**********************************************************************
// *             test 08: piu' processi                                 *
// **********************************************************************/

natl t08s0;
natl t08p0;
natq SHRI(08, 0);
natl t08v0 = 0;

natl t08p1;
natq SHRI(08, 1);
natl t08v1 = 0;

TCNT(08);

void t08g0(int t, natq e, natq r)
{
	SHCK(08, 0, t, 0, e, 0, r, SHRI(08, 0));

	t08v0 = 1;

	testok(08);
	sem_signal(end_test);
	end_handler(r);
}

void t08p0b(int test_num)
{
	(void)&&error;

	signal(0, t08g0);

	sem_wait(t08s0);

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	xorl %%edx, %%edx\n"
	"	movq $1, %%rax\n"
	"1:	divl %1\n"
	: "=m" (SHRI(08, 0))
	: "m" (t08v0)
	: "rax", "rdx", "memory");

	testok(08);
	end_test();
}

void t08g1(int t, natq e, natq r)
{
	sem_signal(t08s0);

	SHCK(08, 1, t, 0, e, 0, r, SHRI(08, 1));

	t08v1 = 1;

	testok(08);
	sem_signal(end_test);
	end_handler(r);
}

void t08p1b(int test_num)
{
	(void)&&error;

	signal(0, t08g1);

	asm volatile (
	"	movabsq $1f, %%rax\n"
	"	movq %%rax, %0\n"
	"	xorl %%edx, %%edx\n"
	"	movq $1, %%rax\n"
	"1:	divl %1\n"
	: "=m" (SHRI(08, 1))
	: "m" (t08v1)
	: "rax", "rdx", "memory");

	testok(08);
	end_test();
}

/**********************************************************************/


#line 433 "utente/prog/psignal.in"
void main_body(int id)
#line 434 "utente/prog/psignal.in"
{
	natl prio = 600;

	end_test = sem_ini(0);

	test_num = 0;
	dbg(">>>INIZIO<<<: errori vari");
	new_proc(00, 0);
	delay(1);
	new_proc(00, 1);
	delay(1);
	new_proc(00, 2);
	delay(1);
	new_proc(00, 3);
	delay(1);
	new_proc(00, 4);
	delay(1);
	dbg("=== FINE ===");

	test_num = 1;
	dbg(">>>INIZIO<<<: funzionalita' minima");
	t01m0 = sem_ini(1);
	new_proc(01, 0);
	sem_wait(end_test);
	if (t01n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 2;
	dbg(">>>INIZIO<<<: eccezione senza handler");
	new_proc(02,0);
	delay(1);
	delay(1);
	dbg("=== FINE ===");

	test_num = 3;
	dbg(">>>INIZIO<<<: piu' di un handler");
	t03m0 = sem_ini(1);
	new_proc(03, 0);
	sem_wait(end_test);
	if (t03n0 == 3) msg("OK");
	dbg("=== FINE ===");

	test_num = 4;
	dbg(">>>INIZIO<<<: salvataggio del contesto");
	t04m0 = sem_ini(1);
	new_proc(04, 0);
	sem_wait(end_test);
	if (t04n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 5;
	dbg(">>>INIZIO<<<: riesecuzione dopo il fault");
	t05m0 = sem_ini(1);
	new_proc(05, 0);
	sem_wait(end_test);
	if (t05n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 6;
	dbg(">>>INIZIO<<<: page fault");
	t06m0 = sem_ini(1);
	new_proc(06, 0);
	sem_wait(end_test);
	if (t06n0 == 2) msg("OK");
	dbg("=== FINE ===");

	test_num = 7;
	dbg(">>>INIZIO<<<: page fault senza handler");
	new_proc(07,0);
	delay(1);
	delay(1);
	dbg("=== FINE ===");

	test_num = 8;
	dbg(">>>INIZIO<<<: piu' processi");
	t08s0 = sem_ini(0);
	t08m0 = sem_ini(1);
	new_proc(08, 0);
	new_proc(08, 1);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	sem_wait(end_test);
	if (t08n0 == 4) msg("OK");
	dbg("=== FINE ===");

	pause();

	terminate_p();
}
short mainp;
#line 528 "utente/utente.cpp"

int main()
{
	mainp = activate_p(main_body, 0, 900, LIV_UTENTE);

	terminate_p();
}
