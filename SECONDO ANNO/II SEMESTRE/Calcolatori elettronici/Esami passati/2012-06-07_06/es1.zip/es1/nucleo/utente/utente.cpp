#line 1 "utente/prog/psend.in"
#include <all.h>

const int N_SENDERS = 4;
const int N_RECEIVERS = 2;
const int NPROC = N_SENDERS + N_RECEIVERS;


#line 8 "utente/prog/psend.in"
extern natl m1;
#line 8 "utente/prog/psend.in"
natl finish[NPROC];

struct conf {
	natl dest;
	natl msg;
};

conf config[N_SENDERS];

void sender(natq a)
{
	printf("%d: invio %d a %d\n", a, config[a].msg, config[a].dest);
	if (send(config[a].dest, config[a].msg))
		printf("%d: invio riuscito\n", a);
	else
		printf("%d: invio fallito\n", a);
	sem_signal(finish[a]);
	terminate_p();
}

void receiver(natq a)
{
	natl m = receive();
	printf("%d: ricevuto %d\n", getpid(), m);
	sem_signal(finish[a]);
	terminate_p();
}

void mio_main(natq a)
#line 37 "utente/prog/psend.in"
{
	for (int i = 0; i < NPROC; i++)
		finish[i] = sem_ini(0);

	natl r1 = activate_p(receiver, 4, 50, LIV_UTENTE);
	config[0].dest = r1;
	config[0].msg  = 1234;
	config[1].dest = r1;
	config[1].msg  = 4321;
	(void) activate_p(sender, 0, 45, LIV_UTENTE);
	(void) activate_p(sender, 1, 30, LIV_UTENTE);

	natl r2 = activate_p(receiver, 5, 32, LIV_UTENTE);
	config[2].dest = r2;
	config[2].msg  = 555;
	config[3].dest = r2;
	config[3].msg  = 333;
	(void) activate_p(sender, 2, 43, LIV_UTENTE);
	(void) activate_p(sender, 3, 42, LIV_UTENTE);

	for (int i = 0; i < NPROC; i++)
		sem_wait(finish[i]);
	pause();

	terminate_p();
}
natl m1;
#line 70 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
