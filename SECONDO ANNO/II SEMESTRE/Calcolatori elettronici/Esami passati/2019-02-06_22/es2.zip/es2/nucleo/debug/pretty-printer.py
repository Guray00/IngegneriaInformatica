import gdb
import gdb.printing

class proc_elemPrinter:
    """Print a proc_elem list"""

    def __init__(self, val):
        proc_elemType = gdb.lookup_type('proc_elem')
        self.val = (val.address if val.type == proc_elemType else val)

    def to_string(self):
        elems, p = [], self.val
        while p != gdb.Value(0):
            elem = p.dereference()
            elems.append("<" + str(elem['id']) + ", " + str(elem['precedenza']) + ">")
            p = elem['puntatore']
        return '[{}]'.format('; '.join(elems))

def proc_elemLookup(val):
    proc_elemType = gdb.lookup_type('proc_elem')
    proc_elem_p = gdb.Type.pointer(proc_elemType)
    if val.type in (proc_elemType, proc_elem_p):
        return proc_elemPrinter(val)
    else:
        return None

gdb.pretty_printers.append(proc_elemLookup)
