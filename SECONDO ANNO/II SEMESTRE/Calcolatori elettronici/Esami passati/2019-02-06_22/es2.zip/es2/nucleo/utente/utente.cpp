#line 1 "utente/prog/preceive.in"
#include <sys.h>
#include <lib.h>

static const int MAX_PAYLOAD = 2048;
static const int HDR_SZ = 2*sizeof(natl);
static const int MAX_MSGSZ = MAX_PAYLOAD + HDR_SZ;

struct msg {
	natl s;
	const char *p;
};

#define MSG(src, dst, payload) { src, payload },

msg toreceive[] = {
#include "messages"
};


#line 20 "utente/prog/preceive.in"

#line 21 "utente/prog/preceive.in"

#line 23 "utente/prog/preceive.in"
void bad2_body(int a)
#line 24 "utente/prog/preceive.in"
{
	natq len = waitnet();
	receive((char *)0x200000, len);
	printf("processo errato 2");

	terminate_p();
}
void bad5_body(int a)
#line 31 "utente/prog/preceive.in"
{
	receive((char *)(0UL-4), 8);
	printf("processo errato 5");

	terminate_p();
}
void hello_body(int a)
#line 37 "utente/prog/preceive.in"
{
	char magic[] = { 'A', 'B', 'C', 'D' };
	char* buf = (char *)mem_alloc(MAX_MSGSZ + sizeof(magic));
	memset(buf, 0, MAX_MSGSZ + sizeof(magic));
	natq len;
	int errors = 0;
	for (unsigned i = 0; i < sizeof(toreceive)/sizeof(msg); i++) {
		unsigned int j;
		memcpy(buf + MAX_MSGSZ, magic, sizeof(magic));
		natq explen = strlen(toreceive[i].p);
		len = waitnet();
		receive(buf, len < MAX_MSGSZ ? len : MAX_MSGSZ);
		if (len < HDR_SZ) {
			printf("message %d too short (len %d)", len);
			errors++;
			continue;
		}
		//printf("message %d len %d", i, len);
		for (j = 0; j < sizeof(magic); j++) {
			if (buf[MAX_MSGSZ + j] != magic[j]) {
				printf("message %d: write after the end of the buffer", i);
				errors++;
				break;
			}
		}
		buf += HDR_SZ;
		len -= HDR_SZ;
		if (len != explen) {
			printf("message %d: len is %d instead of the expected %d", i, len, explen);
			errors++;
			continue;
		}
		buf[len <= MAX_PAYLOAD ? len : MAX_PAYLOAD] = '\0';
		for (j = 0; buf[j] && toreceive[i].p[j] && buf[j] == toreceive[i].p[j]; j++)
			;
		if (buf[j]) {
			if (toreceive[i].p[j]) {
				printf("message %d: payload error at byte %d", i, j);
				printf("   received '%d', expected '%d'", buf[j], toreceive[i].p[j]);
				errors++;
				continue;
			} else {
				printf("message %d: payload error at byte %d", i, j);
				printf("   received '%s' beyond expected end of message", buf + j);
				errors++;
				continue;
			}
		} else if (toreceive[i].p[j] && explen <= MAX_PAYLOAD) {
			printf("message %d: unexpected null byte at %d", i, j);
			errors++;
			continue;
		}
	}
	if (errors == 0)
		printf("receiver: no errors");
	pause();

	terminate_p();
}
short hello;
short bad2;
short bad5;
#line 108 "utente/utente.cpp"

int main()
{
	hello = activate_p(hello_body, 0, 20, LIV_UTENTE);
	bad2 = activate_p(bad2_body, 0, 49, LIV_UTENTE);
	bad5 = activate_p(bad5_body, 0, 46, LIV_UTENTE);

	terminate_p();
}
