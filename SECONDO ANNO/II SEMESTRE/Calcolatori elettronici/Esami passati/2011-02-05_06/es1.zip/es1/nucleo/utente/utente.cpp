#line 1 "utente/prog/prw.in"
/*
 * Lettori scrittori
 */

#include <all.h>

const int DATA_DIM = 10;
const int N_READERS = 10;
const int N_WRITERS = 2;
const int N_PROC = N_READERS + N_WRITERS;
int data[DATA_DIM];
natl mio_rw;


#line 16 "utente/prog/prw.in"
extern natl m1;
#line 16 "utente/prog/prw.in"
natl finish[N_PROC];


void mio_reader(natq a)
{
	delay(8*a+1);
	rw_acq_read(mio_rw);
	int sum = 0;
	for (int i = 0; i < DATA_DIM; i++) {
		sum += data[i];
		delay(1);
	}
	rw_rel_read(mio_rw);
	if (sum % DATA_DIM == 0) {
		printf("Lettore %d: OK\n", a);
	} else {
		printf("Lettore %d: ERRORE\n", a);
	}
	sem_signal(finish[a]);
	terminate_p();
}

void mio_writer(natq a)
{
	rw_acq_write(mio_rw);
	for (int i = 0; i < DATA_DIM; i++) {
		data[i]++;
		delay(1);
	}
	rw_rel_write(mio_rw);
	printf("Scrittore %d: terminato\n", a);
	sem_signal(finish[a]);
	terminate_p();
}

void mio_main(natq a)
#line 52 "utente/prog/prw.in"
{
	mio_rw = rw_init();
	for (int i = 0; i < N_PROC; i++)
		finish[i] = sem_ini(0);
	int i = 0;
	for ( ; i < N_READERS; i++) {
		activate_p(mio_reader, i, 20, LIV_UTENTE);
	}
	for ( ; i < N_PROC; i++) {
		activate_p(mio_writer, i, 20, LIV_UTENTE);
	}
	for (i = 0; i < N_PROC; i++)
		sem_wait(finish[i]);
	pause();

	terminate_p();
}
natl m1;
#line 75 "utente/utente.cpp"

void main()
{
	m1 = activate_p(mio_main, 0, 100, LIV_UTENTE);

	terminate_p();}
