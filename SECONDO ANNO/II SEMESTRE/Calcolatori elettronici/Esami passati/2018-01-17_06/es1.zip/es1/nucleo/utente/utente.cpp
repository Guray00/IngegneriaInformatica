#line 1 "utente/prog/pkill.in"
#include <all.h>


#line 5 "utente/prog/pkill.in"
extern natl psp;
#line 5 "utente/prog/pkill.in"
extern natl sem0;
#line 6 "utente/prog/pkill.in"
extern natl sem1;
#line 7 "utente/prog/pkill.in"
extern natl sem2;
#line 8 "utente/prog/pkill.in"
extern natl sem3;
#line 9 "utente/prog/pkill.in"
extern natl semlast;
#line 11 "utente/prog/pkill.in"
natq get_memlibera()
{
	return getmeminfo().heap_libero;
}

const int NPROC = 9;
natl proc[NPROC];
int nextproc = 0;
natl nextprio = 80;
natq mem1, mem2;

void ckill(natl id)
{
	if (!kill(id)) {
		printf("kill %d fallita\n", id);
	}
}

void addproc(void (*f)(natq), natq a)
{
	proc[nextproc] = activate_p(f, a, nextprio, LIV_UTENTE);
	//flog(LOG_INFO, "addproc: %d => %p(%d)", nextproc, f, a);
	nextproc++;
	nextprio -= 5;
}

void p0(natq a)
{
	printf("p0 start\n");
	sem_wait(sem0);
	printf("p0 end\n");
	terminate_p();
}

void p1(natq a)
{
	printf("p1 start\n");
	sem_signal(semlast);
	sem_wait(sem1);
	printf("p1 end\n");
	terminate_p();
}

void perr(natq a)
{
	ckill(0);
	ckill(proc[0]);
	printf("perror\n");
	terminate_p();
}

void p2(natq a)
{
	printf("p2 start\n");
	addproc(p1, 0);
	addproc(perr, 0);
	sem_wait(sem2);
	sem_signal(sem3);
	ckill(proc[a]);
	printf("p2 end\n");
	terminate_p();
}

void p3(natq a)
{
	printf("p3 start\n");
	addproc(p2, 0);
	sem_wait(sem3);
	ckill(proc[3]);
	ckill(proc[4]);
	printf("p3 end\n");
	terminate_p();
}

void p5(natq a)
{
	printf("p5 start\n");
	ckill(proc[2]);
	printf("p5 end\n");
	terminate_p();
}

void last(natq a)
{
	sem_wait(semlast);
	sem_signal(sem2);
	sem_signal(sem0);
	sem_signal(sem1);
	mem2 = get_memlibera();
	if (mem2 != mem1)
		printf("memoria non liberata: %dB\n", mem1 - mem2);
	pause();
	terminate_p();
}


void psp_body(natq a)
#line 108 "utente/prog/pkill.in"
{
	activate_p(last, 0, 5, LIV_UTENTE);
	mem1 = get_memlibera() + 168;
	addproc(p0, 0);
	addproc(p3, 0);
	addproc(p5, 0);

	terminate_p();
}
natl psp;
natl sem0;
natl sem1;
natl sem2;
natl sem3;
natl semlast;
#line 132 "utente/utente.cpp"

void main()
{
	psp = activate_p(psp_body, 0, 100, LIV_UTENTE);
	sem0 = sem_ini(0);
	sem1 = sem_ini(0);
	sem2 = sem_ini(0);
	sem3 = sem_ini(0);
	semlast = sem_ini(0);

	terminate_p();}
